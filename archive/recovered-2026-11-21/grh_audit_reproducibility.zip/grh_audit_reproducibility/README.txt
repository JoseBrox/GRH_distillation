CONTINUED AUDIT AND CONVENTIONAL RECONSTRUCTION
21 November 2026

Start with grh_audit.pdf and grh_reconstruction.pdf. Their complete,
self-contained TeX sources are in the same directory. Compile with
XeLaTeX until cross-references are stable (normally two or three passes).
There is no external bibliography database or required source include.

STATUS
No fatal flaw in Alpoge's submitted proof was established. The complete
published export was inventoried locally and the five statements with
their transitive definitions were compared with the canonical challenge.
Only propext, Classical.choice and Quot.sound occur as axioms in the
solution export. No local complete proof-kernel replay was conducted.
Andrew Sutherland's primary report supplies the separate, external
evidence of complete nanoda acceptance. Its published log is included;
the log does not itself authenticate the input hash or checker binary.
The inventory and comparison programs are reproducible software, not
formally verified kernels.

The reconstruction is explicitly INCOMPLETE as a proof of GRH. This
continuation adds full ordinary proofs of simultaneous finite-family
quadratic selection under explicit QRH, cyclotomic descent and common
intervals, compatibility
of the scale choices, polynomial coefficient duality by Gaussian
elimination, the finite-group dual exponent and quotient divisor formula,
and the complete local theta germ and positive-majorant induction.
The arithmetic complex is constructed in full, with exactness, stabilizers
and the required orbit estimate. This makes the arithmetic homology
torsion bound unconditional. The unit and ideal-class comparison, strict
Selmer descent, degree-one-prime detection, cyclic homology relation,
determinant-prescribed ideal-lattice isomorphisms and integral character
interpolation are proved. A separate argument from explicitly stated
classical algebraic K-theory and cohomology theorems now proves the
coarse H2 bound, with exponent14. The original finite-field transfer
functionals, arithmetic cycles, odd-degree rank bound, and finite-set
count are now also proved, closing the original coarse Selmer route
with its explicitly stated classical inputs.

The actual coefficient-map estimates, initial decorated lattice, exact
degree, stabilizers, short dual vectors, and finite decorated class set
are also proved. Rational integral cuts are shown to commute with
field extension. The global ideal sum is strengthened; exact period
covolumes and Poisson normalization, including the prime2, are proved.
The archimedean spectral and width calculations are proved from
explicit mass, dimension, and formal-degree inputs, with a sharper
boundary constant80. Integral initial-minor spanning, compact branching,
and the exactly normalized integral branching maps are proved. These
give the actual lowering maps for every auxiliary character. Adelic
class coordinates, the extra coset partition, and the initial class
period bound are also proved with stabilizer weights retained.
The archimedean coefficient identities and separated interpolation
sets are proved, as are terminal radial positivity and the actual
finite orthogonal decomposition. The noncompact radial integration is
proved under the precise weighted Fourier-decay hypothesis.
The exact Fock normalizer is proved to be the hook product; this
establishes the required local equality of coefficient lattices.
Primitive unitary densities and their dyadic lifting are proved, and
the exact source mass ratio follows from the stated classical global
mass formula. The dimension and formal degree are now proved with the
source's exact Haar normalization and the stated classical discrete-series
inputs. All four radial differential lifts, the spectral inverse, terminal
quantum determinant and terminal commutation relations are proved.
The ordinary theta normalization, nonprincipal ideal bases, local
standardization and exact arithmetic equivariance are proved. The local
hyperbolic argument includes dyadic places and retains the determinant
character. The ordinary integrality input is used for split primes at
least five, which includes the selected primes.
The full opposite-parity strict Selmer estimate is proved by a shorter
classical special-value argument, including primes dividing the field
degree; the stated classical duality and special-value theorems are
explicit imports. The lowest compact-type coefficient formula and the
distant rational-orbit estimate are proved. The Jacquet coordinate
integrals have exact values and convergence conditions, and their
weighted unipotent induction is proved with the actual character.
The full-group majorant, geometric integration formula, regularized
Jacquet pairing and adjointness are proved with their actual hypotheses.
The automorphic projection kernel, rare cusp-volume bound and integrated
near-unipotent estimate are proved. Higher-dimensional ordinary moments
and both theta-column supports retain the exact p^(-fa) factor.
The deep-cusp estimate completes the ambient multiplicity comparison.
The exact weighted Hecke incidence and finite coefficient field combine
with the polynomial jet identity to give the selected-prime column bound.
Three complementary-parity cases have direct proofs. The integral
whole-field character comparison has an explicit polynomial torsion error;
the rational adjoint-vanishing implication is matched to Thorne's theorem.
The actual recursive radial frame, the four group lifts, their analytic
adjoints and the rapid Fourier decay of the Jacquet transforms are proved.
Compact lower-rank families give pointwise smooth marginal densities and
terminal compactness. Degenerate off-diagonal vanishing, exact projected
Gram negative moments, sharper orbital volumes and stronger dyadic
summation are also proved.
The full initial radial matrix and its restriction chain, the remaining
orbital energy inputs, auxiliary-level-prime bounds, automorphic character
length estimates and final assembly remain incomplete.
The shorter mean-square alternative is also unproved.
Counterexamples to invalid simplifications are not mislabeled as
counterexamples to the submitted theorems.

CONTENTS
source_archive/: source hashes, safe downloader, import graph and exact
  finite Behrend/cyclotomic controls from the first audit.
formal_export/: complete export inventory, transitive definition
  comparison, small controls, program sources, primary verification
  records and the detailed EXPORTED_PROOF_AUDIT.md reproduction guide.
mathematics/: exact finite computations and source-by-source read coverage
  for the cohomological, integral, theta, QRH and real-zero reviews.
mathematics/continuation_20261121/: the new conventional proof sections,
  exact source hashes and read scope, independent mathematical reviews,
  and reproducible prime-sum, coefficient-lattice and local theta controls.

REPRODUCE THE FORMAL EXPORT CHECKS
Read formal_export/EXPORTED_PROOF_AUDIT.md first. Download the two public
compressed inputs into formal_export/exports/ and check all recorded
SHA-256 hashes. The solution is about 7.7 GB compressed and 61.6 GB raw.
It can be streamed; the comparison indices require about 18 GB of disk.
C++17, nlohmann/json (the licensed single header is supplied), OpenSSL
development libraries, zstd and Python 3 are needed. Compile the three
programs as specified in that guide; run the small positive/negative
controls, then the full inventory and comparison. The successful
comparison includes non-target theorem bodies and deliberately excludes
the five root proof bodies. Changing only a root proof is an accepted
control, documenting that this is not a proof checker.

REPRODUCE THE EXACT MATHEMATICAL CHECKS
Run the Python scripts from their own directories. The integer and
polynomial checks use exact arithmetic. The path-basis, coefficient-lattice
and local theta scripts need SymPy; the prime-sum certificate uses only
the Python standard library and rational arithmetic.
The class-number residue sieve is compiled from its C++17 source.
These computations test precisely the finite cases in the recorded JSON;
they are not substitutes for the general proofs in the documents.
The updated even Selmer example checks N=93548048, with auxiliary primes
11 and 263 and the required congruence 11 | 263+1.
The new coefficient tests compute a saturated integral equation kernel
and a divided-row-operator lattice independently, then check the exact
normalized pairing. Their finite scope is stated in the JSON output.
The bordered-kernel controls enumerate actual finite module maps and
compare them with the independently evaluated finite-duality formula;
28 kernel comparisons and eight exact Parseval totals are checked.
The scalar-germ controls verify four symbolic Hessenberg identities and
five rational p-adic valuation cases. None replaces the general proofs.
The new global-lattice script records41 exact controls. The
archimedean-size script records10124 exact finite identities and
inequalities, including binary Vandermonde coefficients, polynomial
factorizations, mass exponents, and normalized widths. The Gaussian
transference constants are certified by rational inequalities. None
of these finite tests is a substitute for the general proofs.

PROVENANCE AND EXCLUSIONS
The original archive, public compressed proof inputs, generated indices,
toolchain binaries, copyrighted source papers and account/session data
are not included. Their URLs and hashes are recorded where used.
Saved build and audit records retain their actual scope and timestamps;
an intentionally terminated build is not a compiler rejection. The source
papers' unsolved steps are distinguished from our unfinished reading.

bundle_manifest.json lists the exact included files and SHA-256 hashes.
