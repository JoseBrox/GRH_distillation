import Formalism.LocalToGlobal.NumberFieldFamilies.OwnStruct

/- External audit controls. Accepted positive cases precede deliberately invalid
   terms. These terms are not declarations from the submitted archive. -/
set_option Elab.async false

namespace Formalism.DependentProjectionAudit

structure Tagged (n : Nat) where
  value : Fin n

structure Nested (n : Nat) where
  inner : Tagged n

def positive_tagged : Tagged 1 := by
  kcopy (Tagged.mk (0 : Fin 1))

def positive_nested : Nested 1 := by
  kcopy (Nested.mk (Tagged.mk (0 : Fin 1)))

def invalid_index_transport : Tagged 0 := by
  kcopy (Tagged.mk (0 : Fin 1))

def invalid_nested_index_transport : Nested 0 := by
  kcopy (Nested.mk (Tagged.mk (0 : Fin 1)))

theorem invalid_domain_transport : Unit → False := by
  kcopy (fun x : False => x)

end Formalism.DependentProjectionAudit

open Lean Elab Tactic Term in
elab "audit_raw_projection " t:term : tactic => withMainContext do
  let goal ← getMainGoal
  let source ← Term.elabTermAndSynthesize t none
  goal.assign (.proj ``And 0 source)

/- This bypasses the helper's inferType, exposing the final declaration check
   directly to a projection whose structure name does not match its argument. -/
theorem invalid_raw_projection : False := by
  audit_raw_projection True.intro
