import Formalism.LocalToGlobal.NumberFieldFamilies.OwnStruct
import Statements
import Formalism.BehrendSets.Statement
import Formalism.SizeWindowBrackets.RealSlopeBoundsSplit
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.SemiabelianSchemes.SplitTori.SplitTorusAff
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.HeightTheory.RegLaw
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.Signature
import Formalism.SharpRestriction.GrowthBounds.ObjPol
import Formalism.SharpRestriction.Divisibility.AbelianOpenPart.AbelianAt
import Formalism.SizeWindowBrackets.ChainSlopeWindows.WeightedMeanLemmaNeedsDegree
import ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.SemiabelianSchemes.AbelianSchemeQuotients.IsAbelianScheme

/- External audit only. Unlike Lean.collectAxioms, the traversal below does not
   consult imported modules' cached axiom metadata. It follows the actual
   constant types and bodies available in the checked kernel environment.
   This is a dependency inspection, not an independent kernel replay. -/
namespace IndependentAxiomTraversal
open Lean

structure Result where
  seen : NameSet := {}
  axioms : NameSet := {}
  missing : NameSet := {}
  deriving Inhabited

partial def visit (env : Environment) (names : Array Name) : StateM Result Unit := do
  for name in names do
    if (← get).seen.contains name then continue
    modify fun s => { s with seen := s.seen.insert name }
    match env.checked.get.find? name with
    | none => modify fun s => { s with missing := s.missing.insert name }
    | some info =>
      visit env info.type.getUsedConstants
      if let some value := info.value? (allowOpaque := true) then
        visit env value.getUsedConstants
      match info with
      | .axiomInfo _ => modify fun s => { s with axioms := s.axioms.insert name }
      | .inductInfo v => visit env (v.all.toArray ++ v.ctors.toArray)
      | .ctorInfo v => visit env #[v.induct]
      | .recInfo v =>
        visit env v.all.toArray
        for rule in v.rules do
          visit env #[rule.ctor]
          visit env rule.rhs.getUsedConstants
      | _ => pure ()

open Elab Command in
run_cmd do
  let selected : List Name := [
    `Formalism.LocalToGlobal.NumberFieldFamilies.OwnStruct,
    `Statements,
    `Formalism.BehrendSets.Statement,
    `Formalism.SizeWindowBrackets.RealSlopeBoundsSplit,
    `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.SemiabelianSchemes.SplitTori.SplitTorusAff,
    `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.HeightTheory.RegLaw,
    `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.FundamentalDomains.Signature,
    `Formalism.SharpRestriction.GrowthBounds.ObjPol,
    `Formalism.SharpRestriction.Divisibility.AbelianOpenPart.AbelianAt,
    `Formalism.SizeWindowBrackets.ChainSlopeWindows.WeightedMeanLemmaNeedsDegree,
    `ReciprocityTheory.ReductiveGroups.ArithmeticGeometry.SemiabelianSchemes.AbelianSchemeQuotients.IsAbelianScheme]
  let env := (← getEnv).setExporting false
  let modules := env.header.moduleNames
  let mut roots : Array Name := #[]
  for index in [:env.header.moduleData.size] do
    unless selected.contains modules[index]! do continue
    roots := roots ++ env.header.moduleData[index]!.constNames
  let (_, result) := (visit env roots).run {}
  logInfo m!"DIRECT_AUDIT | roots={roots.size} | visited={result.seen.toArray.size}"
  logInfo m!"DIRECT_AXIOMS | {result.axioms.toArray.qsort Name.lt}"
  logInfo m!"DIRECT_MISSING | {result.missing.toArray.qsort Name.lt}"

end IndependentAxiomTraversal
