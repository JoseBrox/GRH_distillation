# Export audit methodology

This directory contains a local byte and declaration-metadata inventory of the exact public proof export. It is not a replacement implementation of Lean's kernel and does not claim to type-check proof terms.

## Inputs

- Published proof export: https://math.mit.edu/~drew/grh/solution.ndjson.zst
- Compressed SHA-256: `61a8938ad5f5e57397c1c0e3b954916af546d9004ade01c3555744a681b05381`
- Expected uncompressed SHA-256: `5ea74b912147c5c93cc2b6d70cc727cf908df2f62ac6a20480a3fa02f6be244e`
- Canonical challenge: https://math.mit.edu/~drew/grh/challenge.ndjson.zst
- Canonical challenge uncompressed SHA-256: `bd484ac9886a96f26b1d9a7a59ebd45b7a70d102c015d4f31f9302bbdd6ab2b9`

The two downloaded compressed artifacts are in `exports/`; the download manifest records exact hashes, byte counts, URLs and dates. The large artifacts should not be included in a small evidence bundle: obtain them from the public source and verify the hashes.

## Inventory

`export_scanner.cpp` scans every line and computes the uncompressed SHA-256 with OpenSSL EVP. It records names, declarations, all axiom records, unsafe and partial declarations, duplicate declaration names, unknown top-level record forms, and the five final theorem declarations and their immediate type constants. It uses nlohmann/json version 3.11.3 for names and declaration records. Expression and universe-level payloads are not type-checked or fully semantically validated. A fast path recognizes only the exact canonical JSON syntax of an application record; other records use a top-level key scanner. This cannot authenticate the mathematical meaning of a definition merely from its name.

Build:

```sh
g++ -std=c++17 -O3 -I export_scan_include export_scanner.cpp -lcrypto -o export_scanner
```

Run from this directory:

```sh
set -o pipefail
zstd -dc --long=30 exports/solution.ndjson.zst | ./export_scanner 5ea74b912147c5c93cc2b6d70cc727cf908df2f62ac6a20480a3fa02f6be244e solution_inventory.json
zstd -dc --long=27 exports/challenge.ndjson.zst | ./export_scanner bd484ac9886a96f26b1d9a7a59ebd45b7a70d102c015d4f31f9302bbdd6ab2b9 challenge_inventory.json
```

Successful process exit means that the recorded inventory finished and the byte hash matched. It does not mean that the file is a valid proof; the JSON output must also be inspected for its axiom/safety findings. Test fixtures in `export_scan_tests/` deliberately include a forbidden axiom, an unsafe definition, changed key order, missing final newline, hidden declaration, unknown record and repeated name ID. The first four remain valid inventories, with the deliberately introduced problems recorded; the last three are rejected. The optimized parser was checked against the original parser on the entire canonical challenge and produced the identical inventory, apart from elapsed time.

## External kernel evidence

`mit_verified/` archives Sutherland's public page, the public axiom audit source and log, nanoda timing/exit log, comparator configuration, checksum list, and complete compiled-file manifest. These are primary reports from an independent verifier. They are not logs of a kernel execution conducted in this workspace. The page reports full compilation, all-module Lean kernel replay and acceptance of the full proof export by independent Rust kernel nanoda. The page explicitly reports that the build/export was unsandboxed and the canonical comparator run remained in progress as of its last update at 19:45 UTC on 2026-11-20.

The all-environment axiom census contains 15 declarations supplied by Lean core, including compiler-support axioms and `sorryAx`. The relevant logical question is which axioms occur in the transitive dependencies of the five target proofs. The public target-specific audit reports only `propext`, `Classical.choice`, and `Quot.sound`. The full proof export inventory independently examines every axiom actually present in that exported proof. The challenge intentionally contains `sorryAx`, because it supplies statements with placeholder proofs.

The local compiled-module comparison checks 31 available archive modules against the published 175,187-entry manifest. It found 25 exact matches and 6 differing hashes. It does not establish complete byte reproduction. A differing binary hash alone does not establish a different proposition or an invalid proof; full proof replay and canonical comparison are the relevant semantic checks.

## Transitive statement comparison

`export_index.cpp` builds a compact read-only index of the two exports. It writes one 16-byte record per expression, universe level and name component, separate variable-length strings and universe arguments, and the declaration records. It rejects nonconsecutive IDs and numbers outside its explicitly bounded index representation. It stops if free disk falls below 6 GB. The index is an intermediate representation for comparison, not a kernel environment.

`compare_export_indices.cpp` starts from the five target declarations and compares their types, the bodies of every definition and opaque constant reached, their constant dependencies, inductive and constructor declarations, recursor rules and universe levels. Names are compared by exact component sequences (string components and numerical components remain distinct), not by their pretty-printed spelling or by a cryptographic hash. The comparison preserves bound-variable indices, binder information, projections, universe arguments and literal values. It ignores only binder names, expression annotations, and reducibility hints, which do not change the mathematical expression.

The default comparison also compares every reached *non-target* theorem body. It deliberately does not compare the five target proof bodies: the challenge has placeholder proofs, whereas the solution is supposed to supply them. Optional `types-only` mode compares the types of all theorems but skips their proof bodies; this mode is reported separately. The default run is therefore stronger than merely comparing named definitions or theorem signatures.

The comparison does not prove that the five supplied proof bodies inhabit their stated types. That is the kernel check reported by the external verifier. One negative-control fixture intentionally changes only the root proof and is still accepted as an equal *statement*, making this limitation explicit. Other controls require rejection of an unchanged alias name with a changed body, a changed endpoint type, a changed transitive inductive definition, and changed binder metadata. Alpha-renaming of a bound variable is accepted.

Build and run (after the inventory has identified the input files):

```sh
g++ -std=c++17 -O3 -I export_scan_include export_index.cpp -o export_index
g++ -std=c++17 -O3 -I export_scan_include compare_export_indices.cpp -o compare_export_indices
python3 test_definition_comparison.py
python3 run_export_indices.py
./compare_export_indices indices/challenge indices/solution statement_definition_comparison.json
```

The full compact indices occupy roughly 18 GB and are deliberately excluded from the small evidence bundle. The public compressed inputs and all programs needed to recreate them are identified here. An affirmative result is an exact structural comparison modulo the explicitly listed irrelevant annotations; it is not a general implementation of Lean definitional equality, so a negative result may require investigation rather than establish a mathematical discrepancy.

## Completed comparison result

The full comparison finished at 2026-11-20 22:34:02 UTC with exit code zero. It compared 53,009 reached declarations, 6,075,060 expression pairs, 2,458 universe-level pairs and 62,024 name-component pairs. All 53,721 challenge declarations other than the placeholder axiom had matching names in the solution. Non-target theorem bodies were included in this successful run. Both indexers and their decompression processes exited zero. The run records and full list of compared declarations are in `statement_definition_comparison_run.json` and `statement_definition_comparison.json`.

This exact comparison rules out an altered target definition relative to the canonical challenge within the recorded representation and normalization. It still does not validate the five target proof bodies, and it is not a completed local execution of the official Comparator or an independent kernel.
