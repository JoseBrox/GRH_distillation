import Formalism.LocalToGlobal.NumberFieldFamilies.OwnStruct

/- External audit probes. The last three declarations are deliberately invalid.
   Their rejection checks the structure-projection branch of kcopy. -/
def WrappedTrue : Prop := True

theorem audit_valid_projection : WrappedTrue ∧ WrappedTrue := by
  kcopy (And.intro True.intro True.intro)

namespace Formalism.ProjectionAudit
structure Source where
  witness : True
structure Target where
  witness : False
end Formalism.ProjectionAudit

theorem audit_false_field : False ∧ True := by
  kcopy (And.intro True.intro True.intro)

theorem audit_wrong_structure : Formalism.ProjectionAudit.Target := by
  kcopy (Formalism.ProjectionAudit.Source.mk True.intro)

theorem audit_nonstructure_projection : False ∧ True := by
  kcopy True.intro
