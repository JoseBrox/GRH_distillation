#include <nlohmann/json.hpp>
#include <sys/mman.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <iostream>
#include <fstream>
#include <filesystem>
#include <unordered_map>
#include <unordered_set>
#include <vector>
#include <string>
#include <chrono>
using J=nlohmann::json;using U=uint32_t;using V=uint64_t;struct Node{U tag,a,b,c;};
struct Map{int fd=-1;size_t bytes=0;void*data=nullptr;Map()=default;Map(const std::filesystem::path&p){fd=open(p.c_str(),O_RDONLY);if(fd<0)throw std::runtime_error("cannot open "+p.string());struct stat st;if(fstat(fd,&st))throw std::runtime_error("stat failed");bytes=st.st_size;if(bytes){data=mmap(nullptr,bytes,PROT_READ,MAP_SHARED,fd,0);if(data==MAP_FAILED)throw std::runtime_error("mmap failed");}}Map(const Map&)=delete;~Map(){if(data&&data!=MAP_FAILED)munmap(data,bytes);if(fd>=0)close(fd);}const Node&n(U i)const{if((V(i)+1)*16>bytes)throw std::runtime_error("node index out of range");return ((const Node*)data)[i];}U u(U i)const{if((V(i)+1)*4>bytes)throw std::runtime_error("argument index out of range");return ((const U*)data)[i];}std::string s(U off,U len)const{if(V(off)+len>bytes)throw std::runtime_error("string offset out of range");return std::string((const char*)data+off,len);}};
struct Index{std::filesystem::path path;Map expr,names,nstr,levels,us,lits;J manifest;
 Index(std::filesystem::path p):path(p),expr(p/"expr.bin"),names(p/"names.bin"),nstr(p/"name_strings.bin"),levels(p/"levels.bin"),us(p/"universe_args.bin"),lits(p/"literals.bin"){std::ifstream f(p/"index.json");f>>manifest;if(manifest.at("status")!="complete")throw std::runtime_error("incomplete index");if(expr.bytes!=manifest.at("expressions").get<V>()*16)throw std::runtime_error("expression file size mismatch");if(names.bytes!=manifest.at("names").get<V>()*16)throw std::runtime_error("name file size mismatch");}
 std::string key(U i)const{std::vector<U>a;U steps=0;while(i){if(++steps>100000)throw std::runtime_error("name cycle/depth");a.push_back(i);i=names.n(i).a;}std::string s;for(auto it=a.rbegin();it!=a.rend();++it){auto&n=names.n(*it);if(n.tag==1){auto t=nstr.s(n.b,n.c);s+='S';s+=std::to_string(t.size());s+=':';s+=t;}else if(n.tag==2){s+='N';s+=std::to_string(V(n.b)|(V(n.c)<<32));s+=';';}else throw std::runtime_error("bad name tag");}return s;}
 std::string display(U i)const{std::vector<U>a;while(i){a.push_back(i);i=names.n(i).a;}std::string s;for(auto it=a.rbegin();it!=a.rend();++it){if(!s.empty())s+='.';auto&n=names.n(*it);if(n.tag==1)s+=nstr.s(n.b,n.c);else s+='['+std::to_string(V(n.b)|(V(n.c)<<32))+']';}return s;}
};
struct Decl{std::string kind;J d;};
V pair(U a,U b){return (V(a)<<32)|b;}
int main(int argc,char**argv){if(argc<4||argc>6){std::cerr<<"usage: compare_export_indices CHALLENGE_INDEX SOLUTION_INDEX REPORT.json [comma-separated-roots] [types-only]\n";return 2;}
 J out={{"scope","Structural comparison of target types and transitive constant declarations; not proof type-checking"},{"ignored_expression_information",{"binder names (alpha-equivalence)","expression metadata"}},{"ignored_declaration_information",{"reducibility hints (not logical content)"}}};
 auto began=std::chrono::steady_clock::now();std::string context;V exprChecked=0,levelsChecked=0,namesChecked=0;std::vector<std::string>checkedNames;J mismatches=J::array();
 try{Index a(argv[1]),b(argv[2]);bool typesOnly=argc==6&&std::string(argv[5])=="types-only";out["compare_non_target_theorem_bodies"]=!typesOnly;
 std::vector<std::string>roots={"riemannHypothesis","riemannZeta_eq_zero_re","LFunction_ne_zero_of_half_lt_re","LFunction_eq_zero_re","LFunction_eq_zero_re_of_isPrimitive"};if(argc>=5){roots.clear();std::string x=argv[4];size_t start=0;for(;;){size_t p=x.find(',',start);roots.push_back(x.substr(start,p-start));if(p==std::string::npos)break;start=p+1;}}
 std::unordered_map<U,Decl>ad,bd;std::unordered_map<std::string,U>byKey;std::unordered_map<U,U>matching;
 auto load=[&](Index&ix,bool challenge){std::ifstream f(ix.path/"decls.ndjson");std::string line;V count=0;while(std::getline(f,line)){++count;J j=J::parse(line);auto&d=j.at("data");U id=d.at("name");std::string k=ix.key(id);if(challenge){if(byKey.count(k)||ad.count(id))throw std::runtime_error("duplicate challenge declaration");byKey.emplace(k,id);ad.emplace(id,Decl{j.at("kind"),std::move(d)});}else{auto it=byKey.find(k);if(it!=byKey.end()){if(bd.count(id)||matching.count(it->second))throw std::runtime_error("duplicate matched solution declaration");matching[it->second]=id;bd.emplace(id,Decl{j.at("kind"),std::move(d)});}}}return count;};
 out["challenge_declarations_loaded"]=load(a,true);out["solution_declarations_read"]=load(b,false);out["matching_declaration_names"]=matching.size();
 std::vector<U>todo;std::unordered_set<U>queued,rootIDs,finished;std::unordered_set<V>seenE,seenL,seenN;
 auto fail=[&](const std::string&what){throw std::runtime_error(context+": "+what);};
 auto ename=[&](U x,U y){std::vector<V>pending;while(x||y){V p=pair(x,y);if(seenN.count(p))break;auto&n=a.names.n(x);auto&m=b.names.n(y);if(n.tag!=m.tag)fail("name component tag differs");if(n.tag==1){if(a.nstr.s(n.b,n.c)!=b.nstr.s(m.b,m.c))fail("name text differs: "+a.display(x)+" versus "+b.display(y));}else if(n.tag==2){if(n.b!=m.b||n.c!=m.c)fail("numeric name component differs");}else if(x||y)fail("invalid name component");pending.push_back(p);x=n.a;y=m.a;}for(V p:pending){seenN.insert(p);++namesChecked;}};
 auto level=[&](U x,U y){std::vector<std::pair<U,U>>st{{x,y}};while(!st.empty()){auto [u,v]=st.back();st.pop_back();if(!seenL.insert(pair(u,v)).second)continue;++levelsChecked;auto&n=a.levels.n(u);auto&m=b.levels.n(v);if(n.tag!=m.tag)fail("universe level constructor differs");if(n.tag==1)st.push_back({n.a,m.a});else if(n.tag==2||n.tag==3){st.push_back({n.a,m.a});st.push_back({n.b,m.b});}else if(n.tag==4)ename(n.a,m.a);else if(n.tag!=0)fail("invalid universe level constructor");}};
 auto schedule=[&](U x,U y){ename(x,y);if(!ad.count(x))fail("challenge constant lacks declaration: "+a.display(x));auto it=matching.find(x);if(it==matching.end()||it->second!=y)fail("solution constant lacks corresponding declaration: "+a.display(x));if(queued.insert(x).second)todo.push_back(x);};
 auto expr=[&](U x,U y){std::vector<std::pair<U,U>>st{{x,y}};while(!st.empty()){auto [u,v]=st.back();st.pop_back();Node n=a.expr.n(u),m=b.expr.n(v);while((n.tag&255)==11){u=n.a;n=a.expr.n(u);}while((m.tag&255)==11){v=m.a;m=b.expr.n(v);}if(!seenE.insert(pair(u,v)).second)continue;++exprChecked;if(n.tag!=m.tag)fail("expression constructors differ at "+std::to_string(u)+", "+std::to_string(v));switch(n.tag&255){
 case 1:if(n.a!=m.a)fail("bound variable index differs");break;
 case 2:level(n.a,m.a);break;
 case 3:ename(n.a,m.a);if(n.c!=m.c)fail("constant universe argument count differs");for(U i=0;i<n.c;++i)level(a.us.u(n.b+i),b.us.u(m.b+i));schedule(n.a,m.a);break;
 case 4:case 5:case 6:st.push_back({n.a,m.a});st.push_back({n.b,m.b});break;
 case 7:st.push_back({n.a,m.a});st.push_back({n.b,m.b});st.push_back({n.c,m.c});break;
 case 8:ename(n.a,m.a);schedule(n.a,m.a);if(n.b!=m.b)fail("projection field index differs");st.push_back({n.c,m.c});break;
 case 9:case 10:if(a.lits.s(n.a,n.b)!=b.lits.s(m.a,m.b))fail("literal differs");break;
 default:fail("unknown expression constructor");}
 }};
 auto narr=[&](const J&x,const J&y,bool deps){if(x.size()!=y.size())fail("name array length differs");for(size_t i=0;i<x.size();++i){U p=x[i],q=y[i];ename(p,q);if(deps)schedule(p,q);}};
 for(auto&r:roots){bool found=false;for(auto&[id,d]:ad)if(a.display(id)==r){if(found)fail("ambiguous root name");found=true;rootIDs.insert(id);auto it=matching.find(id);if(it==matching.end())fail("missing solution root "+r);schedule(id,it->second);}if(!found)fail("missing challenge root "+r);}out["roots"]=roots;
 while(!todo.empty()){U id=todo.back();todo.pop_back();if(!finished.insert(id).second)continue;auto&c=ad.at(id);auto&s=bd.at(matching.at(id));context=a.display(id);checkedNames.push_back(context);if(c.kind!=s.kind)fail("declaration kind differs");auto&d=c.d;auto&e=s.d;narr(d.at("levelParams"),e.at("levelParams"),false);expr(d.at("type"),e.at("type"));
 if(d.contains("isUnsafe")&&d["isUnsafe"]!=e.at("isUnsafe"))fail("isUnsafe differs");
 if(c.kind=="def"){if(d.at("safety")!=e.at("safety"))fail("definition safety differs");expr(d.at("value"),e.at("value"));narr(d.at("all"),e.at("all"),true);}
 else if(c.kind=="opaque"){expr(d.at("value"),e.at("value"));narr(d.at("all"),e.at("all"),true);}
 else if(c.kind=="thm"){narr(d.at("all"),e.at("all"),false);if(!typesOnly&&!rootIDs.count(id))expr(d.at("value"),e.at("value"));}
 else if(c.kind=="axiom"){}
 else if(c.kind=="quot"){if(d.at("kind")!=e.at("kind"))fail("quotient kind differs");}
 else if(c.kind=="inductive"){for(auto k:{"numParams","numIndices","numNested","isRec","isReflexive"})if(d.at(k)!=e.at(k))fail(std::string("inductive metadata differs: ")+k);narr(d.at("all"),e.at("all"),true);narr(d.at("ctors"),e.at("ctors"),true);}
 else if(c.kind=="constructor"){for(auto k:{"cidx","numParams","numFields"})if(d.at(k)!=e.at(k))fail(std::string("constructor metadata differs: ")+k);schedule(d.at("induct"),e.at("induct"));}
 else if(c.kind=="recursor"){for(auto k:{"numParams","numIndices","numMotives","numMinors","k"})if(d.at(k)!=e.at(k))fail(std::string("recursor metadata differs: ")+k);narr(d.at("all"),e.at("all"),true);auto&rr=d.at("rules");auto&ss=e.at("rules");if(rr.size()!=ss.size())fail("recursor rule count differs");for(size_t i=0;i<rr.size();++i){auto&r=rr[i];auto&t=ss[i];schedule(r.at("ctor"),t.at("ctor"));if(r.at("nfields")!=t.at("nfields"))fail("recursor rule field count differs");expr(r.at("rhs"),t.at("rhs"));}}
 else fail("unknown declaration kind");
 }
 out["status"]="equal";out["transitive_declarations_compared"]=finished.size();out["remaining_declarations"]=todo.size();out["challenge_index_meta"]=a.manifest.at("meta");out["solution_index_meta"]=b.manifest.at("meta");
 }catch(const std::exception&e){out["status"]="not_equal_or_error";out["error"]=e.what();}
 out["expression_pairs_compared"]=exprChecked;out["universe_level_pairs_compared"]=levelsChecked;out["name_component_pairs_compared"]=namesChecked;out["declaration_names_compared"]=checkedNames;out["elapsed_seconds"]=std::chrono::duration<double>(std::chrono::steady_clock::now()-began).count();std::ofstream f(argv[3]);f<<out.dump(2)<<'\n';out.erase("declaration_names_compared");std::cerr<<out.dump(2)<<'\n';return out["status"]=="equal"?0:1;
}
