"""Fetch identified public proof exports; never unpack them onto disk."""
from pathlib import Path
import hashlib
import json
import os
import shutil
import time
import urllib.request

ROOT = Path(__file__).resolve().parent / 'exports'
ROOT.mkdir(exist_ok=True)
ITEMS = [
    ('challenge.ndjson.zst', None, 100_000_000),
    ('solution.ndjson.zst',
     '61a8938ad5f5e57397c1c0e3b954916af546d9004ade01c3555744a681b05381',
     7_699_933_588),
]
manifest = {'started_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
            'source':'https://math.mit.edu/~drew/grh/', 'items':[]}
meta = ROOT / 'download_manifest.json'

def save():
    p=meta.with_suffix('.tmp')
    p.write_text(json.dumps(manifest,indent=2))
    p.replace(meta)

for filename, expected, maximum in ITEMS:
    final = ROOT / filename
    partial = ROOT / (filename+'.partial')
    item={'filename':filename,'url':manifest['source']+filename,
          'expected_sha256':expected,'maximum_bytes':maximum,
          'started_utc':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),
          'status':'downloading'}
    manifest['items'].append(item)
    save()
    if final.exists():
        h=hashlib.file_digest(final.open('rb'),'sha256').hexdigest()
        if expected is not None and h != expected:
            raise RuntimeError('Existing file has wrong hash')
        item.update(status='complete',bytes=final.stat().st_size,sha256=h)
        save()
        continue
    digest=hashlib.sha256()
    count=0
    if partial.exists():
        with partial.open('rb') as f:
            while chunk:=f.read(4*1024*1024):
                digest.update(chunk)
                count+=len(chunk)
    request=urllib.request.Request(item['url'])
    if count:
        request.add_header('Range',f'bytes={count}-')
    try:
        with urllib.request.urlopen(request,timeout=45) as response:
            if count and (response.status!=206 or not
                          response.headers.get('Content-Range','').startswith(f'bytes {count}-')):
                raise RuntimeError('Server did not honor exact resume offset')
            item['headers']={k:response.headers[k] for k in
                             ('Content-Length','Content-Range','ETag','Last-Modified')
                             if k in response.headers}
            total = count + int(response.headers.get('Content-Length','0'))
            item['advertised_total_bytes']=total
            if total>maximum:
                raise RuntimeError('Export exceeds expected size bound')
            last=time.monotonic()
            with partial.open('ab') as f:
                while chunk:=response.read(4*1024*1024):
                    if shutil.disk_usage(ROOT).free < 10_000_000_000:
                        raise RuntimeError('Free disk guard reached; partial download retained')
                    count+=len(chunk)
                    if count>maximum:
                        raise RuntimeError('Export exceeds size bound')
                    digest.update(chunk)
                    f.write(chunk)
                    if time.monotonic()-last>20:
                        item.update(bytes=count,updated_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
                        save()
                        print(filename,count,flush=True)
                        last=time.monotonic()
                f.flush()
                os.fsync(f.fileno())
        h=digest.hexdigest()
        if expected is not None and (h!=expected or count!=maximum):
            raise RuntimeError('Compressed solution size or SHA256 mismatch')
        item.update(bytes=count,sha256=h,status='complete',
                    completed_utc=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()))
        partial.replace(final)
        save()
        print('COMPLETE',filename,count,h,flush=True)
    except Exception as exc:
        item.update(status='error',bytes=count,error=repr(exc))
        save()
        raise
manifest['completed_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
save()
