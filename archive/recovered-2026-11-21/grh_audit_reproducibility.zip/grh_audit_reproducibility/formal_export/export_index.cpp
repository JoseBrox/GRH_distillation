#include <nlohmann/json.hpp>
#include <iostream>
#include <fstream>
#include <filesystem>
#include <vector>
#include <string>
#include <array>
#include <limits>
#include <chrono>
using J=nlohmann::json;using U=uint32_t;using V=uint64_t;
struct Node{U tag,a,b,c;};static_assert(sizeof(Node)==16);
enum{BVAR=1,SORT,CONST,APP,LAM,FORALL,LET,PROJ,NAT,STR,MDATA};
U fit(V n){if(n>UINT32_MAX)throw std::runtime_error("32-bit index bound exceeded");return (U)n;}
U val(const J&j,const char*k){return fit(j.at(k).get<V>());}
void node(std::ofstream&f,Node n){f.write((char*)&n,sizeof n);if(!f)throw std::runtime_error("write failed");}
bool app(const std::string&s,U&arg,U&fn,U&id){size_t i=0;auto lit=[&](const char*t){while(*t){if(i>=s.size()||s[i++]!=*t++)return false;}return true;};auto num=[&](U&v){size_t a=i;V n=0;while(i<s.size()&&s[i]>='0'&&s[i]<='9'){n=n*10+(s[i++]-'0');if(n>UINT32_MAX)return false;}v=(U)n;return i>a;};return lit("{\"app\":{\"arg\":")&&num(arg)&&lit(",\"fn\":")&&num(fn)&&lit("},\"ie\":")&&num(id)&&lit("}")&&i==s.size();}
int main(int argc,char**argv){if(argc!=2){std::cerr<<"usage: export_index DIRECTORY < export.ndjson\n";return 2;}std::filesystem::path p=argv[1];std::filesystem::create_directories(p);
 std::ofstream ex(p/"expr.bin",std::ios::binary),na(p/"names.bin",std::ios::binary),ns(p/"name_strings.bin",std::ios::binary),lv(p/"levels.bin",std::ios::binary),us(p/"universe_args.bin",std::ios::binary),ls(p/"literals.bin",std::ios::binary),dc(p/"decls.ndjson");
 node(na,{0,0,0,0});node(lv,{0,0,0,0});V nx=0,nn=1,nl=1,nu=0,nstr=0,nlit=0,lines=0,decls=0;auto began=std::chrono::steady_clock::now();J report={{"format","compact-export-index-v1-little-endian"},{"node_bytes",16},{"scope","Index for exact transitive statement comparison; not a type checker"}};
 auto writeDecl=[&](const J&d,const char*kind){dc<<J{{"kind",kind},{"data",d}}.dump()<<'\n';++decls;};
 try{std::ios::sync_with_stdio(false);std::cin.tie(nullptr);std::string s;while(std::getline(std::cin,s)){++lines;U a,b,id;
  if(app(s,a,b,id)){if(id!=nx++)throw std::runtime_error("nonconsecutive expression ID");node(ex,{APP,b,a,0});}
  else {J j=J::parse(s);
   if(j.contains("ie")){id=val(j,"ie");if(id!=nx++)throw std::runtime_error("nonconsecutive expression ID");Node n{};
    if(j.contains("bvar"))n={BVAR,val(j,"bvar"),0,0};
    else if(j.contains("sort"))n={SORT,val(j,"sort"),0,0};
    else if(j.contains("const")){auto&d=j["const"];auto&u=d["us"];n={CONST,val(d,"name"),fit(nu),fit(u.size())};for(auto&v:u){U x=fit(v.get<V>());us.write((char*)&x,4);++nu;}}
    else if(j.contains("app")){auto&d=j["app"];n={APP,val(d,"fn"),val(d,"arg"),0};}
    else if(j.contains("lam")||j.contains("forallE")){bool lam=j.contains("lam");auto&d=j[lam?"lam":"forallE"];std::string bi=d.at("binderInfo");U binder=bi=="default"?0:bi=="implicit"?1:bi=="strictImplicit"?2:bi=="instImplicit"?3:255;if(binder==255)throw std::runtime_error("unknown binderInfo");n={(lam?LAM:FORALL)|(binder<<8),val(d,"type"),val(d,"body"),0};}
    else if(j.contains("letE")){auto&d=j["letE"];n={LET|(d.at("nondep").get<bool>()?256U:0U),val(d,"type"),val(d,"value"),val(d,"body")};}
    else if(j.contains("proj")){auto&d=j["proj"];n={PROJ,val(d,"typeName"),val(d,"idx"),val(d,"struct")};}
    else if(j.contains("natVal")||j.contains("strVal")){bool nat=j.contains("natVal");std::string v=j[nat?"natVal":"strVal"];n={nat?NAT:STR,fit(nlit),fit(v.size()),0};ls.write(v.data(),v.size());nlit+=v.size();}
    else if(j.contains("mdata"))n={MDATA,val(j["mdata"],"expr"),0,0};
    else throw std::runtime_error("unknown expression variant");node(ex,n);
   }else if(j.contains("in")){id=val(j,"in");if(id!=nn++)throw std::runtime_error("nonconsecutive name ID");if(j.contains("str")){auto&d=j["str"];std::string v=d.at("str");node(na,{1,val(d,"pre"),fit(nstr),fit(v.size())});ns.write(v.data(),v.size());nstr+=v.size();}else{auto&d=j.at("num");V v=d.at("i");node(na,{2,val(d,"pre"),(U)v,(U)(v>>32)});}}
   else if(j.contains("il")){id=val(j,"il");if(id!=nl++)throw std::runtime_error("nonconsecutive level ID");Node n{};if(j.contains("succ"))n={1,val(j,"succ"),0,0};else if(j.contains("max")||j.contains("imax")){bool m=j.contains("max");auto&d=j[m?"max":"imax"];n={m?2U:3U,fit(d.at(0).get<V>()),fit(d.at(1).get<V>()),0};}else if(j.contains("param"))n={4,val(j,"param"),0,0};else throw std::runtime_error("unknown level variant");node(lv,n);}
   else if(j.contains("meta"))report["meta"]=j["meta"];
   else if(j.contains("inductive")){auto&d=j["inductive"];for(auto&v:d.at("types"))writeDecl(v,"inductive");for(auto&v:d.at("ctors"))writeDecl(v,"constructor");for(auto&v:d.at("recs"))writeDecl(v,"recursor");}
   else{bool found=false;for(auto k:{"axiom","def","opaque","thm","quot"})if(j.contains(k)){if(found)throw std::runtime_error("multiple declaration variants");writeDecl(j[k],k);found=true;}if(!found)throw std::runtime_error("unknown declaration variant");}
  }
  if(lines%10000000==0){auto free=std::filesystem::space(p).available;std::cerr<<"lines="<<lines<<" expressions="<<nx<<" names="<<nn<<" free="<<free<<"\n";if(free<6000000000ULL)throw std::runtime_error("free disk guard");}
 }
 if(std::cin.bad())throw std::runtime_error("input read error");report["status"]="complete";
 }catch(const std::exception&e){report["status"]="error";report["error"]=e.what();}
 report["lines"]=lines;report["expressions"]=nx;report["names"]=nn;report["levels"]=nl;report["universe_args"]=nu;report["name_string_bytes"]=nstr;report["literal_bytes"]=nlit;report["declarations"]=decls;report["elapsed_seconds"]=std::chrono::duration<double>(std::chrono::steady_clock::now()-began).count();std::ofstream f(p/"index.json");f<<report.dump(2)<<'\n';std::cerr<<report.dump()<<'\n';return report["status"]=="complete"?0:1;
}
