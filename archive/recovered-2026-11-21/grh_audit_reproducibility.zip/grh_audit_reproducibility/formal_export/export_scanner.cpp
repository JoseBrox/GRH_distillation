#include <openssl/evp.h>
#include <nlohmann/json.hpp>
#include <iostream>
#include <fstream>
#include <unordered_set>
#include <unordered_map>
#include <vector>
#include <string>
#include <iomanip>
#include <sstream>
#include <chrono>
using J=nlohmann::json; using U=uint64_t;
struct N {U p; std::string s;};
// This is a metadata inventory, not a type checker. Expression payloads are
// deliberately not stored or validated. Full raw input is nevertheless hashed.
std::vector<std::string> keys(const std::string &s) {
 std::vector<std::string> out; int depth=0; bool in=false,esc=false; size_t start=0;
 for(size_t i=0;i<s.size();++i){char c=s[i];
  if(in){if(esc){esc=false;continue;} if(c=='\\'){esc=true;continue;}
   if(c=='"'){in=false; if(depth==1){size_t j=i+1;while(j<s.size()&&isspace((unsigned char)s[j]))++j; if(j<s.size()&&s[j]==':')out.push_back(s.substr(start,i-start));}} continue;}
  if(c=='"'){in=true;start=i+1;} else if(c=='{'||c=='[')++depth;else if(c=='}'||c==']')--depth;
  if(depth<0)throw std::runtime_error("negative JSON depth");
 } if(in||depth)throw std::runtime_error("unterminated JSON structure"); return out;
}
bool canonicalApp(const std::string&s){
 size_t i=0; auto lit=[&](const char*t){while(*t){if(i>=s.size()||s[i++]!=*t++)return false;}return true;};
 auto num=[&](){size_t start=i;while(i<s.size()&&s[i]>='0'&&s[i]<='9')++i;return i>start;};
 return lit("{\"app\":{\"arg\":")&&num()&&lit(",\"fn\":")&&num()&&lit("},\"ie\":")&&num()&&lit("}")&&i==s.size();
}
int main(int argc,char **argv){
 if(argc!=3){std::cerr<<"usage: export_scanner EXPECTED_RAW_SHA256 REPORT.json < raw.ndjson\n";return 2;}
 J out={{"scope","Complete byte hash, top-level record inventory, declaration metadata, axiom and safety inventory; NOT a kernel proof check"},{"parser","nlohmann/json 3.11.3 for names and declarations; top-level key scanner for expression/level records"}};
 std::vector<N> names(1,{0,""});std::unordered_set<U> declared;
 std::unordered_map<std::string,U> counts; std::unordered_map<U,std::string> aliasNames,aliasExpr;
 std::unordered_set<std::string> aliases={"RiemannHypothesis","RiemannZetaZerosOnLine","DirichletLNonvanishingRightOfHalf","DirichletLZerosOnLine","PrimitiveDirichletLZerosOnLine"};
 std::unordered_set<std::string> endpoints={"riemannHypothesis","riemannZeta_eq_zero_re","LFunction_ne_zero_of_half_lt_re","LFunction_eq_zero_re","LFunction_eq_zero_re_of_isPrimitive"};
 std::unordered_set<std::string> allowed={"propext","Classical.choice","Quot.sound"};
 auto full=[&](U id){std::vector<std::string> a;U steps=0;while(id){if(id>=names.size()||++steps>names.size())throw std::runtime_error("invalid name reference");a.push_back(names[id].s);id=names[id].p;}std::string r;for(auto i=a.rbegin();i!=a.rend();++i){if(!r.empty())r+='.';r+=*i;}return r;};
 J ax=J::array(),unsafe=J::array(),targets=J::array(),defs=J::array(),duplicates=J::array(),unknown=J::array();U lines=0,bytes=0,parsed=0,maxLine=0;bool lastNL=true;
 EVP_MD_CTX *ctx=EVP_MD_CTX_new();EVP_DigestInit_ex(ctx,EVP_sha256(),nullptr);auto began=std::chrono::steady_clock::now();
 auto decl=[&](const J &d,const std::string& kind){U ni=d.at("name").get<U>();auto nm=full(ni);counts["declaration_"+kind]++;if(!declared.insert(ni).second)duplicates.push_back(nm);
  if(kind=="axiom")ax.push_back({{"name",nm},{"type_expr",d.at("type")},{"allowed_standard_axiom",bool(allowed.count(nm))},{"isUnsafe",d.value("isUnsafe",false)}});
  if(d.value("isUnsafe",false)||(d.contains("safety")&&d["safety"]!="safe"))unsafe.push_back({{"name",nm},{"kind",kind},{"metadata",d}});
  if(endpoints.count(nm)){U t=d.at("type").get<U>();targets.push_back({{"name",nm},{"kind",kind},{"type_expr",t},{"direct_type_const",aliasExpr.count(t)?J(aliasExpr.at(t)):J(nullptr)},{"metadata",d}});}
  if(aliases.count(nm))defs.push_back({{"name",nm},{"kind",kind},{"metadata",d}});
 };
 try{std::ios::sync_with_stdio(false); std::cin.tie(nullptr);std::string line;
  while(std::getline(std::cin,line)){++lines; bytes+=line.size();EVP_DigestUpdate(ctx,line.data(),line.size());lastNL=!std::cin.eof();if(lastNL){EVP_DigestUpdate(ctx,"\n",1);++bytes;}if(line.size()>maxLine)maxLine=line.size();
   if(canonicalApp(line)){++counts["expr"];++counts["expr_app"];if(lines%10000000==0)std::cerr<<"lines="<<lines<<" bytes="<<bytes<<" names="<<names.size()-1<<" decls="<<declared.size()<<"\n";continue;}
   auto kk=keys(line);std::unordered_set<std::string> ks(kk.begin(),kk.end());if(kk.size()!=ks.size())throw std::runtime_error("duplicate top-level keys");
   std::string kind;bool parse=false;
   if(ks.count("meta")){kind="meta";parse=true;}
   else if(ks.count("in")){kind="name";parse=true;}
   else if(ks.count("il")){kind="level";}
   else if(ks.count("ie")){kind="expr";parse=ks.count("const");}
   else for(auto x:{"axiom","def","thm","opaque","quot","inductive"})if(ks.count(x)){if(!kind.empty())throw std::runtime_error("multiple declaration types");kind=x;parse=true;}
   if(kind.empty()){unknown.push_back({{"line",lines},{"keys",kk}});throw std::runtime_error("unknown root record");}
   if(kind=="expr"){std::unordered_set<std::string> e={"bvar","sort","const","app","lam","forallE","letE","proj","natVal","strVal","mdata"};if(kk.size()!=2)throw std::runtime_error("invalid expression root keys");std::string variant;for(auto& k:kk)if(k!="ie"){if(!e.count(k))throw std::runtime_error("unknown expression variant");variant=k;}counts["expr_"+variant]++;}
   else if(kind=="level"){std::unordered_set<std::string> l={"succ","max","imax","param"};if(kk.size()!=2)throw std::runtime_error("invalid level root keys");for(auto& k:kk)if(k!="il"&&!l.count(k))throw std::runtime_error("unknown level variant");}
   else if(kind=="name"){if(kk.size()!=2||ks.count("str")+ks.count("num")!=1)throw std::runtime_error("invalid name root keys");}
   else if(kk.size()!=1)throw std::runtime_error("invalid declaration/meta root keys");
   counts[kind]++;
   if(parse){++parsed;J j=J::parse(line);
    if(kind=="meta")out["meta"]=j.at("meta");
    else if(kind=="name"){U id=j.at("in").get<U>();if(id!=names.size())throw std::runtime_error("nonconsecutive or repeated name ID");auto& v=j.contains("str")?j.at("str"):j.at("num");U pre=v.at("pre").get<U>();if(pre>=id)throw std::runtime_error("forward name reference");std::string s=j.contains("str")?v.at("str").get<std::string>():std::to_string(v.at("i").get<U>());names.push_back({pre,s});if(pre==0&&aliases.count(s))aliasNames[id]=s;}
    else if(kind=="expr"){auto& c=j.at("const");U ni=c.at("name").get<U>();if(ni>=names.size())throw std::runtime_error("invalid constant name ID");if(aliasNames.count(ni))aliasExpr[j.at("ie").get<U>()]=aliasNames.at(ni);}
    else if(kind=="inductive"){auto& d=j.at(kind);for(auto& x:d.at("types"))decl(x,"inductive");for(auto& x:d.at("ctors"))decl(x,"constructor");for(auto& x:d.at("recs"))decl(x,"recursor");}
    else decl(j.at(kind),kind);
   }
   if(lines%10000000==0){std::cerr<<"lines="<<lines<<" bytes="<<bytes<<" names="<<names.size()-1<<" decls="<<declared.size()<<"\n";}
  }
  if(std::cin.bad())throw std::runtime_error("input read error");
  unsigned char md[32];unsigned int len;EVP_DigestFinal_ex(ctx,md,&len);std::ostringstream hs;for(unsigned char c:md)hs<<std::hex<<std::setfill('0')<<std::setw(2)<<(unsigned)c;
  out["sha256"]=hs.str();out["expected_sha256"]=argv[1];out["sha256_matches"]=hs.str()==argv[1];out["status"]="complete";
 }catch(const std::exception&e){out["status"]="error";out["error"]=e.what();out["error_line"]=lines;}
 EVP_MD_CTX_free(ctx);out["bytes"]=bytes;out["lines"]=lines;out["max_line_bytes"]=maxLine;out["ended_with_newline"]=lastNL;out["parsed_json_records"]=parsed;out["names"]=names.size()-1;out["declarations"]=declared.size();out["counts"]=counts;out["axioms"]=ax;out["unsafe_or_partial_declarations"]=unsafe;out["endpoints"]=targets;out["statement_alias_declarations"]=defs;out["duplicate_declaration_names"]=duplicates;out["unknown_records"]=unknown;out["elapsed_seconds"]=std::chrono::duration<double>(std::chrono::steady_clock::now()-began).count();
 std::ofstream f(argv[2]);f<<out.dump(2)<<"\n";std::cerr<<out["status"]<<" bytes="<<bytes<<" lines="<<lines<<" elapsed="<<out["elapsed_seconds"]<<"\n";return out["status"]=="complete"&&out.value("sha256_matches",false)?0:1;
}
