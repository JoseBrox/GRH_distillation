# Concrete corrections from adversarial peer review

Corrections 1 and 2 below have been applied directly to `work/formal_verification_update.tex`. Correction 3 concerns the root report assembly and is left to that assembly step.

## 1. State precisely how the public nanoda log is associated with the export

In `work/formal_verification_update.tex`, after the paragraph citing Sutherland's page and `nanoda.log`, add:

> The timing log names a configuration file and records exit status zero, but does not print that configuration's contents or the input file's hash. Its association with the hash-identified proof export therefore relies on the verifier's accompanying primary report. We did not authenticate the remote checker executable or independently reproduce that execution.

This is a concrete limit of the available evidence: `mit_verified/nanoda.log` records a command using `/home/ubuntu/grh/cmp/nanoda_par.json`, but the contents of that file are not among the supplied public logs. The separately published `comparator.json` is not that configuration file. The existing description as an externally reported result should remain.

## 2. Identify the trust placed in the independently written comparison program

After the successful structural-comparison result, add:

> The parser and comparison program are independently written audit tools, not formally verified software. Their reported equality is reproducible computational evidence under the explicitly stated representation and normalization, rather than an additional kernel certificate.

The implementation compares more than names: transitive definitions, opaque bodies, inductive data, recursor rules and non-target theorem bodies really were included. Thus the result should not be weakened to a name-only check. Conversely, the phrase “establishes identity” should be understood subject to the audit program's correctness; the target proof bodies are intentionally not checked by it.

## 3. Remove the superseded verification status from the assembled audit

At the reviewed snapshot, `output/grh_audit.tex` still contains the earlier statements that only nine archive modules compiled, that no final axiom audit was obtained, and that no independent kernel verification had been obtained. These must be replaced when assembling the new report. The accurate distinctions are:

- 31 local source modules compiled, without a completed local `Main` build;
- a complete local inventory of the published export found only the three standard axioms;
- a successful local comparison of the five target types and their transitive definitions against the canonical challenge;
- full nanoda acceptance and all-module Lean replay reported by an independent verifier, with the stated provenance limitations;
- no complete local kernel replay and no complete human proof reconstruction.

The manuscript's explicit statement that it does not yet prove GRH must remain; the outstanding uniform arithmetic estimate cannot be replaced by the formal verification result.
