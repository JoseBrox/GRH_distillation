from pathlib import Path
import subprocess, datetime, json, hashlib, time, resource
p = Path(__file__).resolve().parent
now = lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
record = {'started_utc': now(), 'status': 'running',
          'indexer_source_sha256': hashlib.sha256((p/'export_index.cpp').read_bytes()).hexdigest(),
          'indexer_binary_sha256': hashlib.sha256((p/'export_index').read_bytes()).hexdigest(), 'runs': []}
manifest = p/'export_indices_run.json'
manifest.write_text(json.dumps(record, indent=2))
for stem, window in [('challenge', 27), ('solution', 30)]:
    d = p/'indices'/stem
    row = {'artifact': stem, 'started_utc': now()}
    t = time.monotonic()
    with (p/f'{stem}_index.log').open('w') as log:
        z = subprocess.Popen(['zstd', '-dc', f'--long={window}', str(p/'exports'/f'{stem}.ndjson.zst')],
                             stdout=subprocess.PIPE, stderr=log)
        b = subprocess.run([str(p/'export_index'), str(d)], stdin=z.stdout, stderr=log)
        z.stdout.close()
        zr = z.wait()
    row.update(indexer_exit=b.returncode, zstd_exit=zr, finished_utc=now(),
               elapsed_seconds=time.monotonic()-t,
               max_children_rss_kib=resource.getrusage(resource.RUSAGE_CHILDREN).ru_maxrss)
    record['runs'].append(row)
    manifest.write_text(json.dumps(record, indent=2))
    if b.returncode or zr:
        record['status'] = 'error'
        break
else:
    record['status'] = 'complete'
record['finished_utc'] = now()
manifest.write_text(json.dumps(record, indent=2))
print(json.dumps(record, indent=2))
