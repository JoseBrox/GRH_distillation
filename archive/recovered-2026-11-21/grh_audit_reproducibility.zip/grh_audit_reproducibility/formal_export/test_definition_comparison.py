#!/usr/bin/env python3
"""Positive and negative controls for structural statement comparison.
These small records test the comparator; they are not kernel certificates.
"""
from pathlib import Path
import copy,json,subprocess
p=Path(__file__).resolve().parent
out=p/'definition_comparison_tests';out.mkdir(exist_ok=True)
base=[{'meta':{'format':{'version':'3.1.0'}}}]
for i,name in enumerate(['Meaning','target','True','intro','False','x','y'],1):
 base.append({'in':i,'str':{'pre':3 if i==4 else 0,'str':name}})
base += [
 {'ie':0,'sort':0},
 {'ie':1,'const':{'name':3,'us':[]}},
 {'ie':2,'const':{'name':5,'us':[]}},
 {'ie':3,'const':{'name':1,'us':[]}},
 {'ie':4,'const':{'name':4,'us':[]}},
 {'ie':5,'bvar':0},
 {'ie':6,'forallE':{'name':6,'type':1,'body':1,'binderInfo':'default'}},
 {'ie':7,'lam':{'name':6,'type':1,'body':5,'binderInfo':'default'}},
]
def ind(name,ctors):
 return {'name':name,'levelParams':[],'type':0,'numParams':0,'numIndices':0,
         'all':[name],'ctors':ctors,'numNested':0,'isRec':False,'isUnsafe':False,'isReflexive':False}
base += [
 {'inductive':{'types':[ind(3,[4])],'ctors':[{'name':4,'levelParams':[],'type':1,
     'induct':3,'cidx':0,'numParams':0,'numFields':0,'isUnsafe':False}],'recs':[]}},
 {'inductive':{'types':[ind(5,[])],'ctors':[],'recs':[]}},
 {'def':{'name':1,'levelParams':[],'type':0,'value':6,'hints':'abbrev','safety':'safe','all':[1]}},
 {'thm':{'name':2,'levelParams':[],'type':3,'value':7,'all':[2]}},
]
def index(name,records):
 d=out/name;d.mkdir(exist_ok=True)
 raw=('\n'.join(json.dumps(x,separators=(',',':')) for x in records)+'\n').encode()
 (d/'input.ndjson').write_bytes(raw)
 r=subprocess.run([str(p/'export_index'),str(d)],input=raw,capture_output=True)
 assert r.returncode==0,r.stderr.decode()
 return d
challenge=index('challenge',base)
results=[]
def run(name,records,expected_equal):
 solution=index(name,records);report=out/(name+'_comparison.json')
 r=subprocess.run([str(p/'compare_export_indices'),str(challenge),str(solution),str(report),'target'],capture_output=True)
 j=json.loads(report.read_text());ok=(r.returncode==0)==expected_equal
 results.append({'name':name,'pass':ok,'expected_equal':expected_equal,'exit_code':r.returncode,
                 'status':j['status'],'error':j.get('error')})
run('identical',base,True)
x=copy.deepcopy(base)
for r in x:
 if 'forallE' in r:r['forallE']['name']=7
 if 'lam' in r:r['lam']['name']=7
run('bound_variable_renaming',x,True)
x=copy.deepcopy(base)
for r in x:
 if 'def' in r:r['def']['value']=2
run('same_alias_name_changed_body',x,False)
x=copy.deepcopy(base)
for r in x:
 if 'thm' in r:r['thm']['type']=2
run('changed_endpoint_type',x,False)
x=copy.deepcopy(base)
for r in x:
 if 'inductive' in r and r['inductive']['types'][0]['name']==3:
  r['inductive']['types'][0]['ctors']=[];r['inductive']['ctors']=[]
run('changed_transitive_inductive',x,False)
x=copy.deepcopy(base)
for r in x:
 if 'forallE' in r:r['forallE']['binderInfo']='implicit'
run('changed_binder_metadata',x,False)
x=copy.deepcopy(base)
for r in x:
 if 'thm' in r:r['thm']['value']=2
run('changed_root_proof_intentionally_ignored',x,True)
(out/'results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps(results,indent=2))
assert all(r['pass'] for r in results)

# The fast application-record path and ordinary JSON path must preserve the
# same ordered pair, and must distinguish a swapped function/argument pair.
import struct
app_controls = []
for name, record in [
    ('app_canonical', {'app': {'arg': 2, 'fn': 1}, 'ie': 0}),
    ('app_shuffled', {'ie': 0, 'app': {'fn': 1, 'arg': 2}}),
    ('app_swapped', {'app': {'arg': 1, 'fn': 2}, 'ie': 0}),
]:
    d = index(name, [record])
    values = list(struct.unpack('<IIII', (d/'expr.bin').read_bytes()))
    app_controls.append({'name': name, 'node': values})
assert app_controls[0]['node'] == app_controls[1]['node'] == [4, 1, 2, 0]
assert app_controls[2]['node'] == [4, 2, 1, 0]
(out/'application_index_controls.json').write_text(json.dumps(app_controls, indent=2)+'\n')
