#!/usr/bin/env python3
"""Regression tests for the metadata inventory, not a proof-checking test suite."""
from pathlib import Path
import hashlib
import json
import subprocess

root = Path(__file__).resolve().parent
outdir = root / 'export_scan_tests'
outdir.mkdir(exist_ok=True)
scanner = root / 'export_scanner'
base = [
    {'meta': {'format': {'version': '3.1.0'}}},
    {'str': {'str': 'propext', 'pre': 0}, 'in': 1},
    {'sort': 0, 'ie': 0},
    {'axiom': {'name': 1, 'type': 0, 'levelParams': [], 'isUnsafe': False}},
]
results = []

def run(name, records, newline=True, expected_rc=0, predicate=lambda _: True):
    raw = '\n'.join(json.dumps(x, separators=(',', ':')) for x in records)
    if newline:
        raw += '\n'
    data = raw.encode()
    (outdir / (name + '.ndjson')).write_bytes(data)
    report = outdir / (name + '.json')
    proc = subprocess.run([str(scanner), hashlib.sha256(data).hexdigest(), str(report)],
                          input=data, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    obj = json.loads(report.read_text())
    ok = proc.returncode == expected_rc and predicate(obj)
    results.append({'name': name, 'pass': ok, 'exit_code': proc.returncode,
                    'stderr': proc.stderr.decode()})

run('standard_axiom_shuffled_keys', base,
    predicate=lambda j: j['axioms'][0]['allowed_standard_axiom'])
run('no_final_newline', base, newline=False,
    predicate=lambda j: not j['ended_with_newline'])
run('forbidden_axiom_detected', base + [
    {'in': 2, 'str': {'pre': 0, 'str': 'adversarialAxiom'}},
    {'axiom': {'name': 2, 'type': 0, 'levelParams': [], 'isUnsafe': False}}],
    predicate=lambda j: len(j['axioms']) == 2 and not j['axioms'][1]['allowed_standard_axiom'])
run('unsafe_definition_detected', base + [
    {'in': 2, 'str': {'pre': 0, 'str': 'badDef'}},
    {'def': {'name': 2, 'type': 0, 'value': 0, 'levelParams': [],
             'safety': 'unsafe', 'hints': 'abbrev', 'all': [2]}}],
    predicate=lambda j: len(j['unsafe_or_partial_declarations']) == 1)
run('declaration_hidden_as_expression', base + [{'ie': 1, 'axiom': {'name': 1, 'type': 0}}],
    expected_rc=1, predicate=lambda j: j['status'] == 'error')
run('unknown_record_rejected', base + [{'surprise': 1}], expected_rc=1,
    predicate=lambda j: j['status'] == 'error')
run('duplicate_name_rejected', base + [{'in': 1, 'str': {'pre': 0, 'str': 'evil'}}],
    expected_rc=1, predicate=lambda j: j['status'] == 'error')
run('canonical_app_fast_path', base + [{'app': {'arg': 0, 'fn': 0}, 'ie': 1}],
    predicate=lambda j: j['counts']['expr_app'] == 1)
run('shuffled_app_fallback', base + [{'ie': 1, 'app': {'fn': 0, 'arg': 0}}],
    predicate=lambda j: j['counts']['expr_app'] == 1)
run('canonical_app_hidden_declaration', base + [
    {'app': {'arg': 0, 'fn': 0}, 'ie': 1, 'axiom': {'name': 1, 'type': 0}}],
    expected_rc=1, predicate=lambda j: j['status'] == 'error')
(outdir / 'results.json').write_text(json.dumps(results, indent=2) + '\n')
print(json.dumps(results, indent=2))
assert all(r['pass'] for r in results)
