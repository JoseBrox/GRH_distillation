# Independent root review: ambient multiplicity reduction

Reviewed manuscript SHA-256:
1efc67deb29eee4d31b1629eb7f248a8f2afba485459e322e5cf57cc1e24dadd.

The root read the complete fragment, including the unipotence proof from
integral traces, covolume duality for nonfree modules, map separation,
packing in a product of matrix spaces, dyadic summation and all numerical
inequalities, the local compression/decay proof, and final error absorption.
The counterexamples are correctly confined to stronger or weakened
statements: a nonidentity unipotent can approach the identity in a cusp.

For the new compression subsection the root independently read Sun's
compact-Haar convention and Theorem 6.4 / Section 6.4, and visually checked
printed page43, including the overbar in the definition of H-tilde.
The root read Vogan--Zuckerman Theorem5.3 and Proposition6.1 excerpts and
visually checked printed page73, including admissibility (5.1).
The parameter nu=lambda-rho is integral dominant; the noncompact Cartan
condition is empty. Reverse Cholesky, complementary minors, the character
lambda+rho and central-J sign removal give precisely the asserted integral.
The finite exponential-moment variance estimate and exterior-power
calculation prove the stronger h/(2 exp(1)) decay constant on the lowest
compact type. The unrestricted-vector counterexample is valid.

Result: PASS for the proved statements and conditional reduction, with
the classical representation theorems explicitly imported.
The kernel/trace construction, integrated near-unipotent bound, rare-cusp
volume and deep-cusp mass estimate remain substantive unproved inputs in
this fragment. No complete ambient multiplicity theorem is certified.
