# Ambient complex multiplicity: exact scope and source trace

## Mathematical contribution

The reconstruction identifies the source's complex multiplicity as the dimension of the image of finite convolution on the continuous archimedean intertwiner space. Its proposed main term is the product of local formal degrees, finite idempotent value at the identity, and quotient volume. Finite-dimensionality is explicitly required before this dimension is treated as a finite integer: Lean's finrank on an infinite-dimensional space is not silently used as an ordinary dimension.

The following arguments are proved in conventional mathematics:

1. Small Cartan displacement, finite integrality and unipotence modulo a completely split prime greater than 3n force rational unipotence, with explicit distance to the identity.
2. Normalized covolume duality and a quotient-image argument give the product operator-norm separation by the square of the least lattice size. This replaces a longer Harder–Narasimhan argument for this particular estimate.
3. Packing in products of matrix spaces and a dyadic sum prove the distant rational-term estimate, with the submitted radius 10^-6 n^-8 f^-2, truncation exponent 11q and gap size 8·10^14(Cg+4)n^19 f^5 log(b r_E).
4. A finite probability variance bound and exterior powers give a direct principal-minor phase bound. Together with the exact lowest compact-type integral it gives coefficient decay with h/(2e), stronger than the submitted h/8.
5. The compression identity is identified precisely with Sun's classical theorem, after checking cohomological induction, parameter shifts, compact Haar probability, the projection at the identity, upper Cholesky factorization, complementary principal minors, and the sign change by the central signature matrix J.
6. The final numerical absorption from the displayed global analytic inputs is proved explicitly.

The local compression argument imports Sun's Theorem 6.4 and its explicit specialization in section 6.4, and the classical cohomological realization/identification in Vogan–Zuckerman (5.1), Theorem 5.3 and Proposition 6.1. These deep theorems are not claimed to be reproved. Their relevant statements and group hypotheses were checked in primary research sources. The source's actual IsDS convention is matched by the separately reviewed formal-degree fragment and its minimum compact-type characterization.

## Important convention checks

The factor in Sun's character is nu + 2 rho = lambda + rho. This gives lambda_i - lambda_(i+1) + 1 in the phase. Upper triangular decomposition produces trailing minors; the complementary-minor identity converts them to leading minors of the inverse. The resulting negative sign is removed by conjugation with central J. Omitting any of these operations would change the asserted formula.

Sun's compact measure is a probability measure and his compact matrix coefficient is the isotypic projection of the representation. Multiplicity one therefore identifies it with the orthogonal compression used here. The factor dim(W) is essential and gives the identity operator at X = 0 by compact Schur orthogonality.

The source's Cartan distance is the Hilbert–Schmidt norm of the Hermitian polar logarithm, exactly the distance used in the draft. For n at least 3 and q^2 at most n, q is the smaller signature; swapping J and -J also gives the exact min(p,q) dependence for arbitrary signatures.

## What remains open in this fragment

The following are separate substantive inputs, stated explicitly and not proved by the packing argument:

- Construction of the actual continuous finite-rank convolution kernel, including the pointwise diagonal identity and its rank equal to the intertwiner multiplicity.
- The integrated bound for nonidentity nearby rational unipotents.
- The small quotient-volume estimate for the excluded cusp.
- The bound for the projection mass in that cusp.

Almost-everywhere equality of kernels on the product space would not alone establish the diagonal trace identity. The draft explicitly requires continuous representatives or a proved pointwise diagonal identity.

The explicit hyperbolic unipotent example shows why nearby rational elements cannot simply be discarded as identities in an indefinite group. Removing the congruence assumption or the small-distance assumption also gives concrete counterexamples to the corresponding weakened statements. No counterexample to the actual hypotheses has been found in the reconstructed components. A decay assertion for arbitrary unit vectors would be false: choose u = sigma(a)v. The submitted theorem and reconstruction both restrict the vectors to the lowest compact type.

## Provenance

The companion JSON records SHA-256 hashes, exact reading scopes and line counts for each inspected source file. It records the downloaded Sun and Vogan–Zuckerman PDF hashes and the precise primary-source passages checked. The named classical results remain imported background theorems. Reading the listed endpoints and implementation files does not certify all their imports, and this work supplies no independent full Lean kernel replay.
