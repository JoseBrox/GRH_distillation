# Root review of the actual arithmetic classes

Recorded by qrh_mathematics from root's messages of 2026-11-21.

Root independently read all 702 lines of the complete draft and found no mathematical defect. The explicit residue-map linearity, arbitrary-Haar-volume clarification, and typography edits produce the stable 707-line fragment with SHA256 `f6d656e74451d3ebdcd853ab856f8661c4756a99986d4db82f7af4d95c2aa792`.

Root checked the dyadic unit-norm and Gram--Schmidt proofs, completed CRT patching, both group actions and stabilizer inverse, principal-congruence fibers, conjugate-prime coefficient identity, rational and complex evaluation, quotient-mass normalization, and all four counterexamples. The fixed standard rational Hermitian space avoids an unstated global Hasse principle. The row stabilizer isomorphism is the exact one needed for the weighted class-period pairing.

The final source trace separately checks every additional row Q-prime using the actual disjointness and conjugate-half providers. The Haar paragraph explicitly gives volume(K_H) times the finite sum for an arbitrary Haar measure; no mass/formal-degree normalization is replaced by one.

The independent Siegel review is recorded in arithmetic_classes_peer_review_siegel.md. Two-pass XeLaTeX compiled the final fragment and its dependencies successfully; see arithmetic_classes_compile.json.
