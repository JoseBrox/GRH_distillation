# Independent review of the arithmetic class comparison

Reviewer: /root/siegel_mathematics. Reviewed the entire 702-line version of arithmetic_classes.tex on 2026-11-21.

SHA-256 at review: 4715be0af7e6bbf7f7ad6fefb898744823d2a87e589433128159618867a657d1.

## Mathematical review

No mathematical defect found. Independently checked the elementary norm lifting in unramified quadratic extensions (including residue characteristic two), integral orthogonal splitting, Chinese-remainder lattice patching, independence of prescribed split-prime decorations, adelic double-coset and finite stabilizer identifications, the inverse level character, the free/transitive fiber argument for local bases, the contragredient polynomial action, conjugate-prime localization of the Hermitian dual, coefficient lattice transport, invariant class values, localization without a stabilizer denominator, and the Haar normalization giving reciprocal stabilizer weights.

The exact identity for the coefficient lattice is correctly taken at the conjugate prime: a basis A of L at conjugate(P) gives a basis conjugate(A)^(-t) of L# at P. The resulting contragredient basis matrix is conjugate(A), including determinant twists. The compact-open Haar normalization yields 1/|Gamma_c| and does not introduce |H|. Discreteness of rational points in the finite adeles is justified here by finiteness of positive-definite lattice isometries.

The four counterexamples have the stated effect and do not satisfy the actual hypotheses they are meant to test. The intermediate coupling-coset/period and global theta obligations remain explicit.

## Precision correction requested

In the decorated-lattice definition, explicitly call ell_P a nonzero O_E-linear map and b_Q an O_E/Q-linear isomorphism. This is already the meaning used in the proofs and the source, but must not be left as an unrestricted map. No other correction requested.

## Limits

This is an independent mathematical review of the displayed proofs and their stated interfaces, not a re-elaboration of the complete formal dependency graph. Source attribution and the actual source read manifest are the author's separate responsibility.
