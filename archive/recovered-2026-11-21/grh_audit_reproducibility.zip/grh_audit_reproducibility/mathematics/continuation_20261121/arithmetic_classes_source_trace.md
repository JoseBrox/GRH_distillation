# Actual adelic classes and their integral coefficient lattices

Audit date: 2026-11-21. Fragment: `arithmetic_classes.tex`.

The companion JSON manifest records the source files, exact line ranges read, and SHA256 hashes. This is a source-level mathematical audit and an independent conventional reconstruction. It is not a transitive audit of every import and not a fresh Lean kernel certification. No counterexample to an actual claim in the ranges reviewed was found.

## Live route, distinguished from the older conditional interface

The earlier `Formalism/LocalToGlobal/Columns/WordFin`, `TiedCrd`, `LocalLevelIsKOneEverywhere`, and `ColumnDeterminants/ColsTiedD` files were followed first. `ColDat` alone does not assert orthonormal coordinates; `ColsTiedD.ColHyp.sp` explicitly supplies `SpStd`. An exact-name search found no external provider of this older conditional package. This is not treated as a gap in the actual final route.

The live provider is:

1. `Development/AbelianVarietyTheory/Proofs/IwasawaDecomposition/ExistsStandardColumnComparisonsTrueColumns.lean`, theorem `TC.colsTiedSym_std` (whole file read).
2. `ExistsStandardFormComparisonSymmetricLevelMember.lean`, theorem `FormSym.formsTiedSym_std` (whole file read).
3. Its downstream use in `GlobalInterpolation/FormsMapAtEveryTrueColumnMember.lean` (whole file read).

The first two providers assemble many additional intermediate, period, and local-level comparisons. Reading their assembly does not discharge every imported assertion. The present fragment independently proves the initial-step class comparison and the row local-basis comparison, together with the required coefficient lattice and norm. The intermediate coupling-coset chart proof remains a separate next component.

## Standard Hermitian space and the actual lattice coordinates

`TrueColumnSpacesStandardInFrameCoords.lean` was read in full. Its `TC.spaces_in_coordinates` obtains the orthonormality and standard integral lattice from `I.Ok.spaces`, which identifies the spaces with `Examples₂.posSpace`. It then proves, by inverse-coordinate cancellation, that the coordinates of `I.latAt ... c` are exactly the kernel lattice `((I.stp ...).rep c).deco.L`. The frame comparison is the identity on matrix coordinates, and its determinant is the ordinary matrix determinant.

The corresponding definitions are in `Definitions/AutomorphicMembership/LatAtLattice.lean:1--180`. In particular `latAt` is the inverse-coordinate image of that kernel lattice. This directly checks the object to which the degree and short-dual theorems are applied. No assertion that an arbitrary Hermitian space has an orthonormal basis over its coefficient field is used.

`TrueColumnChoicesHeckeCharReferenceEqOne.lean:219--286` supplies the actual standard-space and index hypotheses, and proves `twistPrimes_reference_tuple_eq_empty`. The initial coupling set is empty by the definition of `ysAt` away from the penultimate step, and the initial index is unique by `idx_ok.zero_uniq`, used explicitly at `ExistsMemberStepCharts.lean:555--563`. Thus the initial reference column has no additional local-basis or coupling-coset data hidden in its class set. The auxiliary `StepZeroTwistReferenceTupleEqId.lean:380--445` transports the same initial index and reference tuple.

## Unramified local isometries and point existence

The actual point provider is `ValuedLtOfMem.lean:1--344`, read in full. Its `unimodGenus` near line 123 uses `CMData.cmUnram`, and `exists_isPtOf_cm` near line 299 adds the split-prime frames. It invokes the source's general self-dual genus result and integral adelic approximation. Those imported proofs were not audited transitively here.

The conventional fragment replaces these inputs by full elementary proofs:

* The residue trace of an unramified quadratic extension is onto, including characteristic two.
* Residue unit norms are onto by cyclicity of finite-field multiplicative groups.
* The principal-unit formula `N(1+pi^j t)=1+pi^j Tr(t) mod pi^(j+1)` lifts every unit norm by completeness, without division by two.
* In a unimodular Hermitian matrix, either a diagonal entry is a unit or an off-diagonal entry and residue trace produce a unit-norm vector. Integral Gram--Schmidt and unit-norm surjectivity give an orthonormal basis. The split case is a perfect-pairing argument over the two factors.
* CRT in the finite module `a^(-1)O^n/aO^n` patches full local lattices and proves equality with their completed intersections.
* At a selected split prime, the integral unitary group is `GL_n(O_v)` and its full residue reduction is onto. This adjusts the prescribed functional or frame independently.

No global Hasse principle or strong approximation is required: all lattices already lie in the fixed positive standard rational Hermitian space. `BaseFieldsDefiniteLaws.lean:45--95` checks the unramifiedness required for the actual host field. This is a retained property of the actual field construction, not an assertion about arbitrary CM extensions.

## Exact selected-prime hypotheses, including every row twist prime

`ExistsAdelicPointDecoratedLatticeAllTwists.lean` was read in full. It proves the disjointness of the T-primes, type-primes, and the whole finite union of auxiliary character primes. For T-primes it uses `piT_norm` and `piT_cop`: a prime containing both `piT` and its conjugate would contain one. Cross-intersections are excluded because the distinct rational level primes lie in the forbidden set for auxiliary character primes.

`LevOkTwists.lean` was read in full. Its `levOk_twists` proves both `Disjoint vGs SQ` and the stronger condition that `vGs union SQ` contains no conjugate pair. A prime in `SQ` is the chosen `sel(v)` at a good split prime outside the forbidden set; two such primes over the same base prime are the same chosen prime and cannot be conjugates. Type-prime/auxiliary-prime intersections are excluded by their incompatible membership in the forbidden set. These conclusions pass to each individual `Q a subset SQ`.

`ReferenceCharactersFactorTame.lean:430--520,670--721` gives the exact `LevOk` definition and its base proof. The type-prime half is formed from divisors of the conjugates of `piG`; conjugate pairs are excluded by `piG_cop` and by the distinct rational primes `g_1,g_2`. Consequently the row class comparison with `S=empty` and all its additional `Q` primes satisfies the exact disjointness and conjugate-half conditions in the new theorem.

`ExistsUnitaryDiagonalBasePointLevelPrime.lean` was read in full. Its base-point adjustment multiplies the selected final-coordinate functionals by the unit residue of the conjugate of `piT`. The fragment permits arbitrary fixed nonzero scalars `c_P`, proves that these do not change the kernel lattice or stabilizers, and therefore retains this normalization.

## Level character, stabilizers, and the local-basis row description

`Formalism/LocalToGlobal/Columns/RecLevel.lean:1--100` defines `levTyp` as the inverse of `levChr`, which is the character composed with residue reduction. The inverse is not optional: pullback of a frame by `g^{-1}` gives `d_(gk)=(1,red(k)^(-1))d_g`. The new proof derives exactly that identity and the stabilizer inverse `gamma -> (gamma,red(g^(-1) gamma g))`.

`Definitions/AutomorphicMembership/CardStabilizerForgetFr.lean:1--365,480--622` was read. It defines the local-basis forgetful map, proves its surjectivity and equivariance, and proves the stabilizer isomorphism via `exists_redFG_smul` and `eq_of_redFG_eq`. The conventional proof reduces this to a precise group-action lemma: a surjective equivariant map with fibers that are free transitive orbits of the group homomorphism's kernel induces bijections of orbit sets and isomorphisms of stabilizers. The kernel here is the principal congruence group acting on actual localized basis matrices. Its freeness prevents any extra factor, even though the group itself is infinite.

The live row `stepX` near line 524 has no T-functional and no coupling set. Its local basis group is exactly the inverse image of a residue subgroup (`levQX`). `chr_stepX` near line 555 gives the reciprocal relation between the point and row characters, and `card_stabilizer_toRow` near line 567 is exactly the equality required for the weighted class-period sum. The new fragment proves these underlying facts, rather than merely repeating their statement as an input.

The row assertion covers every auxiliary Q-prime under the preceding split/disjointness hypotheses. It does not claim to replace intermediate steps with nontrivial coupling cosets.

## Actual polynomial lattice and the conjugate-prime issue

`PredMemGamRanks.lean:1--210` defines the live `GStep.rho`, `fam`, `hlat`, and `embF`. The representation is the finite character times `rhoVr`, the contragredient polynomial realization. The class lattice is `delAtr` on the representative's Hermitian dual `Lsh`, not an unqualified covariant lattice on `L`.

The new equality is proved prime by prime. At a coefficient prime w, let P be its pullback under tau. Choose a basis A of L at the **conjugate prime** bar(P); then `(bar A)^(-t)` is a basis of L# at P. Applying the contragredient representation gives the covariant representation through `tau composed with conjugation`. All determinant twists, including negative twists, remain present. This agrees with the actual `rhoC` and base-matrix transpose in `GlobalTheory/TransposeBaseMatrixInfinity.lean`, read in full.

`HermitianChartComplexRationalIntegralForms.lean` was read in full. Its `mem_fiC_iff` reconstructs the adelic function from invariant class values; `exists_embF_iff` checks the rational coefficient condition; `val_tied` identifies the actual localized coefficient lattice using local bases of L#. `IsBasisAtOfIsLocBasis.lean:110--178` gives the common-multiplier localization argument. The new section proves these elementary class and polynomial facts directly, retaining invariant fibers unless the actual stabilizers have first been proved trivial.

The remaining imported integral coefficient-lattice identities are the ones independently reconstructed in `coefficient_duality.tex`. The actual coefficient map and slope bounds are in `arithmetic_maps.tex`; this fragment identifies their required lattices rather than reproving them.

## Metric normalization

`UnitaryOfIsON.lean` was read in full. `majAt_classSum`, `majAt_step`, and `norm_step` express the actual algebraic metric as the normalized Fock form summed with the exact weights `1/Nat.card(stabilizer)`. The comparison includes the complex-conjugate embedding branch, and on orthonormal frames every determinant has absolute value one. `ipV_norm_tie` near line 195 is the live provider used by `formsTiedSym_std`.

The source algebraic class norm is **defined by this finite weighted sum**; it does not require a claim that a separate mass or formal-degree Haar normalization gives volume one to every varying level. The fragment states the corresponding measure normalization explicitly. With an arbitrary Haar measure mu, the quotient integral is `mu(K_H)` times the finite sum. Dividing by `mu(K_H)` gives the class norm. Thus there is no omitted level-index or `|H|` factor, and no normalization from the global mass formula is silently imported.

## Counterexamples and review

The fragment proves four counterexamples to weakened assertions: failure of unit-norm surjectivity in the ramified dyadic extension Q_2(i); incompatible simultaneous functionals at conjugate split primes; omission of conjugation in the rank-one ideal P=(2+i); and deletion of stabilizer invariants for a sign representation. These are not counterexamples to the actual source statements.

Root independently read the full 702-line draft and checked the local norm and Gram--Schmidt proofs, CRT patching, both actions, the stabilizer inverse, principal-congruence fibers, conjugate-prime coefficient identity, rational evaluation, quotient mass, and all four examples. No mathematical defect was found. The Siegel agent independently read the same complete argument, found no mathematical defect, and requested that the residue maps and frames be stated explicitly as linear; this definition has been corrected. The subsequent Haar-normalization clarification only makes explicit the already stated normalized-measure convention.

Compilation and final snapshot hashes are recorded in the companion manifest and compile report. The next task is the actual intermediate coupling-coset chart comparison; it is not claimed complete here.
