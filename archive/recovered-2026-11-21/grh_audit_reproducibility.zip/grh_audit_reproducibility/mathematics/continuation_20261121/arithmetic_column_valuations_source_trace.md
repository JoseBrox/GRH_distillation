# Source trace: sharp column valuations

## Scope and status

The conventional fragment `arithmetic_column_valuations.tex` proves the finite
moment-to-kernel, local polynomial-lattice, stabilizer, incidence-lattice and
column-exponent arguments. It is conditional on the explicitly stated ordinary
theta moment and support theorem, the actual kernel's polynomial identification
and equivariance, and its theta/incidence commutation law. It does not claim a
proof of these inputs merely because a provider file declares them.

The exact source paths, hashes and read ranges are in
`arithmetic_column_valuations_source_manifest.json`, generated reproducibly by
`build_column_valuation_manifest.py`. There are 44 source files in this snapshot.
An entry marked partial means exactly the recorded ranges, not an exhaustive
review of that file's dependencies. No Lean build or kernel check is asserted by
this record.

## Actual route and normalizations

The final route runs through the bundle-point level-prime valuation theorem,
the true-column sharp bounds, the stability-lattice column chain, and the
selected/conjugate point-kernel estimates. The declarations in `KerIsTerm.lean`
are particularly useful for fixing the actual statements: the selected-place
kernel loss is `p^(f*N_i + sum sDiv)`, with source `L#` and target `L'`; the
conjugate-place kernel gains `p^(f*(t+1)/2)` and has target `L'#`.

`BlockTheory/GlobalSignature/JetSumTable.lean` states the exact finite simultaneous
approximations: the scalar is `p^(-f*N_i)` in the selected case and one in the
conjugate case. `SubstitutionAdjoint.lean`, `ExistsMulEqOfUnif.lean`,
`AdmissibleAdjointRationalPointPadicMatrix.lean`, `RenameMemDualWeyl.lean` and
`ExistsMulOfApprox.lean` implement the relevant polynomial substitution and
integral-coefficient passage. The replacement proof gives the explicit
determinant factor

    product_tau det(B_tau)^(s'_tau) det(B'_tau)^(-s_tau).

This factor is essential. The local kernel theorem is stated for source and
target representatives standard at every selected prime. A separate corollary
uses rational-unitary approximation and explicitly assumes the actual kernel
equivariance to transport the result to arbitrary representatives.

`NotDvdCardStabilizerForm.lean` supplies the original finite stabilizer argument;
the reconstruction gives a short Cauchy/cyclotomic proof. The precise prime bound
uses the absolute field degree `2f`, and does not confuse it with the relative
lattice rank. The character-factor proof retains the positive-power algebraic
condition needed for half-integral unitary infinity types, and separately proves
the norm-one ideal version used by the source.

The incidence-lattice equality is local at a fixed selected-type coefficient
prime. A global self-dual neighbor also changes its conjugate component, but the
embeddings into that coefficient prime see only the selected components. This
qualification is now part of the statement. Negative top weights are allowed in
the residue-condition removal estimate; the row-weight proof has the correct
direction in that case.

The accumulated column exponent is

    b_m = m*(2*sum W_tau + f*N_m)
          + ((t+1)/2)*|T|*m*(m+1)/2.

The proof uses `U_(i+1) K_i = p^(((t+1)/2)*|T|) K_i U_i` in this direction. It
applies to the source's modified initial lattice `p^A U_0^m S_0`, with `A>=0`;
it is not a statement about every vector of the unmodified class lattice.

## A closed replacement for modular representation theory

The source's target Weyl/dual-Weyl equality uses its closed-lowest-alcove provider.
The conventional reconstruction instead invokes the independently proved
`fock_hook_normalization.tex`: the normalization constant is the exact product of
hook lengths, and this scalar sends the dual-Weyl lattice into the Weyl lattice.
It is a unit when `width + rank - 1 <= p`. The source assumes the stronger
`spread = width + rank < p`, so every actual application is covered. This replaces
the modular simplicity input, without asserting equality at small primes.

## Ordinary theta input traced, not hidden

The relevant provider chain is `KernelJetsLevelPlaceIntegralMoments`,
`JetMomentsOfUnitPeriod`, `UnitPeriodTranslatesMomentsFinite`, and the normalized
vector and lattice-moment providers. All of these files were read as recorded in
the manifest. Their substantive content includes a common normalized CM period,
bounded measures for torsion translates, and finite translation/support
identities. These are stronger than separate bounds for ordinary power moments.

A new separate fragment, `ordinary_theta_moments.tex`, proves the Mahler
criterion, tensor-power descent and formal functional-equation components.
Further CM source and primary-literature verification is being recorded there,
not counted as a proof in this snapshot.

## Counterexamples and review corrections

The fragment gives six explicit counterexamples to false weakenings, including a
matrix-support counterexample satisfying the actual strict rank increase and
canonical polynomial model (`a=1`, `b=2`, `lambda=(0)`, `mu=(1,0)`, `s=0`,
`s'=1`, `F=1`, `A=(p^-1,0)`). The bounded-power-moment example is differentiation
at zero, which has a nonintegral value on the integer-valued polynomial
`binom(X,p)`. The small-prime Weyl/dual-Weyl example is `Sym^2` at two.

Root independently read the full mathematical draft. That review identified a
missing standardness hypothesis in the initial statement of the two-kernel
theorem, an out-of-model first counterexample, and the need to specify the
coefficient-prime localization of the incidence equality. All three corrections
are applied. The exact general-representative corollary now retains kernel
equivariance as a premise. Root's other checks of support duality, determinant
units, negative-weight removal and the triangular exponent passed.

The prior 101-page compilation with prerequisites succeeded; the finalized
snapshot is compiled again after these corrections. Standalone unresolved
references to omitted neighboring fragments are distinguished from errors in
the mathematical fragment in the compile record.
