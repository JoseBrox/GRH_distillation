# Independent review of the arithmetic complex reconstruction

Reviewer: QRH mathematics agent. Date: 21 November 2026 (UTC).

## Scope and conclusion

I read all 752 lines of arithmetic_complex.tex. I found no mathematical defect. This review concerns the complete conventional proof in that fragment, not an independent line-by-line review of every transitive Lean import. The source trace and source manifest are supplied separately by its author.

The proof supplies the geometric hypothesis in homology_torsion.tex: an exact augmented complex of permutation modules for GL_N(O_F), the stated ordered-tuple orbit count, the incidence bound p+2, and the stabilizer bound 3^(n N^2). It does not supply the remaining global strict Selmer class count or its arithmetic detection arguments.

## Delicate points checked

1. **Positive definiteness from integral lattice inequalities.** A negative real direction gives a negative rational direction. After this proves positive semidefiniteness, the box argument applied to G+epsilon I gives a determinant bound uniform as epsilon tends to zero, excluding an irrational singular direction as well. Thus the argument does not assume that a real nullspace contains an integral vector.
2. **Normal cones and compactness.** The dual functionals used are strictly positive on the nonzero semidefinite cone. Their coercivity on this cone makes sublevels compact. The minimum has a vertex, and local finiteness of the defining lattice inequalities gives only finitely many vertices on each compact sublevel. The later finite-cone assertion is proved over a fixed finite convex hull of dual functionals, as required.
3. **Closed convex nerve.** The proof uses an explicit induction on the number of nonempty faces, rather than an inapplicable open-cover theorem. A minimal empty intersection is strictly separated from the remaining compact convex intersection. Both half-cover nerves and their common section have fewer faces. Segment convexity proves the precise union and intersection identities. The chain Mayer--Vietoris filling includes degree zero and augmentation. Repeated ordered tuples cause no orientation problem. Passing to an infinite cover uses finitely many witnesses for the given finitely supported cycle and a finite cover of their compact convex hull.
4. **Common minimal columns.** The average of forms has exactly their common active vectors. If these do not span F^N, an F-linear annihilator supplies a nonzero semidefinite rank-one tuple. Subtracting a sufficiently small multiple preserves all inequalities but lowers the common positive minimizing functional. The resulting N columns form an F-basis; an O_F-basis is never asserted.
5. **Discriminant normalization.** With one embedding from each complex conjugate pair, the squared real embedding determinant is 2^(-d) D^N. A real Hermitian Gram determinant is the square of its complex determinant. This gives the displayed factor 2^d exactly. No CM involution of F is assumed.
6. **Integral matrix representatives without a principal ideal hypothesis.** For alpha in O_F, the additive group O_F/alpha O_F has order |Norm alpha|, hence this integer lies in alpha O_F. Consequently B=I(A) A^(-1) is integral. Equal residues modulo I give A^(-1)-Aprime^(-1)=X integral; both Aprime A^(-1)=1+Aprime X and its inverse 1-A X are integral. Thus the residue key actually determines a GL_N(O_F)-orbit. Counting all full matrix residues gives the stated exponent n N^2.
7. **Short-vector counting.** The Cramer estimate uses Cauchy--Schwarz both for matrix entries and the replaced column. For z=B y, the transformed energy is I^2, giving the claimed bound on every conjugate coordinate. Reduction modulo 2 R0+1 is injective because a nonzero algebraic integer cannot have every conjugate of modulus less than one. The proof counts N coordinates and then at most the real ambient dimension many determining active functionals for a vertex.
8. **Numerical exponent.** I checked I0 <= b^(2d), R0 <= b^(5d), the extra terms introduced by adding one, and the final comparison with 12(p+1)d^3 N for b=2 D d. The formulas are valid for N>=1 and n>=2, including n=2, N=1. The N=0 case is treated separately.
9. **Stabilizers.** Positive definiteness puts a stabilizer in a compact product of unitary groups, while its integral matrix realization is discrete. The resulting finite subgroup injects modulo 3 by the previously proved congruence lemma. The exponent is n N^2=dN, as stated.

## Counterexample searches and limitations

The natural potential failures are explicitly excluded by proved hypotheses: a semidefinite form would have an infinite unipotent stabilizer; arbitrary common minimal columns need not form an integral basis; closed convex covers require a separate nerve argument; and a real singular direction need not be rational. None supplies a counterexample to the actual statements. Nonprincipal ideal classes and the smallest permitted rank do not break the residue argument. No computational spot check is used in place of a proof.

The resulting geometric and homology torsion bounds are genuine closed components of the conventional reconstruction. They must not be represented as a proof of the different global arithmetic class-counting statement.
