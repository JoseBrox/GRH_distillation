# Arithmetic complex: source correspondence and read scope

Audit date: 21 November 2026 (UTC).

## Result and limits

The new fragment arithmetic_complex.tex gives a complete conventional proof of the geometric input formerly left conditional in homology_torsion.tex. It constructs the actual ordered normal-cone nerve for GL_N(O_F), proves that its augmented permutation complex is exact, proves the incoming incidence bound p+2 and stabilizer bound 3^(n N^2), and proves the exact submitted orbit bound

    I0^(1+dN) ((2 R0+1)^d+1)^(dN(p+1))
       <= (2 D d)^(12(p+1)d^3 N),

where d=nN, I0=D^N d^d, and R0=N^N I0^2.

Together with the already proved integral homology arguments, this removes the geometric condition from the exponent-13 homology torsion estimate. No class-number estimate is used in this component. This does not reconstruct the different global strict Selmer class count, its finite-field homology classes and diagonal relations, class-field detection, or odd-degree rational rank input. It is not a renewed formal-kernel certification. No source file was changed, no full export was rescanned, and no Lean compilation was rerun in this task.

The manuscript uses elementary foundational algebraic number theory: the integral basis of O_F, the field norm as determinant, and nonzero discriminant. It proves the needed embedding volume formula and the lattice box estimate. It gives alternative full proofs where the submitted source imports linear-algebra or geometry helper files. Reading a theorem's source below does not assert that every transitive import was read.

## Exact used route

All paths in the next table are relative to

    sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/

| Source | Exact role | Conventional result |
|---|---|---|
| ModularityArgument/ClassCounting/ExponentLe.lean, lines 71–125 | torsAll invokes KT.tors_le and KT.orbnum; sTors specializes N=4E+6. The earlier exponent_le is numerical. | AC20 follows from the stronger numerical estimate already proved in homology_torsion.tex. |
| HermiteNormalForms/Assembly.lean, lines 14–30 | sx_exact invokes the actual Sx nerve; tors_le uses that exactness, orb, and stab. | ac-exact, ac-orbit, ac-stabilizer. |
| HermiteNormalForms/Assembly.lean, lines 32–69 | Different K-theory numerical wrappers torsBound and torsBoundPow. | Read to distinguish them from the actual direct torsAll route; not substituted for it. |

The submitted source also defines a strict chain complex Simp of cells in SmulStrictMono.lean, lines 218–242. That is not the Sx complex consumed by Assembly.sx_exact. The new manuscript explicitly reconstructs Sx, which consists of ordered tuples of vertices with repetitions allowed. It does not silently replace Sx by a triangulation or an oriented cellular complex.

## Definitions and geometric exactness

| Source | Definition or argument checked | Manuscript correspondence |
|---|---|---|
| HermiteNormalForms/SmulStrictMono.lean, lines 11–81 | Lat=O_F^N, Gm=GL_N(O_F), HS=Hermitian tuples at InfinitePlace, q=sum over one representative of each complex pair, Pos and Ry. | AC1; one place from each conjugate pair, with no assumption that F has a field involution. |
| Same, lines 128–169 | pull A=conjugate-transpose congruence; left group action uses inverse; q_smul. | AC2 and its covariance identity. |
| Same, lines 244–259 | I0, RR, orbBound, ColsMin, norm determinant and nearVec. | AC9 and the definitions of T(A), I(A), R0. |
| HermiteNormalForms/SmulNeZeroLat.lean, lines 13–94 | q indexed only by nonzero integral vectors; Psd; Vx; ordered Sx at 76; face deletion at 83; nearVx. | AC4–AC7; T(A) and V(A). |
| ConvexNerveComplexes/NerveFaceClosed.lean, lines 7–56 | Integral tuple chains, deletion boundary, exactness including augmentation, poly, local finiteness, IsVert, posDual, normalCone, simp and Good. | ac-positive-gram, ac-polyhedron, ac-normal-cover, ac-exact. |
| HermiteNormalForms/RynePlace.lean | Identity tuple belongs to Ry by norm of a nonzero algebraic integer. | First part of ac-polyhedron. |
| HermiteNormalForms/Grampd.lean and Gramlow.lean | Lattice lower bound implies positive definiteness and a determinant bound. | ac-positive-gram gives the stronger det G >= r^(-r), by a proved box argument and positive perturbation. |
| HermiteNormalForms/Rypos.lean | Real lattice coordinates transfer positivity to each Hermitian place. | ac-polyhedron; the real embedding map is shown invertible using the discriminant. |
| HermiteNormalForms/Locfin.lean | Uniform positive lower bound near a positive tuple makes the integral inequalities locally finite. | AC3. |
| ConvexNerveComplexes/Sublevel.lean | Strictly positive dual functionals have compact sublevels on the polyhedron. | ac-normal-cover. |
| ConvexNerveComplexes/ExistsVert.lean | A minimum is achieved at an extreme point, which satisfies IsVert using local perturbation. | ac-normal-cover and the equivalence following AC4. |
| ConvexNerveComplexes/VertFinite.lean | Compact subsets of the polyhedron contain finitely many vertices, by finite active sets. | ac-normal-cover. |
| ConvexNerveComplexes/ConeFinite.lean | Normal cones meeting a finite convex hull have vertices in a finite union of compact sublevels. | ac-normal-cover. |
| ConvexNerveComplexes/DualConvex.lean | Positive dual is convex; normal cones are closed and convex. | AC5. |
| ConvexNerveComplexes/NerveCompact.lean | Finite closed-convex cover exactness through separation and induction on the number of faces. | ac-convex-nerve, with a full nearest-point separation proof and chain-level union argument. |
| ConvexNerveComplexes/NerveConvex.lean | Each finitely supported cycle reduces to a compact finite convex hull of witnesses. | ac-exact. |
| ConvexNerveComplexes/AcycSimp.lean | Assembles cover, local finiteness, and convex nerve exactness. | ac-exact. |
| TorsionBoundsChains/TupExact.lean | Identifies supported tuple chains with free modules on the tuple subtype, including augmentation. | AC7 is defined directly on the subtype, so no comparison lemma is needed. |

The finite closed-cover argument does not invoke the open-cover nerve theorem without hypotheses. It includes repeated tuples, the augmentation, and the degree-zero union argument. Finiteness is proved only after restricting to a convex hull of finitely many chosen witnesses; no global local-finiteness assertion in the dual cone is assumed.

## Common minimal columns and determinant normalization

| Source | Checked content | Manuscript correspondence |
|---|---|---|
| ConvexNerveComplexes/SimpSpan.lean | Average of a tuple's forms has exactly its common active vectors; a semidefinite direction annihilating those vectors would lower a common positive minimizing functional. | ac-common-minima. |
| HermiteNormalForms/Spanpsd.lean | A missing F-linear direction gives a nonzero semidefinite rank-one tuple from an annihilating F-linear functional. | ac-common-minima. |
| HermiteNormalForms/ColsMinSmul.lean, lines 13–32 | sx_basis chooses N common minimal F-independent columns; group covariance preserves these columns. | The paragraph after ac-common-minima and the proof of ac-orbit. |
| HermiteNormalForms/Gramdet.lean, all 100 lines | Exact 2^d det(real Gram)=D^N (product det H_v)^2; conjugate embeddings are paired correctly. | AC12, derived directly from the discriminant covolume. |
| HermiteNormalForms/Detlow.lean | I0 times the product of Hermitian determinants is at least one. | AC10, from the stronger box determinant bound. |
| HermiteNormalForms/DetPull.lean, lines 35–86 | Common minimal columns bound every transformed diagonal by one; product determinant equals norm determinant times original product; resulting norm and individual determinant bounds. | AC11–AC13. |

The common columns are an F-basis, not necessarily an O_F-basis. This distinction is essential and explicit. Total imaginarity is used to obtain the real embedding isomorphism from one complex place per pair and in the product norm identity. A CM assumption is not used.

## Integral matrix reduction and counting

| Source | Checked content | Manuscript correspondence |
|---|---|---|
| HermiteNormalForms/Scinv.lean | I(A) belongs to det(A) O_F, so B=I(A) A^(-1) is integral. | ac-scaled-inverse: proved by the finite additive quotient O_F/det(A)O_F. |
| HermiteNormalForms/Hnfeq.lean | Equal scaled inverses modulo I yield g=1+A'X and g^(-1)=1-AX, both integral. | AC15. |
| HermiteNormalForms/Hnfone.lean | Keys are full N by N matrices over O_F/I, not ideals or principal ideal classes. The number of keys is I^(nN^2). | ac-scaled-inverse. |
| HermiteNormalForms/Hnf.lean | Sum representatives over 1 <= I <= J to obtain J^(1+dN). | ac-scaled-inverse. |
| HermiteNormalForms/Cramer.lean | Cauchy–Schwarz bounds entries and the replaced column; determinant expansion gives det(G)|c_a| <= N!. | ac-cramer, then N! <= N^N. |
| HermiteNormalForms/Nearcoord.lean | B=I A^(-1), q_(pull A H)(By)=I^2, and the determinant lower bound give conjugate coordinate radius RR. | AC18. |
| HermiteNormalForms/Cntconj.lean | Reduction modulo 2R+1 injects algebraic integers whose conjugates are bounded by R, because all conjugates of the difference quotient have modulus less than one. | ac-short-count. |
| HermiteNormalForms/Nearvec.lean | B acts injectively on vectors; bound all N coordinates to get (2RR+1)^d. | First half of AC17. |
| HermiteNormalForms/FiniteSubfamilySpansDual.lean | A vertex is determined by at most the ambient real dimension many active functionals. | Second half of ac-short-count. |
| HermiteNormalForms/Nearvx.lean | Counting determining subsets yields ((2RR+1)^d+1)^(dN). | Second half of AC17. |
| HermiteNormalForms/ColsMinSmul.lean, lines 34–75 | Move a common minimal column matrix to a bounded representative; all tuple vertices lie in its nearVx set. | First inequality in AC19. |
| HermiteNormalForms/Orbnum.lean | Pure arithmetic estimates for I0, RR and the exponent 12. | Second inequality in AC19, with all inequalities displayed. |

The proof of the matrix representative bound makes no principal ideal domain assumption. The term “Hermite normal forms” in the directory name does not mean that ordinary integral echelon reduction over O_F was assumed. The concrete source argument is the scaled-inverse residue argument reproduced in full.

## Stabilizers and adversarial checks

HermiteNormalForms/Stabfin.lean proves finite stabilizers by their action on finitely many minimal vectors spanning F^N. The manuscript uses the alternative compact-unitary-group/discrete-lattice proof, under precisely the now-proved positivity hypothesis. HermiteNormalForms/ImportsAlt.lean then uses the mod-3 injectivity theorem for finite matrix subgroups. The same elementary theorem was already fully proved and independently checked in homology_torsion.tex, Lemma ht-congruence-three.

Checks addressed:

- N=0 is separated; the complex is a point nerve with a generator in each degree, and all stabilizers/orbits have order one. The simplified bound using d is only stated for N>=1.
- n=2 and N=1 satisfy all dimension inequalities; no large-rank assumption is present.
- Global freeness of arbitrary O_F-submodules is not assumed.
- The norm index is positive, and its scaled inverse is integral before residue reduction.
- Equal residue keys imply the same orbit; the converse is not asserted or needed.
- No orientation character is dropped: the actual complex is a permutation complex of ordered tuples.
- The discriminant factor is checked symbolically at F=Q(i), N=1.
- A degenerate form with infinite unipotent stabilizer is exhibited but explicitly excluded by the defining Ry inequality.
- The closed convex nerve proof includes the augmentation and does not use an unjustified open-cover theorem.
- No counterexample satisfying the actual hypotheses was found.

No numerical experiments were needed for these conclusions: each relevant assertion is proved. The two displayed examples check normalizations and the role of positivity; they are not proof substitutes.

## Precise read scope and intentional exclusions

The accompanying arithmetic_complex_source_manifest.json lists every fully read source file, its total line count, read interval and SHA-256. A truncated read at the previous context boundary was repeated before those files were included in this full-read list. The list covers 40 Lean files in the geometric/exponent route, plus the complete local homology fragment and its source trace.

The following imported helpers were not fully read in this component, and no such reading is claimed: HermiteNormalForms/Psdcone, LowbdSmul, Rankhs, RealVec, Realsurj, Blockdet, Grampsd, Hadam, Exbasis, Cardsub, Cardsep and Mink3; ConvexNerveComplexes/Perturb, NerveSep, NerveCut, AcycUnion, AcycCone and AcycDirected; and Formalism/PeriodIntegrals/UnitaryGroupMassFormula/AdelicClassFiniteness/HmkFactor. Their needed ordinary mathematical conclusions were proved directly in the fragment or, for the mod-3 theorem, in the already reviewed homology fragment. This is an exact mathematical reconstruction of the used interfaces, not a claim of line-by-line coverage of all transitive Lean imports.

ClassCounting/LemmaKOfSteps and the more global class-counting providers were not newly audited here. Their remaining assertions are kept distinct from the now-proved arithmetic complex.

## Review and compilation

The parent agent independently read the complete initial 751-line draft and explicitly checked the finite closed-convex nerve induction, including degree zero; compact normal-cone finiteness; common minimal F-basis; discriminant normalization; scaled-inverse residue count; coordinate count; and orbit exponent. It reported no mathematical defect. Its sole requested precision edit replaced “admit no counterexample” by “No counterexample satisfying the actual hypotheses was found”; this edit was applied.

The isolated XeLaTeX check compiles to eight pages. The only unresolved citations/references in that isolated wrapper are cross-references to the main homology fragment and the shared source bibliography. There are no overfull boxes after the two display-alignment fixes. This is typesetting verification, not mathematical or formal-kernel certification. The QRH agent subsequently reviewed the entire fragment independently, including the closed-convex nerve and arithmetic constants, and found no mathematical defect. Its detailed record is arithmetic_complex_peer_review_qrh.md.

