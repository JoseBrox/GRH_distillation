# Independent review of the additional-coset class comparison

Reviewer: formal-verification lane. Date: 21 November 2026.

## Outcome

I read all 486 lines of `arithmetic_coupling_classes.tex` and found no mathematical defect. The proof establishes the exact reference-character comparison claimed. It explicitly does not prove transfer for arbitrary nontrivial auxiliary characters, the theta-period identities, or the spectral and mass inputs.

One wording clarification was requested: in the first counterexample, say that the induced quotient map `L^-(N)/L(N) -> A_n` need not be injective after weakening the uniformizer condition. The map from `L^-(N)` itself already has kernel `L(N)` even in the correct theorem. This is a clarification of what the displayed example proves, not a mathematical gap in the proof.

## Checks performed

1. **Actual uniformizers.** The conjugate principal ideals have equal absolute norm. Their product is `(p)` in degree 2f, so each has norm p^f. The f distinct selected primes all have norm p; containment of their product and equality of norms imply `(bar pi)=product P_i` exactly. Coprimality with `(pi)` gives valuation_P(p)=1. This works at p=2 and does not assume unramified means residue degree one.
2. **Global existence for every lattice.** The CRT construction accommodates the possibility that t_P is divisible by several selected primes. Choosing e_P in each Q^(v_Q(t_P)) for Q≠P makes e_P/t_P integral at Q, and multiplying by t_Q forces every cross term into Q N_Q. The diagonal residue is precisely a_Q. No global free basis is used. Empty selected-prime sets and n=0 are covered.
3. **Kernel and local coordinates.** The equivalence `b_P(t_P y)=0 iff y in N_P` uses the proved valuation-one hypothesis. A compatible frame change is congruent to the identity modulo P, so it acts trivially on t_P^(-1)A_P^n/A_P^n. The tuple of coordinate cosets is therefore canonically determined by the residue vectors even on two different lattices.
4. **Equivariance and quantifiers.** The new frame is h_P b_P gamma^(-1), while the new coset is gamma Y; their actions cancel to give a'_P=h_P a_P. Every vector is realized on every decorated lattice before selecting orbit representatives. The preferred representative consequently depends only on the finite residue orbit, with no dependence on a later lattice or prime choice.
5. **Full stabilizers.** The fiber over a selected vector a has acting subgroup H_(b,a), with a fixed as a vector, not as a projective line. `Stab_(U x H_b)(d,a)=Stab_(U x H_(b,a))(d)` is an equality of groups. The rational component and restricted character are retained, not merely the order of an image. The reference datum has no auxiliary group kernel.
6. **Coefficient transport.** Restriction and extension of equivariant functions are inverse. If two chosen group elements send a to a', their quotient belongs to U x H_(b,a), and the transformation law cancels exactly. The integral lattice depends on the same functional kernel lattice and fixed weight, not the added coset. Finite-order character values are integral units and have complex absolute value one, so both integral transport and norm transport are valid.
7. **Level characters and Haar measure.** Right multiplication changes frames by inverse residue matrices, giving chi(r(k))^(-1). Surjective reduction identifies the subgroup index with the vector orbit size. For one fixed Haar measure, volume(K_(b,a))=volume(K_b)/|H_b a|. The finite class sum itself has weights 1/|stabilizer| and only becomes the quotient integral after multiplication by this subgroup volume. No unnoticed |H_b| or reciprocal is inserted.
8. **Forgetting versus selecting a coset.** The fiber above a decorated class is its stabilizer's orbit set on all residue vectors. Summing 1/|Gamma_a| gives |A_n|/|Gamma|. This differs correctly from the restriction to one chosen piece, where no factor |A_n| is inserted.
9. **Endpoint and counterexample checks.** The actual m≥2 makes the first and last steps carry the empty-set datum. The penultimate step carries nonempty additive cosets. The inert-prime, ramified-prime, line-stabilizer, and weighted-orbit counterexamples all have the stated values; each violates an explicitly retained hypothesis and is not an actual source counterexample.

## Independently read source scope

All paths below are under `sources/lean/src/`.

- `Formalism/LocalToGlobal/Columns/AbelianHostFieldConditions.lean`, 174–233: actual selected-prime data.
- `Formalism/LocalToGlobal/Columns/FiniteSumNonzeroLargeDepth.lean`, 808–829 and 1115–1140: qOf, locLat, and ybSet definitions.
- `Development/AbelianVarietyTheory/Definitions/AutomorphicMembership/XiAtPenultimateEqXiCpl1.lean`, 105–145: exact penultimate versus empty-set distinction.
- `Development/AbelianVarietyTheory/Definitions/AutomorphicMembership/LatAtLattice.lean`, 1–90: coordinate cosets, preferred representatives, reference chain definitions.
- `Development/AbelianVarietyTheory/Proofs/IwasawaDecomposition/CouplingCosetInFramesEqIffReductionEq.lean`, complete 183 lines.
- `Development/AbelianVarietyTheory/Proofs/IwasawaDecomposition/ColumnPointEqOfDecoAndCosetReduction.lean`, complete 102 lines.
- `Development/AbelianVarietyTheory/Proofs/IwasawaDecomposition/ExistsCouplingCosetWithGivenReduction.lean`, complete 136 lines.
- `Development/AbelianVarietyTheory/Proofs/IwasawaDecomposition/ExistsMemberStepCharts.lean`, 150–374, 380–425, 458–487, and 521–570: residue action, subgroup and character, preferred-representative quantifiers, full class bijection/stabilizers, and final reference-step assembly.
- `Development/AbelianVarietyTheory/Proofs/DecoratedLatticeProofs/RelIndexCouplingCosetStabilizerEqChartWeight.lean`, complete 113 lines: local quotient action, orbit index, and multiplication by the ambient level index.

The previously reconstructed coefficient transport, class finiteness, and base adelic comparison are used as prior results. I reread `arithmetic_classes.tex` 460–650 for the conjugate coefficient convention, invariant lattices, equivariant functions and Haar normalization. This record does not claim a new full transitive source or Lean-kernel audit.

Reviewed TeX SHA256: `6e1b5798656b71dca954eb3761756ccf65c930efe077abb71a3e433e627728b0`.
Review recorded at UTC: 2026-11-21T01:05:52.872545+00:00.

Follow-up: the requested clarification now explicitly refers to the induced quotient map. The corrected sentence was reread and is accurate. Updated TeX SHA256: `6e1b5798656b71dca954eb3761756ccf65c930efe077abb71a3e433e627728b0`; UTC 2026-11-21T01:06:09.841584+00:00. No change to the mathematical proof.
