# Review of the additional cosets and class decomposition

Reviewer: root. Date: 21 November 2026.

The full mathematical fragment `arithmetic_coupling_classes.tex` was read. The final wording change clarifies that injectivity concerns the induced map on the quotient. No mathematical defect was found.

The selected-prime hypotheses imply the exact principal ideal factorization of the conjugate prime element. Coprimality with its conjugate then gives valuation one for the rational residue cardinality, including at 2. This is stronger than an unramifiedness assumption, which would not suffice. The simultaneous CRT construction realizes every prescribed residue vector in the quotient of the intersections of local modules; the proof does not incorrectly call those intersections finitely generated lattices. Empty prime sets and rank zero are accounted for.

The coordinate coset is independent of a compatible local frame lift because the change of frame is congruent to the identity and the permitted pole has order at most one. The residue-frame group acts on vectors with the stated orientation. The orbit decomposition uses vector stabilizers, retains the full rational-unitary stabilizer, and preserves the inverse level character. Choosing preferred representatives does not introduce a circular quantifier dependency.

For every orbit piece the Haar volume decreases by the exact subgroup index. That factor is not inserted into the finite class sum, which has its separate inverse stabilizer weights. The weighted fiber identity distinguishes one orbit piece from adjoining all residue cosets. The inert-prime, ramified-prime, vector-versus-line, and stabilizer-weight examples correctly illustrate deleted hypotheses; none contradicts the actual source statement.

The fragment proves the actual reference-character class comparison. Arbitrary nontrivial auxiliary characters, their level transfer, and the theta identities are explicitly left to subsequent sections. This review is not a new Lean kernel replay.
