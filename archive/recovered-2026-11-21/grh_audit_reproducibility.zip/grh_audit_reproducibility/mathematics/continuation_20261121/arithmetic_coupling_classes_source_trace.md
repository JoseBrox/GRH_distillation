# Additional cosets and the actual reference-step classes

Date: 2026-11-21. Fragment: `arithmetic_coupling_classes.tex`.

This continues the live class comparison of `arithmetic_classes.tex`. The companion manifest records the exact source ranges read. It does not claim a transitive audit of imports or a fresh Lean kernel certification. No counterexample to an actual claim in these ranges was found.

## Actual definitions and scope

The live assembly is `TC.colsTiedSym_std` through `FormSym.formsTiedSym_std`, already read in full and recorded in the preceding class manifest. The latter explicitly constructs every intermediate chart at `I.mu0`, the reference character, not at an arbitrary auxiliary twist. `I.twistPrimes_reference_tuple_eq_empty` is therefore an actual hypothesis already proved in the construction. The assembly still contains further transfer and period assertions; they are not declared proved by this fragment.

`FiniteSumNonzeroLargeDepth.lean:1121--1132` defines the intersection of localized lattices and its permitted additive cosets. At a type prime the exponents are -1 for a representative and 0 for its period module. At an auxiliary character prime they would be -M and M. For the reference tuple the auxiliary set is empty, so only the former case occurs. `XiAtPenultimateEqXiCpl1.lean:105--141` proves that this coset datum occurs exactly when j+1=m; at every other step the datum is the empty set. `LatAtLattice.lean:1--75` gives its coordinate-coset definition and the exact preferred-representative condition.

The new conventional fragment respects the distinction between an empty set away from the penultimate step and the nonempty coset of an intersection at that step. It does not call either intersection a finitely generated lattice.

## Essential selected-prime condition

`qOf P` is exactly the absolute norm of P, as defined in `FiniteSumNonzeroLargeDepth.lean:817`. `AbelianHostFieldConditions.lean:174--232` states the actual prime data: for each of the two distinct rational primes g, there is an integral pi with pi times its conjugate equal to g, coprime conjugate ideals, exactly f selected divisors of the conjugate pi, and norm g for each selected prime.

`GlobalTwisting/RedPDivOfUnit.lean:174--235` proves `qOf_notMem_sq` from these data by comparing ideal norms. The new proof gives the simpler exact ideal identity `(bar pi)=product P`, and then valuation_P(g)=1 by coprimality. No assumption that every unramified prime has norm equal to a uniformizer is made. No odd-prime restriction is required.

The inert prime (3) in Q(i) and the ramified prime (sqrt 2) in Q(sqrt 2) are explicit counterexamples when the valuation-one hypothesis is deleted. They do not contradict the actual selected-prime hypotheses.

## Three actual providers, all read in full

1. `CouplingCosetInFramesEqIffReductionEq.lean` identifies equality of coordinate cosets with equality of the residue sets. At the penultimate step each such set is a singleton, namely the residue of q_P y in the chosen frame. The key local equivalence uses q_P not in P squared.
2. `ColumnPointEqOfDecoAndCosetReduction.lean` proves that the underlying decorated lattice and those singleton residues determine the entire reference point. Absence of auxiliary local bases is used explicitly.
3. `ExistsCouplingCosetWithGivenReduction.lean` realizes the same residue on an arbitrary other decorated lattice. Its denominator-clearing multipliers are replaced by an explicit finite CRT construction in the new proof.

The ordinary theorem proves a little more at this point: for each decorated lattice the entire quotient `L^-(N)/L(N)` is canonically the full product of residue vector spaces. It proves simultaneous surjectivity for arbitrary prescribed vectors, not merely for one already realized point. This removes any dependence on an unavailable representative.

The coordinate-lift calculation also proves the invariance under rational unitary changes and the exact left matrix action under residue-frame changes. Principal congruence matrices act trivially on `t_P^(-1) A_P^n/A_P^n` precisely because t_P has valuation one.

## Complete live intermediate assembly

`ExistsMemberStepCharts.lean` was now read in full, all 570 lines. The initial 1--180 and final 535--570 ranges were recorded earlier; this continuation covers the entire middle proof as well.

* `bar_ya` proves the same frame action `a -> h a` used in the new theorem.
* `chH`, `chG`, and `chLam` intersect the existing product subgroup with the stabilizers of the residue sets and restrict the character. As the sets are singletons, the condition fixes a vector, not its projective line.
* `lev_iff` and `chr_eq` derive the exact inverse level character from the inverse right frame action. The extra Q-group is trivial at the reference tuple.
* `cls_bij`, `stM_range`, and `stM_inj` give the class bijection and preserve the rational unitary stabilizer. The ordinary slice proof identifies the full stabilizer groups directly.
* `bar_norm` proves that preferred representatives have the same residue if the original residues agree. The proof chooses only within a fixed finite residue orbit, so there is no quantifier cycle with the lattice or prime selection.
* `chart_of` combines those facts with the actual adelic point existence and the standard coordinate-lattice identity from the preceding fragment.
* `exists_charts` takes the finite range of `(index, coordinate coset)` on preferred representatives. The new proof identifies this range with the finite collection of residue orbits. Endpoint index uniqueness and m>=2 give a unique chart at both ends.

Thus the new ordinary decomposition is the actual reference-step decomposition used in `formsTiedSym_std`, not a statement that every arbitrary decorated object is automatically an adelic class.

## Stabilizer index and weights

`RelIndexCouplingCosetStabilizerEqChartWeight.lean` was read in full. Its essential proof is orbit--stabilizer for the action of an integral local matrix subgroup on an additive quotient. Its final theorem multiplies the corresponding relative indices to obtain the local chart weight. The ordinary proof retains exactly that index orientation.

For the reference piece, surjective residue reduction gives `[K_b:K_(b,a)]=[H_b:H_(b,a)]=|H_b a|`; a fixed Haar measure gives `vol(K_(b,a))=vol(K_b)/|H_b a|`. The weighted finite class norm does not acquire that factor by itself. The fragment also proves the exact sum over enhanced classes lying above one decorated class, with stabilizer of each vector retained. This prevents the distinct operations of selecting one orbit and adjoining all cosets from being confused.

## Remaining scope

The reference-step class objects, their integral coefficient lattices, their characters, and their norm weights are now reconstructed using the preceding class and coefficient results. The arbitrary nontrivial auxiliary-character transfer is the next source-specific component. The actual theta/period identities and automorphic spectral or mass inputs remain separate. The numerical controls attached to this fragment check small residue groups and both valuation counterexamples; they do not substitute for its proofs.
