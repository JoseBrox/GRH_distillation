# Independent review of arithmetic_lattices.tex

Reviewer: formal_verification subagent. Date: 21 November 2026.

## Scope and conclusion

I independently read the complete 540-line fragment, in the ranges 1–285 and 285–565 of the then-current file. I checked the arguments as conventional mathematics, rather than relying on the original Lean proof, compilation, or numerical checks. No mathematical defect was found. This review does not certify any later period-map construction or analytic argument.

## Checks

1. **Hermitian dual and degree.** Local elementary-divisor exponents of the Hermitian dual occur with opposite signs at the conjugate prime. Equal residue norms at conjugate primes give the stated indices, without assuming the prime set is disjoint from its conjugate. For the kernel of the nonzero residue functionals, Chinese remainders give the exact index. The two dual indices and the factor of two in the degree are consistent with the ordinary degree normalization. The standard free self-dual lattice has degree zero.

2. **Finite stabilizers.** Positive definiteness makes the rational lattice isometry group finite by bounding the images of an integral basis. The local argument for a finite-order matrix with unipotent reduction correctly proves only that its order is a power of the residue characteristic. If the prime-to-characteristic part is congruent to the identity, successive squaring of the ideal of matrix entries proves it is the identity. The argument does not discard possible order-two elements in residue characteristic two. Two distinct residue characteristics then force identity. The single sufficiently large prime alternative follows from the degree of the cyclotomic polynomial of a nontrivial prime-order rational representation.

3. **Poisson summation.** The proof has the correct reciprocal covolume and Gaussian scaling. Absolute convergence follows from lattice point counting. The comparison of the two shifted Gaussian sums uses the dual-lattice gap and monotonicity in the required direction.

4. **Transference constants.** In dimension D at least two, put m=D/2. The chosen parameters give bases strictly below 45/68 and 1/6. Since m is at least one, their contribution is at most 45/68+1/3=203/204, a contradiction. The elementary exponential lower bounds used for these constants are valid. The resulting covering radius bound is D/(2 lambda), and the short-vector span argument gives the final D/lambda bound, with the discreteness gap used correctly. Dimension one is handled separately.

5. **Codifferent estimate.** For a vector in the Euclidean trace dual of the Hermitian dual lattice, the pairings lie in the codifferent. Multiplication by the different places the vector in the Hermitian dual lattice. Applied twice, this gives h(x,x) times the square of the different as an integral ideal. Its norm is at least one, so the factor involving the absolute field discriminant is squared. The arithmetic–geometric mean inequality therefore gives the stated lower bound for the first Euclidean minimum. The trace dual lies in the rational vector space because the trace-pairing Gram matrix is rational.

6. **Extraction of independent vectors.** The real short vectors span the underlying rational space, and a subset gives a basis over the number field. Dividing the trace norm by the field degree gives exactly the stated mean bound n squared times rho squared. No global free-module assumption is made for the general lattice.

7. **Boundary examples.** The examples correctly show why the finite-order condition, positive definiteness, integrality, and conjugate-prime module structure cannot simply be suppressed. The zero extension of a localized residue functional is only a function, and the example correctly shows that it need not be additive on the ambient vector space.

## Result

The fragment proves its stated arithmetic degree and short-dual-vector inputs. No counterexample satisfying its actual hypotheses was found. All counterexamples in the fragment violate a hypothesis that is explicitly retained.
