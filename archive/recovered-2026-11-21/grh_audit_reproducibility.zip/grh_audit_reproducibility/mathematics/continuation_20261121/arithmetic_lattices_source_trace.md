# Decorated lattices, stabilizers, and short Hermitian dual vectors

Date: 2026-11-21. Conventional proof: `arithmetic_lattices.tex`. Exact source-read ranges and SHA-256 hashes are in `arithmetic_lattices_source_manifest.json`. The fragment is a mathematical reconstruction, not a claim that this continuation recompiled or certified the entire formal development.

## What is closed

The fragment proves: an explicit initial decorated unimodular lattice; the common residue-kernel's index and ordinary determinant degree; the actual two-prime stabilizer argument, including ramified primes and prime two; an elementary Gaussian Euclidean covering/independent-vector transference bound; the codifferent lower bound; and the short independent Hermitian dual vectors required by the coefficient maps. Their substitution gives exactly ordinary degree `-log(T)/2` and mean squared norm at most `n^2 rho_E^2`, where the number-field degree is `d=2f`, the relative rank is `n`, and the real dimension used in transference is `dn`.

No part of these arguments uses QRH, a real-zero theorem, or GRH. The source's stronger discriminant-module decomposition is not needed for its degree. Our degree proof works even when the finite set of selected primes meets its conjugate; the stronger split-module assertion does not, as the explicit ramified-prime example shows.

## Decorated objects and the exact kernel lattice

Paths in this paragraph are relative to `sources/lean/src/Formalism/LocalToGlobal/Columns/`.

* `StdLatUnimodular.lean:1--220` defines the standard Hermitian space, decorations, local residue maps, frames, the common kernel `Deco.L`, and its Hermitian dual `Deco.Lsh`. `Deco.Ok` requires additivity only on the localization and a zero extension outside it. The conventional definition and its counterexample preserve this distinction.
* `StdLatUnimodular.lean:470--675` proves the standard lattice's unimodularity and the validity of its last-coordinate residue functionals and full residue frames. The base object is explicit, not an abstract existence hypothesis.
* `DecoOwed.lean` proves extension of a residue-linear map from a lattice to its localization. The fraction formula in the fragment is a direct shorter proof.
* `Record.lean:1805--1810` makes every recorded class set nonempty by using this base decoration; the read range was 1740--1830.
* `DecoFin.lean:2112--2412` contains the CRT residue vectors, dual-module comparison, and the actual quotient assertion. `Deco.Ok.Lsh_quot_L` explicitly assumes no selected prime is conjugate to any other selected prime. `card_Lsh_quot_L_of_ok` substitutes the actual hypotheses: `f` primes, each of norm `T`, giving cardinality `T^(2f)`. We read 2080--2505, including the following norm/principal-generator argument. The conventional degree proof replaces the long quotient description by the elementary identity `[L#:N]=[N:L]` and therefore requires fewer hypotheses.
* `RecLevelCls.lean:460--535`, especially `colBase_index` near 517, identifies the initial common-kernel lattice and its dual index. The earlier adelic-surjectivity proof is not claimed as reviewed here.
* `BrpStarLatLattice.lean:420--470` supplies the degree/slope substitution for the actual representatives. Its source uses doubled slopes; the new fragment states ordinary degree and ordinary slope, followed by the explicit factor-two translation.

The source definition `Formalism/SharpRestriction/GlobalSchurBounds/FlipTwoThree.lean:68--92` confirms that `LatT` consists of integrality plus the additive-group index in the Hermitian dual. Its index is not the index of the kernel in the unimodular ambient lattice: the latter is `T^f`, while the former is `T^(2f)`.

## Actual adm3 provider: two primes, not reduction modulo three

Paths are relative to `sources/lean/src/Formalism/LocalToGlobal/GroupLattices/`.

The actual chain is:

`TrivialTransfer/SmallOrderPrimeLogSumBound.adm3`
→ `GramTotallyDefinite.stabZero_rec`
→ `card_stab` and `trivStabU`
→ `GenCoprime.gen_triv`.

All four files were read in full. `trivStabU` uses the level's local lattice preservation at every place, and its upper-unipotent reductions at two distinct selected rational primes. It obtains local field factors from the split-place data. The field embeddings used to pull equality back to the rational matrix are injective. `gen_triv` first obtains finite order from the definite adelic stabilizer, extracts a power of the first prime, then applies the prime-to-second-prime argument. The conventional finite-order lemma states exactly the common mathematical content.

`TrivialTransfer/OneAddPowOfSq.lean` was read in full. Its `unip_pow`, `cong_coprime`, `unip_coprime`, and `iwU_coprime` use the separated maximal-ideal filtration and invert only integers prime to the residue characteristic. The ordinary proof gives the same implication by successive doubling of the ideal power. It is valid when the residue characteristic is two or the local field is ramified.

`TrivialTransfer/FiniteStabAtOfLocal.lean` was read in full. It proves bounded-denominator comparisons before invoking a definite adelic stabilizer theorem. The new argument supplies an independent elementary replacement for the required finiteness: intersect the adelic translate with the rational vector space, sandwich it between two scalar multiples of a full lattice, and use bounded images of a lattice basis under isometries. It does not assume strong approximation.

`StabilizerCount/StabiliserTrivialOfTiedChain.lean` was read in full: it transports cardinality-one stabilizers to the twisted chain through the actual class/stabilizer equivalences. It is a transport statement, not an independent proof of the equivalences.

A different decoration route occurs in `Columns/DecorationStabilizerTrivialUnipotent.lean`, read in full. It uses a **single** rational prime with `p-1 > [E:Q] n`; the `isometry_unipotent_mod_eq_one` and `Deco.stab0` lemmas are near 440 and 497, and the actual decoration conclusion at 631. The fragment proves this alternative by the rational cyclotomic degree bound. Only the initial definitions in `Formalism/GL3MeanSquares/RationalMatrixPrimeOrderBound.lean:1--90` were read; its transitive provider was not audited here, because the ordinary Eisenstein proof is supplied directly.

The earlier principal-congruence mod-three argument for finite subgroup cardinalities is therefore not the direct provider of this `adm3`. The two-prime proof closes the exact required stabilizer claim without adding a principal-congruence hypothesis.

## Actual short-dual provider

`Formalism/SharpRestriction/GlobalSchurBounds/SlopeMaxOpenOfHookTwoLeV.lean:196--236` defines `ShortAt` and `ShortDual`: an independent tuple in the Hermitian dual with trace divided by `2f` at most `n^2(2v)^2`.

The complete source range `Formalism/SharpRestriction/GlobalSchurBounds/TotallyPositiveTraceGeOfNormDiscr.lean:1--965` was read. Key anchors are:

* `rational_transference_short_basis` near line 47, which converts Euclidean transference into a rational positive form;
* `one_le_norm_mul_discr_sq` near 280 and the arithmetic-geometric-mean estimate at 326;
* `trace_form_lower_bound_dual` at 435;
* `exists_short_basis_of_dual_lower` at 533;
* `exists_short_basis_dual` at 647;
* `shortDual_holds` at 932, where only the **integrality** part of the supplied `LatT` hypothesis is used.

The new proof preserves this last point: no upper bound or equality for `[L#:L]` is used in the short-dual theorem. It distinguishes the Hermitian dual from the trace dual. The relation `beta D^2 subset O`, the norm bound `|N beta| Delta^2 >= 1`, and the Euclidean real dimension `dn` give the exact required factors. An independent integral tuple is all that is needed; no integral basis is claimed.

## Gaussian transference and numerical certificate

`Formalism/PeriodIntegrals/Transference.lean` and `OrbitalBoundsConclusion/TransferenceMinima.lean` were read in full. The latter uses the Gaussian route in `UnitaryGroupMassFormula/LatticeTransference/`. We read `Skeleton.lean`, `TransferenceKey.lean`, `GaussAbs.lean`, `NumericMain.lean`, and `KeySmall.lean` in full. The declarations and their source locations in `Poisson.lean` were searched, but its full formal Fourier-integral proof was not read in this component.

The conventional fragment proves Gaussian Fourier transformation and periodization independently, then obtains the covering bound `D/(2 lambda)` by the same parameters `tau=4/9`, `theta=1/4`, and `s=18 lambda^2/(25m)`, `m=D/2`. It uses a simpler exact numerical certificate: the two bases are less than `45/68` and `1/6`, so their required sum is at most `203/204 < 1`. The endpoint `D=1` is proved by rounding, and the passage from the covering radius to `D` independent short vectors is proved directly using a finite gap in lattice norms. This avoids importing the full successive-minima theorem, of which only its final-minimum/first-dual-minimum case is required here.

`check_arithmetic_lattices.py` verifies every explicit rational comparison in that numerical certificate using `fractions.Fraction`. Its JSON output records positive exact margins. It does not purport to verify the analytic theorem by numerical sampling.

## Independent review and remaining scope

Root independently read the initial 540 lines of the fragment and checked the Gaussian constants and directions, both small-dimensional endpoints, the codifferent argument, the three different dimensions, degree signs, both stabilizer routes, and all five counterexamples. No mathematical defect was found. The formal-verification agent independently read the same 540-line version and confirmed the Gaussian inequalities and exact constants, the discriminant-squared factor, conjugate-prime exponents in the degree, and both stabilizer routes, including residue characteristic two. No mathematical defect was found.

## Additional finiteness proof

The new subsection `al-finite-classes`--`al-finite-decorated` gives an independent, complete proof of finiteness of the actual decorated class sets. The source range `Columns/DecoFin.lean:1--285` was read for `unimod_finite`, the finite decoration fibers, finite orbit sets, and finite stabilizers. This is in addition to the previously recorded later source range; the 2830-line file has not been read in full in this component.

The source's `unimod_finite` invokes `classSetFinite_core` and the `final_shortVectors`, `final_finIntermediate`, and `final_isomOfTrace` providers. The new proof avoids importing that separate reduction theorem: apply the proved short-dual theorem to a unimodular lattice, bound every embedded Gram entry of a short field basis, and choose among finitely many possible integral Gram matrices. With a fixed Gram matrix, all lattices lie between one fixed lattice `M` and its Hermitian dual `M#`. The finite quotient `M#/M` permits only finitely many intermediate lattices. The fixed residue functionals and residue frames have finite sets of choices; their localized extensions are uniquely determined. This proves precisely the finiteness needed for the coefficient class spaces, without a quantitative class-count estimate or an assumption that the chosen field basis is an integral basis.

The initial version compiled twice with XeLaTeX to a 44-page component wrapper. Its final pass had no undefined references, undefined citations, or overfull boxes. After adding the finiteness subsection, the wrapper compiled twice to 45 pages. The final pass again had no undefined references, undefined citations, or overfull boxes. Root independently reviewed every new finiteness proof line and found no mathematical defect. The fragment is now stable at the hash recorded in its manifest.

The identification of all automorphic class lattices with decorated representatives and the class-polynomial lattice/norm identifications remain the next source-audit component. The current fragment proves the arithmetic statements for the actual decorated objects once those identifications are supplied; it does not silently treat a package of identification hypotheses as a proof. The period maps and remaining global theta estimates are outside this fragment.
