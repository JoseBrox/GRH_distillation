# Independent root review of arithmetic coefficient maps

All of arithmetic_maps.tex was read on 21 November 2026.
No mathematical defect was found. A stray comma in the Gaussian
moment exponent was reported for correction.

The review checked:

- the representation multiplication order with transpose;
- independence from local bases and the determinant fractional ideal,
  including negative weights and nonfree global lattices;
- row-weight majorization from injective lower-triangular restriction;
- Smith exponents in increasing order paired with the decreasing partition;
- attainment of the coefficient ideal using the primitive extremal polynomial;
- unitary Fock adjoints and the largest/smallest singular-value endpoints;
- integrality of r*d/n in the determinant character;
- Gaussian moments, Gram--Schmidt conditioning and the normalization bound;
- the exterior-coordinate proof of the maximal-slope bound;
- the sign and factor two in ordinary degree and squared norm conventions;
- Riesz conjugation, the determinant-frame cancellation and Jensen's inequality;
- coefficient-field base change and the absence of an unjustified integral basis
  assumption on the chosen independent dual vectors.

The final application still explicitly requires the actual base lattices,
their degrees and their short integral functionals. These coefficient
map valuations must not be substituted for bounds on the different
iterated period maps.

## Later additions

Also read and checked the class-stabilizer paragraph and the interpolation proof that invertible translates span the representation. Integer interpolation is legitimate in characteristic zero; diagonal shear parameters are chosen nonnegative so 1+t is nonzero. The sign-representation counterexample correctly excludes full-product evaluation without trivial stabilizers.
