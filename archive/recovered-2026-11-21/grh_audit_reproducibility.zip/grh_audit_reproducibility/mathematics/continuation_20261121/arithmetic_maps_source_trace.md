# Concrete coefficient maps: source correspondence and audit scope

Date: 2026-11-21. Fragment: `arithmetic_maps.tex`. The accompanying JSON manifest records SHA-256 hashes, line counts, and the exact ranges read. The ranges describe this source review; they do not assert a transitive import audit or a new Lean kernel certification.

## Mathematical result reconstructed

The fragment gives full conventional proofs for the actual polynomial coefficient map, including its fractional-ideal image, sharp elementary-divisor content over a discrete valuation ring, largest and smallest singular values, determinant, normalized Fock weights, Gaussian highest-vector bound, and the slope estimate obtained from integral short dual vectors. All transposes, complex conjugates, determinant weights, localizations, and the ordinary rather than doubled slope convention are explicit.

The map is coefficient extraction after the polynomial substitution `rho_0(g)`. The determinant character is **not** included in this map: it enters the transported source lattice and therefore the fractional ideal in its image. This distinction is required when the lowest weight is negative. The proof of the singular-value bound is stronger and shorter than the source's Hilbert--Schmidt estimate; the elementary Gaussian proof supplies the required highest-vector normalization bound without importing a highest-weight dimension formula. All closed claims are proved for the actual representation, rather than for the larger and incorrect space defined only by column degrees.

## Exact source anchors

All paths in the following first two lists are relative to `sources/lean/src/Formalism/LocalToGlobal/`.

* `Columns/StandardDeltaIntegralCoeffs.lean`: the monomial index and column degrees are defined near line 18; the coefficient map is at line 110, injectivity at 131, and the twisted-ideal image is proved in the final portion, ending at line 268.
* `Columns/CoefficientMapHeightBound.lean`: normalized Fock norms begin at line 16, monomial weights near 120, and the substitution/coefficient norm and height estimates occupy 190--265.
* `Columns/FockNormSubstitutionBound.lean`: the source's derivative/Euler-recursion proof occupies the latter part, especially 174--249. The fragment replaces it by an exact singular-value calculation.
* `Columns/TwistedLocalisationComparable.lean`: transported lattices at 113, local-basis independence at 124, localization at 139, fractional ideal at 201, product ideal at 219, and norm comparison at 318--387.
* `Columns/MultiFactorialEqTripleProd.lean`: source slope comparison at 19--86, highest-vector bound near 100, and the monomial-weight estimates near 141 and 192. `Columns/FactorialSumLePowMulProd.lean:53--57` is the required highest-vector norm bound.
* `GlobalTheory/GL4/FockNExtCNu.lean` identifies the exact normalization constant and bounds the monomial weights; the fragment retains the same constant before giving an elementary upper bound.

For the arithmetic class maps:

* `GlobalTheory/GL4/BcBasisApply.lean:48,65` constructs the integral functionals from Hermitian dual vectors after base change.
* `GlobalTheory/GL4/CoeffMemOfIntSpanAt.lean:21--106` defines class coordinates, local lattices, their matrices, and the local integrality statement. `CfMemTwId.lean:19--85` proves the actual coefficient image lies in the determinant ideal.
* `GlobalTheory/GL4/NfAllSelfEq.lean:61,109,127,145,169` supplies polarization, the Riesz identification, matrix transport, its Hilbert--Schmidt norm, and the class-norm identity. The conventional proof writes the row vectors as conjugate transposes and obtains the exact identity `g X = R`.
* `GlobalTheory/GL4/PacketOfFrameDegree.lean:14,72` defines the frame-degree input and constructs the actual class map from class projection and coefficient extraction. `ClassMapArchimedean.lean:59,125` supplies the frame degree and the norm estimates.
* `GlobalTheory/GL4/ColumnLatticeExactSlope.lean:106,183` proves base-change invariance and the degree of the base-changed class lattice. In the source's doubled convention its specified slope is `-log(T_u)/k`; the fragment uses ordinary degree and states the factor two explicitly.
* `GlobalTheory/GL4/PColInf.lean:134--187` supplies the inverse archimedean frames and the sum of class norms.
* `GlobalTheory/GL4/ThirdPropositionOfClass.lean:20--125` supplies the class projections, their integral images, orthogonal sum, and injectivity. Only the stated range was read here.
* `GlobalTheory/GL4/ThirdLinkOfArchimedean.lean`, `ShortAtMeanLog.lean`, and `PColSlopeEq.lean` make the final logarithmic/slope substitutions. The fragment independently proves those substitutions from the mean squared-norm bound.

## Class evaluation and stabilizers

`Formalism/SharpRestriction/GlobalSchurBounds/FlipTwoThree.lean:390--449` contains the full class-value package: semilinear embeddings, base-changed class lattices, their metrics, the class-value injection, its full-product range, finite-place integrality criterion, and archimedean norm identity. `GlobalTheory/ColValS.lean` promotes a criterion at one local basis to every local basis. `GlobalTheory/ColValOfTiedSOfFin.lean:20--34` explicitly obtains trivial stabilizers from `adm3` before invoking the full-product range and norm formulas. `GlobalTheory/TransposeBaseMatrixInfinity.lean:153--179` constructs the package through a simultaneous local-basis criterion; its earlier proof and the transitive proof of `locWCrit_proved` were not read in this component.

The fragment now explicitly distinguishes values in the invariant subspaces from unrestricted class values. Its single-orbit sign-representation example proves that the full-product assertion is false without the stabilizer condition. This is a counterexample to omitting a hypothesis, **not** a flaw in the actual source, which retains it. The separate audit of the actual `adm3` provider is being recorded in the arithmetic-lattice continuation: it uses two distinct unipotent residue characteristics, not merely reduction modulo three.

## Separation from iterated period divisibility

The elementary coefficient-ideal result is not the iterated period valuation theorem. `Divisibility/Inputs.lean:469` asks for a valuation statement for all source vectors and target test polynomials. `Divisibility/RecBridge.lean:462--467` invokes `GroupLattices/JointServices/ValIntNonneg.val2AllAtR`. The family version appears at `GroupLattices/ServJointF.lean:84`.

Those reductions require the actual period input `LocalQuadraticParts.adm2`, the cut/intersection condition `CutUp` for the used weights, the dictionary ties, and the source-lattice inclusion. The read argument forms integral linear combinations of the period tests and uses closure of a nonnegative valuation set under addition and integral scalar multiplication. This algebraic reduction is valid. The providers of `adm2` and of the cut/intersection theorem are not proved in this coefficient-map section. No stronger period statement has been inferred from coefficient extraction.

## Hypotheses tested and preserved

Counterexamples in the fragment show why one must retain negative determinant weights, integral functionals, normalized monomial weights, stabilizer invariants, and the difference between an independent integral tuple and a lattice basis. Additional examples distinguish determinant control from operator-norm control and genuine highest-weight invariance from column homogeneity. None contradicts an actual source theorem.

The DVR content calculation is in characteristic zero, includes primes above two, and only uses integral polynomial identities; it makes no claim for arbitrary nonmaximal orders. The global fractional-ideal argument does not assume principal ideal classes. Normalized degree and the mean of the squared norms are proved invariant under coefficient-field extension.

## Remaining arithmetic inputs

The actual decorated base lattices, their prescribed determinant degree, and short independent vectors in their Hermitian duals are construction inputs not supplied by this fragment. The existence and exact identification of all class-coordinate lattices remain separate from the elementary map estimates. The continued audit is following their actual providers rather than treating the packages as proofs.

## Independent review and compilation

Root independently read the full fragment and the later class-evaluation paragraph; no mathematical defect was found. The formal-verification agent independently read the main 708-line draft, including majorization, sharp local content, singular-value endpoints, Gaussian moments, slope signs, Riesz conjugation, and frame cancellation, and found no mathematical defect. The corresponding review records are `arithmetic_maps_peer_review_root.md` and `arithmetic_maps_peer_review_formal.md`.

The standalone check includes the earlier central slope theorem, divisor section, and coefficient duality section. Its final compile record and warning list are in `arithmetic_maps_compile.json`; only final-pass unresolved references or layout warnings, if present there, should be treated as outstanding.

Final check after the interpolation and stabilizer additions: two XeLaTeX passes succeeded, 37 pages. The final log has no undefined references, undefined citations, or overfull boxes; the only warnings concern the expected unicode-math bracket-command definitions.
