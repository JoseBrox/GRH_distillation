# Review of the integral lowering map for every auxiliary character

Reviewer: root. Date: 21 November 2026.

The full fragment was read. Its mathematical statements are correct with the explicit polynomial branching input, which is now proved in integral_branching.tex and polynomial_minor_spanning.tex. No mathematical defect was found.

The selected prime element has the required squarefree ideal factorization by its norm and the cardinality of the selected set. At the auxiliary primes, the split degree-one and valuation-one assumptions give the exact local uniformizer and ensure that both the selected generator and its conjugate are units. The actual top group is the diagonal lower-level group times a deep principal congruence subgroup; it is not silently replaced by the larger residue preimage. The inverse determinant character has the stated restriction and the inverse right-equivariant convention is retained.

The extended lattice is N plus O, its kernel is N plus pi O, and its Hermitian dual is N plus bar(pi)^(-1) O. The residue-frame and local-basis actions prove exact equivariance and character compatibility. No injectivity or surjectivity on class sets is assumed. CRT and Nakayama give one rational basis at all primes over a specified rational prime. The coefficient criterion therefore works simultaneously for every embedding into the coefficient field.

The last-coordinate scalar includes both the polynomial bottom-row degree and the common determinant shift, so its exponent can be negative. The local basis identity uses t=bar(pi) and remains valid where t is not a unit, including at 2. Intersecting localized containments yields the global inclusion. The formula for values at class representatives includes the actual transporting group element and its character. Stabilizer invariance, rather than averaging, gives independence of that element, so no additional stabilizer denominator is introduced.

The converse descent from complex coordinates first recovers unique coefficient-field values, then uses injectivity of complexification to recover all stabilizer equalities. Finiteness of the class set permits one common denominator outside the chosen coefficient prime. The infinite-product example correctly shows why this last step needs finiteness.

The result concerns the actual final lowering operation for every auxiliary character. Intermediate twisted theta-transfer identities and the later improvement in column valuations remain separate obligations, as stated in the fragment.
