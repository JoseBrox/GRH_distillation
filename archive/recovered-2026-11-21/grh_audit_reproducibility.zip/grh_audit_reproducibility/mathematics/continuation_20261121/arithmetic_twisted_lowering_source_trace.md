# The actual lowering map for every auxiliary character

Date: 2026-11-21. Fragment: `arithmetic_twisted_lowering.tex`.

The manifest records exact source ranges read, including earlier direct reads in the ongoing class-comparison lane. This is not a transitive audit of imported declarations or a new kernel certificate. No counterexample to an actual claim in these ranges was found.

## Actual target and live assembly

`LowerTieTwAt.lean` defines the evaluation-then-lowering map, the two coordinate maps, the integral-source property and the target descent criterion. `TwistedEvaluationBranchingAllTuplesTrueColumns.lean` proves the all-character statement by the actual evaluation-map and coordinate providers. `ExistsIntegralCoordinatesTwistedTrueChain.lean` only assembles providers; it is not taken as a substitute for their mathematics. Those providers and their essential local algebra were read in full.

`TrueColumnChoicesHeckeCharReferenceEqOne.lean:165--245` gives the actual auxiliary index a finite type, with a finite support Q(a) for every member. The final result really is quantified over every one of these characters, including the reference character. `TrueWeightsEqDescentShiftedWeightsInterlace.lean` identifies the exact shifted weights and shows interlacing and equal determinant shifts; for fixed word index they do not depend on a.

## Selected primes and the exact deep Q-level

`Tuples.lean` defines GoodPl by splitting in E/F, absolute residue degree one, the rational residue prime not lying in the square of the base prime, and exclusion from S. `LevOkTwists.lean` verifies the fixed conjugate-half and all disjointness requirements. `PrimeNotMemOfMemQE.lean` and `TrueColumnsPeriodMapDatumOkAndOverLevelPrime.lean` prove T is a unit at Q(a), hence pi_T and its conjugate are units there. The conventional proof gives the valuation-one statement and includes the dyadic case under its exact hypotheses; the actual selected set itself may exclude 2 through S.

The full `CongruenceLevelEqDepthSucc.lean` was read. Its actual top Q-group is diag(H_Q-preimage,1) times the principal congruence subgroup at C=max(4m+1,2m+2M). It is not the full inverse image of the diagonal subgroup modulo Q. Its character is the pullback of the lower-rank character, namely the inverse of xi_Q(det of the mt block). The right adelic character is the inverse of the action character. The new proof keeps all these inverses, the exact depth, and the finite-index assertion. The explicit I+pE21 example shows the strict difference between the two possible groups.

## The extended object and its dual

The actual decoration has underlying unimodular N plus O, functional x -> conjugate(pi_T) times its last coordinate modulo each T-prime, type frame (b(x_initial),x_last/pi_T), and auxiliary local basis diag(F_Q,pi_T). These formulas were checked in `StdLatUnimodular`, `CardStabilizerForgetFr`, and the actual period datum provider. They are not inferred from an abstract isomorphic object.

`AbelianHostFieldConditions.lean:174--242` supplies exactly f prime divisors of pi_T, each of norm T, in degree 2f. Comparing the norms of (pi_T) and that squarefree product proves (pi_T)=product P. Thus the kernel is N plus pi_T O and its Hermitian dual is N plus conjugate(pi_T)^(-1) O. The actual `tz` is conjugate(pi_T), not pi_T. `ProdAbsNormDivsDvd.lean` was read in full to verify that these prime data are obtained in the live construction. No global Hasse principle or assertion that every higher-rank class is an extension is used.

The extension embeds stabilizer groups and preserves the character. It need not give a bijection of the two full class sets. The source chooses preferred extended representatives only for classes which meet the image. The ordinary proof makes exactly that limited choice.

## Coordinates, normalization and rational descent

`CoP.lean` defines the source coordinate map with transport from the chosen top representative to the actual extended row object before changing basis. The ordinary formula retains the full character times R_lambda of that transporting element. It is well-defined by stabilizer invariance and integral because roots of unity are units. No averaging or division by stabilizer orders occurs.

At the rational prime below w, a CRT argument produces a single basis for every prime of E above that rational prime. This supplies every embedding-induced local basis used in the coefficient lattice. The top basis is exactly diag(B',t^(-1)). `ExistsLocalBasisSnocOfLocalBasis` and `LocalBasisRepLatticeIntegralCoordsSpec` prove the same normalization in the actual provider.

The exact source maps are defined in `FiniteSumNonzeroLargeDepth.lean:33--137`: nBr is sum(lambda)-sum(sigma), and brAt is product_tau tau(t)^(-nBr_tau) times brStd. The new proof checks this scalar directly from last-row coefficient extraction, including the determinant shift. The coordinate identity is R_sigma(B'^(-1)) B_t = B_1 R_lambda(diag(B',t^(-1))^(-1)). Root's separate `integral_branching.tex` proves the standard integral map and diagonal covariance; the integral initial-minor span has now also been proved in `polynomial_minor_spanning.tex` and independently reviewed. This fragment does not infer integral normalization from characteristic-zero multiplicity one.

`MemLocWDelAtrIff` is the local coefficient criterion; `MemLocWHlatIff` is the finite-class common-denominator assertion. `ExistsHermitianFormDescentCoefficientField` and `ExistsIntegralHyperplaneFormOfLocalCoordsIntegra` descend complex form values using injectivity of polynomial evaluation. The new proof gives these steps directly, retaining all stabilizer equalities. Normalized partitions may be identified after a constant shift, but determinant factors in R_lambda are never discarded.

## Quantifiers and remaining scope

The arguments work at every coefficient prime w, including primes above Q(a), T and 2. The finite-prime exclusion in `PerDecTwT` concerns the later period valuation statement; it is not an exception in the lowering integrality theorem. There is no new prime choice depending on the local basis or the class. All bases are chosen after u,a,w and the class have been fixed.

This closes the class and coordinate part of the actual final lowering construction, using the separately proved standard integral branching map. It does not by itself establish intermediate nontrivially twisted theta transfer identities, the sharp level-prime valuation gain, or the global automorphic estimates.

Root and the Siegel lane independently reviewed the complete mathematical draft positively. Their requested typesetting corrections were applied. The four counterexamples in the fragment concern weakened hypotheses only: shallower level, missing conjugation, omitted representative transport, and infinite rather than finite class sets.
