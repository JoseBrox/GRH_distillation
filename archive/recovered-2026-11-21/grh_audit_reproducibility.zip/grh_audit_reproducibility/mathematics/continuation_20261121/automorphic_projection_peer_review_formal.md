# Independent review of the automorphic projection and diagonal trace

Reviewer: /root/formal_degree_review.

Complete reviewed fragment: automorphic_projection_kernel.tex.
SHA-256:
6d1f966337de0069c399f6b516eb6f85b9895c3c8fade1cdc0ff90f42a771362.

**Conclusion: PASS within its stated setting and named classical input.**
No mathematical correction was identified. The result supplies the
finite-rank projection, continuous Poincaré kernel, and exact diagonal
trace used in the ambient comparison. It does not supply the remaining
quantitative near-unipotent or deep-cusp estimates.

## Actual reading scope

The entire 464-line fragment was read, including the final assumptions
n >= 3 and q <= n/2, and the paragraph pairing the approximate-identity
limit with compactly supported continuous test functions.

The primary Getz–Hahn author manuscript of 22 April 2022 was independently
consulted at:

https://sites.duke.edu/jgetz/files/2022/04/Graduate_Text.pdf

The passages read were the classical component and matrix norm conventions
in section 6.2; Definitions 6.1, 6.2, 6.3; Theorem 6.2.3 and its reductive
group qualification; the adelic conventions and Definition 6.5 in section
6.3; and Theorem 6.3.2 with its component argument. These are the relevant
printed pages 140–146. Neither the whole manuscript nor a new proof of
Harish–Chandra's finiteness theorem is claimed.

The source interface is the one already read and recorded in
ambient_multiplicity_source_manifest.json: the continuous complex
intertwiner multiplicity in GlobAut, the lowest-type coefficient in
LayerProd, and the Poincaré kernel with argument x^(-1) gamma y.
In particular the coefficient is conjugated, as in AK6. This review
does not certify every dependency of those source files or replay
the complete Lean development.

## Detailed checks

### Projection and conjugation conventions

With inner products linear in the second variable, the formal-degree
orthogonality formula is

\[
 d\int\overline{\langle a,\sigma(g)b\rangle}
       \langle c,\sigma(g)v\rangle\,dg
       =\langle c,a\rangle\langle b,v\rangle .
\]

For the second factor in AK5, unitarity gives

\[
 \overline{\langle w,\sigma(x^{-1}g^{-1}y)w\rangle}
             =\langle\sigma(y)w,\sigma(g)\sigma(x)w\rangle .
\]

Consequently the integral is a_w(x) phi(y), with exactly the
conjugations printed in AK5. Under y=gxh, this gives P pi(x) P.
At x=1 it gives convolution idempotence. The involution relation
phi(g^(-1))=conjugate(phi(g)) makes P self-adjoint.

For a unit vector in the range of P, its coefficient is a_w.
Equality of all Gram matrices of finite orbit sums gives the
isometric intertwiner. This directly proves the range identification;
no unstated discrete direct-sum decomposition of a general unitary
representation is needed. The finite idempotent commutes with the
archimedean representation, so its image cuts out the required
intertwiner space. The rank is identified with D only after finiteness
is proved.

### Two-point convergence

The quotient lattice in the separation argument belongs to the
source point y, and the image lattice to the target point x.
Their largest and least sizes give the product lambda_x lambda_y
in AK7. Thus the denominator tau_x tau_y in AK8 has the right
orientation and exponent.

The Cartan root multiplicities give
2 rho = sum_i 2(n-2i+1)e_i, and
t^2 = 2 sum_i a_i^2. The polar Jacobian is bounded by a constant
times exp(sqrt(2) n sqrt(q) t). AK9 therefore implies integrability
of the lowest-type coefficient. The compact case is treated
separately and does not divide by sqrt(q).

The shell estimate has ratio exp(-(H-2n^2)); it converges under
the stated strict inequality. On compact subsets the least sizes
are uniformly positive. A compact set in the quotient can be
covered by finitely many relatively compact local lifts. Bounded
archimedean matrices and finite components in a fixed compact
adelic set then leave only finitely many rational matrices.
This justifies passing from uniform shell tails to local uniform
convergence of the original series.

Unfolding against a compactly supported bounded function is
absolutely justified by the L1 norm of Phi. It gives the same
right-convolution convention as the source.

### The continuous-kernel lemma does not assume a square-integrable row

For nonnegative integral-one approximate identities u_(x,j),
the projection identity gives

\[
 \langle Qu_{x,j},Qu_{y,l}\rangle
          =\langle u_{x,j},Qu_{y,l}\rangle\longrightarrow K(x,y).
\]

At y=x the two-index limit makes Qu_(x,j) a Cauchy sequence
in L2. Thus k_x is constructed in the Hilbert space before
any claim that a kernel row belongs to L2.
The identity <k_x,k_y>=K(x,y) gives Hilbert-norm continuity.

The convention in the added test-function paragraph is also correct:

\[
       \langle v,k_x\rangle=\overline{(Qv)(x)},\qquad
       Qu=\int u(x)k_x\,dx .
\]

The second equality is established weakly against C_c first.
Its Hilbert integral exists because x -> k_x is continuous
and bounded on each compact support. Pairing it with a range
vector F proves that <k_x,F> is the original L2 function
almost everywhere. Full support of the measure makes its
continuous representative unique.

Parseval now gives K(x,y)=sum_i F_i(x) conjugate(F_i(y))
with absolute convergence at every pair. It gives the diagonal
identity at every point, rather than merely almost everywhere
on a product. Tonelli yields the trace formula, including
the infinite-rank alternative before finiteness is invoked.
No integrable diagonal was assumed in this argument.

### Smoothness and moderate growth

The lowest compact type has multiplicity one. Compact matrix
coefficient orthogonality therefore gives an actual projection
onto the line Cw on the whole representation, not just a
projection onto an unspecified isotypic component.
Convolving this compact measure on both sides of a smooth
compactly supported approximate identity yields a smooth
compactly supported a with sigma(a)w=w. The scalar used to
normalize it is nonzero by continuity at the identity.

Convolution by a and the finite-level Haar idempotent gives
smooth representatives. Its Poincaré kernel is locally a
finite sum, and over a fixed compact x-neighborhood its
other variable is confined to a fixed compact quotient set.
Derivative bounds and Cauchy–Schwarz therefore justify
the stated differentiation under the integral. The result
coincides with the already obtained continuous representative.
Equivariance of T then transports the fixed compact type
and infinitesimal character as identities of smooth functions.

The evaluation bound from the continuous-kernel lemma is
|F(x)| <= sqrt(K(x,x)) ||F||_2. Combining it with AK12
gives exactly the power tau_x^(-2n^2f) in AK18.
The lower bound

\[
 \tau_{(g,x_f)}\ge\tau_{(1,x_f)}
              \left(\prod_v\|g_v\|_{\rm op}\right)^{-1/f}
\]

follows from the lower metric bound for g^(-1) on every
sublattice. Each norm is at least one since |det g_v|=1,
so truncation of the least size at 1/2 preserves the inequality.
Thus the resulting growth is polynomial in the archimedean
matrix norm on each fixed finite component.

The imported finiteness theorem requires smoothness, fixed
compact type and finite level, a fixed finite-codimensional
central annihilator, and moderate growth. These hypotheses
are all established. Its adelic form permits a finite direct
sum of classical arithmetic components. Applying it proves
finite rank without assuming cuspidality or a quantitative
cusp bound.

## Remaining scope

The diagonal trace is now a mathematical consequence of the
displayed hypotheses, using the stated classical finiteness
theorem. This review is not a verification of the quantitative
global comparison, the complete submitted proof, or any
claimed GRH conclusion. No new computational or kernel-replay
claim is made by this review.
