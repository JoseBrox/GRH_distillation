# Projection and diagonal trace: source correspondence

The conventional proof is `automorphic_projection_kernel.tex`. It
constructs the actual coefficient projection of the submitted ambient
multiplicity problem, with the conjugated lowest-type coefficient and
the kernel argument x^(-1) gamma y. `LayerProd.lean` gives these
conventions, and `ConvolutionSmoothL2.lean` states the relevant source
interfaces. The two kernel-diagonal files listed in the manifest were
read to compare the submitted absolute-convergence and unfolding
requirements with the conventional proof.

The new route constructs kernel vectors by applying the orthogonal
projection to compactly supported approximate identities. This proves
the pointwise diagonal identity without inferring it from equality of
measurable kernels almost everywhere on a product. Finiteness is proved
afterward from the explicitly stated classical theorem, using the
polynomial growth bound furnished by lattice separation.

All four listed files were read in full. Earlier source interfaces,
including the precise intertwiner multiplicity, are recorded in
`ambient_multiplicity_source_manifest.json`. This is a direct proof of
the required mathematical result, not a claim to have checked every
transitive source dependency or to have replayed the complete Lean
kernel. The independent review and its separate primary-reference
scope are recorded in `automorphic_projection_peer_review_formal.md`.
