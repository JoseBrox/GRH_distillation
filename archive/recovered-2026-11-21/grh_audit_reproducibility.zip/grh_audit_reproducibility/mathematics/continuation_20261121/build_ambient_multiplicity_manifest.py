"""Record actual reading scopes; this is not a transitive Lean replay."""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SRC = ROOT / "sources/lean/src"

records = [
    ("Formalism/SharpRestriction/CuspSpanNormBounds/GlobAut.lean", "all",
     "Actual adelic group, point lattice, finite level, positive idempotent, Hom space, finrank and main-term definitions."),
    ("Formalism/SharpRestriction/CuspSpanNormBounds/DstarEq.lean", "all",
     "AutTie identifies these complex multiplicities and main terms with the submitted row count."),
    ("Formalism/SharpRestriction/CuspSpanNormBounds/SArith.lean", "all",
     "Complete-splitting convention includes residue norm and absence of ramification."),
    ("Formalism/SharpRestriction/CuspSpanNormBounds/PlaceDegreeData.lean", [[1,230]],
     "HidaSetting, CountData, coefficient and formal-degree products, finite-dimensionality interface and exact lowest-type integral statement."),
    ("Formalism/SharpRestriction/CuspSpanNormBounds/BridgeCountE.lean", [[1,170]],
     "Required quantitative complex multiplicity theorem, row identifications and family bridge."),
    ("Formalism/HarderNarasimhan/StatementPl.lean", "all",
     "Exact normalized covolume, least and largest sizes, quotient and map inequalities."),
    ("Formalism/SharpRestriction/CuspSpanNormBounds/BruhatCellsKronecker/SphericalFunctionIntegrableOfLocal.lean", [[408,437]],
     "Cartan distance is the Hilbert-Schmidt norm of the polar logarithm; near and far sums."),
    ("ReciprocityTheory/ReductiveGroups/DiscreteSeries/FormalDegree/PmatIsHermitian.lean", "all",
     "Exact principal-minor phase, adjacent shift by one, compact probability normalization and FData.formF compression identity."),
    ("Development/AbelianVarietyTheory/Statements/CuspFrameWeights/EigenfunctionFiniteCoefficients.lean", "all",
     "Actual FormulaGap and DecGap, including their lowest-type restriction and large-gap hypothesis."),
    ("Development/AbelianVarietyTheory/Proofs/FlagMeasures/DecGapOfFormula.lean", "all",
     "Source passage from principal-minor decay and the compact integral to coefficient decay."),
    ("Development/AbelianVarietyTheory/Proofs/FlagMeasures/PtBoundAndFarBoundAndDecGap.lean", "all",
     "Source assembly of pointwise decay, rational tail bounds and local coefficient decay."),
    ("Development/AbelianVarietyTheory/Statements/CuspFrameWeights/CuspFrame.lean", "all",
     "Exact PtBound, FarBound and cuspidal frame endpoints."),
    ("Development/AbelianVarietyTheory/Statements/CuspFrameWeights/ConvolutionSmoothL2.lean", "all",
     "Exact finite multiplicity, kernel, cusp, rational count and near-unipotence interfaces. These are not all proved in the reconstruction."),
    ("Development/AbelianVarietyTheory/Proofs/FlagMeasures/FarTermsModerateRegionOfFlagBound.lean", "all",
     "Exact radius and tail estimate on the moderate set; comparison with the directly reconstructed numerical estimate."),
    ("Formalism/SharpRestriction/CuspSpanNormBounds/UnimodularSchurMeasures/NearCountOfLayers.lean", "all",
     "Finite layer-count assembly for nearby unipotents; substantive layer and integrated estimates remain open here."),
    ("Formalism/FlagUnipotentLattices/MinkowskiFactorialBounds/NearFarVolumeBounds.lean", [[1,160]],
     "Inspected preliminary polar and finite layer-count estimates only; no claim to read the entire file."),
]

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

files = []
for rel, scope, role in records:
    p = SRC / rel
    files.append(dict(path=rel, sha256=sha(p),
                      line_count=len(p.read_text().splitlines()),
                      read_scope=scope, role=role,
                      reader="/root/formal_degree_review"))

primary = []
for filename, url, scope in [
    ("sun_eisenstein_v2.pdf", "https://arxiv.org/pdf/math/0403440v2",
     "Sections 1.1–1.4 conventions, the cohomological-induction definition, sections 6.1–6.2 matrix coefficient and Theorem 6.4, all of section 6.4, and the discrete-series discussion in section 7.5. Printed page 43 visually checked, including the compact-conjugation overbar. The full paper and full proof of Theorem 6.4 are not claimed as read."),
    ("vogan_zuckerman_1984.pdf", "https://www.numdam.org/article/CM_1984__53_1_51_0.pdf",
     "The construction discussion following Theorem 2.5; admissibility (5.1), Theorem 5.3, Proposition 6.1. Printed pages 73, 74 and 78 visually checked. These classical results are imported, not reproved; no whole-article reading claim."),
]:
    p = BASE / "primary_compression" / filename
    primary.append(dict(file=str(p.relative_to(BASE)), url=url,
                        sha256=sha(p), bytes=p.stat().st_size, read_scope=scope))

p = BASE / "ambient_multiplicity.tex"
data = dict(
    mathematical_deliverable=p.name,
    mathematical_deliverable_sha256=sha(p),
    source_root="sources/lean/src", files=files,
    primary_references=primary,
    peer_review=dict(
        file="ambient_multiplicity_peer_review_root.md",
        sha256=sha(BASE / "ambient_multiplicity_peer_review_root.md"),
        reviewer="/root",
        reviewed_deliverable_sha256=sha(p),
    ),
    related_formal_degree_trace="unitary_formal_degree_source_manifest.json",
    scope="Conventional proofs of local compression and decay, rational unipotence, size duality and separation, packing and the distant-term estimate, conditional only on the named classical representation-theoretic theorems. The global multiplicity comparison still requires the displayed finite-rank continuous kernel, integrated near-unipotent, rare-volume and deep-cusp estimates. No full Lean kernel replay, all-dependency reading or exhaustive proof certification is claimed.",
)
out = BASE / "ambient_multiplicity_source_manifest.json"
out.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
print(json.dumps(dict(files=len(files), sha256=sha(p), manifest=str(out))))
