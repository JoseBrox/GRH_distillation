"""Record the actual source and reference scope of the projection argument."""
from pathlib import Path
import hashlib
import json

base = Path(__file__).resolve().parent
root = base.parents[1]
src = root / 'sources/lean/src'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

names = [
    'Development/AbelianVarietyTheory/Definitions/SemilocalFrames/LayerProd.lean',
    'Development/AbelianVarietyTheory/Statements/CuspFrameWeights/ConvolutionSmoothL2.lean',
    'Formalism/SharpRestriction/CuspSpanNormBounds/UnimodularSchurMeasures/KernelDiagonalOfL2UnfoldIdempotent.lean',
    'Formalism/SharpRestriction/CuspSpanNormBounds/UnimodularSchurMeasures/KernelDiagonalOfAbsoluteConvergence.lean',
]
data = {
    'fragment': 'automorphic_projection_kernel.tex',
    'fragment_sha256': digest(base / 'automorphic_projection_kernel.tex'),
    'author_reader': '/root',
    'review_status': 'Independent mathematical review PASS; classical finiteness input explicitly stated.',
    'source_files': [
        {'path': name, 'sha256': digest(src / name),
         'lines': len((src / name).read_text().splitlines()),
         'root_read_scope': 'all'} for name in names
    ],
    'related_source_interface': 'ambient_multiplicity_source_manifest.json',
    'primary_reference': {
        'authors': 'J. R. Getz and H. Hahn',
        'title': 'An Introduction to Automorphic Representations',
        'version': 'author manuscript, 22 April 2022',
        'url': 'https://sites.duke.edu/jgetz/files/2022/04/Graduate_Text.pdf',
        'root_scope': 'Relevant definitions and conventions in sections 6.2–6.3; Theorems 6.2.3 and 6.3.2, including the finite classical-component argument, printed pages 140–146.',
        'retrieval': 'Primary web text; no local PDF hash claimed.',
        'limitation': 'The classical Harish–Chandra and finite-component theorems are imported, not reproved.'
    },
    'review': {
        'file': 'automorphic_projection_peer_review_formal.md',
        'sha256': digest(base / 'automorphic_projection_peer_review_formal.md'),
        'reader': '/root/formal_degree_review'
    },
    'scope': 'Conventional proof of finite-rank projection, locally uniformly convergent continuous kernel, and pointwise diagonal trace. Quantitative cusp integrals are separate.',
    'full_source_dependency_review_claimed': False,
    'independent_full_kernel_replay_claimed': False,
}
(base / 'automorphic_projection_source_manifest.json').write_text(
    json.dumps(data, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'source_files': len(names), 'fragment_sha256': data['fragment_sha256']}))
