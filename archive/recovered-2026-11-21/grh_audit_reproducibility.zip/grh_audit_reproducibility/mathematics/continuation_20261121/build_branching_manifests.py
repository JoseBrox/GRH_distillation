"""Record the source interfaces read for the two ordinary branching proofs.

The proofs in the TeX fragments are independent reconstructions. These
records distinguish a complete read of a short file from selected intervals
of the large source proof; they do not assert a kernel replay.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SRC = ROOT / 'sources/lean/src'
F = 'Formalism/'
D = 'Development/AbelianVarietyTheory/'
scopes = {
    F+'LocalRingCardinality/DataCoeff.lean': [[1, 65]],
    F+'SharpRestriction/Divisibility/PrimeDegreeVariant.lean': [[1, 195]],
    F+'LocalToGlobal/Columns/FiniteSumNonzeroLargeDepth.lean': [[1, 190]],
    F+'LocalToGlobal/KernelLattices/InterlaceAll.lean': [[1, 190]],
    D+'Proofs/GlobalInterpolation/StatementWithTransposeOfBranching.lean': [[1, 275], [400, 484]],
    D+'Proofs/GlobalInterpolation/RhoVrBrAtEqBrStd.lean': None,
    D+'BlockTheory/GlobalSignature/OnePlaceBranchStatement.lean': None,
    F+'BranchSandwichDivisors/BranchIsometryProofs/BranchMap.lean': [[1, 200], [1800, 1876], [2180, 2235], [2440, 2645]],
    F+'BranchSandwichDivisors/BranchIsometryProofs/Numeric.lean': None,
    F+'BranchSandwichDivisors/BranchIsometryProofs/BranchScale.lean': [[1, 140], [290, 396]],
    F+'BranchSandwichDivisors/BranchIsometryProofs/Interlace.lean': None,
    F+'GradedWeylDivisibility/FockSpaceTableaux/LeadInterlaced.lean': None,
}
records = []
for name, ranges in scopes.items():
    data = (SRC/name).read_bytes()
    length = len(data.decode().splitlines())
    actual = [[1, length]] if ranges is None else [[a, min(b, length)] for a, b in ranges]
    assert all(1 <= a <= b <= length for a, b in actual), (name, length, actual)
    records.append({
        'path': 'sources/lean/src/'+name,
        'sha256': hashlib.sha256(data).hexdigest(),
        'line_count': length,
        'scope': 'full file read' if actual == [[1, length]] else 'specified intervals read',
        'line_ranges_read': actual,
    })

for fragment, purpose, deps in [
    ('compact_branching',
     'Ordinary proof of highest-weight classification and multiplicity-one unitary branching by normal ordering and Gaussian elimination.',
     ['coefficient_duality.tex: divided-row cyclicity of the integral polynomial model',
      'theta_radial_positivity.tex: independent convolution proof that finite-dimensional continuous unitary representations are smooth']),
    ('integral_branching',
     'Ordinary proof of the exact integral branching scalar, normalized adjoint maps, norm bound and determinant/conjugate-uniformizer covariance.',
     ['compact_branching.tex: multiplicity-one branching',
      'polynomial_minor_spanning.tex: integral spanning by products of initial-column minors',
      'coefficient_duality.tex: perfect integral Weyl and dual-Weyl pairing',
      'theta_radial_positivity.tex: independently proved ordered Capelli operator identity']),
]:
    data = (HERE/(fragment+'.tex')).read_bytes()
    result = {
        'date_utc': datetime.now(timezone.utc).isoformat(),
        'purpose': purpose,
        'fragment': fragment+'.tex',
        'fragment_sha256': hashlib.sha256(data).hexdigest(),
        'files': records,
        'separate_dependencies': deps,
        'limits': 'The source read scopes document the interfaces and selected arguments actually examined, not a complete read of the large branching development. The conventional proofs establish these interfaces by a different route.',
    }
    (HERE/(fragment+'_source_manifest.json')).write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'fragment': fragment, 'files': len(records), 'sha256': result['fragment_sha256']}))
