"""Record the source scopes actually read for the initial class-period proof."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
SRC = ROOT / 'sources/lean/src'
PREFIX = 'Development/AbelianVarietyTheory/'
full = [
    PREFIX + 'Definitions/LatticeFrames/AdmissiblePeriodOfPeriodInt.lean',
    PREFIX + 'Definitions/LatticeFrames/PerIntOnAmb.lean',
    PREFIX + 'Definitions/GlobalTwisting/ReferenceChainEvaluationAtBundlePoints.lean',
    PREFIX + 'Definitions/GlobalTwisting/LowerTieTwAt.lean',
    PREFIX + 'Proofs/GlobalInterpolation/PeriodAdmissibleOfIntegralPeriodRows.lean',
    PREFIX + 'Proofs/GlobalInterpolation/AdmissiblePeriodZeroOfClassPeriodDecompositionAl.lean',
    PREFIX + 'Proofs/GlobalInterpolation/ReferencePeriodIntegralBundlePointsOfOverColumns.lean',
    PREFIX + 'Proofs/GlobalInterpolation/ClosedFamilyAdmissibleTwistLink.lean',
    'Development/AutomorphicArithmetic/ThetaCorrespondence/ThetaPairLifts/ThirdPlaceSeries/ClosedFamilyAdmissibleTwistLink.lean',
    'Formalism/SharpRestriction/Divisibility/StatementFT/PeriodPointConditions.lean',
    'Formalism/LocalToGlobal/HilbertRowConditions/RowPinD.lean',
    PREFIX + 'Proofs/GlobalInterpolation/VAddNonnegOfInt.lean',
    PREFIX + 'Proofs/GlobalInterpolation/PeriodRowLatticesIntegralProvisionalRows.lean',
    PREFIX + 'Proofs/GlobalInterpolation/ExistsTrueColsRowInt.lean',
    PREFIX + 'Proofs/GlobalInterpolation/ClassPairingIntegralFormRowIsIntegralStatement.lean',
    PREFIX + 'Proofs/GlobalInterpolation/ClassPairingIntegralFormRowIsIntegral.lean',
    PREFIX + 'Proofs/GlobalInterpolation/PerDecTwTOfStd.lean',
    PREFIX + 'Proofs/GlobalInterpolation/IsClassSumPairingFormsLat.lean',
    PREFIX + 'Proofs/GlobalInterpolation/IsClassSumPairingOfIsFormsOf.lean',
    PREFIX + 'Proofs/SatakeParameters/RowFormsMatchPeriodMapOfFurtherProperties.lean',
    PREFIX + 'Proofs/GlobalInterpolation/AdmissiblePeriodTwistOfIntegralRows.lean',
    PREFIX + 'Proofs/GlobalInterpolation/TwistedPeriodDecompositionOfClasswiseTwistedPair.lean',
    PREFIX + 'Proofs/GlobalInterpolation/PropertyAtConstructedPointsOfTrueColumnsView.lean',
    PREFIX + 'Proofs/GlobalInterpolation/PropertyAtConstructedPointsOfTrueColumnsViewStatement.lean',
]
partial = {
    PREFIX + 'Definitions/AutomorphicMembership/PredMemGamRanks.lean': [[455, 585]],
    PREFIX + 'Definitions/AutomorphicMembership/LatAtLattice.lean': [[70, 130]],
}
records = []
for name in full + list(partial):
    data = (SRC / name).read_bytes()
    lines = len(data.decode().splitlines())
    scope = partial.get(name, [[1, lines]])
    assert all(1 <= a <= b <= lines for a, b in scope), (name, lines, scope)
    records.append({
        'path': 'sources/lean/src/' + name,
        'sha256': hashlib.sha256(data).hexdigest(),
        'line_count': lines,
        'scope': 'specified intervals read' if name in partial else 'full file read',
        'line_ranges_read': scope,
    })
fragment = HERE / 'class_period_integrality.tex'
manifest = {
    'date_utc': datetime.now(timezone.utc).isoformat(),
    'purpose': 'Conventional proof of the actual initial finite class-period bound; not a kernel replay or a proof of the stronger column containment.',
    'fragment': fragment.name,
    'fragment_sha256': hashlib.sha256(fragment.read_bytes()).hexdigest(),
    'files': records,
    'separate_dependencies': [
        'coefficient_duality.tex: normalized integral Weyl/dual-Weyl pairing',
        'arithmetic_classes.tex: actual row classes, inverse level characters, and stabilizers',
        'integral_period_pairings.tex: coefficient-field extension and integral test-vector range',
    ],
}
(HERE / 'class_period_integrality_source_manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({'files': len(records), 'fragment_sha256': manifest['fragment_sha256']}))
