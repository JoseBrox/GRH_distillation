from pathlib import Path
import hashlib
import json

ROOT = Path(__file__).resolve().parents[2]
OUT = Path(__file__).resolve().parent
SRC = ROOT / 'sources/lean/src/Development/AbelianVarietyTheory'

FULL = [
    'Definitions/GlobalTwisting/LevelPrimeColumnValuationsAtBundlePoints.lean',
    'Proofs/GlobalInterpolation/LevelPrimeColumnValuationsBundlePointsOverColumn.lean',
    'Proofs/GlobalInterpolation/ClosingTrueCols.lean',
    'Proofs/GlobalInterpolation/TrueColumnsRowSharpBounds.lean',
    'Proofs/GlobalInterpolation/FivePointLawsTrueChains.lean',
    'Proofs/GlobalInterpolation/SharpBoundStabilityLatticeColumnChain.lean',
    'Proofs/GlobalInterpolation/ExtInOfValIn.lean',
    'Proofs/GlobalInterpolation/ValBOfInc.lean',
    'Proofs/GlobalInterpolation/LevelChainSharpColumnValuationOfStability.lean',
    'Proofs/GlobalInterpolation/LevelChainSharpColumnValuationOfPointKernelLiftL.lean',
    'Proofs/GlobalInterpolation/TupleChainSharpColumnValuationOfTwisted.lean',
    'Proofs/GlobalInterpolation/IntPOfKerP.lean',
    'Proofs/GlobalInterpolation/ConjugatePrimeBoundPointKernelOfCoefficientKerne.lean',
    'Definitions/GlobalTwisting/KerIsTerm.lean',
    'Definitions/GlobalTwisting/LatIntZero.lean',
    'Proofs/GlobalInterpolation/TrueChainKernelsBoundLevelPrimePlaces.lean',
    'Proofs/GlobalInterpolation/TrueChainKernelsBoundConjugatePrimePlaces.lean',
    'Proofs/GlobalInterpolation/PTermOfStd.lean',
    'Proofs/GlobalInterpolation/ExistsMulEqOfUnif.lean',
    'Proofs/GlobalInterpolation/AdmissibleAdjointRationalPointPadicMatrix.lean',
    'Proofs/GlobalInterpolation/RenameMemDualWeyl.lean',
    'BlockTheory/GlobalSignature/SubstitutionAdjoint.lean',
    'BlockTheory/GlobalSignature/JetSumTable.lean',
    'Proofs/GlobalInterpolation/HighestWeightVectorMemOfLtStableDualWeylStatement.lean',
    'Proofs/GlobalInterpolation/HighestWeightVectorMemOfLtStableDualWeyl.lean',
    'Proofs/GlobalInterpolation/IsRowOperatorStableDualWeylAndGLSubmodulesStatement.lean',
    'Proofs/GlobalInterpolation/NotDvdCardStabilizerForm.lean',
    'Proofs/GlobalInterpolation/ExistsUnitaryCarries.lean',
    'BlockTheory/GlobalSignature/CharacterValuation.lean',
    'Proofs/GlobalInterpolation/KernelJetsLevelPlaceIntegralMoments.lean',
    'Proofs/GlobalInterpolation/JetMomentsOfUnitPeriod.lean',
    'Proofs/GlobalInterpolation/UnitPeriodTranslatesMomentsFiniteStatement.lean',
    'Proofs/GlobalInterpolation/EqAndAlg.lean',
    'Proofs/GlobalInterpolation/LatticeFactsAll.lean',
    'Proofs/GlobalInterpolation/UnitPeriodTranslatesMomentsFinite.lean',
    'Proofs/GlobalInterpolation/NormalizedVectorTranslatesPrimeOrderIntegral.lean',
    'Proofs/GlobalInterpolation/MomentMeasureNormLeOneIffLatticeIntegral.lean',
]
PARTIAL = {
    'Definitions/GlobalTwisting/LevelChainSharpColumnValuationOwnChainIff.lean': [[1,220],[292,350]],
    'Definitions/GlobalTwisting/FormsStable.lean': [[1,260],[280,350]],
    'Proofs/GlobalInterpolation/LevelPrimePowSmulMemValueLatticeErase.lean': [[1,260]],
    'Proofs/GlobalInterpolation/CharacterValueAtT.lean': [[295,440],[487,638],[730,914]],
    'Proofs/GlobalInterpolation/ExistsMulOfApprox.lean': [[1,420]],
}
EXTRA = [
    'sources/lean/src/PublishedTheorems/GlobalTheta/WeylDualWeylLatticesAgreeOfLowestAlcove.lean',
    'sources/lean/src/PublishedTheorems/GlobalTheta/WeylModuleSimpleClosedLowestAlcove.lean',
]

def resolve(rel):
    p = SRC / rel
    if p.exists():
        return p
    matches = list((ROOT/'sources/lean/src').rglob(Path(rel).name))
    if len(matches) != 1:
        raise RuntimeError((rel, [str(x) for x in matches]))
    return matches[0]

def record(p, scope):
    data = p.read_bytes()
    return {'path':str(p.relative_to(ROOT)), 'sha256':hashlib.sha256(data).hexdigest(),
            'bytes':len(data), 'lines':len(data.splitlines()), 'read_scope':scope}

sources = [record(resolve(p), 'entire file') for p in FULL]
sources += [record(resolve(p), {'line_ranges':r}) for p,r in PARTIAL.items()]
sources += [record(resolve(p), 'entire file') for p in EXTRA]
artifact = record(OUT/'arithmetic_column_valuations.tex', 'entire reconstruction')
result = {
    'created_utc':'2026-11-21', 'scope':'Independent conventional reconstruction and source audit; no claim of Lean compilation or exhaustive dependency read.',
    'original_archive_sha256':'9631b4f020199e580ba86178cb56c6e9b09f690c2369a80dc4334aa93f49c7fc',
    'artifact':artifact, 'sources':sources,
    'remaining_inputs':['normalized ordinary theta measure with its common unit period and finite translation support',
                        'exact polynomial identification and rational-unitary equivariance of the actual kernel',
                        'theta incidence commutation identity'],
    'closed_replacement_input':'Weyl and dual-Weyl equality at the actual large primes is supplied by fock_hook_normalization.tex.'
}
(OUT/'arithmetic_column_valuations_source_manifest.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'sources':len(sources),'artifact_sha256':artifact['sha256']},indent=2))
