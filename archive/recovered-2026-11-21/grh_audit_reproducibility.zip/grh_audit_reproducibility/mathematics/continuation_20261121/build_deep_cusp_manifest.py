"""Exact hashes and bounded reading scopes for the deep-cusp proof."""
from pathlib import Path
import hashlib
import json
import re
import shutil

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SRC = ROOT / "sources/lean/src"
AB = "Development/AbelianVarietyTheory/"


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


scopes = [
    (AB + "BlockTheory/SiegelWeilLocal/DeepSetBound.lean", "all"),
    (AB + "BlockTheory/SiegelWeilLocal/DeepKernelBound.lean", "all"),
    (AB + "BlockTheory/SiegelWeilLocal/CoveringRadii.lean", "all"),
    (AB + "Proofs/FlagMeasures/DeepPointBoundCuspidalIsometricIntertwinerFamily.lean", "all"),
    (AB + "Proofs/FlagMeasures/DeepPointBoundCuspidalIsometricIntertwinerFamilyStatement.lean", "all"),
    (AB + "Proofs/FlagMeasures/DeepPointKernelBoundOfPointwiseBound.lean", "all"),
    (AB + "Proofs/FlagMeasures/DeepRegionKernelDiagonalBound.lean", "all"),
    (AB + "Statements/CuspFrameWeights/ConvolutionSmoothL2.lean", "all"),
    (AB + "Definitions/SemilocalFrames/HermitianFormUnitaryOneOne.lean", [[1, 65]]),
    ("Formalism/SharpRestriction/CuspSpanNormBounds/GlobAut.lean", [[125, 165]]),
    (AB + "Definitions/SemilocalFrames/PosPartUnitaryMul.lean", [[80, 117]]),
    (AB + "Statements/CuspFrameWeights/SameKindIsometric.lean", "all"),
    (AB + "Definitions/SemilocalFrames/DefClassNum.lean", [[30, 49]]),
    (AB + "BlockTheory/PoincareCuspForms/SmallUnipotentElements.lean", "all; investigated but unused"),
]
primaries = [
    ("primary_deep/bost_kunnemann_2007.pdf",
     "printed pp. 46--48, especially Theorem 3.7.2 (3.54); p. 46 visually checked"),
    ("primary_deep/khare_larsen_savin_math0610860v3.pdf",
     "section 4.1, printed pp. 14--15; p. 15 visually checked; selected section 4.3 excerpt only"),
    ("primary_deep/zaman_1502.05679v4.pdf",
     "section 2.1 (2.1)--(2.3), Lemma 2.1, printed pp. 6--7; p. 6 visually checked"),
    ("primary_deep/urban_eigenvarieties_2011.pdf",
     "selected introduction and sections 1.3.3--1.3.5; investigated but unused"),
    ("primary_formal_degree/harish_chandra_ds_ii.pdf",
     "for this fragment: selected introduction, sections 14--15 Lemmas 21--22 and Theorem 3, sections 32--33 Lemmas 64--65/Corollary 1; not the whole paper"),
]
fragment_sha = sha(BASE / "deep_cusp_mass.tex")
compile_record = {
    "fragment_sha256": fragment_sha,
    "completed": False, "records": [],
    "standalone_note": "Unresolved references are only external companion fragments.",
}
for iteration in (1, 2):
    source = ROOT / "work" / f"deep_cusp_mass_check_compile_{iteration}.log"
    target = BASE / f"deep_cusp_mass_compile_{iteration}.log"
    if source.exists():
        shutil.copyfile(source, target)
        log = target.read_text()
        success = "Output written on deep_cusp_mass_check.pdf" in log
        compile_record["records"].append({
            "pass": iteration, "exit_code": 0 if success else None,
            "log": str(target.relative_to(ROOT)),
        })
        if iteration == 2:
            compile_record["completed"] = success
            match = re.search(r"Output written on deep_cusp_mass_check.pdf \((\d+) pages", log)
            compile_record["pages"] = int(match.group(1)) if match else None
            compile_record["overfull_boxes"] = len(re.findall(r"Overfull \\[hv]box", log))
            compile_record["unresolved_refs"] = sorted(set(
                re.findall(r"Reference .([^']+)'", log)))
            compile_record["visual_review"] = {
                "pages": [8, 10],
                "images": ["work/continuation_20261121/deep_cusp_page8.png",
                           "work/continuation_20261121/deep_cusp_page10.png"],
                "finding": "Readable equations and clean layout; external references intentionally unresolved in wrapper.",
            }
(BASE / "deep_cusp_mass_compile.json").write_text(
    json.dumps(compile_record, indent=2) + "\n")
data = {
    "fragment": "deep_cusp_mass.tex",
    "fragment_sha256": fragment_sha,
    "reader": "/root/formal_degree_review",
    "review": "Root independently reviewed all mathematics and the two tracked additions; PASS at final da39087d, with all 20672 controls independently rerun.",
    "scope": "Final deep-cusp mass bound, with explicit classical imports; no full transitive source audit or Lean replay.",
    "source_files": [
        {"file": name, "sha256": sha(SRC / name),
         "line_count": len((SRC / name).read_text().splitlines()),
         "read_scope": scope}
        for name, scope in scopes
    ],
    "conventional_inputs": [
        {"file": name, "sha256": sha(BASE / name)}
        for name in ("unitary_formal_degree.tex", "ambient_multiplicity.tex",
                     "automorphic_projection_kernel.tex", "rare_cusp_volume.tex",
                     "near_unipotent_integral.tex")
    ],
    "primary_files": [
        {"file": name, "sha256": sha(BASE / name), "read_scope": scope}
        for name, scope in primaries
    ],
}
for name in ("deep_cusp_source_trace.md", "deep_cusp_references.tex",
             "check_deep_cusp_constants.py", "deep_cusp_constants_checks.json",
             "deep_cusp_mass_compile.json", "deep_cusp_mass_peer_review_root.md",
             "deep_cusp_peer_review_root.md"):
    if (BASE / name).exists():
        data.setdefault("records", []).append({"file": name, "sha256": sha(BASE / name)})
(BASE / "deep_cusp_source_manifest.json").write_text(
    json.dumps(data, indent=2) + "\n")
print(json.dumps({"fragment_sha256": fragment_sha,
                  "source_files": len(scopes),
                  "primary_files": len(primaries),
                  "compile": compile_record}, indent=2))
