#!/usr/bin/env python3
"""Hash only the explicit DF read scopes; do not imply dependency closure."""
from pathlib import Path
from hashlib import sha256
import json

HERE = Path(__file__).resolve().parent
BASE = HERE.parents[1]
SRC = BASE/'sources/lean/src'


def hashed(p):
    return {'path': str(p.relative_to(BASE)), 'sha256': sha256(p.read_bytes()).hexdigest()}


scopes = {
 'Formalism/SharpRestriction/CuspSpanNormBounds/NonGenericAndKTwoTheorems.lean': 'all',
 'Formalism/SharpRestriction/CuspSpanNormBounds/BlockEnds.lean': 'all',
 'Formalism/SharpRestriction/CuspSpanNormBounds/KappaEndpoints.lean': [[1, 230]],
 'Formalism/FlagUnipotentLattices/MemOfOrthogonalAnisotropic.lean': [[1, 200]],
 'Formalism/FlagUnipotentLattices/MinkowskiFactorialBounds/ExistsHasLeadingCoeffOfMemSpanBelow.lean': [[335, 639]],
 'Formalism/FlagUnipotentLattices/AutBoundOfMinkowskiBound.lean': 'all',
 'Formalism/LocalToGlobal/SiegelLatticeTheory/CokernelGLCounts/RankPointCounts/SubOneMulVecFix.lean': 'all',
 'Formalism/LocalToGlobal/SiegelLatticeTheory/CokernelGLCounts/RankPointCounts/CplxNF.lean': 'all',
 'Formalism/LocalToGlobal/SiegelLatticeTheory/ClosedLocalOrbits/TermOp.lean': [[1, 60], [110, 170]],
 'Formalism/LocalToGlobal/SiegelLatticeTheory/ClosedLocalOrbits/GaugeLatticeShifts/Vanish.lean': [[175, 240]],
 'Formalism/SharpRestriction/CuspSpanNormBounds/IsPrimitiveSub.lean': [[245, 285]],
 'Formalism/LocalToGlobal/SiegelLatticeTheory/CokernelGLCounts/RankPointCounts/KappaOffDiagonal.lean': 'all',
 'Formalism/LocalToGlobal/SiegelLatticeTheory/CokernelGLCounts/RankPointCounts/FixedDecomposition.lean': [[1, 150], [650, 779]],
 'Formalism/LocalToGlobal/SiegelLatticeTheory/ClosedVolumeStatements/FullExistsTiedHolds.lean': [[1, 55]],
 'Formalism/LocalToGlobal/SiegelLatticeTheory/CokernelGLCounts/RankPointCounts/SchurCoreA.lean': 'all',
 'Formalism/LocalToGlobal/SiegelLatticeTheory/CokernelGLCounts/RankPointCounts/SchurNFCOf.lean': 'all',
 'Formalism/LocalToGlobal/SiegelLatticeTheory/CokernelGLCounts/RankPointCounts/KppOffCOfSteps.lean': 'all',
 'Formalism/SharpRestriction/CuspSpanNormBounds/RelevantZeroGramTerms.lean': [[45, 100]],
 'Formalism/FormalDegreeBessel/StatementDS.lean': [[1, 85]],
 'Formalism/RealPlaceAnalysis/StatementA.lean': [[1, 53]],
 'Formalism/PeriodIntegrals/UpqRep.lean': [[186, 237]],
 'Formalism/HermitianCurvature/HermitianCurvatureProofs/LowKAllPos.lean': 'all',
 'Formalism/SharpRestriction/CuspSpanNormBounds/DataS.lean': 'all',
 'Formalism/LocalToGlobal/SiegelLatticeTheory/ClosedLocalOrbits/GaugeLatticeShifts/DistinctWordsDistinctParameters.lean': [[690, 752], [844, 845]],
 'Formalism/SharpRestriction/CuspSpanNormBounds/StandingHypothesesHoldFamily.lean': [[762, 790], [1520, 1578]],
 'Formalism/SharpRestriction/CuspSpanNormBounds/StandingNumericalData.lean': [[1, 25], [80, 124]],
 'Formalism/SharpRestriction/CuspSpanNormBounds/CntPartners.lean': [[1, 48]],
}
records = []
for name, spans in scopes.items():
    p = SRC/name
    length = len(p.read_text().splitlines())
    intervals = [[1, length]] if spans == 'all' else spans
    assert all(1 <= a <= b <= length for a, b in intervals), (name, length, intervals)
    r = hashed(p)
    r.update(file_lines=length, read_intervals_inclusive=intervals)
    records.append(r)

artifact_names = [
 'work/continuation_20261121/degenerate_flag_orthogonality.tex',
 'work/continuation_20261121/degenerate_flag_source_trace.md',
 'work/continuation_20261121/check_degenerate_flag_orthogonality.py',
 'work/continuation_20261121/degenerate_flag_orthogonality_checks.json',
 'work/continuation_20261121/build_degenerate_flag_manifest.py',
 'work/continuation_20261121/degenerate_flag_orthogonality_compile.json',
 'work/continuation_20261121/degenerate_flag_orthogonality_peer_review_root.md',
 'output/degenerate_flag_orthogonality_check.tex',
 'output/degenerate_flag_orthogonality_check.pdf',
 'work/degenerate_flag_orthogonality_check_compile_1.log',
 'work/degenerate_flag_orthogonality_check_compile_2.log',
]
payload = {
 'author': '/root/formal_degree_review',
 'scope': 'ordinary proof plus the listed source intervals and exact finite controls; no full transitive dependency audit and no Lean replay',
 'excluded_conclusions': ['absolute convergence of all actual orbital terms', 'diagonal Kpp bound', 'degenerate amplitude estimate', 'lattice-pair mass count'],
 'source_read_scopes': records,
 'artifacts': [hashed(BASE/p) for p in artifact_names if (BASE/p).exists()],
 'pending_optional_records': [p for p in artifact_names if not (BASE/p).exists()],
}
out = HERE/'degenerate_flag_source_manifest.json'
out.write_text(json.dumps(payload, indent=2)+'\n')
print(json.dumps({'manifest':str(out.relative_to(BASE)), 'source_files':len(records), 'artifacts':len(payload['artifacts']), 'pending':payload['pending_optional_records']}, indent=2))
