"""Reproducible hashes and conservative read coverage for the global theta pass."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
SRC = BASE / "sources/lean/src"
OUT = Path(__file__).resolve().parent
HC = "Formalism/HermitianCurvature/"
HP = HC + "HermitianCurvatureProofs/"
LR = "Formalism/LatticeRigidity/"
LC = "Formalism/LocalToGlobal/SiegelLatticeTheory/CokernelGLCounts/"
DATA = [
    (LR+"StatementC.lean", "all", "Exact smoothed ideal-sum statement and its hypotheses."),
    (LR+"PackCount.lean", "all", "General packing-count statement."),
    (LR+"HeightMinimum/SqrtAbsNormLeProd.lean", "all",
     "All421 lines directly read across this pass: norm minimum, lattice box count, dyadic cube sum, and final interpolation. Source already reaches K−1 before relaxing to K−5/2."),
    (LR+"HeightMinimum/PackingCountGeometricMean.lean", "all",
     "Full general volume-packing proof, including the final coordinate rescaling."),
    (HC+"PrimeToDifferent.lean", [[1,255]],
     "Actual different, period, lift and scaled trace-dual definitions; lattice and norm statements. Local-to-global statements beyond255 not fully read."),
    (HC+"StatementL.lean", "all", "Exact normalized dual-ideal and dual-lattice inclusion statements."),
    (HC+"StatementJ.lean", [[1,98],[112,304],[328,430]],
     "Actual profile, ideal sizes, block ideals, embeddings, trace pairing, frames, Poisson hypotheses, K=5 instance, and lift-width factor2. Later theorem packages not read in full."),
    (HC+"StatementTA.lean", [[50,64]], "Exact finite nonzero-lattice sum definition."),
    (HC+"StatementTB.lean", [[135,245]],
     "Exact local support, positivity, EstWave/EstLift/EstBlock, lattice sums, and beginning of their recursion consumers. The actual analytic estimates remain unproved in this reconstruction."),
    (HC+"LevelRecursionCondNeeded.lean", [[1,260],[325,397]],
     "Initial polynomial/Schur statement inventory and complete Poisson definitions, including product decay exponent3 and absolute Fourier summability."),
    (HC+"StatementPB.lean", [[230,399]],
     "Actual scalar-energy RealInputs, LocalCores, GlobalCores and MainRow assembly hypotheses. This is a statement/dependency audit, not a proof of MainRow."),
    (HC+"StatementSz.lean", [[1,120],[452,612]],
     "Exact size/mass/column definitions and final threshold-size statements; broad provider hypotheses remain open."),
    (HP+"PeriodLatticeFactsSplitOfGeneral.lean", "all",
     "Degree, different/unramifiedness, scaled-ideal norm and adjacent-ideal identities; full190-line file."),
    (HP+"TwistedIsRealOrderLattice.lean", "all",
     "Full254-line finite-index/covolume/scaling and real-order lattice proof."),
    (HP+"LocalisationScaledIdealMemIff.lean", [[350,505]],
     "Actual dual inclusion, least norm and stronger parity condition. Full declaration index was also inspected; other proof bodies are not included in read coverage."),
    (HP+"FinrankLeOfMapLe.lean", [[340,395]],
     "Final exact twisted-lattice index provider and its assembly; earlier lifting/rank lemmas not read in full. Replaced by the displayed local unramified quadratic-ring proof for the actual different powers."),
    (HP+"DualCovolumeChangeOfVariables.lean", "all",
     "Full401-line file: trace normalization, trace-dual surjectivity, exact dual volumes and actual PoissonJoint assembly."),
    (HP+"PoissonSummationDecay.lean", "all",
     "Full295-line proof, including locally uniform product-decay summability and the actual Poisson hypotheses."),
    (HP+"PoissonJointFirstReduction.lean", [[1,65]],
     "Transform at zero and actual first Poisson reduction; later frame/threshold providers not read in full."),
    (HP+"LevelSizesJointMean.lean", [[1,110]],
     "Actual BoxSumLattice wrapper, zero-width handling and product-size enlargement. Later probability/recursion proof not read in full."),
    (HP+"SixteenMulLeTwoPow.lean", [[1,145]],
     "Early positivity, beta-bound assembly and the beginning of SizesMain; its imported archimedean/mass estimates remain open."),
    (HP+"SecondDerivativeHolds.lean", "all",
     "Exact local/global core provider assembly identifying the ideal-sum, lattice and Poisson dependencies."),
    (LC+"RowsConc.lean", [[1,170]],
     "Concrete four-energy/diagonal definitions and initial interface. Declaration index also inspected; later proof bodies not read in full."),
    (LC+"RowsOther.lean", [[1,180]],
     "Degenerate off-diagonal/diagonal and row-loop/nongeneric interfaces; global imported estimates not reconstructed."),
    ("Formalism/SharpRestriction/CuspSpanNormBounds/NonGenericAndKTwoTheorems.lean", [[1,220]],
     "Exact KTwo parameter conditions, off-diagonal vanishing, diagonal conclusion, and initial mass/counting hypotheses. These full global statements remain open."),
]
files = []
for path, ranges, note in DATA:
    p = SRC/path
    raw = p.read_bytes()
    lines = len(raw.decode().splitlines())
    if isinstance(ranges, list):
        ranges = [[a, min(b, lines)] for a,b in ranges]
    files.append({"path": path, "sha256": hashlib.sha256(raw).hexdigest(),
                  "line_count": lines, "read_scope": ranges, "assessment": note})
result = {
    "scope": "Global ideal sums, actual period-lattice arithmetic, exact Fourier/covolume normalization and continuous Poisson step",
    "source_root": "sources/lean/src",
    "mathematical_deliverable": "global_theta_estimates.tex",
    "source_trace": "global_theta_source_trace.md",
    "exact_controls": "check_global_theta.py",
    "files": files,
    "warning": "Read coverage is not formal dependency closure or Lean re-elaboration. The actual archimedean test-function Fourier/width bounds, finite-place mass formulas, four full global orbital energies, diagonal bound and ambient-dimension estimate remain separate obligations.",
}
(OUT/"global_theta_source_manifest.json").write_text(json.dumps(result, indent=2)+"\n")
print(f"Recorded {len(files)} global theta source hashes and exact read scopes.")
