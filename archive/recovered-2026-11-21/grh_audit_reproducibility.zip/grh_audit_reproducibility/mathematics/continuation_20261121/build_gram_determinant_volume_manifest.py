"""Record exact scope of the independent Gram-volume proof."""
from pathlib import Path
from hashlib import sha256
import json

base = Path(__file__).resolve().parent
root = base.parents[1]
src = root / 'sources/lean/src'
def record(p):
    raw = p.read_bytes()
    return dict(path=str(p.relative_to(root)), sha256=sha256(raw).hexdigest(),
                bytes=len(raw), lines=len(raw.splitlines()))

prefix = 'Development/AbelianVarietyTheory/'
data = [
    (prefix+'Definitions/SemilocalFrames/UpperOff.lean', [[1,110]]),
    (prefix+'Definitions/SemilocalFrames/IsNormalFormStabilizerMeasure.lean', None),
    (prefix+'Proofs/FlagMeasures/MeasurePreservingMulVec.lean', None),
    (prefix+'Proofs/FlagMeasures/VolumeGramConditionCodimTwoThree.lean', None),
    ('Formalism/FlagUnipotentLattices/MinkowskiFactorialBounds/MeasurePreservingPiCompProd.lean',
     [[650,720],[780,915]]),
    (prefix+'Proofs/FlagMeasures/FlagUnipotentGramNullAndFibreVolumeNormalForm.lean', None),
    (prefix+'Proofs/FlagMeasures/FlagUnipotentGramNullAndFibreVolumeNormalFormStatement.lean', None),
    (prefix+'Proofs/FlagMeasures/FlagGramEqGramDetProjectionNormalFormStatement.lean', None),
]
sources=[]
for name, windows in data:
    r=record(src/name)
    r.update(inspected_line_intervals=windows or [[1,r['lines']]],
             full_file_inspected=windows is None)
    sources.append(r)
names=['gram_determinant_volume.tex','gram_determinant_volume_source_trace.md']
names += [p.name for p in base.glob('gram_determinant_volume_peer_review_*.md')]
out=dict(scope='Exact projected Gram negative moments, optimal sublevel exponent, and both orbital volume leaves.',
         sources=sources, artifacts={n:record(base/n) for n in names},
         limits=['Flag-coordinate and coordinate-size reductions remain separate.',
                 'No numerical calculation is used to certify the general analytic inequalities.',
                 'No full Lean replay is asserted.'])
(base/'gram_determinant_volume_source_manifest.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'sources':len(sources),'manuscript_sha256':out['artifacts'][names[0]]['sha256']},indent=2))
