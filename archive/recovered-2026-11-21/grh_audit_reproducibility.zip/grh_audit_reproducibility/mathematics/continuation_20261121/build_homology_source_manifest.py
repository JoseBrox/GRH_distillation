from pathlib import Path
import hashlib
import json

base = Path(__file__).resolve().parents[2]
root = base / "sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties"
full = {
    "GeneratorCountTuples/Bridge.lean": "Exact conditional KBridge definition, including kernel exponent.",
    "GeneratorCountTuples/Reduction.lean": "Complete conditional cardinality reduction; not a provider of KBridge.",
    "GeneratorCountTuples/TorsBoundPow.lean": "Definitions of integral group homology, torsion and both numerical bounds.",
    "GeneratorCountTuples/CardRed.lean": "Complete finite-module cardinality argument.",
    "GeneratorCountTuples/TensCard.lean": "Complete finite-subgroup tensor bound.",
    "GeneratorCountTuples/NumT.lean": "Complete numerical conversion.",
    "GeneratorCountTuples/LemmaKOfPublished.lean": "Complete assembly still conditional on KBridge.",
    "TensorHomCubes/KBridgeOfKPublished.lean": "Complete file; defines KPublished but proves no KBridge.",
    "HermiteNormalForms/TorsMain.lean": "Complete wrapper.",
    "HermiteNormalForms/Assembly.lean": "Complete assembly from geometric exactness, orbit and stabilizer providers.",
    "HermiteNormalForms/ImportsAlt.lean": "Complete stabilizer assembly.",
    "HermiteNormalForms/SmulNeZeroLat.lean": "Complete definitions of ordered tuples and their action, not proof of geometric acyclicity.",
    "HermiteNormalForms/Orbnum.lean": "Complete elementary numerical orbit bound, not the geometric orbit classification.",
    "HermiteNormalForms/Mink3.lean": "Complete reduction-modulo-3 stabilizer bound.",
    "TorsionBoundsChains/FaceDSingle.lean": "Complete complex, boundary, orbit and stabilizer definitions.",
    "TorsionBoundsChains/Imports.lean": "Complete zero-homology torsion reduction.",
    "TorsionBoundsChains/ImportsAlt.lean": "Complete finite-group homology annihilation argument.",
    "TorsionBoundsChains/FinGroup.lean": "Complete finite-group homology cardinality argument.",
    "TorsionBoundsChains/TorsBoundOf.lean": "Complete numerical torsion assembly.",
    "ModularityArgument/ClassCounting/LemmaKOfSteps.lean": "Complete intermediate definitions and dependency composition; providers remain separate.",
    "ModularityArgument/ClassCounting/LemmaKOfLitN.lean": "Complete concrete provider assembly.",
    "ModularityArgument/ClassCounting/ExponentLe.lean": "Complete all-degree torsion numerical bound, exponent 24.",
    "ModularityArgument/ThresholdArguments/DenseThresholdCases/KFinal.lean": "Complete coarse-cohomology assembly actually passed to the final interval route.",
    "ModularityArgument/ThresholdArguments/DenseThresholdCases/WindowBoundOfLiteratureLevel.lean": "Complete use of coarse cohomology in the final VWin assembly.",
    "SmallClassNumbers/CorGKOf.lean": "Complete second concrete consumer of the same coarse bound.",
    "HeightAndVanishing/FinalU.lean": "Complete older conditional KBridge route, distinguished from the route above.",
    "HeightAndVanishing/HeightVanishingHypotheses.lean": "Complete imported-hypothesis structure.",
}
records = []
for name, scope in full.items():
    p = root / name
    data = p.read_bytes()
    lines = len(data.decode().splitlines())
    records.append({
        "path": str(p.relative_to(base)), "bytes": len(data), "lines": lines,
        "sha256": hashlib.sha256(data).hexdigest(),
        "read_ranges": [[1, lines]], "scope": scope,
    })
p = root / "ModularityArgument/ClassCounting/SFinal.lean"
data = p.read_bytes()
lines = len(data.decode().splitlines())
records.append({
    "path": str(p.relative_to(base)), "bytes": len(data), "lines": lines,
    "sha256": hashlib.sha256(data).hexdigest(),
    "read_ranges": [[1, min(lines, 180)]],
    "scope": "Local invariant bounds and Selmer-to-H2 proof through line 180; the general duality theorem is imported.",
})
out = Path(__file__).with_name("homology_source_manifest.json")
out.write_text(json.dumps({
    "date": "2026-11-21",
    "scope_note": "Full-file reading does not assert exhaustive review of imported proof dependencies. The written geometric input and global class count remain conditional.",
    "files": records,
}, indent=2) + "\n")
print(json.dumps({"files": len(records), "manifest": str(out)}, indent=2))
