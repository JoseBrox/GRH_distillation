"""Record exact source scopes for the actual Jacquet Fourier argument."""
from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
SRC = OUT.parents[1]/'sources/lean/src'
H = 'Formalism/HermitianCurvature/'
P = H+'HermitianCurvatureProofs/'

data = [
 (H+'StatementJC.lean',[[12,43]],'Actual NiceCoef definition and beginning of the separate full radial-module target.'),
 (H+'StatementWd.lean',[[112,140],[190,201]],'Six coordinate operators, finite bT words and wave matrices.'),
 (H+'StatementQ.lean',[[148,214]],'Exact group cofactor operators tL; retained as the separate full-matrix application still to be completed.'),
 (H+'CompositeFormulaLevelZero.lean',[[1,115]],'First part only: coordinate waves, QQi, RRi, bTl and partial pairings.'),
 (H+'HerGenC.lean',[[1,80]],'Complete compact generated class and actual compact theorem target.'),
 (P+'RadialIdentityOfQuadratic.lean',[[1,158]],'First part only: exact four operators, collapse identity, shifted Gauss adjoint identity and spectral normalization.'),
 (P+'CutSERDIdentSpec.lean',[[15,114]],'Actual radial adjoints, group operator conditions, regular spectral choice and four lift targets.'),
 (P+'CutSERDSOpR.lean',[[1,136]],'Complete spectral composition construction for the two coupled lifts.'),
 (P+'CutSERDAsm.lean',[[1,94]],'Complete iterative Fourier decay and transfer to actual radial pairings.'),
 (P+'CutSE2.lean',[[225,277],[386,418]],'Partial class definitions, all-coordinate closure target, density, Fourier and multiplication targets.'),
 (P+'CutSESiteOpsC.lean',[[1,166]],'Complete first-minor polynomial multiplication and invariance proof.'),
 (P+'CutSH2.lean',[[1,118]],'First part only: exact compact lower-rank family, its normalization and derivative/representation targets.'),
 (P+'CutSEJSliceCut.lean',[[1,122]],'Complete compact wave generators, local square-integrable slices and derivative targets.'),
 (P+'CutSEJSRadLocCut.lean',[[1,19]],'Complete common-seminorm bound target for compact families.'),
 (P+'CutSEJSRadLocFamCC.lean',[[1,160]],'First part only: local derivative bounds and uniform compact-family seminorm estimates.'),
 (P+'CutSEJSRadLoc.lean',[[1,140]],'First part only: actual source assembly of lower-rank compact families and the pairing bound.'),
 (P+'CutSELeibnizClsC.lean',[[1,62]],'Complete source reduction of generated smooth densities and Leibniz formulas to compact slice regularity.'),
 (P+'CutSETopFinal.lean',[[1,16]],'Complete active compact theorem assembly; prevents confusing the active result with an unproved general class interface.'),
 (P+'LevelFormSesquilinearFiniteClass.lean',[[1235,1287],[1639,1689]],'Two excerpts identifying the separate bcGood_tL and rma_Qop full-matrix obligations, not claimed discharged by the present four lifts.'),
]
files = []
for rel, scope, note in data:
    raw = (SRC/rel).read_bytes()
    n = len(raw.decode().splitlines())
    assert all(1 <= a <= b <= n for a,b in scope),(rel,n,scope)
    files.append(dict(path=rel,sha256=hashlib.sha256(raw).hexdigest(),line_count=n,read_scope=scope,assessment=note))

deps = []
for stem in ['theta_radial_spectral_lift','theta_radial_differential_lifts',
             'theta_radial_coupled_lifts','theta_terminal_quantum_determinant',
             'theta_terminal_commutation','theta_recursive_radial_frame',
             'jacquet_unipotent_decay','jacquet_majorant',
             'jacquet_integration_formula','jacquet_pairing_adjointness']:
    for suffix in ['.tex','_peer_review_root.md']:
        f = OUT/(stem+suffix)
        if f.exists():
            deps.append(dict(path=f.name,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
reviews = []
f = OUT/'jacquet_fourier_decay_actual_peer_review_root.md'
if f.exists():
    reviews.append(dict(path=f.name,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
report = dict(
    mathematical_deliverable='jacquet_fourier_decay_actual.tex',
    manuscript_sha256=hashlib.sha256((OUT/'jacquet_fourier_decay_actual.tex').read_bytes()).hexdigest(),
    source_root='sources/lean/src',
    source_trace='jacquet_fourier_decay_actual_source_trace.md',
    exact_controls='check_jacquet_fourier_decay_actual.py',
    files=files,proved_dependencies=deps,peer_reviews=reviews,
    status='Actual Fourier decay and compact slice regularity proved. Full initial matrix lift and its restriction identity remain explicitly separate.',
    kernel_replay_claimed=False,
)
(OUT/'jacquet_fourier_decay_actual_source_manifest.json').write_text(json.dumps(report,indent=2)+'\n')
print(f'Recorded {len(files)} source files and {len(reviews)} reviews.')
