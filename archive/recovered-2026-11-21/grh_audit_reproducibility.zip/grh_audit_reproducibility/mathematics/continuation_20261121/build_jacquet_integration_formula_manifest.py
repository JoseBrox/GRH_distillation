"""Exact source scopes for the geometric integration formula."""
from pathlib import Path
import hashlib, json

OUT = Path(__file__).resolve().parent
SRC = OUT.parents[1]/"sources/lean/src"
data = [
 ("Formalism/HermitianCurvature/StatementB.lean", [[1,565]], "Complete real-place data and actual IntFormula, CCIntegrable, dilation, and pairing targets."),
 ("Formalism/FormalDegreeBessel/StatementG.lean", [[1,90]], "Hermitian convention, group, unipotent and compact stabilizers, character and Bessel minors."),
 ("Formalism/FormalDegreeBessel/StatementBF.lean", [[50,161]], "Actual bigCell, Mdim, bcWeight, Jacquet transform and radial pairing definitions."),
 ("Formalism/FormalDegreeBessel/StatementRP.lean", [[60,92]], "Exact smooth exterior section and radial domain definitions."),
 ("Formalism/HermitianCurvature/WeylElementCommutesLevelOne.lean", [[270,360],[396,407]], "IterInt, compact terminal orbit and measure assertions, IntConst, IntNorm and GNIntSharp.")
]
files = []
for name, scope, note in data:
    raw = (SRC/name).read_bytes()
    line_count = len(raw.decode().splitlines())
    assert all(1 <= a <= b <= line_count for a,b in scope)
    files.append(dict(path=name, sha256=hashlib.sha256(raw).hexdigest(),
                      line_count=line_count, read_scope=scope, assessment=note))
deps = []
for stem in ["jacquet_kernel_estimates", "jacquet_unipotent_decay", "jacquet_majorant"]:
    for suffix in [".tex", "_peer_review_root.md"]:
        path = OUT/(stem+suffix)
        if path.exists():
            deps.append(dict(path=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
reviews = []
path = OUT/"jacquet_integration_formula_peer_review_root.md"
if path.exists():
    reviews.append(dict(path=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
result = dict(
    mathematical_deliverable="jacquet_integration_formula.tex",
    manuscript_sha256=hashlib.sha256((OUT/"jacquet_integration_formula.tex").read_bytes()).hexdigest(),
    source_root="sources/lean/src", source_trace="jacquet_integration_formula_source_trace.md",
    exact_controls="check_jacquet_integration_formula.py", files=files,
    proved_dependencies=deps, peer_reviews=reviews,
    status="Full geometric IntFormula, terminal quotient measure, GNIntSharp and CCIntegrable, character dilation, and both pushforward Jacobians proved in conventional mathematics.",
    kernel_replay_claimed=False)
(OUT/"jacquet_integration_formula_source_manifest.json").write_text(json.dumps(result, indent=2)+"\n")
print(f"Recorded {len(files)} source files and {len(reviews)} reviews.")
