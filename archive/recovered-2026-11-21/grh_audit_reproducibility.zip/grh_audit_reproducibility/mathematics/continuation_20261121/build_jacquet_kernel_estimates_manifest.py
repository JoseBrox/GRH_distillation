"""Conservative provenance for the Jacquet coordinate integral reconstruction."""
from pathlib import Path
import hashlib
import json

OUT = Path(__file__).resolve().parent
SRC = OUT.parents[1] / "sources/lean/src"
PREFIX = "ReciprocityTheory/ReductiveGroups/DiscreteSeries/TailIntegrals/"
descriptions = {
    "TailInt.lean": "All actual coordinate definitions and the seven assertions proved in the manuscript.",
    "Imports.lean": "Exact rotation and reciprocal scaling definitions.",
    "CriticalExponentSucc.lean": "First complex-coordinate integration and exact CH-to-Tail identity.",
    "TailFinOf.lean": "Convergence inequalities, completed square, and CH/TailFin induction.",
    "LintegralInsertFiberLe.lean": "Weighted complex-coordinate integration, with precise powers.",
    "DeZeroBounds.lean": "Bounds in the remaining real coordinate and the correct uniform scale.",
    "ExponentConditionNeg.lean": "Exact exponent shift and weighted subcritical integral.",
    "RhoMulStar.lean": "Full rotation invariance, measure preservation, and first polynomial average.",
    "RhoSqNonneg.lean": "Full reciprocal scaling calculation and second polynomial average.",
    "OscillatoryBound.lean": "Complete source assembly of the OS estimate.",
    "InductiveHeisenbergInputs.lean": "Definitions of subsequent group estimates; not all proved here.",
}
files = []
for basename, assessment in descriptions.items():
    name = PREFIX + basename
    raw = (SRC / name).read_bytes()
    lines = len(raw.decode().splitlines())
    files.append({
        "path": name,
        "sha256": hashlib.sha256(raw).hexdigest(),
        "line_count": lines,
        "read_scope": [[1, lines]],
        "assessment": assessment,
    })
reviews = []
review = OUT / "jacquet_kernel_estimates_peer_review_root.md"
if review.exists():
    reviews.append({"path": review.name, "sha256": hashlib.sha256(review.read_bytes()).hexdigest()})
result = {
    "mathematical_deliverable": "jacquet_kernel_estimates.tex",
    "manuscript_sha256": hashlib.sha256((OUT / "jacquet_kernel_estimates.tex").read_bytes()).hexdigest(),
    "source_root": "sources/lean/src",
    "source_trace": "jacquet_kernel_estimates_source_trace.md",
    "exact_controls": "check_jacquet_kernel_estimates.py",
    "files": files,
    "peer_reviews": reviews,
    "status": "CH, TailFin, C1, SUB, KER, SLOW and actual OS proved in conventional mathematics. CH and TailFin have exact values and necessary convergence conditions. Geometric induction, group integral, and final Jacquet pairing arguments remain separate.",
    "kernel_replay_claimed": False,
}
(OUT / "jacquet_kernel_estimates_source_manifest.json").write_text(json.dumps(result, indent=2) + "\n")
print(f"Recorded {len(files)} source files and {len(reviews)} reviews.")
