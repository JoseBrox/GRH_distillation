"""Conservative provenance for the complete full-group Jacquet majorant."""
from pathlib import Path
import hashlib,json
OUT=Path(__file__).resolve().parent
SRC=OUT.parents[1]/"sources/lean/src"
P="ReciprocityTheory/ReductiveGroups/DiscreteSeries/TailIntegrals/"
data=[
 ("Formalism/HermitianCurvature/StatementB.lean",[[230,230],[243,243],[313,327],[439,453]],"Exact norm, threshold, CoefBound, XiInt and XiExists targets; beginning of subsequent targets."),
 (P+"InductiveHeisenbergInputs.lean",None,"Full actual group-integral, flag-kernel and induction definitions."),
 ("Formalism/HermitianCurvature/WeylElementCommutesLevelOne.lean",[[195,263]],"Actual one-step cell, inverse-left convention, Haar density and null-set assertions."),
 (P+"TLeftH.lean",None,"Complete two-sided compact factorization of integrals."),
 (P+"XphiLinInd.lean",None,"Complete flag scaling and Haar substitution statements and proofs."),
 (P+"EIntBound.lean",None,"Actual right-Heisenberg estimate and complex radial integral."),
 (P+"AStepFin.lean",None,"Complete AAt induction and exact exponent shifts."),
 (P+"InnerCLe.lean",[[1,125]],"Exact norm weight and scaling and first part of inner bound; remainder not claimed read."),
 (P+"HeisenbergRankOneDecomposition.lean",None,"Actual compact/stabilizer factorization and norm identities."),
 (P+"Phi2.lean",None,"Exact alternate isotropic frame in the group step."),
 (P+"XiRNonneg.lean",[[50,204]],"Primed/unprimed H-conjugation and complete coefficient estimate; initial helper lemmas not claimed read."),
 (P+"XiIntH.lean",None,"Complete compact-stabilizer integrability argument."),
 (P+"XiExists2.lean",None,"Actual assembly of the majorant from AAt, BAt and the two estimates."),
]
files=[]
for name,scope,note in data:
 raw=(SRC/name).read_bytes();n=len(raw.decode().splitlines())
 if scope is None:scope=[[1,n]]
 assert all(1<=a<=b<=n for a,b in scope),(name,n,scope)
 files.append(dict(path=name,sha256=hashlib.sha256(raw).hexdigest(),line_count=n,read_scope=scope,assessment=note))
deps=[]
for name in ["jacquet_kernel_estimates.tex","jacquet_unipotent_decay.tex",
             "jacquet_kernel_estimates_peer_review_root.md","jacquet_unipotent_decay_peer_review_root.md"]:
 deps.append(dict(path=name,sha256=hashlib.sha256((OUT/name).read_bytes()).hexdigest()))
reviews=[]
name="jacquet_majorant_peer_review_root.md"
if (OUT/name).exists():reviews.append(dict(path=name,sha256=hashlib.sha256((OUT/name).read_bytes()).hexdigest()))
result=dict(mathematical_deliverable="jacquet_majorant.tex",
 manuscript_sha256=hashlib.sha256((OUT/"jacquet_majorant.tex").read_bytes()).hexdigest(),
 source_root="sources/lean/src",source_trace="jacquet_majorant_source_trace.md",
 exact_controls="check_jacquet_majorant.py",files=files,proved_dependencies=deps,peer_reviews=reviews,
 status="Full AAt, CoefBound, XiInt and XiExists proved in conventional mathematics; final regularized pairing, dominated unfolding and Jacquet adjointness remain separate.",
 kernel_replay_claimed=False)
(OUT/"jacquet_majorant_source_manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(f"Recorded {len(files)} source files and {len(reviews)} reviews.")
