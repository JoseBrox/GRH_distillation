"""Conservative source scopes for the regularized Jacquet pairing."""
from pathlib import Path
import hashlib, json

OUT = Path(__file__).resolve().parent
SRC = OUT.parents[1]/"sources/lean/src"
P = "Formalism/HermitianCurvature/HermitianCurvatureProofs/"
data = [
 ("Formalism/HermitianCurvature/StatementB.lean", [[1,565]], "Complete actual statements and hypotheses, including the full IntClause and polynomial coefficient criterion."),
 ("Formalism/FormalDegreeBessel/StatementG.lean", [[1,90]], "Exact Hermitian convention, character, Bessel minors and invariant polynomial Gf."),
 ("Formalism/FormalDegreeBessel/StatementBF.lean", [[50,161]], "Exact Jacquet and weighted radial pairing definitions."),
 (P+"NormDiagonalEntryDilationGeneratorLeOne.lean", [[2087,2180],[3156,3242]], "Actual regularized bracket expansion and mixed derivative, Fourier average assembly, and final RegBound/RegAverage assertions. Intermediate helper proofs outside these ranges are not claimed fully read."),
 (P+"OrbitalIntegralAeConvergenceContinuity.lean",
  [[608,661],[729,759],[894,937],[1033,1060],[1540,1571],[1707,1749]],
  "Actual dilation identities and radial exponent, almost everywhere convergence/continuity, compact-unitary correlation identity, fixed-orbit averaged identity and final unfolding. The rest of this large file is not claimed fully read."),
 (P+"RegularisedPairingViaPhase.lean", [[188,202],[695,897]], "Regularized phase congruence, invariant integration by parts, reversed word, smooth translation and final phase adjointness proof."),
 (P+"AdjointnessPolynomiallyBounded.lean", [[1,149]], "Full actual assembly of pairing equality and adjointness, polynomial-coefficient reduction, and dilation identities."),
 (P+"BetaSesquilinearity.lean", [[1407,1498]], "Actual fifth-derivative dilation argument upgrading almost everywhere equality. The manuscript uses a shorter direct Hilbert-space continuity proof.")
]
files = []
for name, scope, note in data:
    raw = (SRC/name).read_bytes()
    line_count = len(raw.decode().splitlines())
    assert all(1 <= a <= b <= line_count for a,b in scope)
    files.append(dict(path=name, sha256=hashlib.sha256(raw).hexdigest(),
                      line_count=line_count, read_scope=scope, assessment=note))
deps = []
for stem in ["jacquet_kernel_estimates", "jacquet_unipotent_decay",
             "jacquet_majorant", "jacquet_integration_formula"]:
    for suffix in [".tex", "_peer_review_root.md"]:
        path = OUT/(stem+suffix)
        if path.exists():
            deps.append(dict(path=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
reviews = []
path = OUT/"jacquet_pairing_adjointness_peer_review_root.md"
if path.exists():
    reviews.append(dict(path=path.name, sha256=hashlib.sha256(path.read_bytes()).hexdigest()))
result = dict(
    mathematical_deliverable="jacquet_pairing_adjointness.tex",
    manuscript_sha256=hashlib.sha256((OUT/"jacquet_pairing_adjointness.tex").read_bytes()).hexdigest(),
    source_root="sources/lean/src", source_trace="jacquet_pairing_adjointness_source_trace.md",
    exact_controls="check_jacquet_pairing_adjointness.py", files=files,
    proved_dependencies=deps, peer_reviews=reviews,
    status="Full regularization, averaged unfolding, equality at every positive character, exact IntClause adjointness, and polynomial-coefficient adjointness proved. Operator-specific covariance remains an algebraic verification in the radial fragments.",
    kernel_replay_claimed=False)
(OUT/"jacquet_pairing_adjointness_source_manifest.json").write_text(json.dumps(result, indent=2)+"\n")
print(f"Recorded {len(files)} source files and {len(reviews)} reviews.")
