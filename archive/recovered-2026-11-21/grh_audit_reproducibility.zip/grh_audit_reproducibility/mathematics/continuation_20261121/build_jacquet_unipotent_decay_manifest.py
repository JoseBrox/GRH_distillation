"""Conservative provenance for weighted unipotent integrability."""
from pathlib import Path
import hashlib,json
OUT=Path(__file__).resolve().parent
SRC=OUT.parents[1]/"sources/lean/src"
P="ReciprocityTheory/ReductiveGroups/DiscreteSeries/TailIntegrals/"
data=[
 (P+"InductiveHeisenbergInputs.lean",None,"Full actual definitions of the group estimates and geometric inputs."),
 ("Formalism/FormalDegreeBessel/StatementG.lean",[[1,150]],"Exact Hermitian form, flags, Nset, ell and fvec."),
 ("Formalism/HermitianCurvature/StatementB.lean",[[135,135]],"Actual real character normalization."),
 ("Formalism/HermitianCurvature/WeylElementCommutesLevelOne.lean",[[90,165]],"Heisenberg group, conjugation and recursive Haar statements."),
 (P+"DelFormula.lean",[[1,225],[229,269],[451,462]],"Basis and Gram computations, exact final norm identity; middle index proofs not claimed read."),
 (P+"IndexEmbeddingBijective.lean",[[1,155],[165,206]],"Unitary coordinate transformation and full final measure-preserving shear; omitted index lines not claimed read."),
 (P+"LevelDeterminantOfTriangularChange.lean",[[240,266]],"Exact lower-rank triangular norm factors and first coefficient."),
 (P+"InnerBound.lean",None,"Full nonvanishing and weighted lower-rank integral proof."),
 (P+"BStepSuccOf.lean",None,"Full actual BAt induction, including exponent windows and Haar passage."),
]
files=[]
for name,scope,note in data:
 raw=(SRC/name).read_bytes();n=len(raw.decode().splitlines())
 if scope is None:scope=[[1,n]]
 assert all(1<=a<=b<=n for a,b in scope),(name,n,scope)
 files.append(dict(path=name,sha256=hashlib.sha256(raw).hexdigest(),line_count=n,read_scope=scope,assessment=note))
reviews=[]
for name in ["jacquet_unipotent_decay_peer_review_root.md"]:
 if (OUT/name).exists():reviews.append(dict(path=name,sha256=hashlib.sha256((OUT/name).read_bytes()).hexdigest()))
deps=[]
for name in ["jacquet_kernel_estimates.tex","jacquet_kernel_estimates_peer_review_root.md"]:
 deps.append(dict(path=name,sha256=hashlib.sha256((OUT/name).read_bytes()).hexdigest()))
result=dict(mathematical_deliverable="jacquet_unipotent_decay.tex",
 manuscript_sha256=hashlib.sha256((OUT/"jacquet_unipotent_decay.tex").read_bytes()).hexdigest(),
 source_root="sources/lean/src",source_trace="jacquet_unipotent_decay_source_trace.md",
 exact_controls="check_jacquet_unipotent_decay.py",files=files,proved_dependencies=deps,peer_reviews=reviews,
 status="Full BAt induction, FormulaF and IW proved. Full-group AAt and the final Jacquet pairing passage remain separate.",
 kernel_replay_claimed=False)
(OUT/"jacquet_unipotent_decay_source_manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(f"Recorded {len(files)} source files and {len(reviews)} reviews.")
