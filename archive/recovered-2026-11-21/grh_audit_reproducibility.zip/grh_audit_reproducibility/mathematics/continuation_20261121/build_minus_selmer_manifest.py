"""Conservative source/proof scope for the independent minus-Selmer route."""
from pathlib import Path
import hashlib
import json

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[1]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
sources=[
 ("Development/AutomorphicArithmetic/AutomorphicVarieties/LengthEqAddEigen.lean",
  [[1,130]],"Actual conjugation action, ShaMinus sign, lengths and VVminusLe."),
 ("Development/AutomorphicArithmetic/AutomorphicVarieties/StmtFields.lean",
  [[1,130]],"Abelian compositum, conductor and precise minusBound."),
 ("Development/AutomorphicArithmetic/AutomorphicVarieties/PrimeSetBoundDataOfPrimitiveChar.lean",
  [[50,85]],"Actual ThmBcFree statement and its quantifiers."),
 ("Formalism/GaloisCohomology/Statement.lean",
  [[1,115]],"Cyclotomic negative twist, p-local restriction kernel and cohomology conventions."),
]
records=[]
for rel,scope,note in sources:
    p=ROOT/"sources/lean/src"/rel
    count=len(p.read_text().splitlines())
    scope=[[a,min(b,count)] for a,b in scope]
    records.append({"path":rel,"sha256":sha(p),"line_count":count,
                    "read_scope":scope,"assessment":note})
artifacts={}
for name in ["minus_selmer_classical.tex","minus_selmer_references.tex",
             "minus_selmer_source_trace.md","minus_selmer_peer_review_formal.md",
             "check_minus_selmer_special_values.py","minus_selmer_special_value_checks.json"]:
    p=HERE/name
    if p.exists():artifacts[name]={"sha256":sha(p),"bytes":p.stat().st_size}
pdf=HERE/"primary_minus/greither_popescu_1103.3069v1.pdf"
data={
 "scope":"Independent conventional replacement of the odd-prime opposite-parity bound; named classical inputs retained.",
 "artifacts":artifacts,
 "source_root":"sources/lean/src","sources":records,
 "primary_references":[
  {"url":"https://arxiv.org/pdf/1103.3069v1","sha256":sha(pdf),"bytes":pdf.stat().st_size,
   "verified_parts":"Section6.2, Lemma6.9, Theorem6.11 and Lemma6.12, printed pp38--40.",
   "not_claimed":"No independent reconstruction of the entire equivariant main-conjecture proof."},
  {"url":"https://www.jmilne.org/math/Books/ADTnot.pdf",
   "verified_parts":"ChapterI, Theorem4.10(a), printed pp56--57; pairing naturality.",
   "use":"Finite-coefficient duality; passage to limits and parity supplied in this manuscript."},
  {"url":"https://annals.math.princeton.edu/1979/190-2/p05",
   "verified_parts":"Primary bibliographic record for Ferrero--Washington; classical theorem already used in the common-interval reconstruction."}
 ],
 "remaining":"Complementary-parity cohomology, actual global theta estimates and final GRH assembly remain separate."
}
(HERE/"minus_selmer_source_manifest.json").write_text(json.dumps(data,indent=2)+"\n")
print(json.dumps({"sources":len(records),"artifacts":len(artifacts),"status":"written"}))
