"""Record exact files and honest reading scope of the near-count proof."""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SRC = ROOT / "sources/lean/src/Development/AbelianVarietyTheory"


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


scopes = [
    ("Definitions/SemilocalFrames/LayerProd.lean", "all"),
    ("Definitions/SemilocalFrames/DefClassNum.lean", "all"),
    ("BlockTheory/SiegelWeilLocal/NearNonzeroTerms.lean", "all"),
    ("Statements/CuspFrameWeights/SameKindIsometric.lean", [[95, 114]]),
    ("Statements/CuspFrameWeights/ConvolutionSmoothL2.lean", [[136, 145]]),
    ("Proofs/FlagMeasures/OneTypeArith.lean", "all"),
    ("Proofs/FlagMeasures/CanonicalFlagExistsUniqueSemistable.lean",
     [[1, 90]]),
]
data = {
    "fragment": "near_unipotent_integral.tex",
    "fragment_sha256": sha(BASE / "near_unipotent_integral.tex"),
    "reader": "/root/formal_degree_review",
    "source_root": str(SRC.relative_to(ROOT)),
    "source_files": [
        {"file": name, "sha256": sha(SRC / name),
         "line_count": len((SRC / name).read_text().splitlines()),
         "read_scope": scope} for name, scope in scopes
    ],
    "conventional_inputs": [
        {"file": name, "sha256": sha(BASE / name)}
        for name in ("ambient_multiplicity.tex", "rare_cusp_volume.tex")
    ],
    "new_classical_imports": [],
    "scope": (
        "Actual integrated near count via a directly constructed flag, "
        "successive block packing and repeated single-rank unfolding. "
        "The classical imports are exactly those of the linked RV proof. "
        "No deep-cusp estimate, whole dependency review or Lean replay."
    ),
}
for name in ("near_unipotent_source_trace.md",
             "check_near_unipotent_constants.py",
             "near_unipotent_constants_checks.json",
             "near_unipotent_integral_compile.json",
             "near_unipotent_peer_review_root.md",
             "near_unipotent_integral_peer_review_root.md"):
    if (BASE / name).exists():
        data.setdefault("records", []).append(
            {"file": name, "sha256": sha(BASE / name)})
(BASE / "near_unipotent_source_manifest.json").write_text(
    json.dumps(data, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"fragment_sha256": data["fragment_sha256"],
                  "source_files": len(scopes)}), flush=True)
