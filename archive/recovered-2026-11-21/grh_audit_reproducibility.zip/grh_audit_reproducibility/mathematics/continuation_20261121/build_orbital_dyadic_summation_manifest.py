"""Bind the dyadic theorem, independent review and actual source statements."""
from pathlib import Path
from hashlib import sha256
import json

base = Path(__file__).resolve().parent
root = base.parents[1]
prefix = root / 'sources/lean/src/Development/AbelianVarietyTheory/Proofs/FlagMeasures'

def record(p):
    raw = p.read_bytes()
    return dict(path=str(p.relative_to(root)), bytes=len(raw),
                lines=len(raw.splitlines()), sha256=sha256(raw).hexdigest())

sources = []
for name, intervals in [
    ('DyadicSummationWithDecay.lean', None),
    ('DyadicSummationWithDecayStatement.lean', None),
    ('AmplitudeDegenerateOperatorNormLeRealPlace.lean', [[1, 220]]),
]:
    item = record(prefix / name)
    item['inspected_line_intervals'] = intervals or [[1, item['lines']]]
    item['full_file_inspected'] = intervals is None
    sources.append(item)

names = ['orbital_dyadic_summation.tex',
         'orbital_dyadic_summation_source_trace.md',
         'orbital_dyadic_summation_peer_review_theta.md']
out = dict(
    scope='Stronger dyadic summation theorem and exact recovery of the submitted bound.',
    sources=sources, artifacts={n: record(base / n) for n in names},
    limits=['The geometric and one-sided square-integral inputs remain separate.',
            'The counterexample deletes a hypothesis retained in the submitted theorem.',
            'No complete Lean kernel replay is asserted.'])
(base / 'orbital_dyadic_summation_source_manifest.json').write_text(
    json.dumps(out, indent=2) + '\n')
print(json.dumps({'sources': len(sources),
                  'manuscript_sha256': out['artifacts'][names[0]]['sha256']}, indent=2))
