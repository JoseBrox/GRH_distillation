"""Record exactly the source intervals inspected for the OT/CM reconstruction."""
from pathlib import Path
from hashlib import sha256
import json
from datetime import datetime, timezone

base = Path(__file__).resolve().parent
root = base.parents[1]
src = root/"sources/lean/src/Development/AbelianVarietyTheory"
spec = {
 "Definitions/Jets/CmLatticeCommutatorPairingPowEqOneOfGoodLift.lean": [(1,180)],
 "Proofs/JetHarmonics/ThetaLawsUnitPeriod.lean": "full",
 "Proofs/JetHarmonics/CmEvenThetaSeriesChartCoeffIntegral.lean": "full",
 "Proofs/JetHarmonics/NormTranslatePowerCombLeCoprimeTranslation.lean": "full",
 "Proofs/JetHarmonics/WeilOperatorThetaTranslateShiftPrimeToQ.lean": "full",
 "Proofs/GlobalInterpolation/LawsAndChart.lean": "full",
 "Proofs/GlobalInterpolation/UnitPeriodTranslatesMomentsFinite.lean": "full",
 "Proofs/GlobalInterpolation/TranslateMomentsAll.lean": [(1,220)],
 "Proofs/GlobalInterpolation/NormalizedVectorTranslatesPrimeOrderIntegral.lean": "full",
 "Proofs/GlobalInterpolation/CmBaseThetaTensorPowerTranslatesIntegral.lean": "full",
 "Proofs/GlobalInterpolation/TranslateNormalizedVectorIntegralCombTensorPower.lean": "full",
 "Proofs/GlobalInterpolation/LatticeJetsAreBoundedMomentsOfSpanImagQuadratic.lean": "full",
 "Proofs/GlobalInterpolation/LatticeJetsAreBoundedMomentsOfTensorFourthPower.lean": "full",
 "Proofs/GlobalInterpolation/LatticeJetsAreBoundedMomentsPullback.lean": "full",
 "Proofs/GlobalInterpolation/CmThetaBaseVectorTranslatesIntegral.lean": "full",
 "Proofs/GlobalInterpolation/ExistsStandardIsometryFourthPowerSplitPrime.lean": "full",
 "Proofs/GlobalInterpolation/NormKappaSqMulDetSplitPrime.lean": "full",
}
sources = []
for relative, ranges in spec.items():
    path = src/relative
    raw = path.read_bytes()
    n = len(raw.splitlines())
    intervals = [[1,n]] if ranges == "full" else [[a,min(b,n)] for a,b in ranges]
    sources.append({"path":str(path.relative_to(root)),
                    "sha256":sha256(raw).hexdigest(),
                    "lines":n, "inspected_line_intervals":intervals,
                    "full_file_inspected":intervals==[[1,n]]})
artifacts = {}
for name in ["ordinary_theta_moments.tex","cm_theta_integrality.tex",
             "ordinary_theta_references.tex","ordinary_theta_peer_review_root.md"]:
    raw=(base/name).read_bytes()
    artifacts[name]={"sha256":sha256(raw).hexdigest(),"bytes":len(raw)}
primary=base/"primary_ordinary_theta/bannai_kobayashi_math_0610163v4.pdf"
record = {
 "created_utc":datetime.now(timezone.utc).isoformat(),
 "scope":"Ordinary moment algebra and classical one-dimensional CM reconstruction. "
         "Read ranges are source inspections, not a transitive source audit or kernel replay.",
 "artifacts":artifacts, "sources":sources,
 "primary_reference":{
   "url":"https://arxiv.org/pdf/math/0610163v4",
   "sha256":sha256(primary.read_bytes()).hexdigest(),
   "bytes":primary.stat().st_size,
   "verified_parts":["Proposition 2.15 and Corollary 2.16(i), printed pp.28-29",
                     "Lemma 2.7, printed p.24",
                     "Section 3.1, printed pp.35-36"],
   "not_claimed":"The full 55-page paper's proofs have not been independently rechecked."},
 "remaining_inputs":[
   "Existence of a good ordinary CM model is an explicitly cited classical input.",
   "The complete higher-dimensional normalized theta identity and its unit scalar "
   "have not been reconstructed merely from the one-dimensional laws.",
   "The actual column-kernel support identities and incidence commutation remain separate.",
   "The cited elliptic integrality statement is used only at p>=5, not at p=2 or p=3."],
}
(base/"ordinary_theta_source_manifest.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({"artifacts":artifacts,"source_files":len(sources)}))
