"""Record actual read scopes for the one-rank cusp-volume proof."""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SRC = ROOT / "sources/lean/src/Development/AbelianVarietyTheory"


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


records = [
    ("Definitions/SemilocalFrames/LayerProd.lean", "all"),
    ("Definitions/SemilocalFrames/DefClassNum.lean", "all"),
    ("Definitions/SemilocalFrames/IsGaugeAll.lean", "all"),
    ("Statements/CuspFrameWeights/SameKindIsometric.lean", "all"),
    ("Proofs/FlagMeasures/IsotropicFlagProbabilityBoundOfVolumeRatio.lean", "all"),
    ("Proofs/FlagMeasures/IsotropicFlagUnfoldingBound.lean", [[1, 180]]),
    ("Proofs/FlagMeasures/FlagRareOfNonzeroFlagBound.lean", "all"),
    ("BlockTheory/SiegelWeilLocal/RareFlags.lean", "all"),
]

primary = [
    ("primary_cusp/weil_siegel_1965.pdf",
     "https://archive.ymsc.tsinghua.edu.cn/pacm_download/117/5988-11511_2006_Article_BF02391774.pdf",
     "Relevant passages in sections 27, 53–54, 57; printed pages 40–41, 81–82, 85–86. Printed pages 41 and 82 visually checked. Not the whole article."),
    ("primary_cusp/louboutin_residue_2001.pdf",
     "https://doi.org/10.4153/CJM-2001-045-5",
     "Theorem 1(1) and its notation on printed page 1195. The proof and whole article are not claimed as read."),
    ("primary_mass/kirschmer_herm.pdf",
     "existing primary source in the earlier mass-formula manifest",
     "Theorem 2.4.1 and its surrounding rational-space/genus distinction, printed pages 19–20. No whole-thesis reading claim."),
]

data = {
    "fragment": "rare_cusp_volume.tex",
    "fragment_sha256": sha(BASE / "rare_cusp_volume.tex"),
    "reader": "/root/formal_degree_review",
    "review_status": "PASS after independent root review; scope is recorded in the linked review.",
    "source_root": str(SRC.relative_to(ROOT)),
    "source_files": [
        {"path": name, "sha256": sha(SRC / name),
         "line_count": len((SRC / name).read_text().splitlines()),
         "read_scope": scope}
        for name, scope in records
    ],
    "primary_references": [
        {"file": name, "sha256": sha(BASE / name),
         "bytes": (BASE / name).stat().st_size, "url": url,
         "read_scope": scope}
        for name, url, scope in primary
    ],
    "related_source_trace": "ambient_multiplicity_source_manifest.json",
    "imported_mathematical_fragment": {
        "file": "unitary_mass_densities.tex",
        "sha256": sha(BASE / "unitary_mass_densities.tex"),
        "current_reader_scope": "Lines 1–370: finite local counts and lifting, classical global input, exact mass ratio and beginning of source-convention discussion. Other reviewers' scopes are recorded separately.",
    },
    "scope": (
        "Direct conventional proof of rare cusp volume, using one "
        "primitive isotropic sublattice and explicit named classical "
        "Tamagawa, class-number, Hasse and residue theorems. "
        "No full transitive dependency reading or Lean kernel replay. "
        "Near-unipotent and deep-cusp estimates remain separate."
    ),
}
for name in ("rare_cusp_constants_checks.json", "rare_cusp_volume_compile.json",
             "rare_cusp_volume_peer_review_root.md"):
    if (BASE / name).exists():
        data.setdefault("verification", []).append(
            {"file": name, "sha256": sha(BASE / name)})

(BASE / "rare_cusp_source_manifest.json").write_text(
    json.dumps(data, ensure_ascii=False, indent=2) + "\n")
print(json.dumps({"fragment_sha256": data["fragment_sha256"],
                  "source_files": len(records)}), flush=True)
