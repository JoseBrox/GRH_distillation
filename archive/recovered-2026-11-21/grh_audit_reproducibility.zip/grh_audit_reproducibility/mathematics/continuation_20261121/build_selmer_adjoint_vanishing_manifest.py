"""Conservative source and primary-reference scope for adjoint Selmer vanishing."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json

base=Path(__file__).resolve().parent
root=base.parents[1]
prefix="sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/"
full=[
    "WeilGroupCharacters/UniversalOrdinaryDeterminantRing.lean",
    "WeilGroupCharacters/ContinuousResP.lean",
    "WeakShimuraTheory/UnipotentIdempotents/PrFacts.lean",
    "WeakShimuraTheory/EigenbasisLifts/IsTanZero.lean",
    "TheoremsMuLinked/OrdZero.lean",
    "ModularityArgument/ThresholdArguments/DenseThresholdCases/AutomorphicPointGalois.lean",
    "ModularityArgument/AutomorphyLifting/IsAutCsdA.lean",
    "AutomorphicForms/BlochKatoSelmerVanishes.lean",
    "PadicHodgeTheory/FiniteCohomology.lean",
    "LiteratureResults/Thorne.lean",
    "ModularityArgument/ThresholdArguments/DenseThresholdCases/AdLOf.lean",
    "ModularityArgument/ThresholdArguments/DenseThresholdCases/RigSp4.lean",
]
paths=[prefix+n for n in full]+[
    "sources/lean/src/Development/AutomorphicArithmetic/Foundations/GaloisRepresentations/AdmissibleResidues/IsAutomorphicOverImagQuad.lean",
    "sources/lean/src/Development/AbelianVarietyTheory/Definitions/GaloisGeometry/DualIsConjByOne.lean",
]
def rec(p):
    raw=p.read_bytes()
    return dict(path=str(p.relative_to(root)),sha256=sha256(raw).hexdigest(),bytes=len(raw),lines=len(raw.splitlines()))
sources=[]
for name in paths:
    x=rec(root/name)
    x.update(full_file_inspected=True,inspected_line_intervals=[[1,x["lines"]]])
    sources.append(x)
primary=[]
for name,url,pages,visual in [
    ("thorne_adjoint_2207_04925v1.pdf","https://arxiv.org/pdf/2207.04925",[[1,4],[24,25]],[]),
    ("newton_thorne_jems_2023.pdf","https://ems.press/content/serial-article-files/32858",[[1,5]],[2]),
]:
    x=rec(root/"sources/primary"/name)
    x.update(url=url,full_paper_inspected=False,inspected_pdf_page_windows=pages,visually_checked_pdf_pages=visual,
             inspection_scope="Relevant passages within these page windows; not a claim to have read every line of every listed page. Exact passages are specified in the source trace.")
    primary.append(x)
names=["selmer_adjoint_vanishing.tex","selmer_adjoint_vanishing_references.tex","selmer_adjoint_vanishing_source_trace.md"]
names.extend(p.name for p in base.glob("selmer_adjoint_vanishing_peer_review*.md"))
out=dict(created_utc=datetime.now(timezone.utc).isoformat(),
    scope="Actual AdjointLiftingTheorem from the classical Thorne theorem, with coefficient, polarization, quotient and local-condition comparisons; exact rational symplectic projection.",
    sources=sources,primary_sources=primary,artifacts={n:rec(base/n) for n in names},
    compile=dict(engine="XeLaTeX",passes=2,wrapper="output/selmer_adjoint_vanishing_check.tex",pdf="output/selmer_adjoint_vanishing_check.pdf",logs=["work/selmer_adjoint_vanishing_check_compile_1.log","work/selmer_adjoint_vanishing_check_compile_2.log"]),
    limits=["No complete Lean replay.","Thorne's theorem is a cited classical input, not a full-paper reproof.","Automorphy and quantitative integral congruence estimates remain separate.","The rank-four matrix projection does not establish the source's separate CM-field/twist existence input."])
(base/"selmer_adjoint_vanishing_source_manifest.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"sources":len(sources),"manuscript_sha256":out["artifacts"]["selmer_adjoint_vanishing.tex"]["sha256"]},indent=2))
