"""Conservative provenance for the finite character comparison."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json

base = Path(__file__).resolve().parent
root = base.parents[1]
prefix = "sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/"
full = [
    "LengthEqAddEigen.lean", "PartsConj.lean",
    "CharacterLevelBounds/ShaFamMono.lean",
    "CharacterLevelBounds/ReductionToDirichletCharAnyLevelOfLe.lean",
    "GaloisLibrary/GaloisCohomologyLength/LevelInertiaLeLevelDec.lean",
    "HeightAndVanishing/LayerLe.lean", "HeightAndVanishing/LossLe.lean",
    "HeightAndVanishing/RedAll.lean", "HeightAndVanishing/HostIndex.lean",
    "HeightAndVanishing/DirichletPrimeToLPartMulLPowerPart.lean",
    "HeightAndVanishing/FinalLe.lean",
]
spec = {prefix+n: "full" for n in full}
spec[prefix+"GaloisLibrary/SelmerTransport/ConjStableShaFam.lean"] = [(65, 130)]
spec[prefix+"PrimeSetBoundDataOfPrimitiveChar.lean"] = [(1, 155)]
spec["sources/lean/src/Formalism/GaloisCohomology/Statement.lean"] = [(1, 90)]

def rec(p):
    raw = p.read_bytes()
    return dict(path=str(p.relative_to(root)), sha256=sha256(raw).hexdigest(),
                bytes=len(raw), lines=len(raw.splitlines()))

sources = []
for name, intervals in spec.items():
    x = rec(root/name)
    x["full_file_inspected"] = intervals == "full"
    x["inspected_line_intervals"] = (
        [[1, x["lines"]]] if intervals == "full"
        else [[a, min(b, x["lines"])] for a, b in intervals])
    sources.append(x)

names = [
    "selmer_character_comparison.tex",
    "selmer_character_comparison_source_trace.md",
    "selmer_layer.tex",
    "selmer_fixed_conductor_restriction.tex",
    "selmer_bounded_order_characters.tex",
]
names.extend(p.name for p in base.glob("selmer_character_comparison_peer_review*.md"))
out = dict(
    created_utc=datetime.now(timezone.utc).isoformat(),
    scope="Explicit Shapiro and integral Fourier comparison with exact source inverse-character and parity conventions; fixed polynomial torsion error for the growing family.",
    sources=sources,
    primary_inputs=[dict(
        author="J. S. Milne", title="Class Field Theory", version="4.03",
        url="https://www.jmilne.org/math/CourseNotes/CFT.pdf",
        read_scope="Chapter V Theorem 1.7 and proof (printed 150--151; PDF 159--160), and Theorems 3.5--3.6 (printed 158; PDF 167); directly opened on 2026-11-21.",
        full_book_inspected=False)],
    artifacts={n: rec(base/n) for n in names},
    compile=dict(
        engine="XeLaTeX", passes=2,
        wrapper="output/selmer_character_comparison_check.tex",
        pdf="output/selmer_character_comparison_check.pdf",
        logs=["work/selmer_character_comparison_check_compile_1.log",
              "work/selmer_character_comparison_check_compile_2.log"]),
    limits=[
        "No complete Lean replay.",
        "The Fourier maps have a genuine torsion kernel when p divides the field degree; this kernel is bounded, not discarded.",
        "Finiteness and quantitative bounds for the remaining automorphic character cases remain separate.",
        "The polynomial error uses logarithmic class-number bounds and is uniform in the growing conductor and coefficient degree.",
    ],
)
(base/"selmer_character_comparison_source_manifest.json").write_text(
    json.dumps(out, indent=2)+"\n")
print(json.dumps({"sources": len(sources),
    "manuscript_sha256": out["artifacts"]["selmer_character_comparison.tex"]["sha256"]}, indent=2))
