"""Conservative provenance for the complementary-parity trivial-character vanishing proof."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json
base=Path(__file__).resolve().parent
root=base.parents[1]
prefix="sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/"
full=["CharacterLevelBounds/ShaFamMono.lean", "LevelCohomology/TorsClass.lean",
      "LevelCohomology/ZqField.lean", "LevelCohomology/HQuad.lean", "LevelCohomology/PropZ.lean",
      "HeightAndVanishing/DirichletPrimeToLPartMulLPowerPart.lean", "HeightAndVanishing/Counts.lean",
      "HeightAndVanishing/Cases.lean", "HeightAndVanishing/CountZ.lean"]
spec={prefix+n:"full" for n in full}
spec.update({prefix+"GaloisLibrary/SelmerTransport/ConjStableShaFam.lean":[[65,125]],
             prefix+"GaloisLibrary/SelmerTransport/RestrictionMemInvariantH1.lean":[[1,125]]})
def rec(p):
    raw=p.read_bytes()
    return dict(path=str(p.relative_to(root)),sha256=sha256(raw).hexdigest(),bytes=len(raw),lines=len(raw.splitlines()))
sources=[]
for name,r in spec.items():
    x=rec(root/name)
    x["full_file_inspected"]=r=="full"
    x["inspected_line_intervals"]=[[1,x["lines"]]] if r=="full" else [[a,min(b,x["lines"])] for a,b in r]
    sources.append(x)
names=["selmer_complementary_vanishing.tex","selmer_complementary_vanishing_source_trace.md","selmer_layer.tex"]
names.extend(p.name for p in base.glob("selmer_complementary_vanishing_peer_review*.md"))
out=dict(created_utc=datetime.now(timezone.utc).isoformat(),scope="Exact case Z complementary-parity vanishing, with a general residual class-group injection.",
         sources=sources,artifacts={n:rec(base/n) for n in names},
         primary_inputs=[dict(author="J. S. Milne",title="Class Field Theory",version="4.03",url="https://www.jmilne.org/math/CourseNotes/CFT.pdf",read_scope="Chapter V section 3, Theorems 3.5–3.6 and Example 3.9, printed pages 158–159; opened directly in web reader on 2026-11-21.")],
         compile=dict(engine="XeLaTeX",passes=2,wrapper="output/selmer_complementary_vanishing_check.tex",pdf="output/selmer_complementary_vanishing_check.pdf",logs=["work/selmer_complementary_vanishing_check_compile_1.log","work/selmer_complementary_vanishing_check_compile_2.log"]),
         limits=["No complete Lean replay.","The other complementary-parity counting cases remain open in the reconstruction.","The residual injection alone bounds the p-rank, not the full Selmer length."])
(base/"selmer_complementary_vanishing_source_manifest.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"sources":len(sources),"manuscript_sha256":out["artifacts"]["selmer_complementary_vanishing.tex"]["sha256"]},indent=2))
