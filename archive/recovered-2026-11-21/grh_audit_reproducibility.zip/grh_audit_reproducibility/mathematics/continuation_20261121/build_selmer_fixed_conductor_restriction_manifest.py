"""Conservative provenance for the fixed-conductor complementary Selmer comparison."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json
base=Path(__file__).resolve().parent
root=base.parents[1]
prefix="sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/"
full=["CharacterLevelBounds/ShaFamMono.lean", "HeightAndVanishing/DirichletPrimeToLPartMulLPowerPart.lean",
      "HeightAndVanishing/LayerLe.lean", "HeightAndVanishing/HostComp.lean", "HeightAndVanishing/HostOdd.lean",
      "HeightAndVanishing/IvField.lean", "HeightAndVanishing/CountIV.lean"]
spec={prefix+n:"full" for n in full}
def rec(p):
    raw=p.read_bytes()
    return dict(path=str(p.relative_to(root)),sha256=sha256(raw).hexdigest(),bytes=len(raw),lines=len(raw.splitlines()))
sources=[]
for name,r in spec.items():
    x=rec(root/name)
    x["full_file_inspected"]=r=="full"
    x["inspected_line_intervals"]=[[1,x["lines"]]] if r=="full" else [[a,min(b,x["lines"])] for a,b in r]
    sources.append(x)
names=["selmer_fixed_conductor_restriction.tex","selmer_fixed_conductor_restriction_source_trace.md","selection_assembly.tex","selmer_complementary_vanishing.tex"]
names.extend(p.name for p in base.glob("selmer_fixed_conductor_restriction_peer_review*.md"))
out=dict(created_utc=datetime.now(timezone.utc).isoformat(),scope="Exact case IV restriction to fixed cyclotomic layers, with an explicit linear error in t and a fixed additive coefficient of B.",
         sources=sources,artifacts={n:rec(base/n) for n in names},
         compile=dict(engine="XeLaTeX",passes=2,wrapper="output/selmer_fixed_conductor_restriction_check.tex",pdf="output/selmer_fixed_conductor_restriction_check.pdf",logs=["work/selmer_fixed_conductor_restriction_check_compile_1.log","work/selmer_fixed_conductor_restriction_check_compile_2.log"]),
         limits=["No complete Lean replay.","The automorphic complementary-parity cases are not proved by this note.","The fixed-layer B is retained as the exact input supplied by the common interval.","The final whole-field character comparison is a distinct step."])
(base/"selmer_fixed_conductor_restriction_source_manifest.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"sources":len(sources),"manuscript_sha256":out["artifacts"]["selmer_fixed_conductor_restriction.tex"]["sha256"]},indent=2))
