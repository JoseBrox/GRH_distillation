"""Hash the exact source files read for the two ordinary Selmer comparisons."""
from pathlib import Path
import datetime
import hashlib
import json

base = Path(__file__).resolve().parents[2]
dest = Path(__file__).resolve().parent
root = Path("sources/lean/src")
prefix = root / "Development/AutomorphicArithmetic/AutomorphicVarieties"
class_count = prefix / "ModularityArgument/ClassCounting"
unit = class_count / "SelmerOrderCounts"
groups = {
    "selmer_layer_source_manifest.json": [
        root / "Development/EtaleCohomology/CyclotomicDiscriminants/FinSLayer.lean",
        root / "Development/EtaleCohomology/CyclotomicDiscriminants/SLayerCut.lean",
        prefix / "GeneratorCountTuples/LemmaK.lean",
        *[root / ("Development/AutomorphicArithmetic/CyclotomicBounds/"
                  "ClassNumberBounds/IdealCounting/" + name + ".lean")
          for name in ("ClassA", "ClassB", "ClassC")],
    ],
    "selmer_unit_source_manifest.json": [
        class_count / "SelmerOrderCounts.lean",
        *[unit / (name + ".lean") for name in (
            "TwoLe", "DatEx", "CardKerEqCoker", "CardEQ", "UnitLat",
            "KerFDelNm", "PCount", "SelInj", "SelLCard", "SelInvLe",
            "EqHomLe", "ActUPow")],
    ],
}
for target, paths in groups.items():
    sources = []
    for path in paths:
        raw = (base / path).read_bytes()
        lines = len(raw.splitlines())
        sources.append({
            "path": str(path), "sha256": hashlib.sha256(raw).hexdigest(),
            "lines": lines, "read_intervals": [[1, lines]],
            "scope": "full source text read; not a claim about all transitive imports",
        })
    result = {
        "created_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "scope": "ordinary proof and precise source comparison; no kernel replay",
        "sources": sources,
        "source_count": len(sources),
        "source_lines": sum(s["lines"] for s in sources),
    }
    (dest / target).write_text(json.dumps(result, indent=2) + "\n")
    print(target, result["source_count"], result["source_lines"])
