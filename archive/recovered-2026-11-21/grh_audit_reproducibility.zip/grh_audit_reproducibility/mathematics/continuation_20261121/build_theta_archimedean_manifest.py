"""Hash exact source versions and conservative read scopes for the size pass."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
SRC = BASE/"sources/lean/src"
OUT = Path(__file__).resolve().parent
HC = "Formalism/HermitianCurvature/"
HP = HC+"HermitianCurvatureProofs/"
DATA = [
    (HC+"StatementSz.lean", "all",
     "All612 lines read across the global and archimedean passes. Exact spectral, mass, column, critical-scale, threshold and final size statements."),
    (HP+"VandermondeRatioHarmonic.lean", "all",
     "Full448-line harmonic perturbation, ordering, and position-difference proof. The new proof improves the binary linear-term bound."),
    (HP+"MassRatioFormula.lean", "all",
     "Complete finite-level exponent, factorial and mass-chain identities. Actual mass and column formulas are hypotheses, not supplied by this algebraic provider."),
    (HP+"CorollaryAOfPropositionA.lean", [[1,125],[305,445]],
     "Initial zeta/logarithm estimates, actual product-of-critical-scales corollary, and bracket bound. Other intermediate proof bodies are not claimed as read."),
    (HP+"CriticalThresholdLowerBound.lean", [[1,210]],
     "Initial Vandermonde splitting and actual lambda lower bound; later1038-line provider not read in full. The new text independently proves both u cases and the critical lower bound."),
    (HP+"BetaBoundOnBoundary.lean", "all",
     "Full264-line boundary assembly, including all edge factors and the exact source constant160. Imported polynomial-factorization providers are replaced by direct factorization in the new proof."),
    (HP+"CmRingIdempotentUnitRatioIdentity.lean", [[153,559]],
     "All actual g-power and width normalizations, four threshold products, theta lower/power estimates and final smallness. Initial quantitative helper bodies are not claimed as read."),
    (HP+"SixteenMulLeTwoPow.lean", "all",
     "Complete339-line assembly of SizesMain, including mass-ratio product bounds and finite supremum arguments."),
    (HP+"SupremumAIsMajorant.lean", [[1,310]],
     "Supremum majorant and complete actual InstSizes proof, including different powers, terminal factor2 and normalized threshold products."),
    (HP+"JointInstanceTheoremA.lean", [[1,105]],
     "Actual frame products and initial block-lattice identities; later theorem assembly not read in full."),
    (HC+"StatementC.lean", [[1,261]],
     "Actual global Gram functions, positive-phase Fourier normalization, finite word averages and plane-wave/off-diagonal statement definitions."),
    (HC+"StatementJC.lean", [[283,342]],
     "Exact per-place-subset Fourier/lift/terminal bounds and threshold predicates."),
    (HC+"StatementJCT.lean", [[1,109],[149,247]],
     "Actual built-input decomposition and the claimed per-place provider interfaces. These are not treated as proofs of the coefficient identities."),
    (HP+"RealInputsBuiltClosedForm.lean", [[1,215]],
     "Actual assembly route from coefficient identities and representation inputs to RealInputs, showing which premises remain separate."),
    (HP+"LevelZeroEstimateProduct.lean", "all",
     "Full finite-product/minimum assembly of EstWave and related wrappers; not the underlying differential-polynomial identities."),
    (HP+"TheoremPIntegralOfPlaces.lean", [[1,35],[366,559]],
     "Initial concrete-setting definitions and the actual all-place Fourier/lift aggregation, including the terminal three-way partition."),
    (HP+"FirstNormRealNonneg.lean", [[1,145]],
     "Actual conjugated embedding and Fourier-frequency sign map; the positive psiInf convention corresponds to the negative standard Fourier frequency."),
]
files = []
for path, ranges, assessment in DATA:
    raw=(SRC/path).read_bytes()
    lines=len(raw.decode().splitlines())
    if isinstance(ranges,list):
        assert all(1 <= a <= b <= lines for a,b in ranges), (path,lines,ranges)
    files.append({"path":path,"sha256":hashlib.sha256(raw).hexdigest(),
                  "line_count":lines,"read_scope":ranges,"assessment":assessment})
result = {
    "scope":"Independent archimedean polynomial and size reconstruction, plus exact tracing of remaining coefficient inputs",
    "source_root":"sources/lean/src",
    "mathematical_deliverable":"theta_archimedean_sizes.tex",
    "source_trace":"theta_archimedean_source_trace.md",
    "exact_controls":"check_theta_archimedean.py",
    "files":files,
    "warning":"Read coverage is not formal dependency closure or Lean re-elaboration. The actual mass recurrence, source-space dimension formula, formal-degree bound, and representation-theoretic coefficient identities remain explicit separate obligations."
}
(OUT/"theta_archimedean_source_manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(f"Recorded {len(files)} exact source hashes and conservative read scopes.")
