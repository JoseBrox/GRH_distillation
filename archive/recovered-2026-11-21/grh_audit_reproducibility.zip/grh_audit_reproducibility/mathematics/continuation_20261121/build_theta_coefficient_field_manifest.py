"""Conservative source provenance for finite theta coefficient fields."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json
base=Path(__file__).resolve().parent
root=base.parents[1]
prefix="sources/lean/src/Development/AbelianVarietyTheory/"
full=["Proofs/IwasawaDecomposition/FinAlgOfFinite.lean",
 "Proofs/IwasawaDecomposition/ExistsFinsetSdLatReps.lean",
 "Proofs/IwasawaDecomposition/FinAlgJetSet.lean",
 "Proofs/IwasawaDecomposition/DerivAt0CompMem.lean",
 "Proofs/IwasawaDecomposition/DegreeEqTotDeg.lean",
 "Proofs/IwasawaDecomposition/ExistsColInJetsIn.lean",
 "Proofs/IwasawaDecomposition/ExistsColumnInputAssembled.lean",
 "Proofs/IwasawaDecomposition/ExistsGaloisGe.lean",
 "Proofs/IwasawaDecomposition/GensJAlgebraic.lean",
 "Proofs/IwasawaDecomposition/BaseFieldsPrimesOk.lean",
 "Definitions/AutomorphicMembership/JetsInIffStepField.lean"]
spec={prefix+n: "full" for n in full}
spec.update({prefix+"Proofs/GlobalInterpolation/ExistsHypJetsAll.lean":[[1,125]],
 prefix+"Definitions/Foundations/ExistsBaseTwoWords.lean":[[140,239]],
 prefix+"Proofs/GlobalInterpolation/StepBoxIffStepSuppDeg.lean":[[95,150]],
 prefix+"BlockTheory/GlobalSignature/JetSumTable.lean":[[70,103]]})
def rec(p):
 raw=p.read_bytes()
 return dict(path=str(p.relative_to(root)),sha256=sha256(raw).hexdigest(),bytes=len(raw),lines=len(raw.splitlines()))
sources=[]
for name,r in spec.items():
 x=rec(root/name)
 x["full_file_inspected"]=r=="full"
 x["inspected_line_intervals"]=[[1,x["lines"]]] if r=="full" else [[a,min(b,x["lines"])] for a,b in r]
 sources.append(x)
names=["theta_coefficient_field.tex","theta_coefficient_field_source_trace.md",
 "theta_general_moments_source_manifest.json","theta_equivariance_source_manifest.json",
 "theta_column_support_source_manifest.json","arithmetic_lattices_source_manifest.json"]
names += [p.name for p in base.glob("theta_coefficient_field_peer_review*.md")]
out=dict(created_utc=datetime.now(timezone.utc).isoformat(),
 scope="One finite coefficient field for all prescribed bounded jets in a fixed finite column construction, with the prime and level data fixed beforehand.",
 sources=sources,artifacts={n:rec(base/n) for n in names if (base/n).exists()},
 compile=dict(engine="XeLaTeX",passes=2,wrapper="output/theta_coefficient_field_check.tex",
   pdf="output/theta_coefficient_field_check.pdf",logs=["work/theta_coefficient_field_check_compile_1.log","work/theta_coefficient_field_check_compile_2.log"]),
 limits=["No complete Lean replay.","No field uniform over unbounded independent levels or derivative orders.","This supplies field descent, not the separate Hecke incidence identity."])
(base/"theta_coefficient_field_source_manifest.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"sources":len(sources),"manuscript_sha256":out["artifacts"]["theta_coefficient_field.tex"]["sha256"]},indent=2))
