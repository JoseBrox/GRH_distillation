"""Exact source versions and read scopes for the separated-grid reconstruction."""
import hashlib
import json
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]
SRC=BASE/"sources/lean/src"
OUT=Path(__file__).resolve().parent
HC="Formalism/HermitianCurvature/"
HP=HC+"HermitianCurvatureProofs/"
RT="Formalism/LocalToGlobal/SiegelLatticeTheory/FlagStabilizerTensors/RootLatticeThresholds/"
DATA=[
    (RT+"CarrierGrids.lean","all",
     "Full actual Chebyshev sets, interpolation sum, shifted separation, polynomial nonvanishing and GridsOK/GridsRich assembly."),
    (RT+"CarrierSizes.lean",[[1,245]],
     "Numerical interval length, exact short-node selection, finite zero avoidance and separation; later provider bodies not claimed as read."),
    (RT+"GridsRichITc.lean","all",
     "Actual identification of the chosen grids with the global theta input, including the exact N=20(r+1)."),
    (HP+"AdmissibleAtOfAdmissibleList.lean","all",
     "Full signed-sequence extension, unused short-node selection, reversed block indices, probability pushforward, K=0 and degree-zero cases."),
    (HP+"RoomOffGridSymmetric.lean","all",
     "Adjacent finite-set avoidance and stronger separation used for admissible extensions; the manuscript uses the actual disjoint-block construction."),
    (HP+"ChebyshevExtremalPolynomials.lean",[[1,170]],
     "Initial exact Chebyshev coefficient identities; remaining proof body not claimed as read. The mathematical fragment uses the independent proof already given."),
    (HP+"PBCutInside.lean","all",
     "Actual spectral margin from differing binary entries."),
    (HC+"StatementI.lean","all",
     "Exact spectral margin, interlacing and q-polynomial definitions."),
    (HC+"StatementC.lean",[[1,35],[214,230]],
     "Grid-block endpoints and all actual GridsOK separation conditions."),
    (HC+"StatementKB.lean",[[28,58]],
     "Exact GridsRich and local probability interfaces."),
    (HC+"StatementSz.lean",[[224,226]],
     "Long and short spectral interval definitions."),
    (HC+"RealInputsClosedAdmissibleSettings.lean",[[318,334]],
     "Exact CutInside interface; full analytic input assembly remains outside this grid proof."),
]
files=[]
for path,ranges,assessment in DATA:
    raw=(SRC/path).read_bytes();lines=len(raw.decode().splitlines())
    if isinstance(ranges,list):
        assert all(1<=a<=b<=lines for a,b in ranges),(path,lines,ranges)
    files.append({"path":path,"sha256":hashlib.sha256(raw).hexdigest(),
                  "line_count":lines,"read_scope":ranges,"assessment":assessment})
result={"scope":"Complete actual finite interpolation-set and separation construction",
        "source_root":"sources/lean/src",
        "mathematical_deliverable":"theta_coefficient_grids.tex",
        "source_trace":"theta_coefficient_grids_source_trace.md",
        "exact_controls":"check_theta_coefficient_grids.py","files":files,
        "warning":"This closes finite grids and separation, not the radial representation, analytic domain, mass, dimension or formal-degree inputs."}
(OUT/"theta_coefficient_grids_source_manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(f"Recorded {len(files)} exact source versions and conservative read scopes.")
