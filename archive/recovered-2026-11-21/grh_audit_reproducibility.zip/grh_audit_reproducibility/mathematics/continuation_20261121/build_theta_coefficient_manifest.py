"""Record exact source versions and conservative coverage for coefficient algebra."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
SRC = BASE / "sources/lean/src"
OUT = Path(__file__).resolve().parent
HC = "Formalism/HermitianCurvature/"
HP = HC + "HermitianCurvatureProofs/"
FD = "Formalism/FormalDegreeBessel/"
DATA = [
    (HC+"StatementKB.lean", "all",
     "Exact local block positivity, Fourier, lift, and terminal statement definitions."),
    (HP+"WaveLocalBuiltPlaces.lean", "all",
     "Actual coefficient barrier Xw and change-of-variable scale T=g lambda/(2 pi)."),
    (HP+"WaveLocalPositiveCompactSupport.lean", "all",
     "Complete actual assembly of the Fourier local estimate from grids, degree, size, isometry, and form positivity."),
    (HP+"BlockKWaveC.lean", "all",
     "Complete positive-block proof and exact Gamma, old-size, node-weight, Fourier-power normalizers."),
    (HP+"PBGWaveMain.lean", "all",
     "Actual polynomial/slice assembly, including the level-zero convention."),
    (HP+"PBFCstmt.lean", "all",
     "Exact compact-support mixed form inequality and wave isometry interfaces."),
    (HP+"LagrangeExtraction.lean", "all",
     "Leading-coefficient extraction, iterated extraction, probability weights, norm and square bounds."),
    (HP+"LeadingTermIdentity.lean", "all",
     "Both actual ordered-minor leading identities; replaced in the manuscript by direct expansion."),
    (HP+"LevelOneWordEstimate.lean", "all",
     "Actual rational correction and source exponential loss. The manuscript improves the loss at N>=20."),
    (HP+"SizeAtMinusW.lean", "all",
     "Plus/minus normalizer identities and actual grids interface. The imported grid construction is not proved by reading this wrapper."),
    (HP+"RatioBound.lean", "all",
     "Exact normalizer cancellation, finite averaging, and weighted block conversion."),
    (HP+"PBGDegW.lean", "all",
     "Actual one-variable mixed pairing and iterative coefficient extraction, including order reversal."),
    (HP+"PBGWave.lean", "all",
     "Actual sesquilinearity, component operation, old-index action and preservation of equality on the group."),
    (HP+"PBGLet.lean", "all",
     "Actual differential operator definitions, both normalized leading terms, and smooth coefficient representatives."),
    (HP+"GramLocSetCApp.lean", [[1,140]],
     "Actual Gram form normalizer and initial radial Fourier interface; remaining proof bodies not claimed as read."),
    (HP+"SizeStandardCompact.lean", "all",
     "Complete reduction of the mixed inequality to the radial positive representation theorem and weighted determinant identity. Those imported analytic/algebraic inputs are not reconstructed here."),
    (HP+"VectorIsomorphismCompactSupport.lean", "all",
     "Complete actual wave-isometry assembly; depends on radial module comparison and the two wave identities."),
    (HP+"ModuleFormPosCompactSupport.lean", "all",
     "Complete reduction of actual form positivity to ThmPActualCpt; does not independently prove that imported theorem."),
    (HP+"StandardPairingOfHeads.lean", "all",
     "Exact radial Fourier identity with compact support and its dependence on radial and terminal integration identities."),
    (HP+"CutIntervalLong.lean", "all",
     "Actual q0=Q comparison, sign on the selected interval, denominator separation and node majorant."),
    (HC+"RealInputsClosedAdmissibleSettings.lean", [[1,215]],
     "Actual signs, normalized operators, two-component transformation, and analytic input interfaces."),
    (HC+"StatementD.lean", [[200,250]],
     "Actual scalar minor and normalized differential-letter conventions in the coefficient pass."),
    (HC+"OperatorsCommuteTranslations.lean", [[26,35],[107,107],[220,279]],
     "Exact ordered differential minor definitions and index ordering; unlisted proof bodies not claimed as read."),
    (FD+"StatementIO.lean", [[1,75],[86,103]],
     "Complexified Lie derivatives and ordered column quantum minor, including shifts."),
    (FD+"StatementG.lean", [[1,95]],
     "Actual Hermitian basis, group, principal minors, and conjugate-linear-second matrix pairing."),
    ("Formalism/RealPlaceAnalysis/SmoothOnGVIff.lean", [[150,173]],
     "Right-invariant directional derivative convention."),
    (HC+"CompositeFormulaLevelZero.lean", [[38,38]],
     "Only the exact phase definition fsv(s,z)=exp(sz-conjugate(s)conjugate(z)) was inspected here."),
    (HC+"StatementWd.lean", [[75,114]],
     "Actual rational correction factors and recursive operator words."),
]
files = []
for path, ranges, assessment in DATA:
    raw = (SRC / path).read_bytes()
    lines = len(raw.decode().splitlines())
    if isinstance(ranges, list):
        assert all(1 <= a <= b <= lines for a, b in ranges), (path, lines, ranges)
    files.append({"path": path, "sha256": hashlib.sha256(raw).hexdigest(),
                  "line_count": lines, "read_scope": ranges, "assessment": assessment})
result = {
    "scope": "Independent ordinary proof of actual coefficient algebra and exact tracing of analytic inputs",
    "source_root": "sources/lean/src",
    "mathematical_deliverable": "theta_coefficient_algebra.tex",
    "source_trace": "theta_coefficient_source_trace.md",
    "exact_controls": "check_theta_coefficient.py",
    "files": files,
    "warning": "These read scopes are not a formal dependency-closure claim. The actual radial Fourier identity, radial representation theorem, form positivity/mixed inequality/isometry, separated grids and function-domain assertions remain explicit obligations. Mass, source dimension and formal degree remain separate as well."
}
(OUT / "theta_coefficient_source_manifest.json").write_text(json.dumps(result, indent=2) + "\n")
print(f"Recorded {len(files)} exact source versions and read scopes.")
