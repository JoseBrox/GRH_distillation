"""Exact provenance for the two arithmetic theta moment supports."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json

base=Path(__file__).resolve().parent
root=base.parents[1]
pref="sources/lean/src/Development/AbelianVarietyTheory/Proofs/"
full=[
 "GlobalInterpolation/TranslateMomentsAll.lean",
 "GlobalInterpolation/JetMomentsOfUnitPeriod.lean",
 "GlobalInterpolation/MemSuppBarOfNe.lean",
 "GlobalInterpolation/MomentsCosetSum.lean",
 "GlobalInterpolation/MomentCompanion.lean",
 "GlobalInterpolation/RelDetCompanion.lean",
 "GlobalInterpolation/PerLatticeFacts.lean",
 "GlobalInterpolation/MomentsTranslateRationalPointUnitDenominator.lean",
 "GlobalInterpolation/RelIndexNeZeroOfSmul.lean",
 "GlobalInterpolation/ThetaMovedCosetIndicatorVacuumShape.lean",
 "GlobalInterpolation/ThetaMovedCosetIndicatorVacuumShapeStatement.lean",
 "GlobalInterpolation/NotDvdDifferent.lean",
 "GlobalInterpolation/PairingScaledDirectionsEqPeriodPairing.lean",
 "SatakeParameters/NormPadicEmbeddingLeOneOfMemInverseHalfDifferent.lean",
 "SatakeParameters/NormDgenEqOne.lean"]
spec={pref+n:"full" for n in full}
spec.update({
 "sources/lean/src/Development/AbelianVarietyTheory/BlockTheory/GlobalSignature/JetSumTable.lean":"full",
 "sources/lean/src/Formalism/LocalToGlobal/KernelLattices/ThDistC.lean":[(42,120),(461,490)],
 "sources/lean/src/Formalism/LocalToGlobal/KernelLattices/XiIndCClass.lean":[(1,290)],
 "sources/lean/src/Formalism/LocalToGlobal/Columns/StdLatUnimodular.lean":[(68,112)],
 "sources/lean/src/Formalism/LocalToGlobal/Columns/FiniteSumNonzeroLargeDepth.lean":[(638,658),(815,855),(1098,1122)],
 "sources/lean/src/Formalism/SharpRestriction/GlobalSchurBounds/GeneralLinearActions/IsDiscriminantTwelfthRootOfIdealLattice.lean":[(52,83),(135,166),(300,400)],
})

def rec(p):
 raw=p.read_bytes()
 return dict(path=str(p.relative_to(root)),sha256=sha256(raw).hexdigest(),
             bytes=len(raw),lines=len(raw.splitlines()))

sources=[]
for rel,ranges in spec.items():
 e=rec(root/rel)
 e["full_file_inspected"]=ranges=="full"
 e["inspected_line_intervals"]=([[1,e["lines"]]] if ranges=="full" else
   [[a,min(b,e["lines"])] for a,b in ranges])
 sources.append(e)
names=["theta_column_support.tex","theta_column_support_source_trace.md",
 "check_theta_column_support.py","theta_column_support_checks.json",
 "theta_general_moments_source_manifest.json","theta_equivariance_source_manifest.json",
 "arithmetic_column_valuations.tex"]
names += [p.name for p in base.glob("theta_column_support_peer_review_root.md")]
out=dict(created_utc=datetime.now(timezone.utc).isoformat(),
 scope="Two actual arithmetic theta moment supports and the exact p^(-f*a) "
       "factor, for sufficiently large selected split primes p>=5.",
 sources=sources,artifacts={n:rec(base/n) for n in names if (base/n).exists()},
 exact_interfaces={
  "indicator":"ThDistC.lean90–98; the two square-root volume factors cancel exactly.",
  "matrix_test":"FiniteSumNonzeroLargeDepth.lean646–650, nonzero residue functionals at StdLatUnimodular.lean81–97.",
  "moments":"JetSumTable.lean30–35,64–88,95–120: both supports, adjoint coordinates and p^(-f*a).",
  "period":"JetMomentsOfUnitPeriod.lean44–48 and PairingScaledDirectionsEqPeriodPairing.lean: cD/(A*Omega0*deltaI/delta0)."},
 exact_checks=json.loads((base/"theta_column_support_checks.json").read_text()),
 compile=dict(wrapper="output/theta_column_support_check.tex",
   pdf="output/theta_column_support_check.pdf",engine="XeLaTeX",passes=2,
   external_reference_note="The check wrapper imports only prefixed cross-references "
       "to the reviewed full manuscript for acl-patching and cv-two-kernels. "
       "The check fragment differs only by these two reference prefixes.",
   logs=["work/theta_column_support_check_compile_1.log",
         "work/theta_column_support_check_compile_2.log"]),
 limits=["No complete Lean replay or import-closure audit.",
         "General kernel covariance and adjacent-column incidence remain separate tasks.",
         "The zero-functional example is excluded by the actual nonzero hypothesis."])
(base/"theta_column_support_source_manifest.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"source_files":len(sources),"manuscript_sha256":
 out["artifacts"]["theta_column_support.tex"]["sha256"]},indent=2))
