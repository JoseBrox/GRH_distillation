"""Conservative provenance for the actual selected-prime column closure."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json

base = Path(__file__).resolve().parent
root = base.parents[1]
prefix = "sources/lean/src/"
spec = {
    "Formalism/LocalToGlobal/KernelLattices/ThDistC.lean": [(1, 220)],
    "Formalism/LocalToGlobal/Columns/FiniteSumNonzeroLargeDepth.lean": [(580, 647)],
    "Development/AbelianVarietyTheory/BlockTheory/GlobalSignature/JetSumTable.lean": "full",
    "Development/AbelianVarietyTheory/Proofs/SatakeParameters/ValuationLeOneOfMemZmu.lean": [(176, 262)],
    "Development/AbelianVarietyTheory/Proofs/SatakeParameters/JetOpIntegral.lean": [(1, 155)],
}

def rec(path):
    raw = path.read_bytes()
    return {"path": str(path.relative_to(root)), "sha256": sha256(raw).hexdigest(),
            "bytes": len(raw), "lines": len(raw.splitlines())}

sources = []
for rel, intervals in spec.items():
    item = rec(root / prefix / rel)
    item["full_file_inspected"] = intervals == "full"
    item["inspected_line_intervals"] = ([[1, item["lines"]]] if intervals == "full"
        else [[a, min(b, item["lines"])] for a, b in intervals])
    sources.append(item)
names = [
    "theta_column_valuation_completion.tex",
    "theta_column_valuation_completion_source_trace.md",
    "arithmetic_column_valuations_source_manifest.json",
    "theta_general_moments_source_manifest.json",
    "theta_column_support_source_manifest.json",
    "theta_coefficient_field_source_manifest.json",
    "theta_hecke_commutation_source_manifest.json",
]
names += [p.name for p in base.glob("theta_column_valuation_completion_peer_review*.md")]
out = {
    "created_utc": datetime.now(timezone.utc).isoformat(),
    "scope": "Exact identification of the actual polynomial theta kernel and the selected-prime column estimate under the displayed construction hypotheses.",
    "sources": sources,
    "artifacts": {name: rec(base / name) for name in names},
    "validation": "Finite algebraic proof, focused peer review, and full-manuscript compilation. No numerical assertion is substituted for a proof.",
    "limits": ["No complete Lean replay.", "No assertion of seed nonvanishing.",
               "Auxiliary-level-prime bounds, integrated archimedean estimates and final assembly remain separate."]
}
(base / "theta_column_valuation_completion_source_manifest.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps({"sources": len(sources), "manuscript_sha256": out["artifacts"][names[0]]["sha256"]}, indent=2))
