"""Source scopes for the exact arithmetic theta equivariance reconstruction."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json

base=Path(__file__).resolve().parent
root=base.parents[1]
eq="sources/lean/src/Formalism/LocalToGlobal/PairingIndexBounds/SplitPairEquations/"
full=[
 "Reduction.lean", "FinalEq.lean", "Outright.lean", "EqPAll.lean",
 "SplitPairOfGen.lean", "SplitPairGen.lean", "PolFamInhabited.lean",
 "SquareSplitPairs/SplitPair.lean", "SquareSplitPairs/EqPOfPair.lean",
 "SquareSplitPairs/SqSplitOf.lean", "SplitTripleEquations/EqPOfSplit.lean",
 "SplitTripleEquations/MuOneOfSplit.lean",
 "TripleSumIndependence/RightMoveTrianglesHold.lean",
 "IntegralSquareRoots/SecondConstantHolds.lean",
 "IntegralSquareRoots/SecondConstantOfGaussSum.lean",
 "IntegralSquareRoots/NormOne.lean"]
spec={eq+p:"full" for p in full}
spec.update({
 "sources/lean/src/Development/AbelianVarietyTheory/Proofs/IwasawaDecomposition/NormalisedFamilySatisfiesEquivarianceLaws.lean":"full",
 "sources/lean/src/Formalism/PeriodIntegrals/OrbitalBoundsConclusion/SplitPairGen.lean":"full",
 "sources/lean/src/Formalism/PeriodIntegrals/OrbitalBoundsConclusion/SqPairLocal.lean":"full",
 "sources/lean/src/Formalism/PeriodIntegrals/OrbitalBoundsConclusion/SqPairGlue.lean":"full",
 "sources/lean/src/Formalism/PeriodIntegrals/OrbitalBoundsConclusion/LocCartanPair.lean":"full",
 "sources/lean/src/Formalism/PeriodIntegrals/UnitaryGroupMassFormula/SquarePairLocal/SqPairLocalOf.lean":"full",
 "sources/lean/src/Formalism/PeriodIntegrals/SqPair.lean":"full",
 "sources/lean/src/Formalism/LocalToGlobal/KernelLattices/LateralTheory.lean":"full",
 "sources/lean/src/Formalism/SharpRestriction/GlobalSchurBounds/TaylorLogMetric.lean":[(1,100)],
 "sources/lean/src/Formalism/SharpRestriction/GlobalSchurBounds/GeneralLinearActions/IsDiscriminantTwelfthRootOfIdealLattice.lean":[(42,140),(300,370)],
 "sources/lean/src/Formalism/LocalToGlobal/KernelLattices/ColumnData.lean":[(245,271)],
 "sources/lean/src/Formalism/LocalRingCardinality/DataHost.lean":[(55,73),(145,164)],
 "sources/lean/src/Formalism/SharpRestriction/RamificationFrobenius/TotientGaloisClasses/ConjEMemHostFIff.lean":[(10,98),(135,135)],
 eq+"SquareSplitPairs/SumThreeComm.lean":[(1,90)],
 "sources/lean/src/Formalism/LocalToGlobal/GlobalTheory/GL3/NormNatCoprime.lean":[(210,275)],
})

def rec(p):
 raw=p.read_bytes()
 return dict(path=str(p.relative_to(root)),sha256=sha256(raw).hexdigest(),
             bytes=len(raw),lines=len(raw.splitlines()))
sources=[]
for rel,ranges in spec.items():
 e=rec(root/rel)
 e["inspected_line_intervals"]=([[1,e["lines"]]] if ranges=="full" else
     [[a,min(b,e["lines"])] for a,b in ranges])
 e["full_file_inspected"]=ranges=="full"
 sources.append(e)
names=["theta_arithmetic_equivariance.tex", "arithmetic_classes.tex",
       "theta_equivariance_local_inputs.tex", "theta_equivariance_source_trace.md",
       "theta_change_of_isometry.tex", "theta_normalization_source_manifest.json",
       "theta_ordinary_extension_source_manifest.json"]
names += [p.name for p in base.glob("theta_arithmetic_equivariance_peer_review_root.md")]
result=dict(created_utc=datetime.now(timezone.utc).isoformat(),
 scope="Exact covariance and both finite-lattice move identities for the actual "
       "even-dimensional normalized theta family. The local simultaneous "
       "hyperbolic decomposition is proved independently in ordinary mathematics; "
       "the full import closure of the Lean local Cartan provider is not claimed read.",
 sources=sources,artifacts={n:rec(base/n) for n in names if (base/n).exists()},
 exact_definitions={
   "eNat":"LateralTheory.lean157–179: product base, two normalized averaging "
          "operators, and the precise determinant character exponents.",
   "EqP":"TaylorLogMetric.lean37–52: unitary covariance, right move, left move; "
         "LateralTheory.lean219 identifies this predicate for eNat.",
   "character":"IsDiscriminantTwelfthRootOfIdealLattice.lean314–325 and "
               "ColumnData.lean251–262 define norm-one ideals, relative determinant, "
               "and chi((z))=product_tau tau(z)^(-1) for unitary z.",
   "half_different":"DataHost.lean65 gives b*bar(b)=relative different, "
                     "and153–154 defines AA0=b inverse.",
   "finite_unramifiedness":"HostDer.unramEF atConjEMemHostFIff.lean135; "
                            "SplitPairOfGen.lean13 invokes D.sp.cm.cmUnram."},
 reconstruction=[
   "Trace-lattice self-duality with the actual ideal and norm semicharacter.",
   "Common hyperbolic decomposition for two unimodular local Hermitian lattices, "
   "including residue characteristic2, proved by primitive-vector correction and induction.",
   "CRT gives an approximate global projector preserving both lattices.",
   "The projector splits the actual triple finite quadratic group P/T into two "
   "subgroups on which the quadratic function is trivial; character sums give positive sign.",
   "Unramified local norm surjectivity gives norm(-1) modulo every integer; "
   "the resulting permutation makes the exact Cayley Gauss sum real.",
   "The even-dimensional unitary scalar has square equal to its complex determinant.",
   "Tensor factorization and the principal-ideal character law give the precise "
   "covariance of the source's eNat, with both move identities."],
 compile=dict(wrapper="output/theta_equivariance_check.tex",pdf="output/theta_equivariance_check.pdf",
              engine="XeLaTeX",passes=2,pages=40,
              final_undefined_references_or_citations=False,final_overfull_boxes=False,
              logs=["work/theta_equivariance_check_compile_1.log","work/theta_equivariance_check_compile_2.log"]),
 limits=["No full Lean kernel replay or transitive source audit was performed.",
         "No counterexample to the retained hypotheses was found.",
         "The explicit Z/3 Gauss sum is a counterexample only to discarding "
         "the arithmetic phase-control hypotheses, not to the actual theorem.",
         "Arithmetic column support, companion normalizations and incidence remain separate steps."])
(base/"theta_equivariance_source_manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"source_files":len(sources),"artifact_sha256":result["artifacts"]["theta_arithmetic_equivariance.tex"]["sha256"]},indent=2))
