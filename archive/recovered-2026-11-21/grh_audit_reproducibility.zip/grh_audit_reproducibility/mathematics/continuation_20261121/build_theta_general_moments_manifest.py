"""Conservative read scopes for the exact ordinary moment reconstruction."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json

base=Path(__file__).resolve().parent
root=base.parents[1]
pref="sources/lean/src/Development/AbelianVarietyTheory/Proofs/"
spec={
 pref+"JetHarmonics/CmLatticeTranslationOperatorEqPhaseMulNegComp.lean":"full",
 pref+"JetHarmonics/ExistsCmThetaEqSumProdTranslates.lean":"full",
 pref+"JetHarmonics/ExistsCmThetaEqSumProdTranslatesStatement.lean":"full",
 pref+"JetHarmonics/ExistsOrthogonalFrameNormsCoprimeOfUnimodular.lean":[(280,419)],
 pref+"GlobalInterpolation/UnitPeriodTranslatesMomentsFinite.lean":"full",
 pref+"GlobalInterpolation/NormalizedVectorTranslatesPrimeOrderIntegral.lean":"full",
 pref+"GlobalInterpolation/TranslateNormalizedVectorIntegralCombTensorPower.lean":"full",
 pref+"GlobalInterpolation/TranslateMomentsAll.lean":"full",
 pref+"GlobalInterpolation/PairingScaledDirectionsEqPeriodPairing.lean":"full",
 "sources/lean/src/Development/AbelianVarietyTheory/Definitions/Jets/CmLatticeCommutatorPairingPowEqOneOfGoodLift.lean":[(1,120)],
 "sources/lean/src/Formalism/SharpRestriction/GlobalSchurBounds/GeneralLinearActions/IsDiscriminantTwelfthRootOfIdealLattice.lean":[(52,83),(135,166),(300,400)],
 "sources/lean/src/Formalism/LocalToGlobal/KernelLattices/ThDistC.lean":[(42,80),(461,490)],
}

def rec(p):
 raw=p.read_bytes()
 return dict(path=str(p.relative_to(root)),sha256=sha256(raw).hexdigest(),
             bytes=len(raw),lines=len(raw.splitlines()))

sources=[]
for name,ranges in spec.items():
 p=root/name
 e=rec(p)
 e["full_file_inspected"]=ranges=="full"
 e["inspected_line_intervals"]=([[1,e["lines"]]] if ranges=="full" else
    [[a,min(b,e["lines"])] for a,b in ranges])
 sources.append(e)
names=["theta_general_moment_laws.tex","theta_general_moments_source_trace.md",
 "ordinary_theta_source_manifest.json","theta_normalization_source_manifest.json",
 "theta_ordinary_extension_source_manifest.json","theta_equivariance_source_manifest.json"]
names += [p.name for p in base.glob("theta_general_moments_peer_review_root.md")]
out=dict(created_utc=datetime.now(timezone.utc).isoformat(),
 scope="Exact bounded ordinary moment laws, unit normalization for eNat and "
       "algebraicity of discriminant-scaled jets; p>=5 split in k.",
 sources=sources,artifacts={n:rec(base/n) for n in names if (base/n).exists()},
 source_interface="TranslateMomentsAll.lean14–49; intrinsic ordinary lattice "
   "coordinates in GM8–GM14. The source's p=3 generic case is not included.",
 reconstruction=[
  "An orthogonal lattice frame of prime-to-p index by local approximation.",
  "Nonzero finite product-theta average by perfect finite character pairing.",
  "The exact p-power Weyl identity follows termwise from the reviewed elliptic law.",
  "The actual eNat measure has norm at most one by TS, TE and prime-to-p averaging.",
  "Uniform bounds over all extensions of the algebraic embedding imply algebraic jets."],
 compile=dict(wrapper="output/theta_general_moment_check.tex",
   pdf="output/theta_general_moment_check.pdf",engine="XeLaTeX",passes=2,
   logs=["work/theta_general_moment_check_compile_1.log",
         "work/theta_general_moment_check_compile_2.log"]),
 limits=["No complete Lean replay or transitive import audit.",
         "The column support and incidence identifications remain separate tasks."])
(base/"theta_general_moments_source_manifest.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({"source_files":len(sources),"manuscript_sha256":
 out["artifacts"]["theta_general_moment_laws.tex"]["sha256"]},indent=2))
