from pathlib import Path
import hashlib
import json

out=Path(__file__).resolve().parent
root=out.parents[1]
src=root/"sources/lean/src"
pref="Development/AbelianVarietyTheory/Proofs/GlobalInterpolation/"
scopes={
    pref+"UkTermOfMoveStep.lean":[[160,537]],
    pref+"MemMulLatIff.lean":[[1,476]],
    pref+"MoveStepOfFamily.lean":[[1,136]],
    pref+"LevelNotMemRowSG.lean":[[95,167]],
    pref+"HeckeLawPointKernelOfCoefficientKernel.lean":[[1,276]],
    pref+"LevelChainUOperatorCommutationOfPointPairLaw.lean":[[1,96]],
    pref+"FivePointLawsTrueChains.lean":[[1,64]],
    pref+"ExistsHypJetsAll.lean":[[1,132]],
    "Development/AbelianVarietyTheory/Definitions/GlobalTwisting/BelowFiniteNonempty.lean":[[1,145]],
    "Development/AbelianVarietyTheory/BlockTheory/GlobalSignature/IndexExponentDegree.lean":[[1,97]],
    "Formalism/LocalToGlobal/KernelLattices/ThDistC.lean":[[58,137]],
    "Formalism/LocalToGlobal/Columns/AbelianHostFieldConditions.lean":[[210,241]],
    "Formalism/LocalToGlobal/Columns/CyclotomicIsCyclotomicExtension.lean":[[236,266]],
}
def rec(path):
    data=path.read_bytes()
    return dict(path=str(path.relative_to(root)),sha256=hashlib.sha256(data).hexdigest(),
                bytes=len(data),lines=len(data.splitlines()))
files=[]
for name,ranges in scopes.items():
    r=rec(src/name)
    r["read_scope"]=[[a,min(b,r["lines"])] for a,b in ranges]
    files.append(r)
names=["theta_hecke_commutation.tex","theta_hecke_commutation_source_trace.md",
       "check_theta_hecke_commutation.py","theta_hecke_commutation_checks.json"]
names += [p.name for p in out.glob("theta_hecke_commutation_peer_review_*.md")]
data=dict(reader="/root",sources=files,artifacts=[rec(out/n) for n in names],
          status="Conventional Hecke identity independently reviewed in full. "
                 "Finite coefficient-field descent is supplied by the independently reviewed JCF reconstruction.",
          kernel_replay_claimed=False)
(out/"theta_hecke_commutation_source_manifest.json").write_text(json.dumps(data,indent=2)+"\n")
print(json.dumps({"source_files":len(files),"manuscript_sha256":rec(out/names[0])["sha256"]}))
