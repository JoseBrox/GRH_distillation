"""Conservative source-read provenance for LM and TC, not a Lean replay."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json

base = Path(__file__).resolve().parent
root = base.parents[1]
qbase = "sources/lean/src/Formalism/LocalToGlobal/TorsionIntegrality/QuadraticSemicharacters/"
abase = "sources/lean/src/Development/AbelianVarietyTheory/Proofs/GlobalInterpolation/"
qfiles = [
    "IsSemiChar.lean", "UnitaryConstant.lean", "KerPNonzero.lean",
    "ProductThetaMem.lean", "GaussDegenerate.lean",
    "QuadraticSemicharactersFactAltForm.lean",
    "QuadraticSemicharactersFactTer.lean",
    "CayleyGaussianIntegrals/GaussSumEighthPower.lean",
    "CayleyGaussianIntegrals/GapStatement.lean",
    "CayleyGaussianIntegrals/DifferentialRepresentation.lean",
    "CayleyGaussianIntegrals/TripleSumEighthOf.lean",
    "CayleyGaussianIntegrals/TripleEighthProof.lean",
    "CayleyGaussianIntegrals/CayleyGaussianIntegral.lean",
    "CayleyGaussianIntegrals/DiagIntegrable.lean",
    "CayleyGaussianIntegrals/UnfoldingIntegral.lean",
    "CayleyGaussianIntegrals/SelfDualCovolumeProof.lean",
    "CayleyGaussianIntegrals/UnitaryEighthOf.lean",
    "CayleyGaussianIntegrals/FinitelyGeneratedModPow.lean",
    "CayleyGaussianIntegrals/StdDataCmProof.lean",
]
afiles = [
    "ExistsStandardIsometryFourthPowerSplitPrime.lean",
    "NormKappaSqMulDetSplitPrime.lean",
    "NormKappaSqMulDetIsometryEqOne.lean",
    "ComplexPadicNormKappaSplitPrime.lean",
    "UnitaryStandardAtQFromIsometryOverField.lean",
    "LatticeJetsAreBoundedMomentsOfSpanImagQuadratic.lean",
    "LatticeJetsAreBoundedMomentsOfTensorFourthPower.lean",
    "LatticeJetsAreBoundedMomentsPullback.lean",
    "CmThetaBaseVectorTranslatesIntegral.lean",
    "CmBaseThetaTensorPowerTranslatesIntegral.lean",
    "TranslateNormalizedVectorIntegralCombTensorPower.lean",
    "NormalizedVectorTranslatesPrimeOrderIntegral.lean",
]
spec = {qbase+p: "full" for p in qfiles}
spec.update({abase+p: "full" for p in afiles})
spec.update({
    "sources/lean/src/Formalism/LocalToGlobal/KernelLattices/LateralTheory.lean":
        [(1,190),(190,270)],
    "sources/lean/src/Formalism/LocalToGlobal/KernelLattices/KernelLocalFactors/BaseEx.lean":
        [(1,110)],
    abase+"MemSuppBarOfNe.lean": [(1,380)],
    abase+"MomentsCosetSum.lean": [(1,200)],
})

def file_record(p):
    raw=p.read_bytes()
    return {"path":str(p.relative_to(root)), "sha256":sha256(raw).hexdigest(),
            "bytes":len(raw), "lines":len(raw.splitlines())}

sources=[]
for rel,ranges in spec.items():
    p=root/rel
    entry=file_record(p)
    n=entry["lines"]
    intervals=[[1,n]] if ranges=="full" else [[a,min(b,n)] for a,b in ranges if a<=n]
    merged=[]
    for a,b in intervals:
        if merged and a<=merged[-1][1]+1:
            merged[-1][1]=max(merged[-1][1],b)
        else:
            merged.append([a,b])
    entry.update(inspected_line_intervals=merged, full_file_inspected=merged==[[1,n]])
    sources.append(entry)

artifact_names = [
    "lattice_theta_measures.tex", "theta_change_of_isometry.tex",
    "ordinary_theta_source_manifest.json", "ordinary_theta_peer_review_root.md",
    "theta_normalization_source_trace.md",
]
artifacts={n:file_record(base/n) for n in artifact_names if (base/n).exists()}
for name in ["lattice_theta_measures_peer_review_root.md",
             "theta_change_of_isometry_peer_review_root.md"]:
    p=base/name
    if p.exists():
        artifacts[p.name]=file_record(p)
record={
    "created_utc":datetime.now(timezone.utc).isoformat(),
    "scope":"LM finite lattice moments and arithmetic determinant correction; "
            "TC exact analytic change of isometry. Read intervals are source "
            "inspection records, not a transitive source audit, kernel replay, "
            "or a claim that all ordinary column support/incidence is closed.",
    "artifacts":artifacts,
    "sources":sources,
    "mathematical_reconstruction":[
        "TC proves theta-space dimension and self-dual covolume by elementary "
        "Fourier/symplectic arguments.",
        "TC proves finite averaging is unitary and its triple scalar has eighth power one.",
        "TC proves the finite quadratic Gauss eighth-power formula using a four-square "
        "congruence and an explicit quaternion matrix.",
        "TC computes the exact Gaussian trace and obtains c^8=det(delta)^4.",
        "TC verifies the sign semicharacter of the general primitive ideal base "
        "Za+Z(b+i*sqrt(D))/2, including the positive index square roots.",
        "LM proves the valuation identity for kappa and the finite moment operations.",
    ],
    "compile":{
        "wrapper":"output/theta_normalization_check.tex",
        "pdf":"output/theta_normalization_check.pdf",
        "passes":2, "engine":"XeLaTeX", "pages":27,
        "final_undefined_references_or_citations":False,
        "final_overfull_boxes":False,
        "logs":["work/theta_normalization_check_compile_1.log",
                "work/theta_normalization_check_compile_2.log"],
    },
    "subsequent_separate_drafts":[
        "cm_ideal_theta_moments.tex: ordinary period and integrality on nonprincipal "
        "bases; separate proof and review scope.",
        "theta_local_standardization.tex: local standardization and ideal-twisted "
        "lattice vector integrality; separate proof and review scope.",
    ],
    "remaining_inputs":[
        "Actual arithmetic column support identities, companion-lattice normalization, "
        "and incidence commutation are not proved merely by TC.",
        "Full source import closures have not all been read here.",
        "No fresh full Lean build or kernel replay was performed for this record.",
    ],
}
(base/"theta_normalization_source_manifest.json").write_text(json.dumps(record,indent=2)+"\n")
print(json.dumps({"source_files":len(sources),"artifacts":artifacts},indent=2))
