"""Record source text actually consulted for the local orbital reconstruction.

This is a read-coverage record, not a verification of imported proofs.  Paths
are explicit because this source checkout contains directory symlinks.
"""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
SRC = BASE / "sources/lean/src"
OUT = Path(__file__).resolve().parent
HC = "Formalism/HermitianCurvature/"
HP = HC + "HermitianCurvatureProofs/"
DATA = [
    (HC + "BlockKernelPropertiesOfSteps.lean", "all",
     "LocalDatum; marked cokernel kernel; InTT/intTT; AvgClaim; TTEnd; BlockKernelSupport. Full statement file read; its imported providers are separate."),
    (HC + "ThetaExistenceInductiveFromPieces.lean", [[1, 740]],
     "Exact local definitions and quantifier order: LocConst, ChangeVar, CrossVanish, GermIdentity, GermKernel, HeadReduction and OscReduction."),
    ("Formalism/DoubleCosetMeasures/Statement.lean", [[1, 233]],
     "Block matrices, coset groups, lower group condition, cokernels and marked isomorphisms."),
    (HP + "HenselRootsBounded.lean", [[560, 905]],
     "Actual complete crossVanish proof, including use of the inverse-parameter hypothesis at m=1. Earlier declarations located by index only."),
    (HP + "PadicChangeOfVariables.lean", [[1, 120], [540, 867]],
     "Local preliminary definitions; complete PhaseDiff and ChangeVar proofs, and final modulus identity. Intermediate preliminary proofs not all read."),
    (HP + "GermSumLattices.lean", [[1, 350], [498, 685]],
     "Double germ expansion, root reindexing, amplitude local invariance and complete final GermIdentity assembly. Lines 351--497 were not read in full."),
    (HP + "GermExpansionMatrixFunction.lean", [[1, 260], [1180, 1370]],
     "Initial and final assembly inspected; declarations/imports elsewhere located by index. Provider alternatives in tactic scripts were not treated as successful proof dependencies."),
    (HP + "ColumnOperationTripleForm.lean", [[384, 438]],
     "Inverse last-column identity and final TTEnd proof read. Other declarations only indexed."),
    (HP + "FirstKernelPropertiesOfHypotheses.lean", [[513, 558]],
     "Actual deduction of strong inverse-parameter support from triangular averaging and TTEnd."),
    (HP + "SecondVanishingOffRing.lean", "all",
     "Complete assembly of the second positive Gram and inverse-parameter support statements."),
    (HP + "LatticeAverageIdentity.lean", [[1, 130], [946, 1005], [1262, 1425], [1824, 1864]],
     "Exact partial module, normalization and relation definitions; initial countId lift argument; complete shiftData and matrixHeart; final lattice_average_identity. Remaining long proof bodies not read in full; the mathematical replacement is proved independently in the TeX."),
    ("Formalism/DoubleCosetMeasures/LowerUnipotentOrbits/MulInvBlockDiagApplySameBlock.lean", [[1, 105]],
     "Initial block reversal indexing lemmas. Main later proof not read; block-group identification in the TeX has its own short proof."),
    (HP + "KernelScalingBack.lean", "index",
     "Declarations and imports only; phase_locally_constant located. No claim to have read its proof. Uniform local constancy is proved independently by a compact finite-coset argument."),
    (HP + "GermExpansionOfSteps.lean", "index",
     "Declaration/import search only, identifying how HeadReduction and GermPhi imply the germ statement."),
    (HP + "OrbitalIntegralReduction.lean", [[1, 110], [1710, 1810], [3130, 3271]],
     "Coordinate definitions, one change estimate and final oscillatory-reduction assembly read. The full matrix change-of-variables and critical-amplitude proof remain unreviewed inputs."),
    (HP + "TwoBlockPoint.lean", [[1680, 1751]],
     "Final HeadReduction provider, including uniform support/local-constancy scales independent of the comparison matrix. Earlier PhiH construction and proofs are not reconstructed."),
]

files = []
for relative, ranges, note in DATA:
    path = SRC / relative
    data = path.read_bytes()
    lines = data.decode().splitlines()
    if isinstance(ranges, list):
        ranges = [[first, min(last, len(lines))] for first, last in ranges]
    files.append({
        "path": relative,
        "sha256": hashlib.sha256(data).hexdigest(),
        "line_count": len(lines),
        "read_scope": ranges,
        "assessment": note,
    })

result = {
    "scope": "Local theta truncated orbital identity, finite-module support, and uniform local constancy",
    "source_root": "sources/lean/src",
    "mathematical_deliverable": "work/continuation_20261121/theta_orbital_identity.tex",
    "related_mathematical_deliverable": "work/continuation_20261121/theta_germ_uniformity.tex",
    "trace": "work/continuation_20261121/theta_orbital_source_trace.md",
    "exact_controls": "work/continuation_20261121/check_theta_orbital.py",
    "files": files,
    "subsequent_local_completion": ["theta_head_reduction.tex", "theta_scalar_germ.tex", "theta_germ_assembly.tex", "theta_parseval.tex"],
    "warning": "Read ranges retain the earlier checkpoint scope; they are not dependency closure, recompilation or kernel checking. Later conventional sections now prove the actual local germ and majorant; their additional source traces are separate. Global theta energy estimates remain unproved in the reconstruction.",
}
(OUT / "theta_orbital_source_manifest.json").write_text(json.dumps(result, indent=2) + "\n")
print(f"Recorded {len(files)} source hashes with conservative read scopes.")
