"""Conservative provenance for the nonprincipal ordinary theta continuation."""
from pathlib import Path
from hashlib import sha256
from datetime import datetime, timezone
import json

base = Path(__file__).resolve().parent
root = base.parents[1]
ab = "sources/lean/src/Development/AbelianVarietyTheory/Proofs/GlobalInterpolation/"
spec = {
    ab + "DiscOneScaleRatioIdealRingAlgebraicUnit.lean": "full",
    ab + "ExistsStandardIsometryFourthPowerSplitPrime.lean": "full",
    ab + "CmThetaBaseVectorTranslatesIntegral.lean": "full",
    ab + "CmBaseThetaTensorPowerTranslatesIntegral.lean": "full",
    ab + "LatticeJetsAreBoundedMomentsOfSpanImagQuadratic.lean": "full",
    ab + "LatticeJetsAreBoundedMomentsOfTensorFourthPower.lean": "full",
    ab + "LatticeJetsAreBoundedMomentsPullback.lean": "full",
    ab + "NormKappaSqMulDetSplitPrime.lean": "full",
    ab + "NormKappaSqMulDetIsometryEqOne.lean": "full",
    ab + "ComplexPadicNormKappaSplitPrime.lean": "full",
    ab + "UnitaryStandardAtQFromIsometryOverField.lean": "full",
    "sources/lean/src/Formalism/SharpRestriction/GlobalSchurBounds/GeneralLinearActions/IsDiscriminantTwelfthRootOfIdealLattice.lean": [(42,140)],
    "sources/lean/src/Formalism/LocalToGlobal/KernelLattices/ColumnData.lean": [(60,87),(385,450)],
}

def rec(p):
    raw = p.read_bytes()
    return dict(path=str(p.relative_to(root)), sha256=sha256(raw).hexdigest(),
                bytes=len(raw), lines=len(raw.splitlines()))

sources = []
for rel, ranges in spec.items():
    e = rec(root / rel)
    e["inspected_line_intervals"] = ([[1,e["lines"]]] if ranges == "full"
        else [[a,min(b,e["lines"])] for a,b in ranges])
    e["full_file_inspected"] = ranges == "full"
    sources.append(e)
names = ["cm_ideal_theta_moments.tex", "theta_local_standardization.tex",
         "ordinary_theta_references.tex", "theta_ordinary_extension_source_trace.md",
         "ordinary_theta_source_manifest.json", "theta_normalization_source_manifest.json"]
reviews = list(base.glob("cm_ideal_theta*peer_review_root.md"))
reviews += list(base.glob("theta_local_standardization*peer_review_root.md"))
reviews += list(base.glob("theta_ordinary_extension_peer_review_root.md"))
artifacts = {p.name:rec(p) for p in [base/n for n in names]+reviews if p.exists()}
result = dict(
    created_utc=datetime.now(timezone.utc).isoformat(),
    scope="CI: common ordinary chart on nonprincipal elliptic ideal bases; "
          "TS: rational fourfold isometry, local standardization, and integral "
          "moments of the normalized selfdual trace-lattice theta function. "
          "This is not a full source import-closure audit or a Lean replay.",
    sources=sources, artifacts=artifacts,
    primary_references=[
      dict(url="https://arxiv.org/pdf/math/0610163v4", inspected="Prop.2.15, "
           "Cor.2.16(i), the stated ordinary reduction hypotheses and the "
           "multiplicative formal parameter in section3.1; not all55 pages.",
           local_file=rec(base/"primary_ordinary_theta/bannai_kobayashi_math_0610163v4.pdf")),
      dict(url="https://stacks.math.columbia.edu/tag/07S7", inspected="Lemma66.14.2 "
           "in full: quotient by a free finite locally free group action on "
           "a projective scheme is a scheme and the quotient map is an fppf torsor.")],
    scope_restrictions=[
      "The ordinary reconstruction retains p>=5 split in k and p not dividing N(I).",
      "The source's generic odd-prime statement also allows p=3; no claim of "
      "having established that case by the present Bannai--Kobayashi route.",
      "The source curve ideal has gcd(N(I),2D)=1, so the primitive ideal norm is odd.",
      "The multiplicative chart may be over the completed maximal unramified "
      "extension or O_Cp. The finite extension is for the algebraic model and sections.",
      "The abstract embedding C into Cp is fixed; no natural continuous embedding is assumed.",
      "Common complex scaling is transported in both functions and lattice directions; "
      "it is not asserted to be a p-adic unit."],
    compile=dict(wrapper="output/theta_ordinary_complete_check.tex",
                 pdf="output/theta_ordinary_complete_check.pdf", engine="XeLaTeX",
                 passes=2,pages=33,
                 logs=["work/theta_ordinary_complete_check_compile_1.log",
                       "work/theta_ordinary_complete_check_compile_2.log"]),
    remaining="Arithmetic column support and incidence still require their own proofs. "
              "The separate TE equivariance draft is not asserted by this manifest.")
(base/"theta_ordinary_extension_source_manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({"source_files":len(sources),"artifacts":{n:v["sha256"] for n,v in artifacts.items()}},indent=2))
