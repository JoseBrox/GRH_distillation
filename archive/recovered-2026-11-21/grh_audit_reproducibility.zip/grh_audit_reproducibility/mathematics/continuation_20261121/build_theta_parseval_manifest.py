"""Pin only source intervals actually consulted for the Parseval proof."""
import hashlib
import json
from pathlib import Path

base = Path(__file__).resolve().parents[2]
source = base / 'sources/lean/src'
out = Path(__file__).resolve().parent
prefix = 'Formalism/HermitianCurvature/'
provider = prefix + 'HermitianCurvatureProofs/'
scopes = [
    (prefix+'BlockKernelPropertiesOfSteps.lean', [[315,445]], 'Exact statements; earlier kernel definitions covered by the orbital audit.'),
    (prefix+'ThetaExistenceInductiveFromPieces.lean', [[1,95],[450,743]], 'Definitions and exact quantifiers for the Gram sums, germ and induction.'),
    (provider+'FirstKernelExplicitFormula.lean', [[1,230],[400,444],[900,1082],[1295,1457],[1570,1945]], 'Specified proof intervals and all declaration headings; other proof bodies not all read.'),
    (provider+'FirstKernelPropertiesOfHypotheses.lean', [[1,260],[300,480]], 'Base majorant, finite character sums and exact factors.'),
    (provider+'FirstKernelProperties.lean', 'all', 'Entire short assembly, not its import closure.'),
    (provider+'AveragedVectorChoices.lean', [[1,260]], 'Truncation positivity and unrestricted diagonal bound.'),
    (provider+'AddedBlockKernelSupport.lean', [[1,200]], 'The exact minor supporting det(head)*t in R.'),
]
records=[]
for relative,ranges,note in scopes:
    data=(source/relative).read_bytes()
    count=len(data.decode().splitlines())
    if isinstance(ranges,list):
        ranges=[[a,min(b,count)] for a,b in ranges]
    records.append({'path':relative,'sha256':hashlib.sha256(data).hexdigest(),
                    'line_count':count,'read_scope':ranges,'assessment':note})
result={'scope':'Single-block Parseval and full local majorant induction using the separately proved orbital germ',
        'mathematical_deliverable':'theta_parseval.tex',
        'source_root':'sources/lean/src','files':records,
        'warning':'Read intervals and independent conventional proofs; not a full import-closure audit or kernel replay.'}
(out/'theta_parseval_source_manifest.json').write_text(json.dumps(result,indent=2)+'\n')
print(f'Recorded {len(records)} source hashes and read scopes.')
