"""Conservative provenance for the two terminal-coupled lifts."""
import hashlib
import json
from pathlib import Path

OUT = Path(__file__).resolve().parent
BASE = OUT.parents[1]
SRC = BASE / "sources/lean/src"
HP = "Formalism/HermitianCurvature/HermitianCurvatureProofs/"
DATA = [
    (HP+"CutJDHatJDCapRGrpP.lean", "all",
     "Actual first full-group determinant coefficient and radial/invariance targets."),
    (HP+"CutJDHatJDCapRGrpM.lean", "all",
     "Actual conjugate full-group determinant coefficient and radial/invariance targets."),
    (HP+"CutJDHatJDCapR.lean", [[1,120]],
     "Exact two coupled radial expressions, coordinate multipliers and model interfaces."),
    ("Formalism/HermitianCurvature/StatementQ.lean", [[1,160],[181,208],[269,338]],
     "Actual minor conventions, border identities, terminal matrix, Weyl cell and root/torus rules."),
    ("Formalism/FormalDegreeBessel/StatementG.lean", [[1,90]],
     "Hermitian convention, basis ordering, unipotent character and stabilizer definitions."),
    ("Formalism/HermitianCurvature/OperatorsCommuteTranslations.lean", [[1,219]],
     "Whittaker derivative constants and ordered first/conjugate polynomial minors."),
]
files=[]
for path, scope, note in DATA:
    raw=(SRC/path).read_bytes();lines=len(raw.decode().splitlines())
    if isinstance(scope,list):assert all(1<=a<=b<=lines for a,b in scope)
    files.append(dict(path=path,sha256=hashlib.sha256(raw).hexdigest(),
                      line_count=lines,read_scope=scope,assessment=note))
deps=[]
for name in ["theta_radial_spectral_lift.tex","theta_radial_differential_lifts.tex"]:
    raw=(OUT/name).read_bytes()
    deps.append(dict(path=name,sha256=hashlib.sha256(raw).hexdigest(),
                     assessment="Previously reconstructed ordinary mathematical dependency; no new kernel replay implied."))
reviews=[]
for name in ["theta_radial_differential_lifts_peer_review_root.md",
             "theta_radial_coupled_lifts_peer_review_root.md"]:
    if (OUT/name).exists():
        reviews.append(dict(path=name,sha256=hashlib.sha256((OUT/name).read_bytes()).hexdigest()))
result=dict(source_root="sources/lean/src",
            mathematical_deliverable="theta_radial_coupled_lifts.tex",
            manuscript_sha256=hashlib.sha256((OUT/"theta_radial_coupled_lifts.tex").read_bytes()).hexdigest(),
            source_trace="theta_radial_coupled_lifts_source_trace.md",
            exact_controls="check_theta_radial_coupled_lifts.py",
            files=files,proved_mathematical_dependencies=deps,peer_reviews=reviews,
            status="Both coupled polynomial lifts and exact radial identities proved; terminal quantum and Jacquet analytic assertions remain separate.")
(OUT/"theta_radial_coupled_lifts_source_manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(f"Recorded {len(files)} source files, {len(deps)} dependencies and {len(reviews)} reviews.")
