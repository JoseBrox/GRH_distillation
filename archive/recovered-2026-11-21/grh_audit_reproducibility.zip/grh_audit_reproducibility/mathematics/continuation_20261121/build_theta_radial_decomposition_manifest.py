"""Exact source versions and read scopes for the direct finite decomposition."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
SRC = BASE / "sources/lean/src"
OUT = Path(__file__).resolve().parent
HC = "Formalism/HermitianCurvature/"
QQ = "Formalism/PeriodIntegrals/UnitaryGroupMassFormula/QuadraticFormTwoTwo/"
DATA = [
    (QQ + "RadialDecompositionOfParts.lean", "all",
     "Actual common-type radial decomposition and its hypotheses."),
    (QQ + "SpecAbstract.lean", "all",
     "Finite polynomial interpolation and terminal eigenfunction decomposition."),
    (QQ + "Vanish.lean", "all",
     "Annihilation of right compact types not present on the left."),
    (HC + "StatementQ.lean",
     [[1, 250], [548, 563], [600, 706], [922, 989], [1010, 1115]],
     "Actual compact spectral parameters, radial space, terminal operators, normal-form interface."),
    ("Formalism/FormalDegreeBessel/StatementWR.lean", [[1, 20]],
     "Nonzero-coordinate parameter domain."),
    (HC + "HermitianCurvatureProofs/QNFAsm.lean", "all",
     "Location of the larger normal-form assembly, not a review of all its imports."),
]
records = []
for path, scope, note in DATA:
    raw = (SRC / path).read_bytes()
    n = len(raw.decode().splitlines())
    if isinstance(scope, list):
        assert all(1 <= a <= b <= n for a, b in scope), (path, n, scope)
    records.append(dict(path=path, sha256=hashlib.sha256(raw).hexdigest(),
                        line_count=n, read_scope=scope, assessment=note))
deps = []
for name in ["theta_radial_positivity.tex", "compact_branching.tex",
             "coefficient_duality.tex", "theta_radial_decomposition.tex"]:
    raw = (OUT / name).read_bytes()
    deps.append(dict(path=name, sha256=hashlib.sha256(raw).hexdigest(),
                     line_count=len(raw.decode().splitlines())))
(OUT / "theta_radial_decomposition_source_manifest.json").write_text(
    json.dumps(dict(
        source_root="sources/lean/src",
        mathematical_deliverable="theta_radial_decomposition.tex",
        source_trace="theta_radial_decomposition_source_trace.md",
        files=records, mathematical_dependencies=deps,
        status="Finite algebra and terminal positivity proved; integrated analytic inputs remain separate."
    ), indent=2) + "\n")
print(f"Recorded {len(records)} source files and {len(deps)} mathematical dependency versions.")
