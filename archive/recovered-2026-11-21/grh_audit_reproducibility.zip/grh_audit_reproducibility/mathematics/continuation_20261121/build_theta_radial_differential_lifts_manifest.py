"""Conservative provenance for the actual polynomial Capelli/Toda lifts."""
import hashlib
import json
from pathlib import Path
BASE=Path(__file__).resolve().parents[2]
SRC=BASE/"sources/lean/src"
OUT=Path(__file__).resolve().parent
HP="Formalism/HermitianCurvature/HermitianCurvatureProofs/"
DATA=[
("Formalism/HermitianCurvature/OperatorsCommuteTranslations.lean",
 [[1,72],[105,126],[219,268]],
 "Exact weighted minors, index ordering, coefficients, and translation-commutation target."),
(HP+"CutJDHatJDCapAGrp.lean","all",
 "Actual full-group lifts and their two precise radial targets."),
(HP+"CutJDHatJDCapARep.lean","all",
 "Polynomial degree and finite real-Lie-word representation; source's zero padding only records order."),
(HP+"CutJDHatJDACapToda.lean","all",
 "Actual first radial identity, source parameters and conjugation normalization."),
(HP+"MinorCellOfParts.lean","all",
 "Exact right/left Whittaker and torus derivative rules."),
(HP+"MinorCellOfPartsAlt.lean","all",
 "Application of the radial minor computation to the actual Jacquet function; its separate analytic provider remains retained."),
(HP+"CutJDHatJDACapTodaVCut.lean","all",
 "Mirror order, parameter, recurrence and three-part assembly target."),
(HP+"CutJDHatJDACapTodaVGrpCut.lean","all",
 "Exact mirror root/torus rules and determinant-chain interface."),
(HP+"CutJDHatJDACapTodaVChain.lean","all",
 "Actual last-column and cofactor reduction behind the mirror determinant recurrence."),
(HP+"CutJDHatJDACapTodaVGrpAll.lean","all",
 "Application of the mirror group computation to the actual domain."),
(HP+"CutJDHatJDACapTodaVCrd.lean","all",
 "Actual scalar conjugation, reversed recurrence, and coordinate matching."),
("Formalism/FormalDegreeBessel/StatementIO.lean",[[1,120]],
 "Right complexified derivatives and ordered quantum-minor definitions."),
("Formalism/RealPlaceAnalysis/SmoothOnGVIff.lean",[[150,170]],
 "Exact real right-derivative convention."),
("Formalism/FormalDegreeBessel/StatementG.lean",[[1,115]],
 "Actual unitary group, unipotent character, cStd, and radial minors."),
("Formalism/HermitianCurvature/StatementQ.lean",
 [[153,158],[210,238],[380,410]],
 "Exact two character laws, scalar radial conjugation and transfer recurrence."),
]
files=[]
for path,scope,note in DATA:
 raw=(SRC/path).read_bytes(); n=len(raw.decode().splitlines())
 if isinstance(scope,list):
  assert all(1<=a<=b<=n for a,b in scope),(path,n,scope)
 files.append(dict(path=path,sha256=hashlib.sha256(raw).hexdigest(),
                   line_count=n,read_scope=scope,assessment=note))
deps=[]
for name in ["theta_radial_positivity.tex","theta_radial_spectral_lift.tex"]:
 raw=(OUT/name).read_bytes()
 deps.append(dict(path=name,sha256=hashlib.sha256(raw).hexdigest(),read_scope="all"))
result=dict(source_root="sources/lean/src",
 mathematical_deliverable="theta_radial_differential_lifts.tex",
 source_trace="theta_radial_differential_lifts_source_trace.md",
 exact_controls="check_theta_radial_differential_lifts.py",
 files=files,proved_mathematical_dependencies=deps,
 status="Both actual weighted isotropic Capelli operators, covariance, class preservation and exact Toda radial identities proved; coupled terminal operators and Jacquet analytic passage remain separate.")
review=OUT/"theta_radial_differential_lifts_peer_review_root.md"
if review.exists():
 result["peer_reviews"]=[dict(path=review.name,sha256=hashlib.sha256(review.read_bytes()).hexdigest())]
(OUT/"theta_radial_differential_lifts_source_manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(f"Recorded {len(files)} source files and {len(deps)} proved dependencies.")
