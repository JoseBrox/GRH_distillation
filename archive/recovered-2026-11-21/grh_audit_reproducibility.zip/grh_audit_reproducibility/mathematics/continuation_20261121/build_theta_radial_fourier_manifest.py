"""Conservative source provenance for noncompact radial integration."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
SRC = BASE / "sources/lean/src"
OUT = Path(__file__).resolve().parent
HP = "Formalism/HermitianCurvature/HermitianCurvatureProofs/"
DATA = [
    ("ContinuousExtensionOfFourierDecay.lean", "all",
     "Actual scalar extension, weighted decay and zero derivative integrals."),
    ("ThmPActualCptOfStepParts2.lean", "all",
     "Exact DecayData and derivative-combination interfaces."),
    ("TheoremPCompactOfStepDensity.lean", [[1, 131]],
     "Complete initial scalar derivative-combination proof and first-coordinate target."),
    ("CutSEOneLetterDens.lean", "all",
     "Exact plus/minus operators, inner-product convention, weight and one-letter density."),
    ("ExpansionSiteZeroInduction.lean", "all",
     "Actual distinct-index induction, elementary component commutation and zeroth term."),
    ("CutSE2.lean", [[1, 418]],
     "Exact expansion, decay conditions, generated class, smoothness and four-operator target."),
    ("CutSELeibnizCls.lean", [[1, 220]],
     "Partial read: local square-integrability class and Leibniz assembly; imported bounds retained."),
    ("CutSEJSRadLoc.lean", [[1, 160]],
     "Partial read: local uniform L2 bounds through the Jacquet family and pairing providers."),
    ("CutSERD.lean", "all",
     "Next-step actual four-operator target and coefficient preservation requirements."),
    ("CutSERDAsm.lean", "all",
     "Next-step iteration from four-operator identity to Fourier decay and normalization."),
    ("CutSERDBdd.lean", "all",
     "Wave-modulus boundedness of the actual Jacquet pairing."),
    ("CutSERDBeta.lean", "all",
     "Exact pairing normalization provider; imported measure formula not reconstructed here."),
]
files = []
for name, scope, note in DATA:
    path = HP + name
    raw = (SRC/path).read_bytes()
    n = len(raw.decode().splitlines())
    if isinstance(scope, list):
        assert all(1 <= a <= b <= n for a, b in scope), (name, n, scope)
    files.append(dict(path=path, sha256=hashlib.sha256(raw).hexdigest(),
                      line_count=n, read_scope=scope, assessment=note))
result = dict(
    source_root="sources/lean/src",
    mathematical_deliverable="theta_radial_fourier.tex",
    source_trace="theta_radial_fourier_source_trace.md",
    exact_controls="check_theta_radial_fourier.py",
    files=files,
    status="Noncompact scalar integration and actual component differential identities proved; actual Jacquet generated-class estimates and frame application remain separate.",
)
(OUT/"theta_radial_fourier_source_manifest.json").write_text(json.dumps(result, indent=2)+"\n")
print(f"Recorded {len(files)} exact source versions and conservative read scopes.")
