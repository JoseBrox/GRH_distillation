"""Exact versions and conservative read scopes for terminal radial positivity."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
SRC = BASE / "sources/lean/src"
OUT = Path(__file__).resolve().parent
HC = "Formalism/HermitianCurvature/"
HP = HC + "HermitianCurvatureProofs/"
QQ = "Formalism/PeriodIntegrals/UnitaryGroupMassFormula/QuadraticFormTwoTwo/"
DATA = [
    ("Formalism/RealPlaceAnalysis/StatementA.lean", [[1, 20]],
     "Exact general-linear commutator and adjoint conventions."),
    ("Formalism/RealPlaceAnalysis/StatementE.lean", "all",
     "Exact ordered column minor, RTT sign, centrality and highest-weight targets."),
    ("Formalism/RealPlaceAnalysis/SmoothOnGVIff.lean", [[156, 171]],
     "Right exponential derivative at g exp(tX), complexification and matrix generators."),
    ("Formalism/FormalDegreeBessel/StatementG.lean", [[1, 24]],
     "Hermitian form is linear first; terminal signature and fixed isotropic pairs."),
    ("Formalism/FormalDegreeBessel/StatementIO.lean", [[1, 55], [80, 112]],
     "Operator composition order, hparts, EabH, and the negative complementary contraction."),
    (HC + "StatementQ.lean", [[1, 250], [600, 706], [922, 989], [1010, 1115]],
     "Exact covariance/contraction, actual tL and shift, compact type and branching interfaces, radial function space, actual operators, and retained normal form."),
    (HC + "StatementQr.lean", [[1, 150]],
     "Actual ordered multiplication factors in ch2; only the displayed initial range was needed."),
    (HC + "StatementM.lean", [[1, 165], [196, 242]],
     "Actual parameter set, finite type labels, interlacing intervals, xC/qC, signed start."),
    (HC + "StatementFr.lean", [[1, 245]],
     "Frame diagonal density, weight |zeta|^2/G, and exact x/q/c recursions."),
    (HC + "StatementWd.lean", [[88, 108]],
     "Exact plus/minus recursion of q_w."),
    (HC + "CompositeFormulaLevelZero.lean", [[72, 100], [145, 188]],
     "Exact terminal density and separate integrated identification, positivity, slice and integral-step interfaces."),
    (HC + "TopDensNonnegOfKappa.lean", "all",
     "Exact KappaFibrePos, XKappa, normal-form implication, and retained analytic interfaces."),
    (HP + "DiagonalTransferAction.lean", "all",
     "Complete actual provider: compact derivative adjoint, self-adjoint Capelli, real separating parameter, pointwise transfer and positivity."),
    (HP + "CapelliTwoByTwo.lean", "all",
     "Complete actual complementary contraction, frozen coordinates, adapted Gram frame, and t22=G times shifted compact minor."),
    (HP + "LemmaDDeterminantIdentity.lean", "all",
     "Provider map for exact covariance and quantum-minor adjoint identities; imported proof files are not claimed as read."),
    (HP + "TopDensNonnegOfKappa.lean", "all",
     "Complete actual terminal density assembly, scalar diagonal identity, weight and off-domain zero."),
    (HP + "SignedCoordinateEqSignSmul.lean", "all",
     "Exact passage from the unsigned normal-form coordinate to the signed start and inverse coordinate."),
    (HP + "AdmissibleRecOfAdmissibleWord.lean", [[330, 448]],
     "Displayed positivity proof for rational updates and c recursion; other ranges were outside this targeted review."),
    (QQ + "TopLevelPointwiseIdentity.lean", "all",
     "Actual terminal transfer to the compact representation, smooth G and domain preservation."),
    (QQ + "RadialDecompositionOfParts.lean", "all",
     "Read for the next step: intersection of left/right compact types and finite spectral decomposition."),
    (HP + "QNFAsm.lean", "all",
     "Exact location of the larger normal-form provider; its additional imported raising/lowering proofs are not claimed as reconstructed."),
    (HP + "CutSETopFinal.lean", "all",
     "Top-level compact theorem assembly; underlying analytic providers remain separate."),
    (HP + "CutSETopR.lean", "all",
     "Spectral operator and adjoint dependencies for the compact radial theorem."),
    (HP + "CutSE_TopSpec.lean", "all",
     "Dependence on one-letter density, smoothness and radial decay."),
    (HP + "CutSETopHer.lean", "all",
     "Dependence on step density and decay identities, not discharged by pointwise positivity."),
]
files = []
for path, scope, assessment in DATA:
    raw = (SRC / path).read_bytes()
    lines = len(raw.decode().splitlines())
    if isinstance(scope, list):
        assert all(1 <= a <= b <= lines for a, b in scope), (path, lines, scope)
    files.append({"path": path, "sha256": hashlib.sha256(raw).hexdigest(),
                  "line_count": lines, "read_scope": scope, "assessment": assessment})
result = {
    "source_root": "sources/lean/src",
    "mathematical_deliverable": "theta_radial_positivity.tex",
    "source_trace": "theta_radial_positivity_source_trace.md",
    "exact_controls": "check_theta_radial_positivity.py",
    "scope": "Actual terminal Capelli identity and its finite-dimensional positive density",
    "files": files,
    "warning": "This targeted proof retains the normal-form existence and integrated analytic assertions explicitly. Later completion is to be recorded separately, without expanding these read scopes.",
}
(OUT / "theta_radial_positivity_source_manifest.json").write_text(json.dumps(result, indent=2) + "\n")
print(f"Recorded {len(files)} exact source versions and read scopes.")
