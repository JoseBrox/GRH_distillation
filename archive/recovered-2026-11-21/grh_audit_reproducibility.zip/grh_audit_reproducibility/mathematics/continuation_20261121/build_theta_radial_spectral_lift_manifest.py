"""Exact source versions and conservative scopes for the regular spectral lift."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
SRC = BASE / "sources/lean/src"
OUT = Path(__file__).resolve().parent
HP = "Formalism/HermitianCurvature/HermitianCurvatureProofs/"
DATA = [
    (HP+"CutSERDSOpX.lean", "all",
     "Actual regular inverse coefficient, covariance, derivative bounds, Good0 and radial restriction."),
    (HP+"XFibreOfParts.lean", "all",
     "Normalized cofactor-vector compact Capelli operator and terminal identity."),
    (HP+"CapelliVectorFrame.lean", "all",
     "One-vector complementary-minor contraction and change of compact frame."),
    (HP+"InvMulVecOfFixedVector.lean", "all",
     "Actual cofactor vector: norm, polynomial degree, covariance and cell values."),
    (HP+"CutSERDSYReal.lean", "all",
     "Real parameter avoiding the three finite sets of spectral roots."),
    (HP+"CutSERDSOpR.lean", "all",
     "Zero-order coefficient class and its composition with the remaining differential operators."),
    ("Formalism/HermitianCurvature/StatementTL.lean", [[195,325]],
     "Exact normalized vector, compact Capelli fibre, inverse polynomial and lifting interfaces."),
    ("Formalism/HermitianCurvature/StatementD.lean", [[75,115]],
     "Exact cofactor-vector and W-projection definitions."),
    ("Formalism/FormalDegreeBessel/StatementG.lean", [[1,115]],
     "Hermitian form, unipotent and compact subgroups, minors and Gram polynomial."),
    ("Formalism/HermitianCurvature/StatementB.lean", [[1,190],[215,280]],
     "Real-place data, group actions, derivative conventions and coefficient classes."),
    ("Formalism/HermitianCurvature/StatementM.lean", [[150,192],[225,225]],
     "Relevant radial inverse definitions and exact scalar sign."),
]
files = []
for path, scope, note in DATA:
    raw = (SRC/path).read_bytes()
    n = len(raw.decode().splitlines())
    if isinstance(scope, list):
        assert all(1 <= a <= b <= n for a,b in scope), (path,n,scope)
    files.append(dict(path=path,sha256=hashlib.sha256(raw).hexdigest(),
                      line_count=n,read_scope=scope,assessment=note))
dependencies = []
for name in ["theta_radial_positivity.tex","theta_radial_decomposition.tex",
             "compact_branching.tex"]:
    raw = (OUT/name).read_bytes()
    dependencies.append(dict(path=name,sha256=hashlib.sha256(raw).hexdigest(),
                             read_scope="all"))
result = dict(
    source_root="sources/lean/src",
    mathematical_deliverable="theta_radial_spectral_lift.tex",
    source_trace="theta_radial_spectral_lift_source_trace.md",
    exact_controls="check_theta_radial_spectral_lift.py",
    files=files,proved_mathematical_dependencies=dependencies,
    status=("Actual global zero-order spectral inverse proved, including the "
            "positive-Gram locus with vanishing intermediate minors; the other "
            "differential lifts and Jacquet analytic bounds remain separate."),
)
(OUT/"theta_radial_spectral_lift_source_manifest.json").write_text(
    json.dumps(result,indent=2)+"\n")
print(f"Recorded {len(files)} source versions and {len(dependencies)} proved dependencies.")
