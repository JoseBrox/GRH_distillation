"""Conservative source scopes for the actual recursive radial frame."""
from pathlib import Path
import hashlib
import json

OUT=Path(__file__).resolve().parent
SRC=OUT.parents[1]/"sources/lean/src"
H="Formalism/HermitianCurvature/"
P=H+"HermitianCurvatureProofs/"
Y="Formalism/YangianSpanCharacter/"
data=[
 (H+"StatementFr.lean",[[1,502]],"Complete frame, initial data, both recursive changes, inverse and regular domains, original and recursive admissibility, shifted base domains and all scalar positivity targets."),
 (H+"StatementR.lean",[[1,137]],"LevelData coordinate relations, formal adjoints and l0/m0 normalization."),
 (H+"StatementWd.lean",[[1,180]],"Fresh tensor factors, matrix units, P/Q rational matrices, weighted modules, words and shifted parameter ypt."),
 (H+"StatementQ.lean",[[1,145],[155,228],[937,1100]],"Quantum minor conventions, exact terminal differential definitions, actual operator pairs, IsActualLevel and LevelStartActual, larger normal form and actual start targets."),
 (H+"StatementM.lean",[[65,155],[203,244],[352,405]],"Parameter ranges, finite spectra, determinant, sign, initial inverse set, and comparison with the larger model normal form."),
 (Y+"StatementT.lean",[[1,57]],"J sign, tensor permutation, and RTT convention."),
 (Y+"StatementY.lean",[[1,69]],"Complete Gauss definitions, shifted identities and four commutator targets."),
 (Y+"StatementF.lean",[[1,51]],"Complete exact block identities for the two Gauss changes."),
 (Y+"ModHypYangian.lean",[[1,27]],"Gauss factorization and the noncommuting two-dimensional model used in exact controls."),
 (P+"PlusLetterFrameOfData.lean",[[1,95]],"Partial helper review: inverses, fresh-factor relations and lower-entry commutator. The remainder is not claimed read."),
 (P+"MinusLetterFrameOfData.lean",[[1,78]],"Partial helper review: inverse relations and fresh-factor commutations. The remainder is not claimed read."),
 (P+"GaussFormMinusLetter.lean",[[1,145]],"Partial initial Gauss helper review. The manuscript supplies its own complete calculation."),
 (P+"QuasiDeterminantFromEntries.lean",[[1,125]],"Partial shifted Schur and adjoint helper review. The manuscript supplies complete proofs."),
 (P+"FrameOfAdmissibleWord.lean",[[1,37]],"Complete source assembly and precise dependency order for both steps and both admissibility forms."),
]
files=[]
for path,scope,note in data:
    raw=(SRC/path).read_bytes()
    n=len(raw.decode().splitlines())
    assert all(1<=a<=b<=n for a,b in scope)
    files.append(dict(path=path,sha256=hashlib.sha256(raw).hexdigest(),
                      line_count=n,read_scope=scope,assessment=note))
deps=[]
for stem in [
    "theta_radial_positivity","theta_radial_decomposition",
    "theta_radial_fourier","theta_radial_spectral_lift",
    "theta_radial_differential_lifts","theta_radial_coupled_lifts",
    "theta_terminal_quantum_determinant","theta_terminal_commutation",
    "jacquet_integration_formula","jacquet_pairing_adjointness",
]:
    for suffix in [".tex","_peer_review_root.md"]:
        f=OUT/(stem+suffix)
        if f.exists():
            deps.append(dict(path=f.name,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
reviews=[]
f=OUT/"theta_recursive_radial_frame_peer_review_root.md"
if f.exists():
    reviews.append(dict(path=f.name,sha256=hashlib.sha256(f.read_bytes()).hexdigest()))
result=dict(
    mathematical_deliverable="theta_recursive_radial_frame.tex",
    manuscript_sha256=hashlib.sha256((OUT/"theta_recursive_radial_frame.tex").read_bytes()).hexdigest(),
    source_root="sources/lean/src",
    source_trace="theta_recursive_radial_frame_source_trace.md",
    exact_controls="check_theta_recursive_radial_frame.py",
    files=files,proved_dependencies=deps,peer_reviews=reviews,
    status="Actual initial connection and spectral data constructed; both recursive frames and compactly supported positive form proved. Application to later noncompact vectors still requires their actual analytic hypotheses.",
    kernel_replay_claimed=False,
)
(OUT/"theta_recursive_radial_frame_source_manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(f"Recorded {len(files)} source files and {len(reviews)} reviews.")
