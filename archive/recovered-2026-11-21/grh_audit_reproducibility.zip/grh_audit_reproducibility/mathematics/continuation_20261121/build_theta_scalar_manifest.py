"""Exact provenance for the scalar Hessenberg reduction and germ assembly."""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
SRC = BASE / "sources/lean/src"
OUT = Path(__file__).resolve().parent
HC = "Formalism/HermitianCurvature/"
HP = HC + "HermitianCurvatureProofs/"
DATA = [
    (HC+"ThetaExistenceInductiveFromPieces.lean", [[67,145],[360,475]],
     "Complete exact definitions PhiHyp, omPhi, bbZ, amplitude and germ coefficients; exact OscReduction, GermPhi, HeadReduction, Germ, GermKernel and assembly quantifiers. These ranges were directly reread for this pass."),
    (HP+"OrbitalIntegralReduction.lean",
     [[1,110],[1170,1322],[1710,1810],[2030,2275],[2334,2407],
      [2483,2640],[2870,3010],[3029,3271]],
     "Concrete Hessenberg and amplitude definitions; two-block orbital formula; bounded change estimates; complete pw_units/pw_main/pw_det; affine coordinate shape; full pointwise formula; amplitude and critical-value identification; complete final fa_main and OscReduction assembly. Earlier 1710--1810 coverage is retained. The finite-lattice/Haar bookkeeping and some polynomial auxiliary proof bodies were not read in full; the conventional text supplies independent proofs."),
    (HC+"BlockKernelPropertiesOfSteps.lean", "all (prior local pass)",
     "Inherited exact local datum and marked-kernel definitions; not a newly claimed full reread."),
    ("Formalism/DoubleCosetMeasures/Statement.lean", [[1,233]],
     "Inherited prior read scope for reversing blocks, unipotent groups and marked cokernels. The scalar proof uses the actual finite-product-field models already traced in theta_source_manifest.json."),
]
files=[]
for name,ranges,note in DATA:
    p=SRC/name
    data=p.read_bytes()
    count=len(data.decode().splitlines())
    if isinstance(ranges,list):
        ranges=[[a,min(b,count)] for a,b in ranges]
    files.append({"path":name,"sha256":hashlib.sha256(data).hexdigest(),
                  "line_count":count,"read_scope":ranges,"assessment":note})
result={
    "scope":"Complete conventional scalar orbital germ and its assembly for the actual marked-cokernel kernel",
    "source_root":"sources/lean/src",
    "mathematical_deliverables":["theta_scalar_germ.tex","theta_germ_assembly.tex"],
    "related_deliverables":["theta_head_reduction.tex","theta_germ_uniformity.tex"],
    "trace":"theta_scalar_source_trace.md",
    "exact_controls":"check_theta_scalar_germ.py",
    "files":files,
    "warning":"Source text coverage is not proof-dependency closure or Lean re-elaboration. The complete mathematical replacement is proved for the actual finite products of p-adic fields, including nonmaximal self-dual compact open orders. No global energy or conductor-uniform estimate across varying local data is claimed.",
}
(OUT/"theta_scalar_source_manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(f"Recorded {len(files)} exact scalar-germ source hashes and read scopes.")
