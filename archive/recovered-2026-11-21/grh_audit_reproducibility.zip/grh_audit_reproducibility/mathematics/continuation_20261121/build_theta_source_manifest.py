"""Record the exact source files used in the scoped theta reconstruction.

Ranges describe text read, not successful re-elaboration or a kernel check.
The source tree contains directory symlinks; use explicit paths rather than
Path.rglob so that the record does not silently omit that tree.
"""
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parents[2]
SRC = BASE / "sources/lean/src"
OUT = Path(__file__).resolve().parent
SR = "Formalism/SharpRestriction/"
CS = SR + "CuspSpanNormBounds/"
LG = "Formalism/LocalToGlobal/SiegelLatticeTheory/"
FT = LG + "FlagStabilizerTensors/"
CK = LG + "CokernelGLCounts/"
HC = "Formalism/HermitianCurvature/"
HP = HC + "HermitianCurvatureProofs/"

# Each record: exact relative path, conservative read ranges, assessment.
# "all" means all text read; "index" means declaration search only.
DATA = [
    (SR+"GlobalTheoremInputs.lean", [[55,85],[130,168]],
     "BesselId, LinkS_at, GamOf, LinkS: exact target and dimension proviso."),
    ("Formalism/SizeWindowBrackets/FrameTraceRatioFinEquiv.lean", [[1,85]],
     "InputSG and normalized Gram matrix; arithmetic lattice definitions."),
    (SR+"GlobalSchurBounds/TopDensityNGeSixteen.lean", [[1,155],[500,1380]],
     "FrameReal_at; full and compressed matrices; ramified dimension loss; PMat, gram_PMat, kp_eq. The remaining file was not read in full."),
    (CS+"RelevantZeroGramTerms.lean", [[1,180],[310,370],[500,525]],
     "Compact-type dimensions, c0, Kmat, KD and normalized actual maps."),
    (LG+"HaarTransversals/PoincareInHH.lean", "all",
     "Poincare seeds and maps, quotient Hilbert spaces, InHH hypotheses, c0X."),
    (FT+"PoincareConstantEq.lean", "all",
     "Exact level-volume placement; conditional folding and convergence statements."),
    (FT+"TheoremS.lean", "all",
     "Actual assembly theorem and order of uniform constants; not an independent proof of its imported inputs."),
    (FT+"RowsPos.lean", "all",
     "Type and mass reduction; positive kernel and diagonal row assembly."),
    (FT+"ThmSOwn.lean", [[1,330],[965,1038]],
     "Off-diagonal and diagonal clauses, isometric transport, selected-family wrappers."),
    (FT+"LinkSPos.lean", "all",
     "Assembly of actual Gram estimates and ambient dimension bound."),
    (FT+"RootLatticeThresholds/WuDecayAll.lean", [[1,190],[980,1065]],
     "Definitions and final local scalar assembly; local reproduction declaration located by search, and weighted decay providers are not fully audited."),
    ("CompanionTheory/AutomorphicTheory/LocalBesselUniqueness/BesselModels/LocScalar.lean", "all",
     "Full scalar-one argument and convolution normalization; weighted L1 input comes from an imported provider."),
    (HC+"StatementPB.lean", [[1,383],[385,467]],
     "Terms, row norm expansion, partitions, local/global input predicates, MainRow and pair bound statements."),
    (HP+"GrowthOfBasic.lean", [[1,260],[1060,1155]],
     "Numerical absorption and part of MainRow assembly; not a full audit of the global recursion."),
    (HP+"SecondDerivativeHolds.lean", "all",
     "Exact localCores/globalCores providers and their role in TheoremS."),
    (HC+"BlockKernelPropertiesOfSteps.lean", "all",
     "LocalDatum, marked cokernels, kernel Gram statements, inverse-parameter support, Parseval, ThetaProps and induction target."),
    ("Formalism/DoubleCosetMeasures/Statement.lean", [[1,220]],
     "Block reversal matrices, lower and upper unipotent groups, marked cokernel definitions."),
    (HC+"ThetaExistenceInductiveFromPieces.lean", [[1,740]],
     "Local Gaussian, Morse, stationary phase, orbital germ, finite averaging, annular majorants and final compactness statements. Most proof providers reside elsewhere."),
    (HP+"GermExpansionMatrixFunction.lean", [[1,260],[1180,1370]],
     "Initial proof assembly and final lattice_average_induction dependency alternatives. Intermediate germ/cross-term provider proofs remain unread."),
    (HP+"GaussSumModulusOfLattice.lean", "index",
     "Declaration locations only; Gaussian lemma proved independently in the TeX."),
    (HP+"HenselRootsBounded.lean", "index",
     "Declaration locations only; local Morse and stationary phase proved independently."),
    (HP+"PadicChangeOfVariables.lean", "index",
     "Declaration locations only; full source change-of-variable/cross-term proof not audited."),
    (CS+"FractionFieldToGenericStalkAlgebraMapEq.lean", [[1,225]],
     "Actual finite-product field models and nonmaximal split order; exact self-dual character and Haar normalization."),
    (CS+"LocalModelPeriodLattices.lean", [[1,90],[385,435],[1095,1135]],
     "Identification predicates and construction of abstract LocalDatum from actual local models."),
    (CS+"LocalGroupInFamilyNontrivial.lean", "index",
     "Declaration search for actual Kr and agreement ties; not a proof audit."),
    (CS+"LocalOrbitGerms.lean", [[1,90]],
     "Actual local group integral coordinates and interfaces to germ formula; the remainder is not audited."),
    (CK+"DataInst.lean", [[1,215]],
     "Actual KrOf and local model at a place; DensInputAt."),
    (CK+"RankPointCounts/DataCut.lean", [[1,160]],
     "Local density constants, place count, row PSD domination and local-factorization predicates."),
    (CK+"RankPointCounts/LocModel.lean", "index",
     "Declaration locations only; proof bodies remain to be audited."),
    (CK+"RankPointCounts/LocModelKSD.lean", "index",
     "Declaration locations only; localModelAt_holds provider remains to be audited."),
    (CK+"RowsConc.lean", [[1,150]],
     "Exact d_u, D_*, PgC, epsL=exp(-kf log k/3), epsNG and Gamma; quantifier order for nongeneric constant."),
    (CK+"RowsOther.lean", [[1,160]],
     "Separate degenerate diagonal bound and generic/nongeneric diagonal assembly."),
    (CS+"AdmissibleBoundsFromSource.lean", [[1,110]],
     "Actual e0 and eta0 scales and comparison constants."),
    ("Formalism/LocalRingCardinality/Params.lean", "all",
     "k, m, f and rS; rS is the flag length, while source r denotes total ambient rank."),
    (CS+"GlobAut.lean", [[180,220]],
     "Dcount, quotient volume, Dstar=d*vol*Re(e(1)); finite idempotent condition."),
    (CS+"PlaceDegreeData.lean", [[1,75]],
     "fdegAll is the product of local formal degrees for the specified Haar measures."),
    (CS+"StandingNumericalData.lean", [[1,95]],
     "Actual P=f3G product and HostFactorProductPowerIdentity; Line2a."),
    ("Formalism/SizeWindowBrackets/ErrorFormsWeakWindowsFalse.lean", [[85,89]],
     "bTx=exp(x^epsilon), inspected by exact declaration search."),
]

manifest = []
for name, ranges, note in DATA:
    p = SRC/name
    data = p.read_bytes()
    lines = data.decode().splitlines()
    if isinstance(ranges, list):
        ranges = [[lo, min(hi,len(lines))] for lo,hi in ranges]
    manifest.append({
        "path":name,"sha256":hashlib.sha256(data).hexdigest(),
        "line_count":len(lines),"read_scope":ranges,"assessment":note,
    })

result = {
    "scope":"Scoped conventional reconstruction of theta estimates; no claim of complete source verification",
    "root":"sources/lean/src", "files":manifest,
    "mathematical_deliverable":"work/continuation_20261121/theta_estimates.tex",
    "exact_controls":"work/continuation_20261121/check_theta_local.py",
    "subsequent_local_completion":["theta_orbital_identity.tex", "theta_head_reduction.tex", "theta_scalar_germ.tex", "theta_germ_assembly.tex", "theta_parseval.tex"],
    "warning":"Read scope is not dependency closure, recompilation, exported-proof checking, or certification of imported providers.",
}
(OUT/"theta_source_manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(f"Recorded {len(manifest)} exact source-file hashes and read scopes.")
