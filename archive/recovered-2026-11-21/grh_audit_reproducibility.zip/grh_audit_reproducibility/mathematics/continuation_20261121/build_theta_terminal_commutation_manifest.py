"""Conservative provenance for the actual terminal RTT reconstruction."""
from pathlib import Path
import hashlib,json
OUT=Path(__file__).resolve().parent
SRC=OUT.parents[1]/"sources/lean/src"
HP="Formalism/HermitianCurvature/HermitianCurvatureProofs/"
data=[
 ("Formalism/HermitianCurvature/StatementQ.lean",[[114,160],[181,208],[269,338],[380,443],[700,791]],
  "Full bordered determinant, terminal operators, one-pair cell/root rules, and actual RTT/independence/adjugate targets."),
 ("Formalism/FormalDegreeBessel/StatementG.lean",[[1,90]],
  "Actual Hermitian convention, unipotent group and character normalization."),
 ("Formalism/FormalDegreeBessel/StatementRP.lean",[[187,207]],
  "Exact two Weyl matrices and their complex-conjugate coordinate conventions."),
 (HP+"RttUpperRelationsFromDescent.lean",[[1,190]],
  "Full initial qdet_main and entrywise adjugate proof, plus beginning of monomial calculus; remainder not claimed read."),
]
files=[]
for name,scope,note in data:
 raw=(SRC/name).read_bytes();n=len(raw.decode().splitlines())
 assert all(1<=a<=b<=n for a,b in scope),(name,n,scope)
 files.append(dict(path=name,sha256=hashlib.sha256(raw).hexdigest(),line_count=n,read_scope=scope,assessment=note))
deps=[]
for name in ["theta_radial_positivity.tex","theta_radial_coupled_lifts.tex","theta_terminal_quantum_determinant.tex"]:
 deps.append(dict(path=name,sha256=hashlib.sha256((OUT/name).read_bytes()).hexdigest(),
                  assessment="Previously reconstructed ordinary mathematical dependency; no kernel replay implied."))
reviews=[]
name="theta_terminal_commutation_peer_review_root.md"
if (OUT/name).exists():reviews.append(dict(path=name,sha256=hashlib.sha256((OUT/name).read_bytes()).hexdigest()))
result=dict(mathematical_deliverable="theta_terminal_commutation.tex",
 manuscript_sha256=hashlib.sha256((OUT/"theta_terminal_commutation.tex").read_bytes()).hexdigest(),
 source_root="sources/lean/src",source_trace="theta_terminal_commutation_source_trace.md",
 exact_controls="check_theta_terminal_commutation.py",files=files,
 proved_mathematical_dependencies=deps,peer_reviews=reviews,
 status="Full terminal RTT and both shifted adjugate identities proved; recursive-frame and Jacquet analytic work remains separate.")
(OUT/"theta_terminal_commutation_source_manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(f"Recorded {len(files)} source files and {len(reviews)} reviews.")
