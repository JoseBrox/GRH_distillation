"""Exact conservative source provenance for the terminal determinant."""
from pathlib import Path
import hashlib
import json
OUT=Path(__file__).resolve().parent
SRC=OUT.parents[1]/"sources/lean/src"
HP="Formalism/HermitianCurvature/HermitianCurvatureProofs/"
data=[
 ("Formalism/HermitianCurvature/StatementQr.lean",[[1,155],[195,226]],
  "Actual variable coefficient relations, quantum Jacobi and contracted determinant statements; frame and left/right interfaces."),
 (HP+"QuantumMinorExpansion.lean","all",
  "Cofactor identities, polynomial cancellation, and exact shifted quantum Jacobi proof."),
 (HP+"QuantumMinorCommutation.lean","all",
  "Actual vector/determinant and covector/minor commutators by row and column expansion."),
 (HP+"AlgebraicQuantumDeterminant.lean",[[1,180]],
  "Full finite-sum algebraic core and signed-cofactor conversion definitions; remaining assembly not claimed read."),
 (HP+"FrameEntries.lean",[[195,275]],
  "Actual terminal composition, contracted identity and conversion to left/right frame determinants."),
 ("Formalism/HermitianCurvature/StatementQ.lean",[[580,630],[625,690],[791,840]],
  "Actual Capelli parameter convention, reversed left products, type actions and DetHat/DetGeneric targets."),
]
files=[]
for name,scope,note in data:
 raw=(SRC/name).read_bytes();n=len(raw.decode().splitlines())
 if isinstance(scope,list):assert all(1<=a<=b<=n for a,b in scope),(name,n,scope)
 files.append(dict(path=name,sha256=hashlib.sha256(raw).hexdigest(),line_count=n,read_scope=scope,assessment=note))
deps=[]
for name in ["theta_radial_positivity.tex","theta_radial_differential_lifts.tex","theta_radial_coupled_lifts.tex"]:
 deps.append(dict(path=name,sha256=hashlib.sha256((OUT/name).read_bytes()).hexdigest(),
                  assessment="Previously reconstructed ordinary mathematical dependency; no kernel replay implied."))
reviews=[]
for name in ["theta_terminal_quantum_determinant_peer_review_root.md"]:
 if (OUT/name).exists():reviews.append(dict(path=name,sha256=hashlib.sha256((OUT/name).read_bytes()).hexdigest()))
result=dict(mathematical_deliverable="theta_terminal_quantum_determinant.tex",
 manuscript_sha256=hashlib.sha256((OUT/"theta_terminal_quantum_determinant.tex").read_bytes()).hexdigest(),
 source_root="sources/lean/src",source_trace="theta_terminal_quantum_determinant_source_trace.md",
 exact_controls="check_theta_terminal_quantum_determinant.py",files=files,
 proved_mathematical_dependencies=deps,peer_reviews=reviews,
 status="Terminal determinant identity and exact finite-type scalar proved; remaining terminal commutation and Jacquet analytic assertions remain separate.")
(OUT/"theta_terminal_quantum_determinant_source_manifest.json").write_text(json.dumps(result,indent=2)+"\n")
print(f"Recorded {len(files)} source files and {len(reviews)} root reviews.")
