"""Record the precise sources inspected for the conventional formal-degree proof."""
from pathlib import Path
import hashlib
import json

BASE = Path(__file__).resolve().parent
ROOT = BASE.parents[1]
SRC = ROOT / "sources/lean/src"

records = [
    ("Formalism/LocalRingCardinality/DataCD.lean", "all",
     "Exact Lie algebra, complexification-normalized Lebesgue measure, exponential ball density, compact probability and equal-density Haar conditions."),
    ("Formalism/LocalRingCardinality/DataTies.lean", "all",
     "Exact Haar transport and universal numerical formal-degree identification; avoids an inference from a potentially empty representation class."),
    ("Formalism/FormalDegreeBessel/StatementDS.lean", "all",
     "Integral Harish-Chandra parameter convention, lowK, fdegHC and product denominator."),
    ("Formalism/SharpRestriction/CuspSpanNormBounds/RelevantZeroGramTerms.lean", [[1,130]],
     "Representation, coefficient, IsFdeg, compact-type, shifted norm and IsDS definitions; no claim to read the rest of this file."),
    ("Development/AbelianVarietyTheory/Definitions/Foundations/CdScaleTieIff.lean", "all",
     "Exact measure and numerical interfaces, including the general universal formal-degree proposition."),
    ("Development/AbelianVarietyTheory/Proofs/FlagMeasures/NormalizedFormalDegreeEqVandermondeOfSizes.lean", "all",
     "Numerical Vandermonde endpoint under the submitted size and gap hypotheses."),
    ("Development/AbelianVarietyTheory/Proofs/FlagMeasures/FormalDegreeEqHarishChandraOfGapStatement.lean", "all",
     "Statement wrapper for the actual numerical formal-degree theorem."),
    ("Development/AbelianVarietyTheory/Proofs/FlagMeasures/FormalDegreeEqHarishChandraOfGap.lean", "all",
     "Existence, both signs present, actual degree theorem and dsigTie substitution."),
    ("Development/AbelianVarietyTheory/Proofs/FlagMeasures/HarishChandraFormalDegreeCompactDualLargeGaps.lean", "all",
     "Source compact-dual measure identification and application of its independent large-gap formal-degree calculation."),
    ("ReciprocityTheory/ReductiveGroups/DiscreteSeries/FormalDegree/FdCons.lean", "all",
     "Source final formal-degree calibration and its dependence on the asymptotic calculation; not a verification of every imported dependency."),
    ("ReciprocityTheory/ReductiveGroups/DiscreteSeries/FormalDegree/FdDefs.lean", "all",
     "Source parameter deformation and Vandermonde conventions."),
    ("ReciprocityTheory/ReductiveGroups/DiscreteSeries/FormalDegree/PmatIsHermitian.lean", "all",
     "Source cPQ, muPolar, muCD, dimVlam and polar-coordinate conventions."),
    ("ReciprocityTheory/ReductiveGroups/DiscreteSeries/FormalDegree/ThmFD.lean", "all",
     "Source asymptotic upper/lower calibration assembly. The reconstruction instead uses a scalar Bergman model and the classical formal-degree theorem."),
    ("ReciprocityTheory/ReductiveGroups/DiscreteSeries/FormalDegree/HaarVolumes/OmegaDensityUnique.lean", "all",
     "Source uniqueness of normalized Lie algebra density and transport of the resulting compact-dual Haar measure."),
]

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

files = []
for rel, scope, assessment in records:
    path = SRC / rel
    files.append({
        "path": rel,
        "sha256": digest(path),
        "line_count": len(path.read_text().splitlines()),
        "read_scope": scope,
        "reader": "/root/formal_degree_review",
        "assessment": assessment,
    })

deliverable = BASE / "unitary_formal_degree.tex"
primary_pdf = BASE / "primary_formal_degree/harish_chandra_ds_ii.pdf"
data = {
    "source_root": "sources/lean/src",
    "mathematical_deliverable": deliverable.name,
    "mathematical_deliverable_sha256": digest(deliverable),
    "source_trace": "unitary_formal_degree_source_trace.md",
    "peer_review": "unitary_formal_degree_peer_review_formal.md",
    "exact_controls": "check_unitary_formal_degree.py",
    "exact_control_record": "unitary_formal_degree_checks.json",
    "exact_controls_scope": "The root reports 39619 exact integer/rational controls for normalization constants and minimum-type inequalities, at this same manuscript SHA. General theorems rest on the written proofs and named classical inputs.",
    "files": files,
    "primary_reference_check": [
        {
            "title": "Harish-Chandra, Discrete series for semisimple Lie groups II",
            "url": "https://archive.ymsc.tsinghua.edu.cn/pacm_download/117/6013-11511_2006_Article_BF02392813.pdf",
            "doi": "10.1007/BF02392813",
            "pdf_sha256": digest(primary_pdf),
            "pdf_bytes": primary_pdf.stat().st_size,
            "read_scope": "Theorem 16 and its formal-degree conclusion in section 41, printed pages 96 and 99–100; not the entire proof.",
        },
        {
            "title": "Duflo–Heckman–Vergne, Projection d'orbites, formule de Kirillov et formule de Blattner",
            "url": "https://www.numdam.org/article/MSMF_1984_2_15__65_0.pdf",
            "read_scope": "Section III.1, theorem (2), printed page 111, and its character convention; not the complete proof.",
        },
        {
            "title": "Baldoni–Vergne, Discrete series representations and K multiplicities for U(p,q)",
            "url": "https://webusers.imj-prg.fr/~michele.vergne/publications/discreteseries.pdf",
            "version": "arXiv:1008.5360v1",
            "read_scope": "Section 2.2, printed pages 12–14: parameter, highest-weight conversion and full Blattner formula passage.",
        },
        {
            "title": "Parthasarathy, Classification of discrete series by minimal K-type",
            "url": "https://www.researchgate.net/publication/282775275_Classification_of_discrete_series_by_minimal_-type",
            "doi": "10.1090/ert/467",
            "read_scope": "Author-posted primary full text, introductory group hypotheses and Theorem 1.1, printed pages 167–168; not the complete proof.",
        },
    ],
    "scope": "Full conventional argument reviewed conditional on the named classical representation theorems. Actual source interfaces and indicated files read. No independent full Lean kernel replay or complete read of transitive dependencies.",
}
target = BASE / "unitary_formal_degree_source_manifest.json"
target.write_text(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"files": len(files), "sha256": data["mathematical_deliverable_sha256"], "manifest": str(target)}))
