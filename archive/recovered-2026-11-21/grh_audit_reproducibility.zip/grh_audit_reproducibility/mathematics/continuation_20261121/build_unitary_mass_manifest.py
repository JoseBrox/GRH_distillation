"""Record exact source and primary-reference scope for the density/mass audit."""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[1]
names = [
    'Formalism/HermitianLattices/StatementMass.lean',
    'Formalism/LocalToGlobal/SiegelLatticeTheory/SiegelMassRatios/MassRatio.lean',
    'Formalism/LocalToGlobal/SiegelLatticeTheory/SiegelMassRatios/DensExact.lean',
    'Development/AbelianVarietyTheory/Proofs/FlagMeasures/SiegelMassRatioUnimodularDefinite.lean',
    'Formalism/GL3MeanSquares/GenusMeanAsymptotics/UnimodularClassRepresentatives/SiegelMassRatioOfLI.lean',
]
records = []
for name in names:
    p = ROOT/'sources/lean/src'/name
    data = p.read_bytes()
    count = len(data.decode().splitlines())
    records.append({'path': str(p.relative_to(ROOT)),
                    'sha256': hashlib.sha256(data).hexdigest(),
                    'line_count': count, 'scope': 'full file read',
                    'line_ranges_read': [[1,count]]})
fragment = HERE/'unitary_mass_densities.tex'
primary = json.loads((HERE/'primary_mass/manifest.json').read_text())
for item in primary:
    if item['name'].startswith('kirschmer'):
        item['read_scope'] = 'Section 4.2, definition of local density and Theorem 4.2.3 with the following local-factor formulas, printed pages 50-53.'
    else:
        item['read_scope'] = 'Section 2.3, including all hypotheses and equation (2.6), printed pages 9-11.'
out = {
    'date_utc': datetime.now(timezone.utc).isoformat(),
    'fragment': fragment.name,
    'fragment_sha256': hashlib.sha256(fragment.read_bytes()).hexdigest(),
    'purpose': 'Independent ordinary proof of finite-field primitive densities, dyadic-unramified lifting, and the exact source mass ratio from an explicitly stated classical Siegel mass formula.',
    'files': records,
    'primary_references': primary,
    'controls': 'check_unitary_mass_densities.py: 58 exact small-field primitive-frame counts; no extrapolation is used in the proof.',
    'limits': 'The global mass formula is a stated classical input. The long Lean proof of that classical theorem is not claimed to have been independently reconstructed or fully read here.',
}
(HERE/'unitary_mass_densities_source_manifest.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'files':len(records),'sha256':out['fragment_sha256']}))
