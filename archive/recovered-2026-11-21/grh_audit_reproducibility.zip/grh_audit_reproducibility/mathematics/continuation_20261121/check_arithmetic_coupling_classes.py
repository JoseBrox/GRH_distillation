"""Exact small-prime controls for the coset and stabilizer normalizations.
These finite controls supplement, and do not prove, the general theorems.
"""
from fractions import Fraction
from itertools import product
from pathlib import Path
import json

checks=[]
def add(name, data):
    checks.append({'name':name, **data})

def red_rat(a, p):
    assert a.denominator % p
    return a.numerator*pow(a.denominator,-1,p)%p

res=[(red_rat(2*Fraction(j,6),2),red_rat(3*Fraction(j,6),3)) for j in range(6)]
assert len(set(res))==6
add('CRT for primes 2 and 3', {'representative_count':6,'distinct_residue_vectors':len(set(res))})

for p in [2,3,5]:
    vs=list(product(range(p),repeat=2))
    gl=[(a,b,c,d) for a,b,c,d in product(range(p),repeat=4) if (a*d-b*c)%p]
    unip=[(1,b,0,1) for b in range(p)]
    for name,H in [('GL2',gl),('upper unipotent',unip)]:
        def act(g,v):
            a,b,c,d=g;x,y=v
            return ((a*x+b*y)%p,(c*x+d*y)%p)
        todo=set(vs); rows=[]; mass=Fraction(0)
        while todo:
            a=min(todo); orb={act(g,a) for g in H}; stab=[g for g in H if act(g,a)==a]
            assert len(stab)*len(orb)==len(H)
            rows.append({'representative':a,'orbit_size':len(orb),'stabilizer_size':len(stab)})
            mass+=Fraction(1,len(stab)); todo-=orb
        assert mass==Fraction(p*p,len(H))
        if name=='GL2':assert len(rows)==2
        else:assert len(rows)==2*p-1
        add(f'{name} over F_{p}', {'group_order':len(H),'orbits':rows,'weighted_mass':str(mass)})

# O=Z[i], P=(3), t=Norm(P)=9: t^-1 O/O = O/(9).
# Reduction to O/(3) has nontrivial kernel; y=1/3 is numerator 3 mod 9.
inert_domain=list(product(range(9),repeat=2))
inert_kernel=[x for x in inert_domain if x[0]%3==x[1]%3==0]
assert len(inert_kernel)==9 and (3,0) in inert_kernel and (3,0)!=(0,0)
add('inert norm is not a uniformizer', {'quotient_order':81,'residue_order':9,'kernel_order':9,'nonzero_kernel_numerator':[3,0]})

# O=Z[sqrt(2)], P=(sqrt(2)), t=2: quotient O/(2) has 4 elements.
# Its residue at P is the constant coefficient mod 2.
ramified_domain=list(product(range(2),repeat=2))
ramified_kernel=[x for x in ramified_domain if x[0]==0]
assert len(ramified_kernel)==2 and (0,1) in ramified_kernel
add('ramified norm is not a uniformizer', {'quotient_order':4,'residue_order':2,'kernel_order':2,'nonzero_kernel_numerator':[0,1]})

assert Fraction(1,2)+1==Fraction(3,2)
assert Fraction(1,2)+Fraction(1,2)!=Fraction(3,2)
add('vector versus line and exact stabilizer weights', {'nonzero_vector_index':2,'line_index':1,'correct_weighted_sum':'3/2','incorrect_fixed_stabilizer_sum':'1'})

out={'all_passed':True,'arithmetic':'exact Python integers and Fraction','scope':'Finite controls only, not a proof of the general number-field assertions.','checks':checks}
p=Path(__file__).with_name('arithmetic_coupling_classes_exact_checks.json')
p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'all_passed':True,'checks':len(checks),'output':str(p)}))
