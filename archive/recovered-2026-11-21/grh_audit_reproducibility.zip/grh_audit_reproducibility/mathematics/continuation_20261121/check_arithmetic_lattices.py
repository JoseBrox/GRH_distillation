"""Exact rational certificates used in arithmetic_lattices.tex.

These certify only the explicit numerical comparisons in the Gaussian
transference proof. They are not a substitute for the analytic proof.
Run with Python 3; no numerical or external algebra packages are required.
"""
from fractions import Fraction as F
from math import factorial
from pathlib import Path
import json

checks = {
    "sqrt3_upper_square_margin": F(1733, 1000)**2 - 3,
    "dodecagon_squared_margin": 72 - 36*F(1733, 1000) - F(31, 10)**2,
    "exp31_over25_series_margin": sum(F(31, 25)**j / factorial(j) for j in range(5)) - F(17, 5),
    "exp1_series_margin": F(163, 60) - F(19, 7),
    "exp16_over5_product_margin": F(19, 7)**3 * F(61, 50) - 24,
    "exponent_comparison_margin": F(25, 24)*F(31, 10) - F(16, 5),
    "gaussian_final_margin": 1 - (F(45, 68) + 2*F(1, 6)),
}
assert all(x > 0 for x in checks.values())
assert F(45, 68) + 2*F(1, 6) == F(203, 204)
result = {
    "status": "all_exact_checks_passed",
    "scope": "Positive rational margins in the displayed numerical certificate only.",
    "checks": {k: str(v) for k, v in checks.items()},
}
path = Path(__file__).with_name("arithmetic_lattices_exact_checks.json")
path.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
