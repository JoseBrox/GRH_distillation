"""Exact controls for CT24--CT31; these finite controls are not the proof."""
from fractions import Fraction as F
from pathlib import Path
import hashlib
import json


def mul(x, y, c):
    a, b = x
    u, v = y
    return (a*u-c*b*v, a*v+b*u+b*v)


def conj(x):
    a, b = x
    return (a+b, -b)


def norm(x, c):
    a, b = x
    return a*a+a*b+c*b*b


def alt(x, y):
    return x[1]*y[0]-x[0]*y[1]


def sub(x, y):
    return tuple(a-b for a, b in zip(x, y))


cases = []
for d in [7, 23, 31, 47, 71]:
    c = (d+1)//4
    for p in [5, 7, 11, 13, 17, 19]:
        if d % p == 0:
            continue
        roots = [r for r in range(p) if (r*r-r+c) % p == 0]
        if len(roots) != 2:
            continue
        for root in roots:
            for n in [1, 2]:
                modulus = p
                r = root
                while modulus < p**(2*n):
                    r = next(r+k*modulus for k in range(p)
                             if ((r+k*modulus)**2-(r+k*modulus)+c)
                             % (p*modulus) == 0)
                    modulus *= p
                rb = (1-r) % modulus
                pn = p**n
                bb = pow(2*(r-rb), -1, pn)
                aa = (-bb*rb) % pn
                eps = (2*aa, 2*bb)
                assert (eps[0]+eps[1]*r-1) % pn == 0
                assert (eps[0]+eps[1]*rb) % pn == 0
                assert norm(eps, c) % 4 == 0
                for b in [1, 2, p-1]:
                    a = (-b*rb) % modulus
                    assert (a+b*rb) % modulus == 0
                    for s in [1, 2, p+1]:
                        y = (F(s*a, pn), F(s*b, pn))
                        l = sub(mul(eps, y, c), y)
                        by = mul(conj(eps), y, c)
                        assert all(z.denominator == 1 for z in l)
                        assert all(z.denominator == 1 and z.numerator % 2 == 0
                                   for z in by)
                        ny = norm(y, c)
                        assert ny.denominator == 1
                        assert alt(y, l) == -eps[1]*ny
                        assert norm(l, c) == (
                            norm(eps, c)-2*eps[0]-eps[1]+1)*ny
                        phase = alt(y, l)-norm(l, c)-ny
                        assert phase.denominator == 1
                        assert phase.numerator % 2 == 0
                        cases.append([d, p, root, n, b, s])

base = Path(__file__).resolve().parent
result = {
    "scope": "Exact rational checks of lattice membership and the parity of "
             "the selected p-power Weyl-translation phase; no theta values "
             "or infinite theorem are numerically asserted.",
    "cases": len(cases),
    "parameters": cases,
    "artifact_sha256": hashlib.sha256(
        (base/"cm_theta_integrality.tex").read_bytes()).hexdigest(),
    "all_passed": True,
}
(base/"cm_theta_phase_checks.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps({k: v for k, v in result.items() if k != "parameters"}))
