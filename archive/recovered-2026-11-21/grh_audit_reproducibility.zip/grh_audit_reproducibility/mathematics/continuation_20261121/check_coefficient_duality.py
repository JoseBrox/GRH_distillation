"""Exact small-case checks for normalized polynomial coefficient duality.

The two lattices are constructed independently: the dual-Weyl lattice
is the saturated integer kernel of the column-invariance equations;
the Weyl lattice is the integer span closed under divided row operators.
All decisive operations use integers or rational numbers.
"""
from itertools import product, permutations
from math import comb, factorial
from functools import reduce
import json
import time

from sympy import Matrix, SparseMatrix, ZZ, Rational, factorint
from sympy.matrices.normalforms import hermite_normal_form
from sympy.polys.matrices import DomainMatrix
from sympy.polys.matrices.normalforms import smith_normal_decomp


def compositions(d, r):
    if r == 0:
        return [()] if d == 0 else []
    if r == 1:
        return [(d,)]
    return [(a,)+b for a in range(d+1) for b in compositions(d-a, r-1)]


def monomials(r, nu):
    return [tuple(x for col in cols for x in col)
            for cols in product(*(compositions(d,r) for d in nu))]


def sign(perm):
    return (-1)**sum(perm[i]>perm[j] for i in range(len(perm))
                     for j in range(i+1,len(perm)))


def poly_mul(f, g):
    out = {}
    for e,a in f.items():
        for z,b in g.items():
            w=tuple(x+y for x,y in zip(e,z))
            out[w]=out.get(w,0)+a*b
    return {e:a for e,a in out.items() if a}


def highest(r, nu):
    n=len(nu); f={(0,)*(r*n):1}
    for k in range(1,n+1):
        minor={}
        for perm in permutations(range(k)):
            e=[0]*(r*n)
            for col,row in enumerate(perm): e[col*r+row]+=1
            minor[tuple(e)]=sign(perm)
        exp=nu[k-1]-(nu[k] if k<n else 0)
        assert exp>=0
        for _ in range(exp): f=poly_mul(f,minor)
    return f


def column_constraints(r, nu, mons):
    n=len(nu); rows={}
    for i,e in enumerate(mons):
        for left in range(n):
            for right in range(left+1,n):
                for choices in product(*(range(e[right*r+a]+1) for a in range(r))):
                    k=sum(choices)
                    if not k: continue
                    z=list(e); c=1
                    for a,q in enumerate(choices):
                        c*=comb(e[right*r+a],q)
                        z[right*r+a]-=q; z[left*r+a]+=q
                    key=(left,right,k,tuple(z))
                    row=rows.setdefault(key,{})
                    row[i]=row.get(i,0)+c
    if not rows:
        return Matrix.zeros(0,len(mons))
    return SparseMatrix(len(rows),len(mons),
                        {(a,b):c for a,row in enumerate(rows.values()) for b,c in row.items()})


def row_operators(r, nu, mons, pos):
    n=len(nu); ops={}
    for source in range(r):
        for target in range(r):
            if source==target:
                for k in range(1,sum(nu)+1):
                    entries={(i,i):comb(sum(e[j*r+source] for j in range(n)),k)
                             for i,e in enumerate(mons)
                             if sum(e[j*r+source] for j in range(n))>=k}
                    if entries:
                        ops[(source,target,k)]=SparseMatrix(len(mons),len(mons),entries)
                continue
            coeff={}
            for i,e in enumerate(mons):
                for choices in product(*(range(e[j*r+target]+1) for j in range(n))):
                    k=sum(choices)
                    if not k: continue
                    z=list(e); c=1
                    for j,q in enumerate(choices):
                        c*=comb(e[j*r+target],q)
                        z[j*r+target]-=q; z[j*r+source]+=q
                    entries=coeff.setdefault(k,{})
                    key=(pos[tuple(z)],i)
                    entries[key]=entries.get(key,0)+c
            for k,entries in coeff.items():
                ops[(source,target,k)]=SparseMatrix(len(mons),len(mons),entries)
    return list(ops.values())


def run_case(r, nu):
    started=time.time(); mons=monomials(r,nu); pos={e:i for i,e in enumerate(mons)}
    nmon=len(mons); A=column_constraints(r,nu,mons)
    if A.rows:
        sm,S,T=smith_normal_decomp(DomainMatrix.from_Matrix(A).convert_to(ZZ))
        sm,T=sm.to_Matrix(),T.to_Matrix()
        rank=sum(sm[i,i]!=0 for i in range(min(sm.shape)))
        assert A.rank()==rank
        assert abs(T.det())==1
        N=T[:,rank:]
        assert A*N==Matrix.zeros(A.rows,N.cols)
    else:
        N=Matrix.eye(nmon)
    h=highest(r,nu)
    H=Matrix([h.get(e,0) for e in mons])
    W=hermite_normal_form(H)
    ops=row_operators(r,nu,mons,pos)
    steps=0
    while True:
        new=hermite_normal_form(Matrix.hstack(W,*(op*W for op in ops))) if ops else W
        steps+=1
        if new==W: break
        W=new
        assert steps<30
    assert W.cols==N.cols
    gram=Matrix.diag(*(reduce(lambda a,b:a*b,(factorial(x) for x in e),1) for e in mons))
    C=(H.T*gram*H)[0]
    assert C>0 and C.q==1
    cross=W.T*gram*N/C
    assert all(a.q==1 for a in cross)
    assert abs(cross.det())==1
    coordinates=N.gauss_jordan_solve(W)[0]
    assert all(a.q==1 for a in coordinates)
    index=abs(int(coordinates.det()))
    return {'rows':r,'partition':list(nu),'monomial_count':nmon,
            'rank':N.cols,'highest_fock_norm':int(C),
            'weyl_index_in_dual_weyl':index,'index_factorization':{str(p):e for p,e in factorint(index).items()},
            'cross_pairing_determinant':int(cross.det()),
            'closure_rounds':steps,'elapsed_seconds':round(time.time()-started,3),
            'result':'exact integral perfect pairing verified'}


if __name__=='__main__':
    cases=[(0,()),(3,()),(1,(0,)),(2,(2,0)),(2,(4,0)),(2,(2,1)),
           (3,(2,0,0)),(3,(2,1,0)),(3,(3,1,0)),(3,(2,2,0)),
           (3,(2,1)),(4,(2,1))]
    results=[]
    for r,nu in cases:
        result=run_case(r,nu); results.append(result)
        print(json.dumps(result),flush=True)
    from pathlib import Path
    Path(__file__).with_name('coefficient_duality_checks.json').write_text(json.dumps({
        'method':'exact integer kernel and divided-operator lattice closure; no floating-point tests',
        'scope':'finite examples only, supplementary to the mathematical proof',
        'cases':results},indent=2)+'\n')
