"""Exact algebraic controls for deep_cusp_mass.tex.

These are finite controls, not a proof of the analytic theorems imported
in that fragment, not a full Lean replay, and not a GRH verification.
Only Python integer/rational arithmetic and symbolic polynomial identities
are used.  The deterministic lattice examples use Z[omega], omega^2+omega+1=0.
"""
from pathlib import Path
from fractions import Fraction as Q
from itertools import combinations, product
import hashlib
import json
import random

import sympy as sp

BASE = Path(__file__).resolve().parent
counts = {}


def check(group, condition):
    counts[group] = counts.get(group, 0) + 1
    if not bool(condition):
        raise AssertionError((group, counts[group]))


# Exact Eisenstein integers, with omega conjugate to -1-omega.
ZERO, ONE, THETA = (0, 0), (1, 0), (0, -1)


def add(a, b):
    return (a[0] + b[0], a[1] + b[1])


def neg(a):
    return (-a[0], -a[1])


def mul(a, b):
    return (a[0] * b[0] - a[1] * b[1],
            a[0] * b[1] + a[1] * b[0] - a[1] * b[1])


def conj(a):
    return (a[0] - a[1], -a[1])


def matzero(a, b):
    return [[ZERO for _ in range(b)] for _ in range(a)]


def matmul(A, B):
    C = matzero(len(A), len(B[0]))
    for i in range(len(A)):
        for j in range(len(B[0])):
            for k in range(len(B)):
                C[i][j] = add(C[i][j], mul(A[i][k], B[k][j]))
    return C


def adj(A):
    return [[conj(A[j][i]) for j in range(len(A))]
            for i in range(len(A[0]))]


def eye(n):
    A = matzero(n, n)
    for i in range(n):
        A[i][i] = ONE
    return A


check("trace_one", add(THETA, conj(THETA)) == ONE)
rng = random.Random(20261121)
for j, m, g in product(range(1, 4), range(1, 4), (1, 2, 3, 8)):
    for trial in range(4):
        n = 2 * j + m
        J = matzero(n, n)
        J0 = matzero(m, m)
        for a in range(j):
            J[a][j+m+a] = J[j+m+a][a] = ONE
        for a in range(m):
            J0[a][a] = (rng.choice((-1, 1)), 0)
            J[j+a][j+a] = J0[a][a]
        Z = [[(g*rng.randint(-3, 3), g*rng.randint(-3, 3))
              for _ in range(j)] for _ in range(m)]
        H = matmul(adj(Z), J0)
        ZZ = matmul(H, Z)
        B = [[neg(mul(THETA, ZZ[a][b])) for b in range(j)]
             for a in range(j)]
        U = eye(n)
        for a in range(j):
            for b in range(m):
                U[a][j+b] = neg(H[a][b])
        for a in range(m):
            for b in range(j):
                U[j+a][j+m+b] = Z[a][b]
        for a in range(j):
            for b in range(j):
                U[a][j+m+b] = B[a][b]
                check("integral_trace_one_lift",
                      add(B[a][b], conj(B[b][a])) == neg(ZZ[a][b]))
        check("unitary_lift", matmul(matmul(adj(U), J), U) == J)
        for a in range(n):
            for b in range(n):
                e = add(U[a][b], neg(eye(n)[a][b]))
                check("congruence_lift", e[0] % g == 0 and e[1] % g == 0)

# The central trace pairing at a dyadic unramified quadratic place:
# alpha=1+2 omega, alpha^2=-3; off-diagonal trace Gram [[2,-1],[-1,2]].
alpha = (1, 2)
check("central_pairing", conj(alpha) == neg(alpha))
check("central_pairing", mul(alpha, alpha) == (-3, 0))
off = sp.Matrix([[2, -1], [-1, 2]])
check("central_pairing", off.det() == 3)
for j in range(1, 12):
    blocks = [sp.Matrix([[3]]) for _ in range(j)]
    blocks += [off for _ in range(j * (j - 1) // 2)]
    gram = sp.diag(*blocks)
    determinant = 3 ** (j * (j + 1) // 2)
    check("central_pairing", gram.det() == determinant)
    check("central_pairing", determinant % 2 == 1)

# Exact noncommuting ordered-product derivatives; each variable appears once.
t = sp.symbols("t0:3", real=True)
Y = []
for i, j in ((0, 1), (1, 2), (2, 0)):
    M = sp.zeros(3)
    M[i, j] = 1
    Y.append(M)
E = [sp.eye(3) + t[i] * Y[i] for i in range(3)]
Psi = E[0] * E[1] * E[2]
A = []
for i in range(3):
    tail = sp.eye(3)
    invtail = sp.eye(3)
    for j in range(i + 1, 3):
        tail = tail * E[j]
    for j in reversed(range(i + 1, 3)):
        invtail = invtail * (sp.eye(3) - t[j] * Y[j])
    A.append(invtail * Y[i] * tail)
for k in range(1, 4):
    for subset in combinations(range(3), k):
        lhs, rhs = Psi, Psi
        for i in subset:
            lhs = lhs.diff(t[i])
            rhs = rhs * A[i]
        check("mixed_chart_derivatives",
              (lhs - rhs).applyfunc(sp.expand) == sp.zeros(3))

# The averaged fundamental theorem of calculus, checked on monomials.
z, r = sp.symbols("z r", positive=True)
for degree in range(15):
    h = z**degree
    avg = sp.integrate(h, (z, -r, r)) / (2*r)
    lhs = sp.integrate((z+r)/(2*r)*sp.diff(h, z), (z, -r, 0))
    rhs = sp.integrate(-(r-z)/(2*r)*sp.diff(h, z), (z, 0, r))
    check("averaged_FTC", sp.simplify(avg + lhs + rhs - h.subs(z, 0)) == 0)

# Chart exponential bounds are certified by e^u <= (1-u)^(-1), 0<=u<1.
for dimension in list(range(1, 257)) + [1000, 10**6, 10**12]:
    S = Q(1, 20*dimension)
    check("chart_constants", S / (1-S) <= 2*S)
    check("chart_constants", 2*S / (1-2*S) <= 3*S)
    check("chart_constants", 4*S*S*dimension <= Q(1, 100))
    check("chart_constants", 9*S*S*dimension < Q(1, 4))
    check("chart_constants", 1/(1-2*S) < 2)
    check("sobolev_constants", 20*dimension**2*2*5*dimension == 200*dimension**3)

# Radical coefficient: jm/sqrt(2)+j^2/2 <= j(m+j) <= n^2/4.
# The first inequality is checked with the larger jm+j^2/2.
for n in range(3, 129):
    for j in range(1, n//2 + 1):
        m = n - 2*j
        check("radical_coefficients",
              Q(j*m) + Q(j*j, 2) <= j*(m+j))
        check("radical_coefficients", 4*j*(n-j) <= n*n)

# Algebra in the Hecke functional-equation strip and quotient-volume estimate.
tt = sp.symbols("tt", real=True)
ratio_difference = Q(1, 16) + tt**2/4 - (Q(9, 4)+tt**2)/4
check("Hecke_strip", sp.expand(ratio_difference) == -sp.Rational(1, 2))
for k in range(2, 256):
    check("Euler_tail", sum((Q(1, a*(a-1)) for a in range(2, k+1)), Q(0))
          == 1-Q(1, k))
for n in range(2, 256):
    check("volume_exponents", Q(n*n, 2)+Q(5, 4) <= n*n)

# Parameter absorption on a deliberately much wider finite grid than needed.
for root_n, f, g, rE, b in product(
        (10**4, 10**5, 10**6), (1, 2, 10, 10**6),
        (1, 5), (Q(1), Q(3, 2), Q(10**6)), (Q(2), Q(3), Q(100))):
    n, X = root_n**2, root_n**2 * f * g * rE * b
    NN = n*n*f
    for q in (1, 2, root_n):
        beta = 2*root_n*b*b + 4*n*root_n + 4*(8*q+1)*NN
        check("parameter_absorption", beta <= X**3)
        check("parameter_absorption", NN <= X**2)
        check("parameter_absorption", 156800 <= X)
        check("parameter_absorption", n*n*f*g*rE <= X**2)
        check("parameter_absorption", Q(1, 2)*X**(-9) < Q(1, 2))
        check("final_exponent", 80*q+13-132*q+3 <= -36)

qq = sp.symbols("q", integer=True, positive=True)
check("symbolic_exponent",
      sp.expand(16*qq*5+13-11*qq*(16-4)+3) == -52*qq+16)
check("symbolic_exponent",
      sp.expand((-52*qq+16)-(-36)) == -52*(qq-1))
check("constant_product", 200*28**2 == 156800)

fragment = BASE / "deep_cusp_mass.tex"
record = {
    "result": "PASS",
    "scope": "Exact finite algebraic and arithmetic controls only; no verification of imported analytic theorems or full Lean replay.",
    "fragment_sha256": hashlib.sha256(fragment.read_bytes()).hexdigest(),
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "assertions": sum(counts.values()),
    "groups": counts,
    "random_seed": 20261121,
}
(BASE / "deep_cusp_constants_checks.json").write_text(json.dumps(record, indent=2)+"\n")
print(json.dumps(record, indent=2))
