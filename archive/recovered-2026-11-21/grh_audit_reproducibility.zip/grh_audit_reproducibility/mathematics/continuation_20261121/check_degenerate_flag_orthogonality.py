#!/usr/bin/env python3
"""Exact finite controls for the degenerate-flag reconstruction.

All matrix entries are in Q(i); there are no floating point tolerances.
These controls check normal forms, the common Lie-algebra character,
and a counterexample when relevance is omitted. They do not replace the
general proofs in degenerate_flag_orthogonality.tex or replay Lean.
"""
from collections import Counter
from hashlib import sha256
from pathlib import Path
import json
import sympy as s

HERE = Path(__file__).resolve().parent
counts = Counter()
cases = Counter()


def check(kind, condition):
    if not bool(condition):
        raise AssertionError(kind)
    counts[kind] += 1


def witt(r, k):
    n = 2*r+k+1
    J = s.zeros(n)
    for a in range(r):
        J[a, r+k+1+a] = J[r+k+1+a, a] = 1
    for a in range(k):
        J[r+a, r+a] = 1
    J[r+k, r+k] = -1
    unit = [s.eye(n)[:, a] for a in range(n)]
    return J, unit[:r], unit[r:r+k], unit[r+k], unit[r+k+1:]


def gram(J, A, B=None):
    if B is None:
        B = A
    if not A or not B:
        return s.zeros(len(A), len(B))
    return (s.Matrix.hstack(*A).conjugate().T*J*s.Matrix.hstack(*B)).applyfunc(s.expand)


def rank(A):
    return s.Matrix.hstack(*A).rank() if A else 0


def abs2(x):
    return s.expand(x*s.conjugate(x))


def lie_basis(J):
    n = J.rows
    ans = []
    for a in range(n):
        A = s.zeros(n)
        A[a, a] = s.I
        ans.append(J*A)
        for b in range(a+1, n):
            A = s.zeros(n)
            A[a, b], A[b, a] = 1, -1
            ans.append(J*A)
            A = s.zeros(n)
            A[a, b] = A[b, a] = s.I
            ans.append(J*A)
    return ans


def common_lie(J, r, k, first, second):
    """Flag coordinates are (coordinate index, nonzero scale).

    Impose Y e_a in X_(a-1), and Y X^perp in X. Hermitian skewness
    is built into the real Q-basis J*A with A skew-Hermitian.
    """
    n = J.rows
    B = lie_basis(J)
    forbidden = set()
    for flag in (first, second):
        earlier = set()
        indices = {a for a, _ in flag}
        duals = {r+k+1+a if a < r else a-(r+k+1) for a in indices}
        for col, _ in flag:
            forbidden.update((row, col) for row in range(n) if row not in earlier)
            earlier.add(col)
        for col in range(n):
            if col not in duals:
                forbidden.update((row, col) for row in range(n) if row not in indices)
    equations = []
    for a, b in sorted(forbidden):
        for part in (s.re, s.im):
            row = [part(Y[a, b]) for Y in B]
            if any(row):
                equations.append(row)
    null = s.Matrix(equations).nullspace() if equations else s.eye(len(B)).columnspace()
    return [sum((c*Y for c, Y in zip(v, B)), s.zeros(n)) for v in null]


def ell(Y, flag, z_index, z_scale):
    extended = flag+[(z_index, z_scale)]
    return s.expand(sum((extended[a+1][1]/extended[a][1])
                        *Y[extended[a][0], extended[a+1][0]]
                        for a in range(len(flag))))


def normal_forms():
    for r in range(4):
        for k in range(4):
            J, E, W, z, F = witt(r, k)
            check('ambient involution', J*J == s.eye(J.rows))
            for j in range(r+1):
                for c in (s.Integer(1), s.Integer(2), s.I, 2+s.I):
                    Ep = F[:j]+[c*e for e in E[j:]]
                    zp = c*z
                    T, Tp = s.Integer(1), abs2(c)
                    cases['normal forms'] += 1
                    check('isotropic primed flag', gram(J, Ep) == s.zeros(r))
                    check('negative vector', gram(J, [zp])[0, 0] == -Tp)
                    check('flag orthogonality', gram(J, Ep, [zp]) == s.zeros(r, 1))
                    check('intersection dimension', 2*r-rank(E+Ep) == r-j)
                    Ds = [s.Integer(1)] + [gram(J, (E+[z])[:a], (Ep+[zp])[:a]).det()
                                                for a in range(1, r+2)]
                    check('nonzero normal-form minor', Ds[j] != 0)
                    check('degenerate determinant', abs2(Ds[r+1])-T*Tp*abs2(Ds[r]) == 0)
                    V0 = E+[z]+Ep+[zp]
                    check('sum dimension', rank(V0) == r+j+1)
                    check('radical dimension', rank(V0)-gram(J, V0).rank() == r-j)
                    check('common positive complement', gram(J, W) == s.eye(k))
                    check('positive complement orthogonal', gram(J, W, V0) == s.zeros(k, len(V0)))
                    check('scalar norm identity', abs2(c)*T == Tp)
                    if r <= 2 and k <= 2 and c in (s.Integer(1), 2+s.I):
                        first = [(a, s.Integer(1)) for a in range(r)]
                        second = [(r+k+1+a, s.Integer(1)) if a < j else (a, c)
                                  for a in range(r)]
                        L = common_lie(J, r, k, first, second)
                        cases['common Lie algebras'] += 1
                        for Y in L:
                            check('skew-Hermitian Lie element', Y.conjugate().T*J+J*Y == s.zeros(J.rows))
                            check('common character relevance',
                                  s.simplify(2*s.re(ell(Y, first, r+k, 1)
                                                  -ell(Y, second, r+k, c))) == 0)


def missing_relevance_control():
    J, E, W, z, _ = witt(1, 1)
    x, w = E[0], W[0]
    zp = 2*z+w
    Y = x*(w.conjugate().T*J)-w*(x.conjugate().T*J)
    D1 = gram(J, E, E).det()
    D2 = gram(J, E+[z], E+[zp]).det()
    check('negative control valid flags', gram(J, E, [zp]) == s.zeros(1, 1))
    check('negative control T prime', gram(J, [zp])[0, 0] == -3)
    check('negative control G zero', abs2(D2)-3*abs2(D1) == 0)
    check('negative control skewness', Y.conjugate().T*J+J*Y == s.zeros(4))
    check('negative control lies in both radicals', Y*x == s.zeros(4, 1) and Y*z == s.zeros(4, 1) and Y*w == x)
    check('negative control characters differ', 2*s.re((Y*zp)[0]-(Y*z)[0]) == 2)
    check('negative control no proportional negative line', rank(E+[z, zp]) == 3)
    check('negative control positive complement lost', 4-rank(E+[z, zp]) == 1)
    cases['omitted-relevance counterexample'] += 1


def compact_shifts():
    for k in range(25):
        for a in range(k):
            rhoC = s.Rational((k-1-a)-a, 2)
            rhoN = 0
            rho = s.Rational(k-1, 2)-a
            check('compact rho shift', rhoN-rhoC == -rho)
    # A nonzero boolean-letter difference survives the common rho shift.
    for delta in (s.Rational(1, 3), s.Integer(1), s.Integer(7)):
        for common in (s.Rational(-5, 2), s.Integer(0), s.Integer(9)):
            a, b = common-s.Rational(1, 2), common-s.Rational(1, 2)-delta
            for rho in (s.Rational(-3, 2), s.Rational(1, 2), s.Integer(4)):
                check('different words remain different', a-rho != b-rho)


if __name__ == '__main__':
    normal_forms()
    missing_relevance_control()
    compact_shifts()
    draft = HERE/'degenerate_flag_orthogonality.tex'
    result = {
        'status': 'PASS',
        'arithmetic': 'exact Q(i) matrices and rational nullspaces, SymPy '+s.__version__,
        'scope': 'finite controls only; no general theorem certification or Lean replay',
        'draft_sha256': sha256(draft.read_bytes()).hexdigest(),
        'script_sha256': sha256(Path(__file__).read_bytes()).hexdigest(),
        'assertions': sum(counts.values()),
        'cases': dict(cases),
        'assertions_by_kind': dict(counts),
        'negative_control': 'Dropping relevance permits G=0 with no common U(k); the actual theorem retains relevance or averages the nontrivial character to zero.'
    }
    out = HERE/'degenerate_flag_orthogonality_checks.json'
    out.write_text(json.dumps(result, indent=2)+'\n')
    print(json.dumps(result, indent=2))
