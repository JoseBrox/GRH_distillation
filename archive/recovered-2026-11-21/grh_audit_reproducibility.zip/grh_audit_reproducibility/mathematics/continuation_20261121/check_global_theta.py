"""Small exact controls for the global ideal/Poisson reconstruction.

All general assertions are proved in global_theta_estimates.tex.  These
finite calculations check sensitive normalizations and excluded cases.
Run with python check_global_theta.py; no external service is used.
"""
from fractions import Fraction as F
from itertools import product
from pathlib import Path
import json

import sympy as sp


def quadratic_kernel(p, e, coefficient, sign):
    """B=(Z/p^e)[w], w^2+coefficient*w+constant=0.

    The constant does not enter conjugation.  The caller chooses an
    unramified polynomial: w^2+w+1 at2, w^2+1 at3, w^2+2 at5.
    """
    n = p**e
    return sum(
        (a - sign * (a - coefficient * b)) % n == 0
        and (b + sign * b) % n == 0
        for a, b in product(range(n), repeat=2)
    )


def split_kernel(p, e, sign):
    n = p**e
    return sum(
        (a - sign * b) % n == 0 and (b - sign * a) % n == 0
        for a, b in product(range(n), repeat=2)
    )


def main():
    report = {"method": "Exact integer, rational and symbolic arithmetic", "checks": []}
    for p, e in [(2, 1), (2, 2), (2, 3), (3, 1), (3, 2), (5, 1), (5, 2)]:
        for sign in [-1, 1]:
            n = p**e
            a = quadratic_kernel(p, e, 1 if p == 2 else 0, sign)
            b = split_kernel(p, e, sign)
            assert a == b == n
            report["checks"].append({"case": "unramified quadratic kernels", "p": p,
                                     "e": e, "sign": sign, "field": a, "split": b,
                                     "expected": n})

    # Q(i), g odd, D=(2i), with real basis of D^nu equal to 2^nu times Z[i].
    # The period coordinates have the extra factor g on the imaginary axis
    # for even s and the real axis for odd s.
    for g, nu, parity in product([3, 5], range(-2, 3), [0, 1]):
        d = F(2)**nu
        p1, p2 = ((g*d, g*g*d) if parity == 0 else (g*g*d, g*d))
        cov = p1*p2
        expected_cov = F(1, 2) * g**3 * F(2)**(2*nu+1)
        dual1, dual2 = F(g, 2)/p1, F(g, 2)/p2
        expected_dual = F(1, 2*g) * F(2)**(-(2*nu+1))
        assert cov == expected_cov
        assert dual1*dual2 == expected_dual
        # The conjugation changes an orientation only, not this absolute basis.
        assert F(2, g)*dual1 == 1/p1 and F(2, g)*dual2 == 1/p2
        for c in [F(2, 3), F(-3, 2)]:
            assert abs(F(2, g)/c)**2 * dual1*dual2 == 1/(c*c*cov)
        report["checks"].append({"case": "Gaussian trace/Fourier normalization",
                                 "g": g, "nu": nu, "parity": parity,
                                 "period_covolume": str(cov),
                                 "trace_dual_covolume": str(dual1*dual2)})

    # At the ramified prime2, conjugation modulo2 is the identity on Z[i]/2.
    ramified = quadratic_kernel(2, 1, 0, 1)
    assert ramified == 4 != 2
    report["checks"].append({"case": "excluded ramified Gaussian index",
                             "kernel_cardinality": ramified,
                             "unramified_formula_would_give": 2,
                             "index_of_period_in_2O": 1})

    a, L = sp.symbols("a L", positive=True)
    for f in range(1, 7):
        tail = sp.exp(-a*L) / a**f * sum((a*L)**j/sp.factorial(j) for j in range(f))
        target_derivative = -sp.exp(-a*L)*L**(f-1)/sp.factorial(f-1)
        assert sp.simplify(sp.diff(tail, L)-target_derivative) == 0
        assert sp.simplify(tail.subs(L, 0)-a**(-f)) == 0
        report["checks"].append({"case": "exact simplex-tail coefficients", "f": f})

    report["passed"] = True
    report["scope"] = ("Finite controls only; no numerical audit of the global orbital energies "
                       "or proof of GRH is claimed.")
    out = Path(__file__).with_name("global_theta_checks.json")
    out.write_text(json.dumps(report, indent=2)+"\n")
    print(f"Passed {len(report['checks'])} exact global theta controls.")


if __name__ == "__main__":
    main()
