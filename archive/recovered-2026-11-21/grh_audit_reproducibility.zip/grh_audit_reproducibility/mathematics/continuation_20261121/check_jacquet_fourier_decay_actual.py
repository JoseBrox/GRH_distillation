#!/usr/bin/env python3
"""Exact controls for the four-operator identity and partial cell geometry.

These are noncommuting differential-operator and rational matrix calculations.
They do not check analytic estimates or replay the Lean kernel.
"""
from pathlib import Path
from itertools import product
import hashlib
import json
import sympy as S

OUT = Path(__file__).resolve().parent
counts = {}


def check(name, value):
    if not value:
        raise AssertionError(name)
    counts[name] = counts.get(name, 0) + 1


def differential_checks(r):
    cs = S.symbols('c0:'+str(r))
    bs = S.symbols('b0:'+str(r))
    z, zb, s, sb = S.symbols('z zb s sb')
    vs = cs + bs + (z, zb)
    nv = len(vs)
    izero = (0,)*nv
    swap = dict(zip(cs,bs)) | dict(zip(bs,cs)) | {z:zb,zb:z,s:sb,sb:s,S.I:-S.I}
    partner = list(range(r,2*r))+list(range(r))+[2*r+1,2*r]

    class DO:
        def __init__(self, coefficients=None):
            self.co = {}
            for a, f in (coefficients or {}).items():
                f = S.cancel(f)
                if f != 0:
                    self.co[a] = f

        @staticmethod
        def of(a):
            return a if isinstance(a, DO) else DO({izero:S.sympify(a)})

        def __add__(self, other):
            other = DO.of(other)
            data = self.co.copy()
            for a,f in other.co.items():
                data[a] = data.get(a,0)+f
            return DO(data)

        __radd__ = __add__

        def __neg__(self):
            return DO({a:-f for a,f in self.co.items()})

        def __sub__(self, other):
            return self + (-DO.of(other))

        def __rsub__(self, other):
            return DO.of(other) + (-self)

        def __mul__(self, other):
            other = DO.of(other)
            data = {}
            for a,f in self.co.items():
                for b,g in other.co.items():
                    for j in product(*(range(v+1) for v in a)):
                        h = g
                        fac = 1
                        for i,n in enumerate(j):
                            if n:
                                h = S.diff(h,vs[i],n)
                                fac *= S.binomial(a[i],n)
                        key = tuple(a[i]-j[i]+b[i] for i in range(nv))
                        data[key] = data.get(key,0)+f*fac*h
            return DO(data)

        def __rmul__(self, other):
            return DO.of(other)*self

        def star(self):
            result = DO()
            for a,f in self.co.items():
                term = DO.of(1)
                for i,n in enumerate(a):
                    adj = -der[partner[i]]
                    if i < 2*r:
                        adj += 1/vs[partner[i]]
                    for _ in range(n):
                        term = term*adj
                result += term*DO.of(f.xreplace(swap))
            return result

        def twist(self):
            result = DO()
            for a,f in self.co.items():
                term = DO.of(f)
                for i,n in enumerate(a):
                    op = der[i] + (s if i==0 else -sb if i==r else 0)
                    for _ in range(n):
                        term = term*op
                result += term
            return result

        def zero(self):
            return not self.co

    der = []
    for i in range(nv):
        a = [0]*nv
        a[i] = 1
        der.append(DO({tuple(a):1}))
    zero = DO()

    def mat(A):
        return [[DO.of(x) for x in row] for row in A]

    def mm(A,B):
        return [[sum((A[i][k]*B[k][j] for k in range(len(B))),zero)
                 for j in range(len(B[0]))] for i in range(len(A))]

    def ms(A):
        return [[A[j][i].star() for j in range(len(A))]
                for i in range(len(A[0]))]

    def mc(name,A,B):
        for ar,br in zip(A,B):
            for a,b in zip(ar,br):
                check(name,(a-b).zero())

    def T(j,u,bar=False):
        if bar:
            return mat([[u-bs[j]*der[r+j],-bs[j]],[1/bs[j],0]])
        return mat([[u+cs[j]*der[j],-cs[j]],[1/cs[j],0]])

    def columns(u,bar=False):
        A = mat([[1],[0]])
        for j in range(r):
            A = mm(T(j,u,bar),A)
        return A[0][0],A[1][0]

    J = mat([[0,1],[-1,0]])
    u = S.Rational(3,2)
    for j in range(r):
        mc('one-site adjoint identity', mm(mm(ms(T(j,u+1,True)),J),T(j,u)),J)
        check('Euler formal adjoint',(DO.of(cs[j])*der[j]).star().co == (-bs[j]*der[r+j]).co)
    twisted = [[a.twist() for a in row] for row in ms(T(0,u+1,True))]
    mc('one-site wave identity',mm(mm(twisted,J),T(0,u)),mat([[s,1],[-1,0]]))
    A,B = columns(u)
    Av,Bv = columns(u+1,True)
    check('Toda telescoping',(Av.star().twist()*B-Bv.star().twist()*A-s).zero())
    wrongA,wrongB = columns(u,True)
    check('omitted spectral shift rejected',not (wrongA.star().twist()*B-wrongB.star().twist()*A-s).zero())

    G = z*zb-2
    ell = -der[2*r]-(u+S.Rational(1,2))*zb/G
    ellstar = ell.star()
    check('terminal Gauss adjoint',(ellstar-der[2*r+1]+(u+S.Rational(1,2))*z/G).zero())
    d = S.prod(cs)
    db = S.prod(bs)
    theta = [db*Av, (1/d)*(ell*A+B), (1/db)*(ellstar*Av+Bv), d*A]
    actual = theta[0].star().twist()*theta[1]-theta[2].star().twist()*theta[3]
    check('complete four-operator identity',(actual-s).zero())
    wrong = theta[0].star().twist()*theta[1]-(ellstar*Av+Bv).star().twist()*theta[3]
    check('omitted Gram cancellation rejected',not (wrong-s).zero())


def H(k,r):
    n=2*r+k+1
    h=S.zeros(n)
    for j in range(r):
        h[j,n-1-j]=h[n-1-j,j]=1
    for j in range(k):
        h[r+j,r+j]=1
    h[r+k,r+k]=-1
    return h


def nmat(h,v,t):
    d=h.rows
    out=S.eye(d+2)
    for j in range(d):
        out[0,j+1]=-(v.conjugate().T*h)[0,j]
        out[j+1,d+1]=v[j]
    out[0,d+1]=S.I*t-(v.conjugate().T*h*v)[0]/2
    return out


def wmat(d,t):
    out=S.eye(d+2)
    out[0,0]=out[d+1,d+1]=0
    out[0,d+1]=1/S.conjugate(t)
    out[d+1,0]=t
    return out


def small_group(k,r,seed):
    if r==0:
        out=S.eye(k+1)
        out[0,0]=out[k,k]=S.Rational(5,3)
        out[0,k]=out[k,0]=S.Rational(4,3)
        return out
    h=H(k,r-1)
    d=h.rows
    v=S.Matrix([S.Rational((seed+j)%5-2,3)+S.I*S.Rational((2*seed+j)%5-2,4) for j in range(d)])
    nr=nmat(h,v,S.Rational(seed,5))
    c=S.Rational(seed+1,2)+S.I*S.Rational(1,3)
    return nr*wmat(d,c)*S.diag(1,small_group(k,r-1,seed+1),1)


def minors(g,k,r):
    h=H(k,r)
    n=g.rows
    v=[]
    for j in range(r):
        x=S.zeros(n,1); x[j]=1; v.append(x)
    x=S.zeros(n,1); x[r+k]=1; v.append(x)
    Z=S.Matrix([[(v[a].conjugate().T*h*g*v[b])[0]
                  for b in range(r+1)] for a in range(r+1)])
    return [S.Integer(1)]+[S.cancel(Z[:j,:j].det()) for j in range(1,r+2)]


def zm(A):
    return all(S.cancel(x)==0 for x in A)


def geometric_checks(k,r,seed):
    h=H(k,r-1)
    d=h.rows
    t=S.Rational(seed+1,3)+S.I*S.Rational(seed+2,5)
    v=S.Matrix([S.Rational((j+seed)%5-2,4)+S.I*S.Rational((2*j+seed)%3-1,3) for j in range(d)])
    vp=S.Matrix([S.Rational((2*j+seed)%3-1,5)+S.I*S.Rational((j+seed)%5-2,6) for j in range(d)])
    tau=S.Rational(seed,7)
    taup=S.Rational(seed+1,8)
    nl,nr=nmat(h,v,tau),nmat(h,vp,taup)
    m=small_group(k,r-1,seed+1)
    g=nl*wmat(d,t)*S.diag(1,m,1)*nr
    check('matrix unitary',zm(g.conjugate().T*H(k,r)*g-H(k,r)))
    vv=g[1:d+1,0]/t
    row=-g[d+1,1:d+1]/t
    check('inverse cell left vector',zm(vv-v))
    check('inverse cell right covector',zm(row-vp.conjugate().T*h))
    check('inverse cell middle group',zm(g[1:d+1,1:d+1]+vv*t*row-m))
    check('inverse cell left centre',S.simplify(S.im(g[0,0]/t)-tau)==0)
    check('inverse cell right centre',S.simplify(S.im(g[d+1,d+1]/t)-taup)==0)
    ds=minors(g,k,r)
    ms=minors(m,k,r-1)
    for j in range(1,r+2):
        check('all shifted leading minors',S.cancel(ds[j]-t*ms[j-1])==0)
    gram=ds[-1]*S.conjugate(ds[-1])-ds[-2]*S.conjugate(ds[-2])
    gm=ms[-1]*S.conjugate(ms[-1])-ms[-2]*S.conjugate(ms[-2])
    check('exact Gram scaling',S.cancel(gram-t*S.conjugate(t)*gm)==0)
    check('normalization exponent', (2*r+k)*2-2 == 2*(2*r+k-1))


for rank in [1,2,3]:
    differential_checks(rank)
for kval in [1,2]:
    for rank in [1,2,3]:
        for seed in [1,2,4]:
            geometric_checks(kval,rank,seed)

report=dict(
    status='PASS',
    scope='Exact noncommuting differential identities and rational unitary cell controls; no analytic estimate or Lean kernel replay claimed',
    checks=counts,
    total=sum(counts.values()),
    fragment_sha256=hashlib.sha256((OUT/'jacquet_fourier_decay_actual.tex').read_bytes()).hexdigest(),
    script_sha256=hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
)
(OUT/'jacquet_fourier_decay_actual_checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report,indent=2))
