"""Exact controls of the quotient measure and the two dilation Jacobians."""
from pathlib import Path
from collections import Counter
import ast, hashlib, json, random
import sympy as S

OUT = Path(__file__).resolve().parent
rng = random.Random(2026112123)
counts = Counter()


def check(name, condition):
    assert bool(condition), name
    counts[name] += 1


def eq(name, left, right):
    if isinstance(left, S.MatrixBase):
        check(name, all(S.simplify(x) == 0 for x in left-right))
    else:
        check(name, S.simplify(left-right) == 0)


def cr():
    return S.Rational(rng.randint(-4, 4), 3)+S.I*S.Rational(rng.randint(-3, 3), 4)


def form(k, r):
    if r == 0:
        return S.diag(*([1]*k+[-1]))
    j = form(k, r-1)
    out = S.zeros(j.rows+2)
    out[0, -1] = out[-1, 0] = 1
    out[1:-1, 1:-1] = j
    return out


def heis(v, t, j):
    d = len(v)
    n = S.eye(d+2)
    n[0, 1:-1] = -v.conjugate().T*j
    n[1:-1, -1] = v
    n[0, -1] = S.I*t-(v.conjugate().T*j*v)[0]/2
    return n.applyfunc(S.expand_complex)


def unipotent(k, r):
    if r == 0:
        return S.eye(k+1)
    j = form(k, r-1)
    v = S.Matrix([cr() for _ in range(j.rows)])
    t = S.Rational(rng.randint(-2, 2), 3)
    return (heis(v, t, j)*S.diag(1, unipotent(k, r-1), 1)).applyfunc(S.expand_complex)


def dilation(k, r, t):
    return S.diag(*[t**a for a in range(r, 0, -1)],
                  *([1]*(k+1)),
                  *[t**(-a) for a in range(1, r+1)])


def bigcell(k, r, c, m):
    out = S.zeros(2*r+k+1)
    out[r:r+k+1, r:r+k+1] = m
    for a in range(r):
        out[-1-a, a] = c[a]
        out[a, -1-a] = 1/S.conjugate(c[a])
    return out.applyfunc(S.expand_complex)


def ell(k, r, z, n):
    return sum((n[a, a+1] for a in range(r-1)), S.Integer(0)) + (
        (n*z)[r-1] if r else 0)


def n_lie_basis(k, r):
    if r == 0:
        return []
    j = form(k, r-1)
    d = j.rows
    basis = []
    for b in range(d):
        for scalar in [1, S.I]:
            v = S.zeros(d, 1)
            v[b] = scalar
            x = S.zeros(d+2)
            x[0, 1:-1] = -v.conjugate().T*j
            x[1:-1, -1] = v
            basis.append(x)
    x = S.zeros(d+2)
    x[0, -1] = S.I
    basis.append(x)
    for y in n_lie_basis(k, r-1):
        x = S.zeros(d+2)
        x[1:-1, 1:-1] = y
        basis.append(x)
    return basis


# Coarea density in genuine coordinates on the negative unit hyperboloid.
for k in range(1, 5):
    for trial in range(3):
        u = S.Matrix([S.Rational(rng.randint(-4, 4), 3) for _ in range(2*k)])
        rho2 = 1+(u.T*u)[0]
        gram = S.zeros(2*k+1)
        gram[:2*k, :2*k] = S.eye(2*k)+(u*u.T)/rho2
        gram[-1, -1] = rho2
        grad2 = 4*((u.T*u)[0]+rho2)
        eq("hyperboloid_coarea_density_squared", gram.det()/grad2, S.Rational(1, 4))
        radius = S.symbols("radius", positive=True)
        rho = S.sqrt(1+radius**2)
        eq("terminal_polar_density",
           radius**(2*k-1),
           (rho**2-1)**(k-1)*rho*S.diff(rho, radius))

# Actual terminal sections, including k=1 and noncompact negative frames.
for k in range(1, 4):
    j = form(k, 0)
    for trial in range(4):
        w = S.Rational(5+trial, 3)+S.I*S.Rational(trial+1, 4)
        rad = S.sqrt(S.expand(w*S.conjugate(w))-1)
        b = S.eye(k+1)
        b[0, 0], b[0, -1], b[-1, 0], b[-1, -1] = S.conjugate(w), rad, rad, w
        eq("terminal_section_unitarity", b.conjugate().T*j*b, j)
        a = S.eye(k+1)
        a[0, 0] = a[-1, -1] = S.Rational(5, 3)
        a[0, -1] = a[-1, 0] = S.Rational(4, 3)
        ap = S.eye(k+1)
        ap[0, 0] = ap[-1, -1] = S.Rational(13, 5)
        ap[0, -1] = ap[-1, 0] = S.Rational(12, 5)
        e = S.eye(k+1)[:, -1]
        z, zp = 2*a*e, 3*ap*e
        mu = a*b*ap.inv()
        eq("terminal_section_general_negative_vectors", (z.conjugate().T*j*mu*zp)[0], -6*w)
        u = S.eye(k+1)
        u[0, 0] = S.Rational(3, 5)+S.I*S.Rational(4, 5)
        kz, kzp = a*u*a.inv(), ap*u*ap.inv()
        g = kz.inv()*mu*kzp
        eq("terminal_double_orbit_parameter", (z.conjugate().T*j*g*zp)[0], -6*w)

for k in range(1, 4):
    for r in range(4):
        j = form(k, r)
        t = S.Rational(3, 2)
        at = dilation(k, r, t)
        eq("dilation_group_membership", at.conjugate().T*j*at, j)
        kap = sum(2*(2*(r-a)+k)*(r-a) for a in range(r))
        jac = S.Integer(1)
        for x in n_lie_basis(k, r):
            eq("unipotent_lie_equations", x.conjugate().T*j+j*x, S.zeros(j.rows))
            tx = at*x*at.inv()
            pivot = next((i, l) for i in range(x.rows) for l in range(x.cols) if x[i, l] != 0)
            scalar = tx[pivot]/x[pivot]
            eq("dilation_real_lie_eigenvalue", tx, scalar*x)
            check("dilation_real_lie_eigenvalue_positive", scalar > 0)
            jac *= scalar
        eq("full_unipotent_real_dilation_jacobian", jac, t**kap)
        cweights = sum(2*(2*(r-a)+k-1)*(r-a) for a in range(r))
        planar = sum(2*(r-a) for a in range(r))
        eq("full_radial_dilation_jacobian", t**(cweights+planar), t**kap)
        n = unipotent(k, r)
        z = S.zeros(j.rows, 1)
        z[r+k] = 1
        eq("character_dilation", ell(k, r, z, at*n*at.inv()), t*ell(k, r, z, n))
        c = [S.Rational(a+2, 3)+S.I/4 for a in range(r)]
        t1, t2 = S.Rational(4, 3), S.Rational(5, 4)
        m = S.eye(k+1)
        g = bigcell(k, r, c, m)
        scaled = [v*(t1*t2)**(r-a) for a, v in enumerate(c)]
        eq("exact_big_cell_dilation", dilation(k, r, t1).inv()*g*dilation(k, r, t2),
           bigcell(k, r, scaled, m))

for k in range(1, 6):
    for r in range(1, 6):
        d, D = 2*r+k-1, 4*r+2*k-1
        threshold = 2*(k+r)*(r+1)
        lower = 2*(k+r-1)*r
        eq("sharp_decay_threshold_recurrence", threshold-lower, D+1)
        eq("large_complex_radial_power", 2*d+1-D, 0)
        eq("small_complex_radial_power", 2*d+1-1, 2*d)
        check("left_heisenberg_weight_integrable", 2*d+2 > 2*d+1)
        for excess in [S.Rational(1, 7), S.Rational(1, 2), S.Integer(1)]:
            A = threshold+excess
            check("right_heisenberg_integrable", A > D)
            check("large_complex_radial_integrable", A-D > 1)
            check("lower_rank_decay_strict", A-D-1 > lower)

result = {
    "manuscript_sha256": hashlib.sha256((OUT/"jacquet_integration_formula.tex").read_bytes()).hexdigest(),
    "total_exact_controls": sum(counts.values()),
    "categories": dict(sorted(counts.items())),
    "status": "All exact controls passed.",
    "scope": "Exact coarea densities, actual terminal unitary sections and compact double orbits, full real unipotent Lie algebra Jacobians, character and radial dilation, and strict decay thresholds. These controls supplement the general proofs and do not certify a Lean build."
}
(OUT/"jacquet_integration_formula_checks.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result, indent=2))
