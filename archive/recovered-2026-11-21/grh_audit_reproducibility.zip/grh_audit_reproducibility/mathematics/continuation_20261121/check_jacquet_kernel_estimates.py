"""Exact controls for the Jacquet coordinate estimates.

These finite checks detect coordinate, normalization, and boundary mistakes.
They do not replace the proofs in jacquet_kernel_estimates.tex.
"""
from pathlib import Path
from collections import Counter
from itertools import product
import hashlib
import json
import random
import sympy as S

OUT = Path(__file__).resolve().parent
rng = random.Random(2026112107)
counts = Counter()


def check(name, condition):
    assert bool(condition), name
    counts[name] += 1


def equal(name, left, right):
    check(name, S.simplify(left - right) == 0)


def complex_rational():
    return S.Rational(rng.randint(-4, 4), rng.randint(1, 4)) + S.I * S.Rational(
        rng.randint(-4, 4), rng.randint(1, 4)
    )


def norm2(z):
    return S.expand(z * S.conjugate(z))


def coordinates(a, b, z, t):
    p = len(a)
    ls = [1 + sum((norm2(v) for v in a[:l]), S.Integer(0)) for l in range(p + 1)]
    zn = sum((norm2(v) for v in z), S.Integer(0))
    bs = [
        -zn / 2 + S.I * t - sum(b[j] * S.conjugate(a[j]) for j in range(l, p))
        for l in range(p + 1)
    ]
    rs = [ls[-1] + zn + sum(norm2(v) for v in b[l:]) for l in range(p + 1)]
    ds = [S.expand(ls[l] * rs[l] + norm2(bs[l])) for l in range(p + 1)]
    return ls, bs, rs, ds


for p in range(4):
    for m in range(3):
        for sample in range(3):
            a = [complex_rational() for _ in range(p)]
            b = [complex_rational() for _ in range(p)]
            z = [complex_rational() for _ in range(m)]
            t = S.Rational(rng.randint(-5, 5), 3)
            ls, bs, rs, ds = coordinates(a, b, z, t)
            for value in ds:
                check("positive_squared_norm", value >= 1)
            if p == 0:
                equal("base_norm", ds[0], (1 + sum((norm2(v) for v in z), S.Integer(0)) / 2) ** 2 + t**2)
            else:
                l = ls[1]
                equal("completed_square", ds[0], l * norm2(b[0] - a[0] * bs[1] / l) + ds[1] / l)
                # Use a first coordinate with square-rational L, independently
                # of the random point: a0=3/4, sqrt(L)=5/4.
                a0 = S.Rational(3, 4)
                scale = S.Rational(5, 4)
                l = scale**2
                aa = [a0] + [scale * v for v in a[1:]]
                bb = [0] + [scale * v for v in b[1:]]
                zz = [scale * v for v in z]
                ll, bc, rr, dd = coordinates(aa, bb, zz, l * t)
                lower = coordinates(a[1:], b[1:], z, t)
                for j in range(p):
                    equal("scaling_L", ll[j + 1], l * lower[0][j])
                    equal("scaling_B", bc[j + 1], l * lower[1][j])
                    equal("scaling_R", rr[j + 1], l * lower[2][j])
                    equal("scaling_d_squared", dd[j + 1], l**2 * lower[3][j])
                # Exact rotation in the source: rho(u)=(1+iu)^2/(1+u^2).
                u = S.Rational(3, 2)
                rho = S.expand((1 + S.I * u) ** 2 / (1 + u**2))
                rot = coordinates([rho*v for v in a], [rho*v for v in b],
                                  [rho*v for v in z], t)
                for j in range(p + 1):
                    equal("rotation_invariance", rot[3][j], ds[j])
                aa, bb = a.copy(), b.copy()
                aa[0] *= u
                bb[0] /= u
                scaled = coordinates(aa, bb, z, t)
                for j in range(p + 1):
                    equal("reciprocal_scaling_B", scaled[1][j], bs[j])
                    check("reciprocal_scaling_norm_bound", scaled[3][j] >= ds[j] / 4)


def cone(v):
    return all(sum(v[:j+1]) > 0 for j in range(len(v))) and all(
        sum(v[:j+1]) + 2 * sum(v[j+1:]) > 0 for j in range(len(v) - 1)
    )


def recursive_cone(v):
    if len(v) == 1:
        return v[0] > 0
    return (
        v[0] > 0
        and v[0] + 2 * sum(v[1:]) > 0
        and recursive_cone((v[0] + v[1],) + v[2:])
    )


for p in range(4):
    for v in product(range(-2, 3), repeat=p + 1):
        check("convergence_cone_recursion", cone(v) == recursive_cone(v))
check("boundary_counterexample_first_integral", not cone((0, 1)))
check("boundary_counterexample_second_integral", not cone((2, -1)))

# Independent elementary integrals for the normalizing constants, including
# dimension zero and a negative alpha in the removed-coordinate integral.
t = S.Symbol("t", real=True)
r = S.Symbol("r", positive=True)
l = 1 + r**2
base01 = S.integrate((1 + t**2) ** -1, (t, -S.oo, S.oo))
base02 = S.integrate((1 + t**2) ** S.Rational(-3, 2), (t, -S.oo, S.oo))
equal("base_normalization", base01, S.pi)
equal("base_normalization", base02, 2)
base11 = S.integrate(4 * S.pi * r * (1 + r**2 / 2) ** -2, (r, 0, S.oo))
equal("base_normalization", base11, 4 * S.pi)
first_p1 = S.integrate(4 * S.pi**3 * r * l ** S.Rational(-3, 2), (r, 0, S.oo))
equal("first_recursive_normalization", first_p1, 4 * S.pi**3)
tail_negative = S.integrate(2 * S.pi**2 * r * l ** S.Rational(-5, 2), (r, 0, S.oo))
equal("negative_alpha_tail_normalization", tail_negative, 2 * S.pi**2 / 3)

# The exact gamma formula at two different complex dimensions.
def base_formula(m, v):
    return 2**m * S.pi**(S.Rational(1, 2) + m) * S.gamma(S.Rational(m + v, 2)) * S.gamma(v) / (
        S.gamma(S.Rational(m + 1 + v, 2)) * S.gamma(m + v)
    )

equal("gamma_normalization", base_formula(0, 1), base01)
equal("gamma_normalization", base_formula(0, 2), base02)
equal("gamma_normalization", base_formula(1, 1), base11)
equal("gamma_normalization", base_formula(2, 1), S.pi**3)

# Explicit vectors obeying the weighted theorem: include all ranks up to 8
# and nonconstant losses, not only equal coordinates.
for p in range(1, 9):
    gamma = S.Rational(1, 32)
    e = tuple(gamma * (j+1) / (20 * (p+1)**2) for j in range(p+1))
    alpha = gamma/2 - e[0]
    check("weighted_loss_condition", e[0] + 2*sum(e[1:]) < gamma/2)
    shifted = (alpha - e[1],) + tuple(-v for v in e[2:])
    check("weighted_tail_cone", cone(shifted))
    check("weighted_tail_radial_exponent", alpha - 2*sum(e[1:]) > 0)

manuscript = OUT / "jacquet_kernel_estimates.tex"
result = {
    "manuscript_sha256": hashlib.sha256(manuscript.read_bytes()).hexdigest(),
    "total_exact_controls": sum(counts.values()),
    "categories": dict(sorted(counts.items())),
    "status": "All exact controls passed.",
    "scope": "Finite exact controls of coordinate identities, normalizations, and exponent conditions; the general analytic results are proved in the manuscript.",
}
(OUT / "jacquet_kernel_estimates_checks.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
