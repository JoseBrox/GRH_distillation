"""Exact matrix and normalization controls for the full Jacquet majorant."""
from pathlib import Path
from collections import Counter
import ast,hashlib,json,random
import sympy as S

OUT=Path(__file__).resolve().parent
rng=random.Random(2026112117)
counts=Counter()
tree=ast.parse((OUT/"check_jacquet_kernel_estimates.py").read_text())
defs=[n for n in tree.body if isinstance(n,ast.FunctionDef)
      and n.name in {"complex_rational","norm2","cone"}]
exec(compile(ast.Module(body=defs,type_ignores=[]),"<exact definitions>","exec"))


def check(name,condition):
    assert bool(condition),name
    counts[name]+=1


def eq(name,a,b):
    if isinstance(a,S.MatrixBase):
        check(name,all(S.expand_complex(v)==0 for v in a-b))
    else:
        check(name,S.simplify(a-b)==0)


def heis(v,t,j):
    d=len(v)
    g=S.eye(d+2)
    g[0,1:d+1]=-v.conjugate().T*j
    g[1:d+1,d+1]=v
    g[0,d+1]=S.I*t-(v.conjugate().T*j*v)[0]/2
    return g


def weyl(c,d):
    w=S.zeros(d+2)
    w[0,d+1]=S.expand_complex(1/S.conjugate(c))
    w[d+1,0]=c
    w[1:d+1,1:d+1]=S.eye(d)
    return w


def frobenius2(g):
    return S.expand(sum((norm2(v) for v in g),S.Integer(0)))


def minor(g,h,columns):
    frame=S.eye(g.rows)[:,columns]
    mat=(frame.conjugate().T*h*g*frame).applyfunc(S.expand_complex)
    return S.expand_complex(mat.det(method="domain-ge"))


for p in range(1,4):
    for mpos in range(3):
        d=2*p+mpos
        j=S.zeros(d)
        j[:p,p:2*p]=S.eye(p)
        j[p:2*p,:p]=S.eye(p)
        j[2*p:,2*p:]=S.eye(mpos)
        h=S.zeros(d+2)
        h[0,-1]=h[-1,0]=1
        h[1:d+1,1:d+1]=j
        for trial in range(2):
            tmat=S.eye(p)
            for a in range(p):
                tmat[a,a]=a+2
                for b in range(a+1,p):
                    tmat[a,b]=S.Rational(a+b+1,3)
            amat=tmat.T*tmat
            lev=j*S.diag(amat,amat.inv(),S.eye(mpos))
            eq("Levi_group_membership",lev.conjugate().T*j*lev,j)
            c=complex_rational()
            if c==0:c=S.Rational(2,3)+S.I/5
            vl=S.Matrix([complex_rational() for _ in range(d)])
            vr=S.Matrix([complex_rational() for _ in range(d)])
            tl=S.Rational(trial-2,3)
            tr=S.Rational(trial+1,4)
            nl,nr=heis(vl,tl,j),heis(vr,tr,j)
            w=weyl(c,d)
            g=(nl*w*S.diag(1,lev,1)*nr).applyfunc(S.expand_complex)
            eq("full_open_cell_group_membership",g.conjugate().T*h*g,h)
            for l in range(p+1):
                cols=[0]+[1+p+q for q in range(l)]
                expect=c if l==0 else c*minor(lev,j,[p+q for q in range(l)])
                eq("singular_minor_factor",minor(g,h,cols),expect)
            b=S.I*tr-(vr.conjugate().T*j*vr)[0]/2
            expect=(
                1/norm2(c)+frobenius2(lev)
                +(vr.conjugate().T*lev.conjugate().T*lev*vr)[0]
                +norm2(c)*(1+(vr.conjugate().T*vr)[0]+norm2(b))
            )
            eq("exact_Frobenius_formula",frobenius2((w*S.diag(1,lev,1)*nr).applyfunc(S.expand_complex)),expect)
            eq("first_open_cell_column",g[:,0],c*nl[:,-1])
            # Recover all the coordinates from the full product.
            eq("recover_left_vector",g[1:d+1,0]/c,vl)
            eq("recover_right_covector",-g[-1,1:d+1]/c,vr.conjugate().T*j)
            eq("recover_middle_block",g[1:d+1,1:d+1]+vl*c*(vr.conjugate().T*j),lev)

print("Exact full group matrix controls passed.",flush=True)

def hermitian_basis(n):
    result=[]
    for i in range(n):
        a=S.zeros(n);a[i,i]=1;result.append(a)
    for i in range(n):
        for j in range(i+1,n):
            a=S.zeros(n);a[i,j]=a[j,i]=1;result.append(a)
            a=S.zeros(n);a[i,j]=S.I;a[j,i]=-S.I;result.append(a)
    return result


def real_lie_coords(x,h):
    a=-S.I*h*x
    n=a.rows
    vals=[S.expand(S.re(a[i,i])) for i in range(n)]
    for i in range(n):
        for j in range(i+1,n):
            vals.extend([S.expand(S.re(a[i,j])),S.expand(S.im(a[i,j]))])
    return S.Matrix(vals)


def cell_jacobian(c,j):
    d=j.rows;n=d+2
    h=S.zeros(n);h[0,-1]=h[-1,0]=1;h[1:d+1,1:d+1]=j
    w=weyl(c,d);winv=w.inv()
    upper=[]
    for i in range(d):
        for factor in [S.Integer(1),S.I]:
            v=S.zeros(d,1);v[i]=factor
            x=S.zeros(n);x[0,1:d+1]=-v.conjugate().T*j;x[1:d+1,d+1]=v
            upper.append(x)
    x=S.zeros(n);x[0,-1]=S.I;upper.append(x)
    cols=[real_lie_coords(winv*x*w,h) for x in upper]
    for dc in [S.Integer(1),S.I]:
        dw=S.zeros(n)
        dw[-1,0]=dc
        dw[0,-1]=-S.conjugate(dc)/S.conjugate(c)**2
        cols.append(real_lie_coords(winv*dw,h))
    for a in hermitian_basis(d):
        x=S.zeros(n);x[1:d+1,1:d+1]=S.I*j*a
        cols.append(real_lie_coords(x,h))
    cols.extend(real_lie_coords(x,h) for x in upper)
    jac=S.Matrix.hstack(*cols)
    check("Haar_Jacobian_square_dimension",jac.shape==(n*n,n*n))
    return S.simplify(jac.det(method="domain-ge"))


for d in [2,3]:
    j=S.diag(*([1]*(d-1)+[-1]))
    base=cell_jacobian(S.Integer(1),j)
    check("Haar_reference_Jacobian_nonzero",base!=0)
    for c in [S.Rational(1,2),S.Integer(2),S.Rational(3,5)+4*S.I/5,
              S.Rational(2,3)+S.I/4]:
        det=cell_jacobian(c,j)
        eq("full_real_Haar_Jacobian",S.Abs(det/base),norm2(c)**d)

print("Exact full real Haar Jacobian controls passed.",flush=True)
# Independent planar angular integrals in two cases where they are elementary.
theta=S.Symbol("theta",real=True)
rad=S.Symbol("rad",positive=True)
angular_k2_s1=S.integrate(2*S.cos(theta),(theta,-S.pi/2,S.pi/2))/S.pi
eq("sphere_angular_normalization",angular_k2_s1,
   S.gamma(2)*S.gamma(1)/S.gamma(S.Rational(3,2))**2)
angular_k3_s2=2/S.pi*S.integrate(2*S.cos(theta)**2,(theta,S.pi/2,3*S.pi/2))
eq("sphere_angular_normalization",angular_k3_s2,
   S.gamma(3)*S.gamma(1)/S.gamma(2)**2)

for r in range(1,7):
    for k in range(1,5):
        d=2*r+k-1;dim=2*d+1
        bound=lambda rank:2*(k+rank)*(rank+1)+1
        eq("decay_threshold_step",bound(r)-bound(r-1),dim+1)
        loss=[S.Rational(j+1,20*(r+1)) for j in range(r+1)]
        sigma=2*r+k-sum(loss)
        check("radial_complex_integrability",1<sigma<2*d+1)
        nu=(loss[0]+2*sum(loss[1:]),)+tuple(-a for a in loss[1:])
        check("remaining_exact_CH_cone",cone(nu))

result=dict(
    manuscript_sha256=hashlib.sha256((OUT/"jacquet_majorant.tex").read_bytes()).hexdigest(),
    total_exact_controls=sum(counts.values()),categories=dict(sorted(counts.items())),
    status="All exact controls passed.",
    scope="Exact full matrix norms and minors, open cell coordinate inversion, full real Lie algebra Jacobians, independent angular normalizations, and exponent conditions. These finite controls do not replace the general proofs.")
(OUT/"jacquet_majorant_checks.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
