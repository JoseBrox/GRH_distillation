"""Independent exact controls for phase signs, covariance, and formal adjoints."""
from pathlib import Path
from collections import Counter
import ast, hashlib, json, random
import sympy as S

OUT = Path(__file__).resolve().parent
rng = random.Random(2026112129)
counts = Counter()


def check(name, condition):
    assert bool(condition), name
    counts[name] += 1


def eq(name, left, right):
    if isinstance(left, S.MatrixBase):
        check(name, all(S.expand_complex(x) == 0 for x in (left-right).applyfunc(S.expand)))
    else:
        check(name, S.simplify(left-right) == 0)


# Read definitions only, without executing another check suite.
tree = ast.parse((OUT/"check_jacquet_integration_formula.py").read_text())
names = {"cr", "form", "heis", "unipotent", "dilation", "bigcell", "ell"}
exec(compile(ast.Module(body=[node for node in tree.body if isinstance(node, ast.FunctionDef)
                             and node.name in names], type_ignores=[]),
             "<exact matrix definitions>", "exec"))


def reduce_matrix(m):
    return m.applyfunc(S.expand_complex)


def compact(k, r, u):
    out = S.eye(2*r+k+1)
    out[r:r+k, r:r+k] = u
    return out


def product(p, q):
    n1, k1, n2, k2 = p
    m1, l1, m2, l2 = q
    return (reduce_matrix(n1*k1*m1*k1.inv()), reduce_matrix(k1*l1),
            reduce_matrix(n2*k2*m2*k2.inv()), reduce_matrix(k2*l2))


def sgs(p, g):
    n1, k1, n2, k2 = p
    return reduce_matrix(k1.inv()*n1.inv()*g*n2*k2)


def eval_F(k, r, g):
    block = g[r:r+k, r:r+k]
    return reduce_matrix(block+g[0, -1]*S.eye(k))


def rho(p, f, g, k, r):
    n1, k1, n2, k2 = p
    return reduce_matrix(k1[r:r+k, r:r+k]*f(sgs(p, g))*k2[r:r+k, r:r+k].inv())


for r in [1, 2]:
    k = 2
    u = S.Matrix([[S.Rational(3, 5), S.Rational(4, 5)],
                  [-S.Rational(4, 5), S.Rational(3, 5)]])
    v = S.diag(S.I, 1)
    ku, kv = compact(k, r, u), compact(k, r, v)
    check("compact_factors_noncommute", ku*kv != kv*ku)
    for trial in range(2):
        p = (unipotent(k, r), ku, unipotent(k, r), kv)
        q = (unipotent(k, r), kv, unipotent(k, r), ku)
        pq = product(p, q)
        g = bigcell(k, r, [S.Rational(a+2, 3)+S.I/4 for a in range(r)], S.eye(k+1))
        f = lambda g: eval_F(k, r, g)
        eq("actual_two_sided_representation",
           rho(p, lambda h: rho(q, f, h, k, r), g, k, r),
           rho(pq, f, g, k, r))
        eq("actual_two_sided_action_order", sgs(q, sgs(p, g)), sgs(pq, g))
        z = S.zeros(g.rows, 1)
        z[r+k] = 1
        for side in [0, 2]:
            eq("semidirect_character_additivity",
               ell(k, r, z, pq[side]), ell(k, r, z, p[side])+ell(k, r, z, q[side]))
        t1, t2 = S.Rational(3, 2), S.Rational(4, 3)
        a1, a2 = dilation(k, r, t1), dilation(k, r, t2)
        dp = (reduce_matrix(a1*p[0]*a1.inv()), p[1],
              reduce_matrix(a2*p[2]*a2.inv()), p[3])
        h = g
        eq("phase_translation_identity",
           sgs(dp, a1*h*a2.inv()), a1*sgs(p, h)*a2.inv())
        dtf = lambda g: f(a1.inv()*g*a2)
        eq("orbital_dilation_integrand",
           rho(dp, dtf, g, k, r), rho(p, f, a1.inv()*g*a2, k, r))

print("Full matrix covariance controls passed.", flush=True)

# Fourier integration by parts on nonseparable polynomial Gaussians.
# The common Gaussian Fourier factor is removed; all remaining values are exact.
x, y, z = S.symbols("x y z", real=True)
xi, eta = S.symbols("xi eta", real=True)


def transform_moments(max_n, variable):
    polys = [S.Integer(1)]
    for _ in range(max_n):
        polys.append(S.expand(-S.I*(S.diff(polys[-1], variable)-variable*polys[-1]/2)))
    return polys


mx, my = transform_moments(9, xi), transform_moments(9, eta)


def fourier_poly(poly, a, b):
    out = 0
    for (i, j), coef in S.Poly(S.expand(poly), x, y).terms():
        out += coef*mx[i].subs(xi, a)*my[j].subs(eta, b)
    return S.expand(out)


def one_minus_dd(poly, variable):
    return S.expand((3-4*variable**2)*poly+4*variable*S.diff(poly, variable)
                    -S.diff(poly, variable, 2))


for trial in range(18):
    poly = sum((rng.randint(-3, 3)+S.I*rng.randint(-2, 2))*x**i*y**j
               for i, j in [(0, 0), (1, 0), (0, 1), (2, 1), (1, 3), (3, 2)])
    a, b = S.Rational(trial-5, 3), -S.Rational(trial+1, 4)
    transformed = one_minus_dd(one_minus_dd(poly, y), x)
    eq("two_character_regularization_denominators",
       fourier_poly(transformed, a, b),
       (1+a*a)*(1+b*b)*fourier_poly(poly, a, b))
    eq("mixed_fourth_derivative_order",
       one_minus_dd(one_minus_dd(poly, x), y), transformed)

# Noncommuting, divergence-free invariant fields on the real Heisenberg group:
# R_X = d/dx, R_Y = d/dy + x d/dz, R_Z = d/dz.
# Every function below is a polynomial times exp(-x^2-y^2-z^2).
def gaussian_derivative(poly, letter):
    if letter == "X":
        return S.expand(S.diff(poly, x)-2*x*poly)
    if letter == "Y":
        return S.expand(S.diff(poly, y)+x*S.diff(poly, z)-2*(y+x*z)*poly)
    return S.expand(S.diff(poly, z)-2*z*poly)


def word_apply(poly, word):
    for letter in reversed(word):
        poly = gaussian_derivative(poly, letter)
    return S.expand(poly)


def gaussian_integral(poly):
    out = S.Integer(0)
    for powers, coef in S.Poly(S.expand(poly), x, y, z).terms():
        if any(p % 2 for p in powers):
            continue
        moment = S.Integer(1)
        for p in powers:
            m = p//2
            moment *= S.factorial2(2*m-1)/4**m if m else 1
        out += coef*moment
    return S.expand(out)


monomials = [1, x, y, z, x*y, y*z, x*z, x*x]
wrong_order = 0
missing_coefficient_derivatives = 0
for trial in range(36):
    P = sum((rng.randint(-2, 2)+S.I*rng.randint(-1, 1))*v for v in monomials[:6])
    Q = sum((rng.randint(-2, 2)+S.I*rng.randint(-1, 1))*v for v in monomials[:6])
    A = sum((rng.randint(-2, 2)+S.I*rng.randint(-1, 1))*v for v in monomials[1:])
    word = tuple(rng.choice("XYZ") for _ in range(1+trial % 4))
    left = gaussian_integral(A*word_apply(P, word)*S.conjugate(Q))
    adj = (-1)**len(word)*word_apply(S.expand(S.conjugate(A)*Q), tuple(reversed(word)))
    right = gaussian_integral(P*S.conjugate(adj))
    eq("noncommutative_variable_coefficient_Haar_adjoint", left, right)
    no_reverse = (-1)**len(word)*word_apply(S.expand(S.conjugate(A)*Q), word)
    if gaussian_integral(P*S.conjugate(no_reverse)) != left:
        wrong_order += 1
    no_product_rule = (-1)**len(word)*S.conjugate(A)*word_apply(Q, tuple(reversed(word)))
    if gaussian_integral(P*S.conjugate(no_product_rule)) != left:
        missing_coefficient_derivatives += 1
check("omitting_word_reversal_has_counterexample", wrong_order > 0)
check("omitting_coefficient_derivatives_has_counterexample", missing_coefficient_derivatives > 0)

result = {
    "manuscript_sha256": hashlib.sha256((OUT/"jacquet_pairing_adjointness.tex").read_bytes()).hexdigest(),
    "total_exact_controls": sum(counts.values()),
    "categories": dict(sorted(counts.items())),
    "status": "All exact controls passed.",
    "negative_controls": {
        "wrong_word_order_cases": wrong_order,
        "missing_coefficient_derivative_cases": missing_coefficient_derivatives,
        "scope": "Counterexamples concern deliberately altered adjoint formulas, not the submitted statements."
    },
    "scope": "Full rational unitary and unipotent matrices with noncommuting compact representations, exact two-variable Fourier identities, and exact Haar integration of noncommuting Heisenberg differential words with variable coefficients. The general analytic results are proved in the manuscript; no Lean kernel replay is claimed."
}
(OUT/"jacquet_pairing_adjointness_checks.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result, indent=2))
