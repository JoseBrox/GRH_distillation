"""Exact full matrix controls for the unipotent Jacquet estimate."""
from pathlib import Path
from collections import Counter
import ast
import hashlib
import json
import random
import sympy as S

OUT = Path(__file__).resolve().parent
rng = random.Random(2026112113)
counts = Counter()

# Reuse only the rational coordinate definitions, not the earlier test loop.
tree = ast.parse((OUT / "check_jacquet_kernel_estimates.py").read_text())
chosen = [node for node in tree.body if isinstance(node, ast.FunctionDef)
          and node.name in {"complex_rational", "norm2", "coordinates"}]
exec(compile(ast.Module(body=chosen, type_ignores=[]), "<coordinate definitions>", "exec"))


def check(name, condition):
    assert bool(condition), name
    counts[name] += 1


def eq(name, a, b):
    if isinstance(a, S.MatrixBase):
        check(name, all(S.simplify(v) == 0 for v in a-b))
    else:
        check(name, S.simplify(a-b) == 0)


def matrix_heis(v, t, j):
    n = len(v)
    out = S.eye(n+2)
    out[0, 1:n+1] = -v.conjugate().T * j
    out[1:n+1, n+1] = v
    out[0, n+1] = S.I*t - (v.conjugate().T*j*v)[0]/2
    return out


def gram_minor(g, columns):
    y = g[:, columns]
    return S.simplify((y.conjugate().T*y).det())


for p in range(1, 4):
    for m in range(3):
        dim = 2*p+m
        j = S.zeros(dim)
        j[:p, p:2*p] = S.eye(p)
        j[p:2*p, :p] = S.eye(p)
        j[2*p:, 2*p:] = S.eye(m)
        h = S.zeros(dim+2)
        h[0, -1] = h[-1, 0] = 1
        h[1:dim+1, 1:dim+1] = j
        for trial in range(3):
            a = [complex_rational() for _ in range(p)]
            b = [complex_rational() for _ in range(p)]
            z = [complex_rational() for _ in range(m)]
            t = S.Rational(rng.randint(-4, 4), 3)
            v = S.Matrix(b+a+z)
            n = matrix_heis(v, t, j)
            eq("hermitian_preservation", n.conjugate().T*h*n, h)
            shifted_t = t + S.im(sum(b[q]*S.conjugate(a[q]) for q in range(p)))
            ds = coordinates(a,b,z,shifted_t)[3]
            for l in range(p+1):
                eq("full_matrix_Gram_formula", gram_minor(n, [dim+1]+list(range(1,l+1))), ds[l])
            vp = S.Matrix([complex_rational() for _ in range(dim)])
            tp = S.Rational(trial-1, 2)
            tnew = t+tp-S.im((v.conjugate().T*j*vp)[0])
            eq("Heisenberg_group_law", n*matrix_heis(vp,tp,j), matrix_heis(v+vp,tnew,j))

            # Nontrivial compact rotation, with an isotropic-pair interchange.
            q = S.eye(p)
            if p > 1:
                q[:2,:2] = S.Matrix([[S.Rational(3,5),-S.Rational(4,5)],
                                     [S.Rational(4,5),S.Rational(3,5)]])
            else:
                q[0,0] = S.I
            compact = S.diag(q,q,S.eye(m))
            swap = S.eye(dim)
            swap.row_swap(0,p)
            compact = swap*compact
            u = S.zeros(p)
            for i in range(p):
                for qj in range(i,p):
                    u[i,qj] = i+2 if i == qj else S.Rational(i+qj+1,3)
            lev = compact*S.diag(u,(u.conjugate().T).inv(),S.eye(m))
            eq("Levi_Hermitian_preservation", lev.conjugate().T*j*lev, j)
            eq("compact_unitarity", compact.conjugate().T*compact, S.eye(dim))
            full_lev = S.diag(1,lev,1)
            vrot = compact.conjugate().T*v
            nrot = matrix_heis(vrot,t,j)
            for l in range(p+1):
                scale2 = S.prod(u[qj,qj]**2 for qj in range(l))
                cols = [dim+1]+list(range(1,l+1))
                eq("full_matrix_Levi_Gram_factor", gram_minor(n*full_lev,cols),
                   scale2*gram_minor(nrot,cols))
            phi0 = S.eye(dim)[:,0]
            paired = S.eye(dim)[:,p]
            w = compact.conjugate().T*lev*paired
            eta0 = (w.conjugate().T*j*phi0)[0]
            eq("nonvanishing_character_coefficient", u[0,0]*eta0, 1)
            eq("character_rotation", ((lev*paired).conjugate().T*j*v)[0],
               (w.conjugate().T*j*vrot)[0])


def epsilon(r,delta):
    if r == 0:
        return S.Rational(1,10)
    old = epsilon(r-1,delta/4)
    gamma = min(delta/8,old/2)
    return min(old/2,gamma/(4*r+4))


for r in range(1,8):
    for delta in [S.Rational(1,2),S.Rational(1,8),S.Rational(1,40)]:
        old=epsilon(r-1,delta/4)
        gamma=min(delta/8,old/2)
        eps=epsilon(r,delta)
        check("rank_induction_OS_condition", (2*r+1)*eps < gamma/2)
        check("rank_induction_lower_window", eps+gamma <= old)
        check("rank_induction_positive_window", eps > 0)

result = {
    "manuscript_sha256": hashlib.sha256((OUT/"jacquet_unipotent_decay.tex").read_bytes()).hexdigest(),
    "total_exact_controls": sum(counts.values()),
    "categories": dict(sorted(counts.items())),
    "status": "All exact controls passed.",
    "scope": "Independent full rational matrix calculations of Hermitian preservation, group law, Gram determinants, Levi factors, character coefficient, and exact exponent windows. General statements are proved in the manuscript.",
}
(OUT/"jacquet_unipotent_decay_checks.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
