"""Exact independent special-value controls for imaginary quadratic fields.

Compute Bernoulli polynomial values and the actual odd higher-root-of-unity
order in quadratic fields. Check the odd-integrality forced by the
special-value theorem, including primes dividing the field degree (which
are excluded here because the only such prime is 2). This does not compute
Selmer groups or prove the imported special-value theorem.
"""
from pathlib import Path
from fractions import Fraction
from math import gcd, factorial, isqrt
import hashlib
import json
from sympy import bernoulli, Rational, kronecker_symbol, primerange

HERE = Path(__file__).resolve().parent

def quadratic_odd_roots(d, m):
    value = 1
    for p in primerange(3, 2*m+2):
        index = 2 if d == -p and p % 4 == 3 else 1
        power, order = 1, (p-1)//index
        while m % order == 0:
            power *= p
            order *= p
        value *= power
    return value

def is_fundamental_negative(d):
    if d % 4 == 1:
        a = -d
    elif d % 4 == 0 and (d//4) % 4 in (2, 3):
        a = -(d//4)
    else:
        return False
    return all(a % (p*p) for p in primerange(2, isqrt(a)+1))

records = []
for d in range(-80, -2):
    if not is_fundamental_negative(d):
        continue
    N = abs(d)
    for m in range(2, 13):
        value = Rational(0)
        for a in range(1, N+1):
            chi = (1 if gcd(a, N) == 1 else 0) if m % 2 == 0 else kronecker_symbol(d, a)
            value += chi * bernoulli(m, Rational(a, N))
        value *= -Rational(N**(m-1), m)
        R = Fraction(int(value.p), int(value.q))
        assert R != 0
        D = m*factorial(m+1)*N
        assert (D*R).denominator == 1
        w = quadratic_odd_roots(d, m)
        denominator = (w*R).denominator
        assert denominator & (denominator-1) == 0, (d, m, R, w)
        records.append({"discriminant":d, "m":m, "R":str(R),
                        "odd_higher_roots_order":w})

result = {
    "scope":"Exact quadratic special values and higher-root orders; no Selmer group computation.",
    "cases":len(records),
    "status":"All denominator and parity controls passed.",
    "manuscript_sha256":hashlib.sha256((HERE/"minus_selmer_classical.tex").read_bytes()).hexdigest(),
    "records":records,
}
(HERE/"minus_selmer_special_value_checks.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps({k:v for k,v in result.items() if k != "records"},indent=2))
