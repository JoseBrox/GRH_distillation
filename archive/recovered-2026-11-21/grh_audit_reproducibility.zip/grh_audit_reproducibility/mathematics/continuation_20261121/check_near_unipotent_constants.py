"""Exact finite controls for the conventional near-unipotent proof.

These checks verify algebraic identities on stated finite ranges, not
universal mathematical statements, classical imports, or Lean replay.
"""
from collections import Counter
from fractions import Fraction
from pathlib import Path
import hashlib
import json
import math
import sympy as sp

BASE = Path(__file__).resolve().parent
counts = Counter()


def check(condition, family):
    assert condition, family
    counts[family] += 1


def compositions(n):
    if n == 0:
        yield ()
    else:
        for first in range(1, n + 1):
            for tail in compositions(n - first):
                yield (first,) + tail


for J in range(1, 9):
    check(sum(1 for _ in compositions(J)) == 2 ** (J - 1),
          "composition_cardinality")
    for js in compositions(J):
        for m in range(1, 6):
            n = 2 * J + m
            d = (4 * sum(a * b for i, a in enumerate(js) for b in js[i + 1:])
                 + 2 * J * m + sum(j * j for j in js))
            check(d == 2 * n * J - 2 * J * J - sum(j * j for j in js),
                  "radical_dimension")
            check(d <= 2 * n * J, "dimension_upper_bound")
            prefix = 0
            radical_sum = 0
            radial = [0] * len(js)
            L_intervals = []
            sphere = Counter()
            p, q = n - J, J
            for i, j in enumerate(js):
                ni = n - 2 * prefix
                radical_sum += 2 * j * ni - 3 * j * j
                L_intervals.extend(range(ni - 2 * j + 1, ni + 1))
                pi, qi = p - prefix, q - prefix
                sphere[pi] += 1
                sphere[qi] += 1
                sphere[pi - j] -= 1
                sphere[qi - j] -= 1
                sphere[j] -= 1
                radial[i] += 2 * j * m + 2 * j * j
                for k in range(i + 1, len(js)):
                    radial[i] += 4 * j * js[k]
                check(radial[i] == 2 * j * (ni - j), "radial_exponents")
                prefix += j
            check(radical_sum == d, "discriminant_telescope")
            check(sorted(L_intervals) == list(range(m + 1, n + 1)),
                  "L_factor_telescope")
            target = Counter({p: 1})
            target[q] += 1
            target[p - J] -= 1
            target[q - J] -= 1
            for j in js:
                target[j] -= 1
            check({k: v for k, v in sphere.items() if v}
                  == {k: v for k, v in target.items() if v},
                  "compact_volume_telescope")
            check(Fraction(d, 2) - n * J + J * J - Fraction(J, 2)
                  == -sum(Fraction(j * (j + 1), 2) for j in js),
                  "powers_of_two")


def block_control(js, core):
    sizes = list(js) + [core] + list(reversed(js))
    n = sum(sizes)
    offsets = [0]
    for size in sizes:
        offsets.append(offsets[-1] + size)
    owner = [b for b, size in enumerate(sizes) for _ in range(size)]
    H = sp.zeros(n)
    for b, size in enumerate(sizes):
        bb = len(sizes) - 1 - b
        for i in range(size):
            H[offsets[b] + i, offsets[bb] + i] = (
                (-1) ** i if b == len(js) else 1)

    def adj(X):
        return H * X.conjugate().T * H

    generators = []
    for r in range(n):
        for s in range(n):
            if owner[r] >= owner[s]:
                continue
            for scalar in (sp.Integer(1), sp.I):
                E = sp.zeros(n)
                E[r, s] = scalar
                X = (E - adj(E)) / 2
                if X != sp.zeros(n):
                    generators.append(X)
    columns = []
    for X in generators:
        columns.append(sp.Matrix([sp.re(z) for z in X]
                                 + [sp.im(z) for z in X]))
    rank = sp.Matrix.hstack(*columns).rank()
    J = sum(js)
    d = 2 * n * J - 2 * J * J - sum(j * j for j in js)
    check(rank == d, "real_unitary_radical_dimension")
    # The deterministic choice has several nonzero lower and higher blocks.
    X = sum(((i % 5 - 2) * Y for i, Y in enumerate(generators)),
            sp.zeros(n))
    check(adj(X) == -X, "Lie_adjoint")
    check(X ** n == sp.zeros(n), "nilpotence")
    g = sp.eye(n)
    power = sp.eye(n)
    for k in range(1, n):
        power = power * X
        g += power / math.factorial(k)
    check((adj(g) * g - sp.eye(n)).applyfunc(sp.expand) == sp.zeros(n), "exact_exponential_unitarity")
    Z = g - sp.eye(n)
    for h in range(1, len(sizes)):
        lower = sp.zeros(n)
        for r in range(n):
            for s in range(n):
                if 0 < owner[s] - owner[r] < h:
                    lower[r, s] = Z[r, s]
        full_product = adj(Z) * Z
        lower_product = adj(lower) * lower
        check(all(sp.expand(full_product[r, s] - lower_product[r, s]) == 0
                  for r in range(n) for s in range(n)
                  if owner[s] - owner[r] == h),
              "quadratic_relation_depends_only_on_lower_heights")


for js, core in [((1,), 1), ((2,), 1), ((1, 1), 1),
                 ((1, 2), 2), ((2, 1), 1), ((1, 1, 1), 1)]:
    block_control(js, core)

# Exact numerical margins used in the analytic inequalities.
check(Fraction(1, 32) + Fraction(1, 240) + Fraction(1, 5)
      < Fraction(1, 4), "factorial_margin")
check(Fraction(24, 1000) < 1, "packing_log_margin")
check(Fraction(1, 16) + Fraction(1, 40) < Fraction(1, 8),
      "logarithm_absorption_margin")
check(Fraction(1, 2) - Fraction(1, 8) == Fraction(3, 8),
      "one_type_exponent")
check(Fraction(3, 8) - Fraction(1, 4) == Fraction(1, 8),
      "geometric_sum_margin")

data = {
    "fragment": "near_unipotent_integral.tex",
    "fragment_sha256": hashlib.sha256(
        (BASE / "near_unipotent_integral.tex").read_bytes()).hexdigest(),
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
    "all_passed": True,
    "assertions": sum(counts.values()),
    "families": dict(counts),
    "scope": (
        "All compositions of J=1,...,8 and final core dimensions 1,...,5 "
        "for exact constant telescoping and radial exponents; six exact "
        "unitary-radical matrix cases for dimensions and block-height "
        "relations; rational numerical margins. No complete theorem "
        "verification, classical-source proof, or Lean kernel replay."
    ),
}
(BASE / "near_unipotent_constants_checks.json").write_text(
    json.dumps(data, indent=2) + "\n")
print(json.dumps({"all_passed": True, "assertions": data["assertions"],
                  "fragment_sha256": data["fragment_sha256"]}), flush=True)
