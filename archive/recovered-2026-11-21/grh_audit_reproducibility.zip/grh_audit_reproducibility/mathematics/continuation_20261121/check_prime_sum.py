"""Exact rational certificate for the prime sum used in divisor.tex.

No floating-point arithmetic is used for a decisive comparison.
For 0 <= z <= 1/3, log((1+z)/(1-z)) is bounded above by
  2 sum_{j=0}^{15} z^(2j+1)/(2j+1)
    + 2 z^33/(33(1-z^2)).
Reduce an integer p by a power of two before using this formula.
"""
from fractions import Fraction as F
from math import isqrt
import json


def log_ratio_upper(z):
    assert F(0) <= z <= F(1, 3)
    return (2 * sum((z ** (2*j+1) / (2*j+1) for j in range(16)), F(0))
            + 2 * z**33 / (33 * (1-z*z)))


def log_integer_upper(p):
    assert p >= 1
    k = p.bit_length() - 1
    x = F(p, 2**k)
    return k * log_ratio_upper(F(1, 3)) + log_ratio_upper((x-1)/(x+1))


def ceil_fraction(x):
    return -((-x.numerator) // x.denominator)


primes = [p for p in range(2, 201)
          if all(p % q for q in range(2, isqrt(p)+1))]
groups = []
total_upper = F(0)
for lo, hi in [(2,40), (41,80), (81,120), (121,160), (161,200)]:
    members = [p for p in primes if lo <= p <= hi]
    upper = sum((log_integer_upper(p)/p**2 for p in members), F(0))
    micro = ceil_fraction(10**6 * upper)
    assert upper <= F(micro, 10**6)
    total_upper += F(micro, 10**6)
    groups.append({"range": [lo, hi], "primes": members,
                   "upper_millionths": micro})

assert log_integer_upper(200) < F(53, 10)
# The two admissible residue classes modulo 6 contribute at most
# 2 log(200)/200^2 + (log(200)+1)/(3*200).
tail_upper = 2 * F(53,10) / 200**2 + (F(53,10)+1)/(3*200)
full_upper = total_upper + tail_upper
assert full_upper < F(1,2)
result = {
    "method": "integer arithmetic and rational series bounds only",
    "terms_in_log_series": 16,
    "groups": groups,
    "head_upper": str(total_upper),
    "tail_upper": str(tail_upper),
    "prime_sum_upper": str(full_upper),
    "twice_prime_sum_upper": str(2*full_upper),
    "conclusion": "2 sum_p log(p)/p^2 < 1"
}
print(json.dumps(result, indent=2))
