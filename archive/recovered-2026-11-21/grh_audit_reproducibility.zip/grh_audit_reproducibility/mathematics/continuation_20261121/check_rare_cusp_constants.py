"""Exact finite controls for the cusp-volume normalization.

This does not test the imported Tamagawa theorems or prove a general
identity by enumeration. It checks the genuinely delicate tangent
Jacobian independently from the formula in the TeX.
"""
from pathlib import Path
import hashlib
import json
import math
import sympy as s

BASE = Path(__file__).resolve().parent
checks = []


def assert_exact(name, got, expected, **parameters):
    difference = s.simplify(got - expected)
    assert difference == 0, (name, parameters, got, expected)
    checks.append(dict(name=name, parameters=parameters))


def skew_basis(n):
    out = []
    for a in range(n):
        x = s.zeros(n)
        x[a, a] = s.I
        out.append(x)
    for a in range(n):
        for b in range(a + 1, n):
            x = s.zeros(n)
            x[a, b], x[b, a] = 1, -1
            out.append(x)
            x = s.zeros(n)
            x[a, b], x[b, a] = s.I, s.I
            out.append(x)
    return out


def real_vector(x):
    return s.Matrix([s.re(z) for z in x] + [s.im(z) for z in x])


def independent(xs):
    if not xs:
        return []
    pivots = s.Matrix.hstack(*map(real_vector, xs)).rref()[1]
    return [xs[i] for i in pivots]


def gram(xs):
    if not xs:
        return s.ones(0, 0)
    return s.Matrix([[s.re(s.trace(x.conjugate().T * y))
                      for y in xs] for x in xs])


def iwasawa_control(p, q, j):
    n = p + q
    m = n - 2 * j
    j0 = s.diag(*([1] * (p - j) + [-1] * (q - j)))
    form = s.zeros(n)
    form[:j, j + m:] = s.eye(j)
    form[j + m:, :j] = s.eye(j)
    form[j:j + m, j:j + m] = j0

    # The radical, with no normalization chosen beforehand.
    radical = []
    for a in range(m):
        for b in range(j):
            for entry in (1, s.I):
                z = s.zeros(m, j)
                z[a, b] = entry
                x = s.zeros(n)
                x[j:j + m, j + m:] = z
                x[:j, j:j + m] = -z.conjugate().T * j0
                radical.append(x)
    for c in skew_basis(j):
        x = s.zeros(n)
        x[:j, j + m:] = c
        radical.append(x)

    levi = []
    for a in range(j):
        for b in range(j):
            for entry in (1, s.I):
                a0 = s.zeros(j)
                a0[a, b] = entry
                x = s.zeros(n)
                x[:j, :j] = a0
                x[j + m:, j + m:] = -a0.conjugate().T
                levi.append(x)
    for c in skew_basis(m):
        x = s.zeros(n)
        x[j:j + m, j:j + m] = j0 * c
        levi.append(x)

    full_lie = [form * c for c in skew_basis(n)]
    compact = independent([(x - x.conjugate().T) / 2
                           for x in full_lie])
    compact_levi = independent([(x - x.conjugate().T) / 2
                               for x in levi])
    cm = s.Matrix.hstack(*map(real_vector, compact_levi))
    projection = cm * (cm.T * cm).inv() * cm.T
    horizontal = []
    for x in compact:
        coefficients = (cm.T * cm).inv() * cm.T * real_vector(x)
        correction = s.zeros(n)
        for coefficient, y in zip(coefficients, compact_levi):
            correction += coefficient * y
        horizontal.append(x - correction)
    horizontal = independent(horizontal)

    all_vectors = radical + levi + horizontal
    d = 2 * m * j + j * j
    assert_exact("lie_dimension", len(all_vectors), n * n,
                 p=p, q=q, j=j)
    for x in all_vectors:
        assert x.conjugate().T * form + form * x == s.zeros(n)
    squared_jacobian = (
        gram(all_vectors).det()
        / (gram(radical).det() * gram(levi).det()
           * gram(horizontal).det())
    )
    assert_exact("iwasawa_squared_jacobian", squared_jacobian,
                 s.Rational(1, 2) ** d, p=p, q=q, j=j)
    assert_exact("radical_dimension", len(radical), d, p=p, q=q, j=j)


for p, q, j in [
    (1, 1, 1), (2, 1, 1), (1, 2, 1),
    (3, 1, 1), (2, 2, 1), (2, 2, 2),
    (3, 2, 1), (3, 2, 2),
    (4, 2, 1), (4, 2, 2), (3, 3, 2), (3, 3, 3),
]:
    iwasawa_control(p, q, j)

# A second calculation of the congruence determinant of the center,
# in non-diagonal Gaussian-integer changes of basis.
for j in range(1, 5):
    a = s.Matrix(j, j, lambda r, c:
                 (r + 2 + s.I) if r == c else
                 (1 + (r - c) * s.I if c > r else 0))
    basis = skew_basis(j)
    coordinates = s.Matrix.hstack(*map(real_vector, basis))
    transformed = s.Matrix.hstack(
        *[real_vector(a * c * a.conjugate().T) for c in basis])
    change = (coordinates.T * coordinates).inv() * coordinates.T * transformed
    assert_exact("central_congruence_determinant", change.det(),
                 (a.det() * s.conjugate(a.det())) ** j, j=j)

# Exact cancellation of compact volumes and discriminant exponents.
# Keep pi as an indeterminate to check its exponent as well.
pi = s.Symbol("pi", positive=True)
root_disc = s.Symbol("root_disc", positive=True)


def sphere_product(n):
    return 2 ** n * pi ** (n * (n + 1) // 2) / math.prod(
        math.factorial(k) for k in range(n))


def unitary_volume(n):
    return 2 ** (n * (n - 1) // 2) * sphere_product(n)


for n in range(2, 22):
    for q in range(1, n):
        p = n - q
        for j in range(1, min(p, q) + 1):
            m = n - 2 * j
            d = 2 * m * j + j * j
            c = (s.Rational(1, 2) ** s.Rational(d + j * j, 2)
                 * unitary_volume(p) * unitary_volume(q)
                 / (unitary_volume(j) * unitary_volume(p-j)
                    * unitary_volume(q-j)))
            simplified = (
                s.Rational(1, 2) ** (j * (j+1) // 2)
                * sphere_product(p) * sphere_product(q)
                / (sphere_product(j) * sphere_product(p-j)
                   * sphere_product(q-j)))
            assert_exact("compact_Iwasawa_constant", c, simplified,
                         n=n, q=q, j=j)
            if m:
                unfolded = (c * 2 ** (j*j)
                            * root_disc ** s.Rational(d, 2)
                            * (root_disc/2) ** (j*j)
                            * root_disc ** (-2*j*(n-j)))
                target = simplified * root_disc ** (-s.Rational(d, 2))
                assert_exact("unfolded_discriminant_constant",
                             unfolded, target, n=n, q=q, j=j)

result = {
    "all_passed": True,
    "assertions": len(checks),
    "checks_by_name": {name: sum(x["name"] == name for x in checks)
                      for name in sorted({x["name"] for x in checks})},
    "scope": (
        "Exact finite controls of tangent Jacobians, non-diagonal "
        "central congruence determinants, compact-volume cancellation "
        "and discriminant exponents. Not a proof by enumeration and "
        "not a test of the imported Tamagawa theorems, arithmetic "
        "unfolding, source dependencies or Lean kernel."
    ),
    "fragment_sha256": hashlib.sha256(
        (BASE/"rare_cusp_volume.tex").read_bytes()).hexdigest(),
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(BASE/"rare_cusp_constants_checks.json").write_text(
    json.dumps(result, indent=2) + "\n")
print(json.dumps(result), flush=True)
