"""Exact checks of the one- and two-prism bar identities over Z[S_3]."""
from collections import Counter
from itertools import permutations,product
from pathlib import Path
import json

G=tuple(permutations(range(3)))
I=(0,1,2)

def mul(a,b):return tuple(a[b[i]] for i in range(3))
def inv(a):return tuple(a.index(i) for i in range(3))
def conj(g,a):return mul(mul(inv(g),a),g)
def clean(z):return Counter({t:n for t,n in z.items() if n})
def add(*terms):
    out=Counter()
    for n,z in terms:
        for t,c in z.items():out[t]+=n*c
    return clean(out)
def image(z,f):
    out=Counter()
    for t,n in z.items():
        for u,m in f(t).items():out[u]+=n*m
    return clean(out)
def boundary(t):
    if not t:return Counter()
    out=Counter();out[t[1:]]+=1;out[t[:-1]]+=(-1)**len(t)
    for i in range(len(t)-1):out[t[:i]+(mul(t[i],t[i+1]),)+t[i+2:]]+=(-1)**(i+1)
    return clean(out)
def P(g,t):
    out=Counter()
    for i in range(len(t)+1):out[t[:i]+(g,)+tuple(conj(g,a) for a in t[i:])]+=(-1)**i
    return clean(out)
def Q(g,h,t):
    out=Counter();gh=mul(g,h)
    for i in range(len(t)+1):
        for j in range(i,len(t)+1):
            out[t[:i]+(g,)+tuple(conj(g,a) for a in t[i:j])+(h,)+tuple(conj(gh,a) for a in t[j:])]+=(-1)**(i+j)
    return clean(out)

counts={'one_prism':0,'two_prism':0}
for m in range(4):
    for t in product(G,repeat=m):
        dz=boundary(t)
        for g in G:
            lhs=add((1,image(P(g,t),boundary)),(1,image(dz,lambda u:P(g,u))))
            rhs=add((1,Counter({tuple(conj(g,a) for a in t):1})),(-1,Counter({t:1})))
            assert lhs==rhs,(g,t,lhs,rhs)
            counts['one_prism']+=1
            for h in G:
                lhs=add((1,image(Q(g,h,t),boundary)),(-1,image(dz,lambda u:Q(g,h,u))))
                rhs=add((1,P(g,t)),(1,P(h,tuple(conj(g,a) for a in t))),(-1,P(mul(g,h),t)))
                assert lhs==rhs,(g,h,t,lhs,rhs)
                counts['two_prism']+=1

result={'status':'passed','group':'S_3','coefficients':'Z','chain_degrees':[0,1,2,3],
        'counts':counts,'limits':'Exact finite sign checks only; the manuscript proves the general identities.'}
Path(__file__).with_name('selmer_prism_exact_checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
