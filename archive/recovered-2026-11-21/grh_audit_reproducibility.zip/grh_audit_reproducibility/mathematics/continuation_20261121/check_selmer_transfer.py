"""Exact finite checks of displayed bar-chain identities; not proof substitutes."""
from collections import Counter
from itertools import product
from pathlib import Path
import json


def clean(c):
    return Counter({t: a for t, a in c.items() if a})


def add(*pairs):
    c = Counter()
    for a, z in pairs:
        for t, b in z.items():
            c[t] += a*b
    return clean(c)


def image(z, f):
    c = Counter()
    for t, a in z.items():
        for u, b in f(t).items():
            c[u] += a*b
    return clean(c)


def boundary(t, mul):
    if not t:
        return Counter()
    c = Counter()
    c[t[1:]] += 1
    for i in range(len(t)-1):
        c[t[:i]+(mul(t[i],t[i+1]),)+t[i+2:]] += (-1)**(i+1)
    c[t[:-1]] += (-1)**len(t)
    return clean(c)


def matmul(a, b, p=3):
    return ((a[0]*b[0]+a[1]*b[2])%p,
            (a[0]*b[1]+a[1]*b[3])%p,
            (a[2]*b[0]+a[3]*b[2])%p,
            (a[2]*b[1]+a[3]*b[3])%p)


def det(a,p=3):
    return (a[0]*a[3]-a[1]*a[2])%p


def inverse(a,p=3):
    u=pow(det(a,p),-1,p)
    return (u*a[3]%p,-u*a[1]%p,-u*a[2]%p,u*a[0]%p)


def mv(a,v,p=3):
    return ((a[0]*v[0]+a[1]*v[1])%p,
            (a[2]*v[0]+a[3]*v[1])%p)


def leading(v):
    return next(x for x in v if x)


def canon(v,p=3):
    u=pow(leading(v),-1,p)
    return tuple(u*x%p for x in v)


G=tuple(a for a in product(range(3),repeat=4) if det(a))
X=((1,0),(1,1),(1,2),(0,1))
I=(1,0,0,1)
actions={(g,x):canon(mv(inverse(g),x)) for g in G for x in X}
cocycles={(g,x):pow(leading(mv(inverse(g),x)),-1,3) for g in G for x in X}
bvalues={x:1+i%2 for i,x in enumerate(X)}


def entries(t,x):
    xs=[x];cs=[];ds=[]
    for g in t:
        y=actions[g,x];c=cocycles[g,x]
        cs.append(c);ds.append(pow(bvalues[x],-1,3)*c*bvalues[y]%3)
        xs.append(y);x=y
    return tuple(cs),tuple(ds),xs


def transfer(t,prime=False):
    out=Counter()
    for x in X:
        cs,ds,_=entries(t,x)
        out[ds if prime else cs] += 1
    return clean(out)


def homotopy(t):
    out=Counter()
    for x in X:
        cs,ds,xs=entries(t,x)
        for i in range(len(t)+1):
            out[cs[:i]+(bvalues[xs[i]],)+ds[i:]] += (-1)**i
    return clean(out)


def umul(a,b):
    return a*b%3


def prism(t,g):
    out=Counter()
    for i in range(len(t)+1):
        out[t[:i]+(g,)+t[i:]] += (-1)**i
    return clean(out)


counts={'chain_map':0,'homotopy':0,'projective_determinant':0,'prism_transfer':0,'functional_value':0}
generators=(I,(1,1,0,1),(1,0,1,1),(2,0,0,1),(0,1,1,0))
tuples=[()]+[(g,) for g in G]+list(product(G,repeat=2))+list(product(generators,repeat=3))
for t in tuples:
    dz=boundary(t,matmul)
    assert image(transfer(t),lambda u:boundary(u,umul)) == image(dz,transfer)
    counts['chain_map']+=1
    lhs=add((1,image(homotopy(t),lambda u:boundary(u,umul))),(1,image(dz,homotopy)))
    rhs=add((1,transfer(t,True)),(-1,transfer(t)))
    assert lhs==rhs,(t,lhs,rhs)
    counts['homotopy']+=1

for p in (2,3,5,7):
    lines=tuple((1,a) for a in range(p))+((0,1),)
    for g in product(range(p),repeat=4):
        if not det(g,p):continue
        value=1
        for x in lines:
            value=value*pow(leading(mv(inverse(g,p),x,p)),-1,p)%p
        assert value==det(g,p)
        counts['projective_determinant']+=1

for E in range(3):
    for x in range(4):
        z=Counter()
        for js in product(range(2),repeat=E):
            us=tuple(u for j in js for u in (pow(2,x*j,3),pow(2,x,3)))
            z[tuple((u,0,0,u) for u in us)]+=1
        zu=Counter({tuple(a[0] for a in t):n for t,n in z.items()})
        for g in G:
            lhs=image(image(z,lambda t:prism(t,g)),transfer)
            rhs=Counter()
            for line in X:
                rhs=add((1,rhs),(1,image(zu,lambda t:prism(t,cocycles[g,line]))))
            assert lhs==rhs,(E,x,g,lhs,rhs)
            counts['prism_transfer']+=1
            def tvalue(t):
                a=1
                for i in range(E):a*=((t[2*i]-1)+(t[2*i+1]-1))//2
                return a*(t[-1]-1)%2
            value=sum(n*tvalue(t) for t,n in lhs.items())%2
            assert value==(x**E*(det(g)-1))%2
            counts['functional_value']+=1

result={'status':'passed','arithmetic':'exact integers and finite fields of prime order',
        'counts':counts,'limits':'Finite normalization and sign checks only; the manuscript contains the proofs for all parameters.'}
path=Path(__file__).with_name('selmer_transfer_exact_checks.json')
path.write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result))
