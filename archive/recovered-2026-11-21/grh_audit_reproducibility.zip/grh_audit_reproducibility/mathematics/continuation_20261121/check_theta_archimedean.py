"""Exact finite controls for the independent archimedean-size reconstruction.

The general inequalities rest on the displayed proofs, not these controls.
The small spectral examples test identities; they need not obey the extra
smallness assumptions used only for the final asymptotic inequalities.
"""
from fractions import Fraction as F
from itertools import product
from math import factorial, prod
from pathlib import Path
import json
import sympy as sp

OUT = Path(__file__).resolve().parent
checks = []

def record(name, count, detail):
    checks.append({"name": name, "cases": count, "passed": True, "detail": detail})

H = [F(0)]
for j in range(1, 21):
    H.append(H[-1] + F(1, j))
count = 0
for J in range(1, 13):
    coeff = [H[i] - H[J - 1 - i] for i in range(J)]
    p = J // 2
    expected = F(0) if J == 1 else J * (H[2*p] - H[p])
    assert sum(max(x, 0) for x in coeff) == expected
    for eps in product((0, 1), repeat=J):
        direct = sum(F(eps[j] - eps[i], 4*(j-i))
                     for i in range(J) for j in range(i+1, J))
        assert direct == sum(eps[i]*coeff[i]/4 for i in range(J))
        count += 1
record("Binary Vandermonde linear term", count,
       "All binary sequences through length12; exact harmonic extremum.")

value = F(1)
for p in range(1, 501):
    value *= 1 + F(2, 4*p-1)
    assert value*value <= F(25, 9)*p
record("Sharper product before the differing index", 500,
       "Squared rational bound (5/3)^2 p; no floating point.")

assert F(8367, 5000)**2 > F(14, 5)
constant = 8*F(5,3)*F(8367,5000)*F(10,9)*F(11,10)/(F(19,50)*F(9,10))
assert constant == F(122716,1539) and constant < 80
for q in range(2, 100):
    assert 4**q*factorial(q) >= (q+2)**q
record("Boundary constant and factorial comparison", 100,
       "Exact rational upper constant 122716/1539 <80 and q=2,...,99.")

count = 0
for k in (4, 5, 6):
    D = F(10)
    v = [4*D*(k-2-i) for i in range(k-1)]
    a = 8*k*D
    b = [F(1000), F(1001)]
    for top in (False, True):
        bp = F(997)
        lam = v + [-x for x in b]
        for e in product((0,1), repeat=k-2):
            eps = list(e) + [0]
            u = [a] + [v[i]-F(1,2)-eps[i]*D for i in range(k-2)]
            u += [-bp if top else v[-1]-F(1,2)]
            for ep in product((0,1), repeat=k-2):
                epsp = list(ep) + [0]
                up = [a] + [v[i]-F(1,2)-epsp[i]*D for i in range(k-2)]
                up += [-bp if top else v[-1]-F(1,2)]
                for l in range(k-2):
                    if eps[l] == epsp[l]:
                        continue
                    y = v[l]-3
                    Y = -y
                    P = prod(Y+x for x in lam)
                    P1 = prod(Y+1+x for x in lam)
                    Q = -6*prod((Y+F(1,2)+x)*(Y+F(1,2)+xp)
                                for x,xp in zip(u,up))
                    squared = prod((x+y)*(x+y-1) for x in b)/(a+F(1,2)-y)**2
                    for i in range(k-1):
                        numerator = abs((v[i]-y)*(v[i]+1-y))
                        denominator = ((bp+y-F(1,2))**2 if top and i==k-2
                            else abs((v[i]-eps[i]*D-y)*(v[i]-epsp[i]*D-y)))
                        squared *= numerator/denominator
                    assert P != 0 and P1 != 0 and Q != 0
                    assert abs(P*P1/Q) == squared/6
                    count += 1
record("Exact boundary polynomial factorization", count,
       "Both final-entry cases, every differing pair of binary words for k=4,5,6.")

def gl(n,q):
    return prod(q**n-q**j for j in range(n))

count = 0
for k,r,q in product(range(4,8), range(3), (2,3,5)):
    m = 2*r+2
    n = k+m-1
    row = F(gl(n,q), q**(r*(2*k+2*r+1)+k*(k-1)//2))
    col = F(gl(k,q), q**(k*(k-1)//2))
    right = q**(k*m+m*(m-1)//2)*prod(1-F(1,q**j) for j in range(k+1,n+1))
    assert row/col == right
    assert sum(range(k+1,n+1)) == (m-1)*k+m*(m-1)//2
    sfac = lambda d: prod(factorial(j) for j in range(d))
    assert sfac(n) == sfac(k)*prod(factorial(j) for j in range(k,n))
    count += 1
record("Finite-level, rank-sum and factorial mass identities", count,
       "Exact orders of finite general linear groups; both rank cases and q=2,3,5.")

C, Bv, rho, g, pi, N, I, TT = sp.symbols(
    "C Bv rho g pi N I TT", positive=True)
ka = 2*pi/rho
kag = 2*pi/g
h = C*ka*N/(g*I)
count = 0
for r in range(5):
    m = 2*r+2
    calA = Bv/(g**m*ka**(-(m-1)))
    for b in range(1,r+2):
        for s in range(1,r+3-b):
            nu = 2*r+3-2*b-s
            degree = 2*(b-1)+s-1
            source_width = C*kag**(-(m-1))*calA*(C*kag*N/I)**degree
            normalized = source_width*g*rho**(nu+1)
            assert sp.simplify(normalized-C*Bv*h**degree) == 0
            count += 1
        source_prime_sq = C*kag**(-(m-1))*calA*kag**(2*b-1)*TT**sp.Rational(-1,2)*(C*N/I)**(2*(b-1))
        expected_sq = C*Bv*ka*TT**sp.Rational(-1,2)*h**(2*(b-1))
        assert sp.simplify(source_prime_sq*(g*rho**(r+1-b))**2-expected_sq) == 0
        count += 1
record("Actual interior and terminal width normalization", count,
       "Symbolic identities for r=0,...,4, including the terminal square root.")

result = {"arithmetic": "Exact rational, integer and symbolic arithmetic",
          "total_cases": sum(x["cases"] for x in checks),
          "checks": checks,
          "scope": "Finite identity and constant controls only; no claim to verify the automorphic mass, formal-degree, or coefficient identities."}
(OUT/"theta_archimedean_checks.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps({"passed": True, "groups": len(checks),
                  "total_cases": result["total_cases"]}))
