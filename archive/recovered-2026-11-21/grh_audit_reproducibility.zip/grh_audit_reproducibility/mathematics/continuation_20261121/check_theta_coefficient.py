"""Exact controls for the coefficient identities, not proofs of analytic inputs."""
from fractions import Fraction
from itertools import combinations, permutations, product
from pathlib import Path
import json
import sympy as sp

OUT = Path(__file__).resolve().parent
groups = {}


def check(group, assertion):
    assert assertion, group
    groups[group] = groups.get(group, 0) + 1


u = sp.Symbol("u", real=True)
identity = sp.eye(2)


def perm_sign(p):
    return (-1) ** sum(p[i] > p[j] for i in range(len(p))
                       for j in range(i + 1, len(p)))


def qminor(a, b):
    ans = sp.zeros(2)
    for p in permutations(range(len(a))):
        term = identity
        for j in range(len(a)):
            aa, bb = a[p[j]], b[j]
            # Deliberately noncommuting endomorphisms.
            op = sp.Matrix([[aa + 1, bb + 2], [aa - bb + 1, aa * bb]])
            term = term * (((u - j) * identity if aa == bb
                            else sp.zeros(2)) + op)
        ans += perm_sign(p) * term
    return ans.applyfunc(sp.expand)


for m in range(4):
    choices = list(permutations(range(3), m))
    for a in choices:
        for b in choices:
            q = qminor(a, b)
            delta = sp.Matrix(m, m, lambda i, j: int(a[i] == b[j])).det()
            leading = q.applyfunc(lambda x: sp.Poly(x, u).nth(m))
            check("noncommutative_column_minors", leading == delta * identity)
            check("noncommutative_column_minors",
                  all(sp.Poly(x, u).degree() <= m for x in q if x != 0))

# The actual basis order e0,e1,w0,f1,f0 with k=0,r=2.
H = sp.zeros(5)
for e, f in [(0, 4), (1, 3)]:
    H[e, f] = H[f, e] = 1
H[2, 2] = -1
for t0, t1, s0, s1 in [(1, 2, 3, 4), (-2, 3, 1, -1), (2, -1, -3, 2)]:
    g = sp.eye(5)
    for e, f, t, s in [(0, 4, t0, s0), (1, 3, t1, s1)]:
        g[e, e], g[e, f] = 1, sp.I * s
        g[f, e], g[f, f] = sp.I * t, 1 - t * s
    check("two_minor_orders", sp.simplify(g.conjugate().T * H * g) == H)
    for m in range(3):
        d = (H * g).extract(range(m), range(m)).det()
        Y = sp.Matrix(m, m, lambda a, b: g.inv()[4 - b, a])
        check("two_minor_orders", sp.simplify(Y.det() - sp.conjugate(d)) == 0)

y = sp.Symbol("y", real=True)
s = 2 + 3 * sp.I
B = sp.Matrix([[1, 2 + sp.I], [3 - 2 * sp.I, -1]])
U = sp.Matrix([[2, 1], [sp.I, 3]])
x, xp = sp.Matrix([1 + sp.I, 2]), sp.Matrix([3, 2 - sp.I])


def pairing(v, w):
    return (v.T * B * sp.conjugate(w))[0]


for j in range(5):
    low = sum((y ** ell for ell in range(j)), sp.Integer(0))
    X0 = y ** j * x + low * sp.Matrix([2, sp.I])
    Y0 = y ** j * xp + low * sp.Matrix([1 - sp.I, 2])
    X1, Y1 = low * x, low * xp
    f = sp.expand(pairing(U * X1 + s * U * X0, Y0)
                  - pairing(U * X0, Y1))
    check("mixed_pairing_leading",
          sp.simplify(sp.Poly(f, y).nth(2 * j) - s * pairing(U * x, xp)) == 0)


def lagrange(nodes):
    return [sp.prod(1 / (a - b) for h, b in enumerate(nodes) if h != i)
            for i, a in enumerate(nodes)]


for d in range(8):
    nodes = [sp.Rational(i * i + 2 * i, 3) for i in range(d + 1)]
    co = lagrange(nodes)
    for e in range(d + 1):
        check("lagrange_extraction", sp.simplify(sum(c * a ** e for c, a
                                                    in zip(co, nodes))) == int(e == d))
    check("lagrange_extraction", sum(abs(c) for c in co) > 0)

# Endpoint Chebyshev nodes give exact algebraic numbers.
for d in range(1, 7):
    nodes = [sp.cos(sp.pi * i / d) for i in range(d + 1)]
    co = lagrange(nodes)
    signed_sum = sp.simplify(sum((-1) ** i * c for i, c in enumerate(co)))
    check("chebyshev_constant", sp.simplify(signed_sum - 2 ** (d - 1)) == 0)

for N in range(20, 501):
    check("rational_correction", Fraction(8 * N, N * N - 8) <= Fraction(20, 49))
for L in range(7):
    for signs in product((-1, 1), repeat=L):
        D = Fraction(50)
        ratio = sp.prod(1 + Fraction(sign, D) for sign in signs)
        check("rational_correction", (1 - 1 / D) ** L <= ratio <= (1 + 1 / D) ** L)
        check("rational_correction", ratio > 0)

# Normalizers cancel exactly in a nontrivial 2+2 dimensional block.
nodes = [sp.Integer(-1), sp.Integer(0), sp.Integer(2)]
co = lagrange(nodes)
C = sum(abs(c) for c in co)
Gamma, old_size, T, A = map(sp.Integer, (3, 5, 7, 2))
vectors = [sp.Matrix([1, 0]), sp.Matrix([0, 1]), sp.Matrix([sp.Rational(3, 5),
                                                          sp.Rational(4, 5)])]
F = sp.zeros(2)
for i, (a, c) in enumerate(zip(nodes, co)):
    P, P1 = a * a + 3, (a + 1) ** 2 + 3
    q = P * P1 / A ** 2
    Rplus = Gamma * old_size * P * sp.eye(2)
    Rminus = Gamma * old_size * P1 * sp.eye(2)
    mixed = Gamma * old_size * A * vectors[i] * vectors[(i + 1) % 3].T
    check("positive_block_normalization",
          sp.simplify((Gamma * old_size * A) ** 2 * q
                      - Rplus[0, 0] * Rminus[0, 0]) == 0)
    F += T * c * mixed / (Gamma * old_size)
X = C * T * A
block = sp.BlockMatrix([[X * sp.eye(2), F], [F.T, X * sp.eye(2)]]).as_explicit()
for size in range(1, 5):
    for rows in combinations(range(4), size):
        check("positive_block_normalization", block.extract(rows, rows).det() >= 0)

bad = sp.BlockMatrix([[sp.eye(2), sp.ones(2)], [sp.ones(2), sp.eye(2)]]).as_explicit()
bad_vector = sp.Matrix([1, 1, -1, -1])
check("counterexamples", (bad_vector.T * bad * bad_vector)[0] == -4)
check("counterexamples", sp.I * sp.conjugate(sp.I) == 1 and sp.I ** 2 == -1)

lr, li, cr, ci, glev, lam = sp.symbols("lr li cr ci glev lam", real=True)
l, c = lr + sp.I * li, cr + sp.I * ci
phase_s, z = 2 * sp.pi * sp.I * l / (glev * lam), lam * c
check("fourier_normalization",
      sp.simplify(phase_s * z - sp.conjugate(phase_s) * sp.conjugate(z)
                  - 4 * sp.pi * sp.I * sp.re(l * c) / glev) == 0)
for K in range(6):
    check("fourier_normalization",
          sp.simplify((glev * lam / (2 * sp.pi)) ** K * phase_s ** K
                      - sp.I ** K * l ** K) == 0)

result = {"status": "passed", "exact_assertions": sum(groups.values()), "groups": groups,
          "limits": "Finite exact controls of displayed algebraic identities only. "
                    "No radial representation, positivity, mass, dimension, or formal-degree "
                    "input is certified by these controls."}
(OUT / "theta_coefficient_checks.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
