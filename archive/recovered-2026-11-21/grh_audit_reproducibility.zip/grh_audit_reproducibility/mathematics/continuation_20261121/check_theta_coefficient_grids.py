"""Exact endpoint/separation controls for the actual interpolation construction."""
from fractions import Fraction as F
from pathlib import Path
import json

OUT=Path(__file__).resolve().parent
groups={}

def check(group, condition):
    assert condition, group
    groups[group]=groups.get(group,0)+1

for r in (0,1,2,5):
    N=20*(r+1)
    R=2*r
    for q in (F(N*N+1),F(N*N+4)):
        I=6*N*q
        ell=q-1
        intervals=[((2*N+2*a-2)*q,(2*N+2*a-1)*q-1)
                   for a in range(1,N+1)]
        for lo,hi in intervals:
            check("long_interval_containment",0<=lo<=hi and hi+1<I)
        for a in range(N-1):
            check("long_interval_separation",
                  intervals[a+1][0]-(intervals[a][1]+1)>=N*N+1)
        short_hi=(N-1)*N*N+F(3,2)
        check("short_interval_containment",short_hi<=N**3-F(5,2)<I)
        check("cross_separation",intervals[0][0]-short_hi>=N*N+1)
        check("short_separation",N*N-F(3,2)>=F(N*N,8)>4)
        for d in range(1,R+1):
            exact_coefficient_sum=F(1,2)*(4/ell)**d
            check("constant_24",exact_coefficient_sum<=(F(24*N)/I)**d)
        check("degree_zero",F(1)==(F(24*N)/I)**0)
        # Concrete spectral data, in both allowed last-entry cases.
        Delta=2*I+5
        k=2*r+4
        m=2*r+2
        l=1
        vv=[4*Delta*(k-1-i) for i in range(1,k)]
        aa=vv[0]+4*k*Delta
        bb=[F(20+j) for j in range(m)]
        ep=[i%2 for i in range(k-1)]
        ep[-1]=0
        ep2=ep.copy();ep2[l-1]=1-ep2[l-1]
        for last in (vv[-1]-F(1,2),-F(15)):
            us=[aa]+[vv[i]-F(1,2)-ep[i]*Delta for i in range(k-2)]+[last]
            us2=[aa]+[vv[i]-F(1,2)-ep2[i]*Delta for i in range(k-2)]+[last]
            alpha=F(5,2)-vv[l-1]
            beta=Delta/2-vv[l-1]
            for YY in (alpha,beta,alpha+1,(alpha+beta)/2):
                pp=F(1)
                for z in vv+[-b for b in bb]:pp*=YY+z
                qq=F(-1)
                for z,z2 in zip(us,us2):qq*=(YY+F(1,2)+z)*(YY+F(1,2)+z2)
                check("spectral_interval",pp!=0 and qq>0)
                low,high=sorted((us[l],us2[l]))
                check("spectral_margin",low+2<=-YY<=high-2)

# A reused short underlying node would violate the separation requirement.
check("excluded_reuse",abs(F(0)-F(0))<=2)
result={"status":"passed","exact_assertions":sum(groups.values()),"groups":groups,
        "limits":"Finite exact endpoint and normalization controls; general conclusions rely on the displayed proofs."}
(OUT/"theta_coefficient_grids_checks.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
