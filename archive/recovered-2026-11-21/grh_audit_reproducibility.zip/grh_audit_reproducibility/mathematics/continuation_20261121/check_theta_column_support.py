"""Exact finite Fourier checks for CS13 and its companion annihilator.

No complex floating point is used. A character sum is represented by
its integer counts in Q[z]/(1+z+...+z^(p-1)). The independent
annihilator check uses Y^t ker(ell')=0 over F_p.
"""
from itertools import product
from fractions import Fraction
from pathlib import Path
import json

def dot(x,y,p):
    return sum(a*b for a,b in zip(x,y))%p

def case(p,a,b,ell,ellp):
    mats=list(product(range(p),repeat=a*b))
    def image(X):
        return tuple(sum(ellp[i]*X[i*a+j] for i in range(b))%p
                     for j in range(a))
    fiber=[X for X in mats if image(X)==ell]
    assert len(fiber)==p**(a*(b-1))
    x0=fiber[0]
    ker=[v for v in product(range(p),repeat=b) if dot(ellp,v,p)==0]
    survivors=0
    for Y in mats:
        annihilator=all(all(sum(Y[i*a+j]*v[i] for i in range(b))%p==0
                            for j in range(a)) for v in ker)
        counts=[0]*p
        for X in fiber:
            counts[(-dot(X,Y,p))%p]+=1
        # Subtract the coefficient of z^(p-1), using Phi_p(z)=0.
        reduced=[n-counts[-1] for n in counts[:-1]]
        expected=[0]*p
        if annihilator:
            survivors+=1
            expected[(-dot(x0,Y,p))%p]=len(fiber)
        expected=[n-expected[-1] for n in expected[:-1]]
        assert reduced==expected,(p,a,b,ell,ellp,Y,counts,expected)
    assert survivors==p**a
    return dict(p=p,a=a,b=b,ell=list(ell),ell_prime=list(ellp),
                matrices=len(mats),fiber=len(fiber),
                annihilator=survivors,character_sums_checked=len(mats))

cases=[]
for ell in [(1,0),(0,1),(1,2)]:
    for ellp in [(1,0),(0,1),(1,2)]:
        cases.append(case(5,2,2,ell,ellp))
for ell in [(1,0),(1,2)]:
    for ellp in [(1,0,0),(0,1,0),(1,1,1),(1,2,0)]:
        cases.append(case(3,2,3,ell,ellp))
cases.append(case(7,1,2,(3,),(2,5)))
exponents=[]
for f in range(1,5):
    for a in (2,4,6):
        valuation=-f*a+Fraction(f*a,2)-Fraction(f*a,2)
        assert valuation==-f*a
        exponents.append(dict(f=f,a=a,valuation=str(valuation)))
out=dict(exact=True,method="Integer coefficient reduction modulo Phi_p",
         cases=cases,total_character_sums=sum(c['matrices'] for c in cases),
         scalar_exponents=exponents,
         excluded_degenerate_control=dict(p=5,a=2,b=2,
             ell=[0,0],ell_prime=[0,0],fiber=625,annihilator=1,
             predicted_by_nonzero_formula=25,
             meaning="Nonzero residue functional is necessary; excluded by Deco.Ok.f_ne."))
p=Path(__file__).with_name('theta_column_support_checks.json')
p.write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(dict(cases=len(cases),character_sums=out['total_character_sums'],
                     exact=True,scalar_cases=len(exponents)),indent=2))
