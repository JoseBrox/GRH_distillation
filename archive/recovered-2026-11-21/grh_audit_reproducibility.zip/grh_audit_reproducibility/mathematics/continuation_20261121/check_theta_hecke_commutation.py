"""Exact finite controls of the actual local incidence and its weights.

Matrices X=A/p modulo integral precision p are tested directly against
all upper and lower decorated neighbors.  The checker does not compare
two copies of the uniqueness proof.  Its small cases supplement the
general proof; they are not a proof by sampling.
"""
from itertools import product, permutations
from fractions import Fraction
from pathlib import Path
import hashlib
import json

base = Path(__file__).resolve().parent
cases = []
total = 0
for p, a, b in [(2, 1, 1), (3, 1, 2), (2, 2, 2),
                (3, 2, 2), (2, 2, 4), (2, 4, 2)]:
    uppers = [u + (1,) for u in product(range(p), repeat=b-1)]
    lowers = [w + (1,) for w in product(range(p), repeat=a-1)]
    count = both = 0
    for flat in product(range(p*p), repeat=a*b):
        mat = [flat[i*a:(i+1)*a] for i in range(b)]
        # In M+ = R^b + R(v/p), p X e_j = A_j must reduce
        # to alpha_j v; ell+(X e_j)=alpha_j=delta_{j,a-1}.
        up = 0
        for v in uppers:
            if all(mat[i][j] % p == ((j == a-1)*v[i]) % p
                   for i in range(b) for j in range(a)):
                up += 1
        # L0 has basis e_1,...,e_(a-1),p e_a.  Test integrality
        # and ell_M X on this actual basis against each ell0.
        down = 0
        integral = all(mat[i][j] % p == 0
                       for i in range(b) for j in range(a-1))
        if integral:
            image_values = tuple((mat[b-1][j]//p) % p
                                 for j in range(a-1)) + (mat[b-1][a-1] % p,)
            for ell0 in lowers:
                if image_values == ell0:
                    down += 1
        assert up == down and up in (0, 1), (p,a,b,mat,up,down)
        both += up
        count += 1
    cases.append(dict(p=p,a=a,b=b,matrices=count,nonzero=both,
                      upper_neighbors=len(uppers),lower_neighbors=len(lowers)))
    total += count

# All finite indicator refinements in one nontrivial two-coordinate
# module, using integer character multiplicities modulo Phi_3.
def cyclotomic_zero(coeff):
    return len(set(coeff)) == 1
p = 3
points = list(product(range(p),repeat=2))
characters = points
orthogonality = 0
for x in points:
    for z in points:
        coeff = [0]*p
        for y in characters:
            coeff[sum((z[i]-x[i])*y[i] for i in range(2)) % p] += 1
        if x == z:
            assert coeff == [p*p,0,0]
        else:
            assert cyclotomic_zero(coeff)
        orthogonality += 1

# Exact positive square-root ratios when both ranks are even.
scalar_checks = 0
for p in (2,3,5,7):
    for a,b in product((2,4,6,8),repeat=2):
        for e,ep in product(range(-2,3),repeat=2):
            volume_ratio = Fraction(p)**(b*e-a*ep)
            rho = Fraction(p)**((b*e-a*ep)//2)
            assert rho > 0 and rho*rho == volume_ratio
            w = Fraction(7,5)
            char_ratio = w**(-e) / w**(-ep)
            assert char_ratio == w**(ep-e)
            if e == ep == 1:
                assert char_ratio*rho == Fraction(p)**((b-a)//2)
            scalar_checks += 1

# Orbit enumeration for a nonfree action; omitting stabilizers fails.
group = list(permutations(range(3)))
def act(g,x):
    return 3 if x == 3 else g[x]
points4 = range(4)
relation = {(3,i) for i in range(3)}
representatives = (3,0)
stabilizers = {x:sum(act(g,x)==x for g in group) for x in representatives}
left = sum(Fraction(sum((x,y) in relation for y in points4),stabilizers[x])
           for x in representatives)
right = sum(Fraction(sum((y,x) in relation for y in points4),stabilizers[x])
            for x in representatives)
assert left == right == Fraction(1,2)
assert sum(sum((x,y) in relation for y in points4) for x in representatives) == 3
assert sum(sum((y,x) in relation for y in points4) for x in representatives) == 1

out = dict(status="passed", manuscript_sha256=hashlib.sha256(
    (base/"theta_hecke_commutation.tex").read_bytes()).hexdigest(),
    exhaustive_local_cases=cases,total_matrices=total,
    exact_fourier_orthogonality=orthogonality,scalar_checks=scalar_checks,
    weighted_mass_identity=str(left),unweighted_negative_control=[3,1],
    scope="Finite exact checks of the local identity, volume/character scalars, "
          "and stabilizer weights; no complete formal kernel replay.")
(base/"theta_hecke_commutation_checks.json").write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({k:v for k,v in out.items() if k != "exhaustive_local_cases"},indent=2))
