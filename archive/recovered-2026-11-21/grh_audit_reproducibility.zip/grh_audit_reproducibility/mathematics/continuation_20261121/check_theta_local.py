"""Exact controls for local Gaussian and stationary-phase normalizations.

All root-of-unity identities are reduced modulo cyclotomic polynomials over
ZZ.  No numerical evaluation of oscillatory integrals is used.  These are
small controls of the displayed general proofs, not proofs of their scope.
"""
from fractions import Fraction
from itertools import product
from pathlib import Path
import json
import sympy as sp

X = sp.Symbol("X")


def reduce_coefficients(coeffs, modulus):
    poly = sp.Poly.from_dict({(i,): int(c) for i, c in enumerate(coeffs) if c}, X)
    return sp.rem(poly, sp.Poly(sp.cyclotomic_poly(modulus, X), X))


def valuation(n, p):
    out = 0
    while n % p == 0:
        out += 1
        n //= p
    return out


def gaussian(p, m, e):
    modulus = p ** e
    counts = [0] * modulus
    for v in product(range(modulus), repeat=m):
        # (sum x_i^2 + (sum x_i)^2)/2 is an integral polynomial.
        q = sum(x*x for x in v) + sum(v[i]*v[j] for i in range(m) for j in range(i))
        counts[q % modulus] += 1
    corr = [sum(counts[k] * counts[(k+r) % modulus] for k in range(modulus))
            for r in range(modulus)]
    reduced = reduce_coefficients(corr, modulus)
    prediction = p ** (e*m + valuation(m+1, p))
    okay = reduced == sp.Poly(prediction, X)
    return {
        "p": p, "m": m, "e": e,
        "modulus": modulus, "points": modulus ** m,
        "admissibility_sufficient_condition": e >= valuation(2, p) + valuation(m+1, p),
        "exact_squared_gauss_sum": str(reduced.as_expr()),
        "predicted_squared_gauss_sum": prediction,
        "formula_holds": okay,
    }


def stationary(p, e, ball_exponent):
    """f(x)=x+x^-1, A=1_(Z_p^x), critical points z=+1,-1."""
    modulus = p ** e
    lhs = [0] * modulus
    rhs = [0] * modulus
    for x in range(modulus):
        if x % p:
            lhs[(x + pow(x, -1, modulus)) % modulus] += 1
    for z in (1, -1):
        for y in range(0, modulus, p ** ball_exponent):
            # Critical value 2z; quadratic term y^2/z.
            rhs[(2*z + z*y*y) % modulus] += 1
    rem = reduce_coefficients([a-b for a, b in zip(lhs, rhs)], modulus)
    return {"p": p, "e": e, "critical_ball_exponent": ball_exponent,
            "normalized_common_denominator": modulus,
            "cyclotomic_remainder": str(rem.as_expr()),
            "formula_holds": rem.is_zero}


def split_order(p):
    # R={(a,b) in Z_p^2:a=b mod p}, psi_R=psi((a-b)/p).
    # Integrate psi_R(x^2,y^2) over Z_p^2. Haar_R=p Haar_product.
    coeff = [0] * p
    for x, y in product(range(p), repeat=2):
        coeff[(x*x-y*y) % p] += 1
    integral_numerator = reduce_coefficients(coeff, p)
    assert integral_numerator == sp.Poly(p, X)
    return {"p": p,
            "integral_with_product_Haar": str(Fraction(1, p)),
            "Haar_normalization_factor": p,
            "integral_with_self_dual_Haar": 1,
            "predicted_Gaussian_modulus": 1}


gaussian_cases = [(2, 1, 2), (2, 3, 3), (3, 2, 2), (3, 3, 1), (5, 2, 1), (5, 4, 2)]
gaussian_results = [gaussian(*c) for c in gaussian_cases]
assert all(row["formula_holds"] for row in gaussian_results)
stationary_results = [stationary(3, 2, 1), stationary(3, 3, 1),
                      stationary(5, 2, 1), stationary(2, 8, 3)]
assert all(row["formula_holds"] for row in stationary_results)
control = gaussian(2, 3, 1)
assert not control["admissibility_sufficient_condition"]
assert not control["formula_holds"]
result = {
    "gaussian_cases": gaussian_results,
    "stationary_phase_cases": stationary_results,
    "split_order_cases": [split_order(3), split_order(5)],
    "omitted_admissibility_counterexample": control,
    "interpretation": "These controls support the proved local lemmas. The last example violates an explicit hypothesis and does not refute the source theorem.",
}
out = Path(__file__).with_name("theta_local_checks.json")
out.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
