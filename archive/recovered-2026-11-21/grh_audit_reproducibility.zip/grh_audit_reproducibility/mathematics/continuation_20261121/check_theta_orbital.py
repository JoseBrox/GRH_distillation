"""Exact small controls for the local marked-cokernel averaging argument.

For t=p*a, u=b/p, enumerate C=Z_p^2 / [[0,t],[t,a*b]] Z_p^2
through the exact finite quotient (Z/p^2 Z)^2.  All module maps are
enumerated by images of the two standard generators.  No floating point
or presumed isomorphism classification is used.
"""
import json
from itertools import product
from pathlib import Path


class Cokernel:
    def __init__(self, p, unit, b):
        self.p, self.q = p, p * p
        self.unit, self.b = unit, b
        q = self.q
        self.inv_unit = pow(unit, -1, q)
        t = p * unit
        self.columns = ((0, t), (t, unit * b))
        self.space = list(product(range(q), repeat=2))
        image = {
            ((t * y) % q, (t * x + unit * b * y) % q)
            for x, y in self.space
        }
        self.representative = {}
        for v in self.space:
            if v in self.representative:
                continue
            coset = {((v[0] + w[0]) % q, (v[1] + w[1]) % q)
                     for w in image}
            representative = min(coset)
            self.representative.update((w, representative) for w in coset)
        self.elements = sorted(set(self.representative.values()))
        assert len(self.elements) == q
        self.zero = self.reduce((0, 0))
        self.mark = self.reduce((0, 1))

    def reduce(self, v):
        return self.representative[(v[0] % self.q, v[1] % self.q)]

    def combination(self, x, v, y, w):
        return self.reduce((x*v[0] + y*w[0], x*v[1] + y*w[1]))

    def lam(self, i, v):
        """Numerator modulo p^2 of the inverse-coordinate value in Q_p/Z_p."""
        x, y = v
        if i == 1:
            return (self.p * self.inv_unit * x) % self.q
        return (self.inv_unit * (-self.b*x + self.p*y)) % self.q


def iso_counts(source, target):
    assert source.p == target.p
    q, p = source.q, source.p
    plain = triangular = 0
    for v in target.elements:
        w = target.mark
        if any(target.combination(a, v, b, w) != target.zero
               for a, b in source.columns):
            continue
        if target.lam(1, v) != source.lam(1, (1, 0)):
            continue
        if target.lam(1, w) != source.lam(1, (0, 1)):
            continue
        image = {target.combination(x, v, y, w) for x, y in source.elements}
        if len(image) != q:
            continue
        plain += 1
        # T_0: lambda'_0 phi-lambda_0 is an R-multiple of lambda_1.
        delta_1 = (target.lam(0, v) - source.lam(0, (1, 0))) % q
        delta_2 = (target.lam(0, w) - source.lam(0, (0, 1))) % q
        if delta_2 == 0 and delta_1 % p == 0:
            triangular += 1
    return plain, triangular


def cyclotomic_reduce_prime(coefficients):
    """Reduce exactly modulo Phi_p(X)=1+X+...+X^(p-1)."""
    return [a-coefficients[-1] for a in coefficients[:-1]]


def check_kernel(p, first_unit, second_unit):
    source = [Cokernel(p, first_unit, b) for b in range(p)]
    target = [Cokernel(p, second_unit, b) for b in range(p)]
    counts = [[iso_counts(s, t) for t in target] for s in source]
    plain = [0] * p
    triangular = [0] * p
    for b, row in enumerate(counts):
        for c, (a, d) in enumerate(row):
            plain[(b-c) % p] += a
            triangular[(b-c) % p] += d
    plain_reduced = cyclotomic_reduce_prime(plain)
    triangular_reduced = cyclotomic_reduce_prime(triangular)
    assert plain_reduced == triangular_reduced
    support_holds = (first_unit-second_unit) % p == 0
    if not support_holds:
        assert not any(plain_reduced)
    else:
        assert any(plain_reduced)
    return {
        "p": p, "first_unit": first_unit, "second_unit": second_unit,
        "plain_iso_counts": [[x[0] for x in row] for row in counts],
        "triangular_iso_counts": [[x[1] for x in row] for row in counts],
        "plain_phase_coefficients": plain,
        "triangular_phase_coefficients": triangular,
        "cyclotomic_remainder": plain_reduced,
        "inverse_parameter_support_holds": support_holds,
    }


def representative_change(N):
    """Check the omitted-support example modulo exactly the character modulus."""
    p = 3
    modulus = p**(N-1)
    target = (1-p**(N-2)) % modulus
    # The near-one root mod 3^(N-1), represented by a finite integer.
    roots = [w for w in range(1, modulus, 3) if w*w % modulus == target]
    assert len(roots) == 1
    w = roots[0]
    phase_difference = (4*(w-1)) % modulus
    predicted = (-2 * p**(N-2)) % modulus
    assert phase_difference == predicted and phase_difference != 0
    assert (3*w-3) % 9 == 0
    return {"N": N, "root_modulus": modulus, "near_one_root": w,
            "phase_difference_numerator": phase_difference,
            "phase_denominator": modulus,
            "equals_minus_two_thirds_mod_one": True}


if __name__ == "__main__":
    result = {
        "scope": "Exact finite controls only; the general theorems rest on the displayed proofs.",
        "kernel_cases": [check_kernel(p, 1, v) for p in (3, 5) for v in (1, 2, p+1)],
        "omitted_support_cases": [representative_change(N) for N in range(4, 8)],
    }
    out = Path(__file__).with_name("theta_orbital_checks.json")
    out.write_text(json.dumps(result, indent=2) + "\n")
    print(f"Passed {len(result['kernel_cases'])} exact marked-kernel controls and "
          f"{len(result['omitted_support_cases'])} representative-change controls.")
