"""Exact independent bordered-cokernel and single-block Parseval controls.

Actual finite quotient modules are constructed from 2 by 2 integral
matrices over F_p. Every module homomorphism is tested by its images on
the two standard generators. These counts are compared with the separate
finite-duality formula, then summed over c mod Z_p. No floating point.
The heads are (p*u), c=1 for the zero class and c=k/p otherwise.
All these bordered cokernels are killed by p, so mod-p quotients suffice.
"""
from itertools import product
from pathlib import Path
import json


class Border:
    def __init__(self, p, unit, r, b, k):
        self.p, self.unit, self.r, self.b, self.k = p, unit, r, b, k
        c_num = p if k == 0 else k
        assert (r*b+c_num) % p == 0
        self.columns = ((p*unit,unit*r),(b,(r*b+c_num)//p))
        self.determinant = unit*c_num
        # All determinants have p-valuation either 0 or 1.
        assert self.determinant % (p*p) != 0
        space = list(product(range(p), repeat=2))
        image = {((a*self.columns[0][0]+b0*self.columns[1][0]) % p,
                  (a*self.columns[0][1]+b0*self.columns[1][1]) % p)
                 for a,b0 in space}
        self.reps = {}
        for x in space:
            if x in self.reps:
                continue
            coset = {((x[0]+y[0])%p,(x[1]+y[1])%p) for y in image}
            rep = min(coset)
            self.reps.update((z,rep) for z in coset)
        self.elements = sorted(set(self.reps.values()))
        assert len(self.elements) == (p if k==0 else 1)
        self.zero = self.reduce((0,0))
        self.mark = self.reduce((0,1))
        self.phase = (r+pow(unit,-1,p)*b) % p
        # Check that the inverse-coordinate value descends to the quotient.
        assert all(self.lam(z)==0 for z in image)

    def reduce(self,v):
        return self.reps[(v[0]%self.p,v[1]%self.p)]

    def lam(self,v):
        # Numerator of the last inverse-coordinate functional, denominator p.
        return 0 if self.k else (-self.r*v[0]) % self.p

    def combination(self,a,v,b,w):
        return self.reduce((a*v[0]+b*w[0],a*v[1]+b*w[1]))


def iso_count(source,target):
    if len(source.elements)!=len(target.elements):
        return 0
    count=0
    for v in target.elements:
        w=target.mark
        if any(target.combination(a,v,b,w)!=target.zero for a,b in source.columns):
            continue
        if target.lam(v)!=source.lam((1,0)) or target.lam(w)!=source.lam((0,1)):
            continue
        image={target.combination(a,v,b,w) for a,b in source.elements}
        if len(image)!=len(target.elements):
            continue
        count+=1
    return count


def reduce_phi(coeff):
    return [x-coeff[-1] for x in coeff[:-1]]


def case(p,unit,other):
    actual=[]
    formula=[]
    for k in range(p):
        lhs=[Border(p,unit,r,b,k) for r,b in product(range(p),repeat=2)
             if (r*b+k)%p==0]
        rhs=[Border(p,other,r,b,k) for r,b in product(range(p),repeat=2)
             if (r*b+k)%p==0]
        coefficients=[0]*p
        for z in lhs:
            for zz in rhs:
                coefficients[(z.phase-zz.phase)%p]+=iso_count(z,zz)
        independently=[0]*p
        iu,iv=pow(unit,-1,p),pow(other,-1,p)
        for theta in range(1,p):
            it=pow(theta,-1,p)
            for r,b in product(range(p),repeat=2):
                if (r*b+k)%p==0:
                    exponent=(r*(1-it)+(iu-iv*theta)*b)%p
                    independently[exponent]+=1
        assert reduce_phi(coefficients)==reduce_phi(independently)
        actual.append(reduce_phi(coefficients))
        formula.append(reduce_phi(independently))
    total=[sum(v[j] for v in actual) for j in range(p-1)]
    base_marked_iso=int(unit%p==other%p)
    expected=[p*p*base_marked_iso]+[0]*(p-2)
    assert total==expected
    return {'p':p,'first_unit':unit,'second_unit':other,
            'actual_border_kernel_by_class':actual,
            'finite_duality_formula_by_class':formula,
            'sum':total,'base_marked_isomorphism_count':base_marked_iso,
            'expected_cokernel_factors':p*p,
            'identity_and_exact_normalization_verified':True}


if __name__=='__main__':
    cases=[case(p,1,u) for p,units in ((2,(1,3)),(3,(1,2,4)),(5,(1,2,6)))
           for u in units]
    assert cases[0]['actual_border_kernel_by_class']==[[3],[1]]
    result={'scope':'Eight rank-one head pairs, giving 28 exact bordered-kernel comparisons over Q_2, Q_3 and Q_5. No claim of computational coverage of general ranks or nonmaximal orders.',
            'method':'Enumerated all marked isomorphisms of actual matrix cokernels, compared with independent finite-duality formula; exact reduction modulo Phi_p.',
            'cases':cases,'general_results':'proved in theta_parseval.tex, not inferred from these controls'}
    Path(__file__).with_name('theta_parseval_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print('Passed 28 exact bordered-kernel comparisons and eight Parseval normalization checks.')
