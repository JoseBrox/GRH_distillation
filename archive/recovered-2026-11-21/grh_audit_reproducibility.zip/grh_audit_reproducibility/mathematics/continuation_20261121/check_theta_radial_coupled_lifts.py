"""Exact controls for the two terminal-coupled polynomial lifts.

The differential controls use actual GL_n right vector fields and finite
Taylor jets, independently of the bordered-minor recurrence.  The exterior
controls use exact rational Gaussian unitary matrices.  These finite tests
check conventions; the manuscript supplies the general proofs.
"""
from fractions import Fraction as Q
from itertools import combinations, permutations
from pathlib import Path
import ast
import hashlib
import json
import sympy as sp

HERE = Path(__file__).resolve().parent
# Reuse only the independently written exact jet definitions, without
# executing or regenerating the earlier file's test run.
tree = ast.parse((HERE / "check_theta_radial_differential_lifts.py").read_text())
defs = [n for n in tree.body if isinstance(n, (ast.Import, ast.ImportFrom,
                                             ast.ClassDef, ast.FunctionDef))]
exec(compile(ast.Module(body=defs, type_ignores=[]), "jet_definitions", "exec"))

counts = {}
def checked(name, actual, wanted):
    if isinstance(actual, sp.MatrixBase):
        diff = (actual-wanted).applyfunc(sp.cancel)
        assert diff == sp.zeros(*diff.shape), (name, diff)
    elif isinstance(actual, sp.Expr):
        assert sp.cancel(actual-wanted) == 0, (name, actual, wanted)
    else:
        assert actual == wanted, (name, actual, wanted)
    counts[name] = counts.get(name, 0)+1

def minor_jet(X, I, J, u, F):
    ans = Jet()
    for perm in permutations(range(len(I))):
        v = F
        for b in reversed(range(len(I))):
            i, j = I[perm[b]], J[b]
            v = right(X, i, j, v)+(u-b)*v if i == j else right(X, i, j, v)
        ans += sign(perm)*v
    return ans

for n in (2, 3):
    for trial in range(2):
        c = [Q(3+trial+2*i, i+1) for i in range(n)]
        lam = [(trial+i) % 3 for i in range(n)]
        X, F = gauss_function(n, c, lam)
        for e in (0, n-1):
            other = [i for i in range(n) if i != e]
            for q in range(n):
                for I in permutations(other, q):
                    for J in permutations(other, q):
                        for u in (Q(-2), Q(5, 2)):
                            if e == 0:
                                actual = minor_jet(X, (e,)+I, (e,)+J, u, F).constant()
                                base = minor_jet(X, I, J, u-1, F)
                                wanted = (u*base+right(X, e, e, base)).constant()
                                for a, i in enumerate(I):
                                    for b, j in enumerate(J):
                                        ell = c[i]/c[e] if i == e+1 else Q(0)
                                        rr = Q(1) if j == e+1 else Q(0)
                                        wanted -= (-1)**(a+b)*ell*rr*minor_jet(
                                            X, I[:a]+I[a+1:], J[:b]+J[b+1:], u-2, F).constant()
                                checked("first_bordered_actual_vector_fields", actual, wanted)
                            else:
                                actual = minor_jet(X, I+(e,), J+(e,), u, F).constant()
                                wanted = minor_jet(X, I, J, u,
                                    (u-q)*F+right(X, e, e, F)).constant()
                                for a, i in enumerate(I):
                                    for b, j in enumerate(J):
                                        rr = Q(1) if i+1 == e else Q(0)
                                        ell = c[e]/c[j] if j+1 == e else Q(0)
                                        wanted -= (-1)**(a+b)*rr*ell*minor_jet(
                                            X, I[:a]+I[a+1:], J[:b]+J[b+1:], u, F).constant()
                                checked("last_bordered_actual_vector_fields", actual, wanted)

# Check the boundary contraction coefficient by coefficient in independent
# formal omitted-pair symbols, rather than at a particular minor value.
for d in range(2, 7):
    b = [Q(2*i+1) for i in range(d)]
    bp = [Q(i*i+3) for i in range(d)]
    a = [Q(3*i+2) for i in range(d)]
    ap = [Q(i*i+2*i+5) for i in range(d)]
    for rows in combinations(range(d), 2):
        for cols in combinations(range(d), 2):
            i, ip = rows; j, jp = cols
            target = -(-1)**(i+ip+j+jp)*(b[i]*bp[ip]-b[ip]*bp[i])*(a[j]*ap[jp]-a[jp]*ap[j])
            plus = minus = Q(0)
            for s, ii in (rows, rows[::-1]):
                for t, jj in (cols, cols[::-1]):
                    sg = (-1)**(s+t+ii-(ii>s)+jj-(jj>t))
                    plus += sg*bp[s]*a[t]*b[ii]*ap[jj]
                    minus += sg*b[s]*ap[t]*bp[ii]*a[jj]
            checked("terminal_boundary_plus", plus, target)
            checked("terminal_boundary_minus", minus, target)

def clean(A):
    return A.applyfunc(sp.cancel) if isinstance(A, sp.MatrixBase) else sp.cancel(A)

def setup(k, r):
    n = 2*r+k+1; H = sp.zeros(n)
    for i in range(r): H[i,n-1-i] = H[n-1-i,i] = 1
    for i in range(k): H[r+i,r+i] = 1
    H[r+k,r+k] = -1
    z = sp.eye(n)[:,r+k]
    return n,H,z

def cayley(H, seed):
    n = H.rows; A = sp.zeros(n)
    i,j = seed%n,(3*seed+1)%n
    if i == j:j=(j+1)%n
    A[i,j]=(1+sp.I)/3
    X=H*(A-A.conjugate().T)
    return clean((sp.eye(n)-X).inv()*(sp.eye(n)+X))

def coeffs(k,r,g):
    n,H,z=setup(k,r); eye=sp.eye(n); M=r+k
    gi=clean(H*g.conjugate().T*H)
    fixed=sp.Matrix.hstack(*[gi[:,i] for i in reversed(range(r))], gi*z)
    fixedrow=sp.Matrix.vstack(*[(eye[:,i].T*H*g) for i in range(r)], z.T*H*g)
    B={};A={}
    for J in combinations(range(n),M):
        B[J]=clean(fixed.row_join(eye[:,J]).det())
        A[J]=clean(fixedrow.col_join(eye[list(J),:]).det())
    return B,A

for k,r in ((1,0),(1,1),(2,1),(1,2)):
    n,H,z=setup(k,r); eye=sp.eye(n); M=r+k
    c=[sp.Rational(i+2,2)+sp.I/3 for i in range(r)]
    bc=eye.copy()
    for i,v in enumerate(c):
        j=n-1-i;bc[i,i]=bc[j,j]=0;bc[j,i]=v;bc[i,j]=1/sp.conjugate(v)
    JH=sp.diag(*([1]*k+[-1]));mw=cayley(JH,1)
    m=eye.copy();m[r:r+k+1,r:r+k+1]=mw
    g=clean(bc*m);B,A=coeffs(k,r,g);avec=clean(mw.inv()*sp.eye(k+1)[:,k])
    bvec=clean(avec.conjugate().T*JH);ac=sp.prod(c);sigma=(-1)**(r*(k+1))
    for inds in B:
        expectedB=expectedA=0
        for t in range(k+1):
            Ip=tuple(range(r))+tuple(r+i for i in range(k+1) if i!=t)
            Jp=tuple(r+i for i in range(k+1) if i!=t)+tuple(range(r+k+1,n))
            if inds==Ip: expectedB=sigma*(-1)**t*sp.conjugate(ac)*avec[t]
            if inds==Jp: expectedA=(-1)**t*ac*bvec[t]
        checked("exact_cell_B",B[inds],expectedB)
        checked("exact_cell_A",A[inds],expectedA)
    # An exact nontrivial compact determinant tests the character factors.
    s=eye.copy();s[r,r]=(3+4*sp.I)/5
    if r:
        N=eye.copy();ii=r-1;jj=n-1-ii
        v=sp.Matrix([sp.Rational(i+1,3)+sp.I/5 for i in range(k+1)])
        top=clean(-v.conjugate().T*JH)
        for i in range(k+1):N[ii,r+i]=top[i];N[r+i,jj]=v[i]
        N[ii,jj]=clean(-(v.conjugate().T*JH*v)[0]/2+sp.I/7)
        s=clean(s*N)
    checked("right_symmetry_unitary",clean(s.conjugate().T*H*s),H)
    Bp,Ap=coeffs(k,r,clean(g*s));si=clean(s.inv());det=clean(s.det())
    for L in B:
        rhs=sum(B[J]*s.extract(J,L).det() for J in B)
        checked("exterior_covariance_B",rhs,det*Bp[L])
        rhs=sum(si.extract(L,J).det()*A[J] for J in A)
        checked("exterior_covariance_A",rhs,Ap[L]/det)

result={"arithmetic":"Exact rational Taylor jets and rational Gaussian matrices",
        "counts":counts,"total":sum(counts.values()),
        "manuscript_sha256":hashlib.sha256((HERE/"theta_radial_coupled_lifts.tex").read_bytes()).hexdigest(),
        "status":"All controls passed; the general identities rest on the manuscript proofs."}
(HERE/"theta_radial_coupled_lifts_checks.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
