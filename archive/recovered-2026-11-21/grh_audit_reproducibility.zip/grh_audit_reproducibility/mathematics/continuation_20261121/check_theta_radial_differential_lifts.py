"""Exact independent checks of the Capelli radial recurrence.

We work with actual right vector fields on GL_n and the function
 exp(sum simple entries of L + sum simple entries of U) prod d_i^lambda_i
in the Gauss decomposition X=L diag(d) U.  Its two Whittaker laws are
literal matrix identities.  Finite Taylor jets compute the differential
operator, independently of the determinant recurrence in the manuscript.
"""
from fractions import Fraction as Q
from itertools import permutations
from pathlib import Path
import hashlib
import json
import math

class Jet:
    n = 0
    degree = 0
    zero = ()
    def __init__(self, terms=None):
        if isinstance(terms, (int,Q)):
            terms = {self.zero:Q(terms)} if terms else {}
        self.a = {e:Q(c) for e,c in (terms or {}).items() if c}
    @classmethod
    def variable(cls,i):
        e=[0]*cls.n;e[i]=1
        return cls({tuple(e):1})
    def __add__(self,o):
        if not isinstance(o,Jet):o=Jet(o)
        a=self.a.copy()
        for e,c in o.a.items():a[e]=a.get(e,Q(0))+c
        return Jet(a)
    __radd__=__add__
    def __neg__(self):return Jet({e:-c for e,c in self.a.items()})
    def __sub__(self,o):return self+-o if isinstance(o,Jet) else self+(-o)
    def __rsub__(self,o):return -self+o
    def __mul__(self,o):
        if not isinstance(o,Jet):o=Jet(o)
        a={}
        for e,c in self.a.items():
            for f,d in o.a.items():
                ef=tuple(x+y for x,y in zip(e,f))
                if sum(ef)<=self.degree:a[ef]=a.get(ef,Q(0))+c*d
        return Jet(a)
    __rmul__=__mul__
    def __pow__(self,n):
        assert isinstance(n,int)
        if n<0:return self.inverse()**(-n)
        ans=Jet(1);b=self
        while n:
            if n&1:ans=ans*b
            b=b*b;n//=2
        return ans
    def constant(self):return self.a.get(self.zero,Q(0))
    def inverse(self):
        c=self.constant();assert c
        u=(self-c)*(-1/c)
        ans=Jet(1);v=Jet(1)
        for j in range(1,self.degree+1):
            v=v*u;ans=ans+v
        return ans*(1/c)
    def __truediv__(self,o):
        return self*(o.inverse() if isinstance(o,Jet) else 1/Q(o))
    def derivative(self,i):
        ans={}
        for e,c in self.a.items():
            if e[i]:
                f=list(e);f[i]-=1
                ans[tuple(f)]=c*e[i]
        return Jet(ans)
    def exp0(self):
        assert not self.constant()
        ans=Jet(1);v=Jet(1)
        for j in range(1,self.degree+1):
            v=v*self/j;ans=ans+v
        return ans

def gauss_function(n,c,lam):
    Jet.n=n*n;Jet.degree=n;Jet.zero=(0,)*(n*n)
    X=[[Jet.variable(i*n+j)+(c[i] if i==j else 0)
        for j in range(n)] for i in range(n)]
    L=[[Jet(int(i==j)) for j in range(n)] for i in range(n)]
    U=[[Jet(int(i==j)) for j in range(n)] for i in range(n)]
    d=[]
    for i in range(n):
        d.append(X[i][i]-sum((L[i][a]*d[a]*U[a][i] for a in range(i)),Jet()))
        for j in range(i+1,n):
            U[i][j]=(X[i][j]-sum((L[i][a]*d[a]*U[a][j] for a in range(i)),Jet()))/d[i]
            L[j][i]=(X[j][i]-sum((L[j][a]*d[a]*U[a][i] for a in range(i)),Jet()))/d[i]
    z=sum((L[i+1][i]+U[i][i+1] for i in range(n-1)),Jet())
    F=z.exp0()
    for di,li in zip(d,lam):F=F*di**li
    for i in range(n):
        for j in range(n):
            actual=sum((L[i][a]*d[a]*U[a][j] for a in range(n)),Jet())
            assert (actual-X[i][j]).a=={}
    return X,F

def right(X,a,b,F):
    n=len(X)
    return sum((X[l][a]*F.derivative(l*n+b) for l in range(n)),Jet())

def sign(p):
    return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))

def qminor(X,I,J,u,F):
    ans=Jet()
    for p in permutations(range(len(I))):
        v=F
        for b in reversed(range(len(I))):
            i,j=I[p[b]],J[b]
            v=right(X,i,j,v)+(u-b)*v if i==j else right(X,i,j,v)
        ans=ans+sign(p)*v
    return ans.constant()

def matchings(n):
    if n==0:return [((),())]
    if n==1:return [((),(0,))]
    out=[]
    for es,vs in matchings(n-1):out.append((es,vs+(n-1,)))
    for es,vs in matchings(n-2):out.append((es+(n-2,),vs))
    return out

def expected(c,lam,u,s):
    val=Q(0)
    for es,vs in matchings(s):
        v=Q(1)
        for i in es:v*=-c[i+1]/c[i]
        for i in vs:v*=u-i+lam[i]
        val+=v
    for ci,li in zip(c,lam):val*=ci**li
    return val

counts={"Gauss_jet_factorizations":0,"actual_right_derivative_Capelli":0,
        "gauged_diagonal_shifts":0,"mirror_diagonal_shifts":0,
        "matching_reversal":0,"empty_rank":0}
for n in range(1,4):
    for trial in range(3):
        c=[Q(2*i+3+trial, i+1) for i in range(n)]
        lam=[(2*i+trial)%4 for i in range(n)]
        X,F=gauss_function(n,c,lam)
        counts["Gauss_jet_factorizations"]+=1
        for u in (Q(-2),Q(3,2)):
            for s in range(1,n+1):
                actual=qminor(X,list(range(s)),list(range(s)),u,F)
                want=expected(c,lam,u,s)
                assert actual==want,(n,trial,s,u,actual,want)
                counts["actual_right_derivative_Capelli"]+=1
for r in range(8):
    for k in range(1,5):
        Y=Q(7,3)
        u=Y+Q(2*r+k,2);w=Y-Q(2*r+k,2)+r-1
        for i in range(1,r+1):
            ni=2*(r-i+1)+k
            assert u-i+1-Q(ni,2)==Y
            counts["gauged_diagonal_shifts"]+=1
            assert w-(r-i)+Q(ni,2)==Y
            counts["mirror_diagonal_shifts"]+=1
        edges={tuple(sorted(es)) for es,vs in matchings(r)}
        rev={tuple(sorted(r-2-i for i in es)) for es,vs in matchings(r)}
        assert edges==rev
        counts["matching_reversal"]+=1
        if r==0:
            assert matchings(r)==[((),())]
            counts["empty_rank"]+=1

out=Path(__file__).resolve().parent
result=dict(arithmetic="Exact rational Taylor jets of actual GL_n right derivatives",
            counts=counts,total=sum(counts.values()),
            manuscript_sha256=hashlib.sha256((out/"theta_radial_differential_lifts.tex").read_bytes()).hexdigest(),
            status="All controls passed; general results rest on the displayed proofs.")
(out/"theta_radial_differential_lifts_checks.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
