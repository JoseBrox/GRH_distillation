"""Exact controls for the radial differential identities.

The general theorems are proved in theta_radial_fourier.tex.
Here t and b are independent Laurent variables with b representing bar(t).
All coefficients are rational Gaussian numbers; no numerical tolerance is used.
"""
from itertools import combinations, permutations, product
from pathlib import Path
import hashlib
import json
import sympy as sp

t, b = sp.symbols("t b", nonzero=True)
I = sp.I
counts = {}


def check(name, value):
    assert sp.expand(value) == 0, (name, sp.expand(value))
    counts[name] = counts.get(name, 0) + 1


def bar(f):
    return sp.conjugate(f).xreplace({sp.conjugate(t): b, sp.conjugate(b): t})


def pair(u, v):
    return sp.expand(sum(x * bar(y) for x, y in zip(u, v)) / (t * b))


def op(v, letter, kind):
    a, sig, Y = letter
    out = [sp.Integer(0)] * len(v)
    mask = 1 << a
    for j in range(len(v)):
        if j & mask:
            continue
        x, y = v[j], v[j | mask]
        if kind == "V" and sig == "+":
            v0, v1 = Y*x + t*sp.diff(x, t) - t*y, x/t
        elif kind == "V" and sig == "-":
            v0, v1 = Y*x - b*sp.diff(x, b) - b*y, x/b
        elif kind == "I" and sig == "+":
            v0, v1 = -y/b, b*x + (Y+1)*y - b*sp.diff(y, b)
        elif kind == "I" and sig == "-":
            v0, v1 = -y/t, t*x + (Y-1)*y + t*sp.diff(y, t)
        elif kind == "S" and sig == "+":
            v0, v1 = Y*x - b*sp.diff(x, b) + y/b, -b*x
        elif kind == "S" and sig == "-":
            v0, v1 = Y*x + t*sp.diff(x, t) + y/t, -t*x
        else:
            raise AssertionError((sig, kind))
        out[j], out[j | mask] = sp.expand(v0), sp.expand(v1)
    return out


def word(v, w, kind):
    for letter in reversed(w):
        v = op(v, letter, kind)
    return v


def elementary(v, a):
    mask = 1 << a
    return [v[j ^ mask] if j & mask else sp.Integer(0) for j in range(len(v))]


def subset_side(u, v, w):
    result = sp.Integer(0)
    for n in range(len(w)+1):
        for J in combinations(range(len(w)), n):
            vv = v
            for j in J:
                vv = elementary(vv, w[j][0])
            term = pair(u, vv)
            for j in J:
                term = -sp.diff(term, b) if w[j][1] == "+" else sp.diff(term, t)
            result += term
    return sp.expand(result)


def sample(d, offset):
    return [
        sp.Rational(j+offset+1, j+2) * t**((j+offset) % 3-1) * b**((2*j+offset) % 3-1)
        + (1+I*(j+1))*t**((j+1) % 2)*b**((j+offset) % 2)
        for j in range(d)
    ]


for h in range(1, 4):
    u, v = sample(2**h, 1), sample(2**h, 2)
    for slots in permutations(range(h)):
        for signs in product("+-", repeat=h):
            w = [(a, sig, [-2, 0, 3][j]) for j, (a, sig) in enumerate(zip(slots, signs))]
            check("full_subset_density", pair(word(u, w, "I"), word(v, w, "V"))
                  - subset_side(u, v, w))
            left_inverse = word(word(v, list(reversed(w)), "S"), w, "I")
            for x, y in zip(left_inverse, v):
                check("word_inverse_formal_adjoint", x-y)

# Both orders of the elementary formal-adjoint inverse.
for sig in "+-":
    for Y in [-3, 0, 2]:
        letter = (0, sig, Y)
        u = sample(2, 3)
        for first, second in [("I", "S"), ("S", "I")]:
            for x, y in zip(op(op(u, letter, second), letter, first), u):
                check("two_sided_elementary_inverse", x-y)

# Exact counterexample to omitting distinct component indices.
u, v = [sp.Integer(0), sp.Integer(1)], [sp.Integer(1), sp.Integer(0)]
w = [(0, "+", 0), (0, "+", 0)]
actual = pair(word(u, w, "I"), word(v, w, "V"))
claimed = subset_side(u, v, w)
check("repeated_index_actual", actual-1/(t*b**2))
check("repeated_index_failed_formula", claimed-2/(t*b**2))
assert sp.expand(actual-claimed) != 0

# The weight derivative coefficient estimate is checked independently by
# differentiating the rational function and clearing the exact denominator.
x, y = sp.symbols("x y", real=True)
weight = (1+x*x+y*y)**(-2)
for j in range(7):
    bound = sp.prod(5*v+4 for v in range(j))
    for a in range(j+1):
        expr = sp.diff(weight, x, a, y, j-a)
        numerator = sp.Poly(sp.cancel(expr*(1+x*x+y*y)**(2+j)), x, y)
        assert numerator.total_degree() <= j
        assert sum(abs(c) for c in numerator.coeffs()) <= bound
        counts["weight_derivative_coefficient_bound"] = counts.get("weight_derivative_coefficient_bound", 0)+1

out = Path(__file__).resolve().parent
manuscript = out/"theta_radial_fourier.tex"
result = {
    "arithmetic": "exact rational and Gaussian-rational Laurent arithmetic in SymPy",
    "counts": counts,
    "total": sum(counts.values()),
    "manuscript_sha256": hashlib.sha256(manuscript.read_bytes()).hexdigest(),
    "status": "All controls passed. General conclusions rest on the displayed proofs.",
}
(out/"theta_radial_fourier_checks.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result, indent=2))
