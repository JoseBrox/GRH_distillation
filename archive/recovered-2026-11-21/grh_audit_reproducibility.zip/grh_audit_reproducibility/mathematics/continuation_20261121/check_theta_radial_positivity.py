"""Exact controls for the proved Capelli and terminal-positivity identities.

All equalities use rational/Gaussian-rational SymPy arithmetic.  These
finite controls check conventions; the general results rest on the
displayed proofs in theta_radial_positivity.tex.
"""
from collections import Counter
from functools import lru_cache
from itertools import combinations, permutations, product
from pathlib import Path
import json
import sympy as s

OUT = Path(__file__).resolve().parent
COUNTS = Counter()


def check(name, condition):
    if not condition:
        raise AssertionError(name)
    COUNTS[name] += 1


def eqmat(a, b):
    return all(s.expand(x) == 0 for x in a - b)


def parity(p):
    return (-1) ** sum(p[i] > p[j] for i in range(len(p)) for j in range(i + 1, len(p)))


def fundamental(n):
    return [[s.eye(n)[:, a] * s.eye(n)[b, :] for b in range(n)] for a in range(n)]


def tensor_square(n):
    a = fundamental(n)
    return [[s.kronecker_product(a[i][j], s.eye(n))
             + s.kronecker_product(s.eye(n), a[i][j])
             for j in range(n)] for i in range(n)]


def wedge(n, degree):
    basis = list(combinations(range(n), degree))
    index = {v: i for i, v in enumerate(basis)}
    e = [[s.zeros(len(basis)) for _ in range(n)] for _ in range(n)]
    for a, b in product(range(n), repeat=2):
        for col, word in enumerate(basis):
            for pos, value in enumerate(word):
                if value != b:
                    continue
                new = word[:pos] + (a,) + word[pos + 1:]
                if len(set(new)) < degree:
                    continue
                sorted_word = tuple(sorted(new))
                e[a][b][index[sorted_word], col] += parity(new)
    return e


def minor_function(e):
    dim = e[0][0].rows

    @lru_cache(None)
    def q(rows, cols, u):
        ans = s.zeros(dim)
        for p in permutations(range(len(rows))):
            term = s.eye(dim)
            for a, j in enumerate(cols):
                i = rows[p[a]]
                term *= e[i][j] + ((u - a) * s.eye(dim) if i == j else s.zeros(dim))
            ans += parity(p) * term
        return ans.applyfunc(s.expand)
    return q


def transform(e, p):
    n, dim = len(e), e[0][0].rows
    r = p.inv()
    return [[sum((p[c, a] * r[b, d] * e[c][d]
                  for c, d in product(range(n), repeat=2)), s.zeros(dim))
             for b in range(n)] for a in range(n)]


def contraction(e, q, u, a, ap, beta, betap):
    n, dim = len(e), e[0][0].rows
    ans = s.zeros(dim)
    for ii, jj in product(combinations(range(n), 2), repeat=2):
        i, ip = ii
        j, jp = jj
        rows = tuple(x for x in range(n) if x not in ii)
        cols = tuple(x for x in range(n) if x not in jj)
        scalar = ((-1) ** (i + ip + j + jp)
                  * (beta[i] * betap[ip] - beta[ip] * betap[i])
                  * (a[j] * ap[jp] - a[jp] * ap[j]))
        ans += scalar * q(rows, cols, u)
    return ans


u = s.Symbol("u", real=True)
models = [(f"standard_{n}", fundamental(n), [1] + [0] * (n - 1)) for n in range(1, 5)]
models += [(f"tensor_square_{n}", tensor_square(n), [2] + [0] * (n - 1)) for n in (2, 3)]
models += [("exterior_square_3", wedge(3, 2), [1, 1, 0])]
for name, e, lam in models:
    n, dim = len(e), e[0][0].rows
    zero = s.zeros(dim)
    for a, b, c, d in product(range(n), repeat=4):
        rhs = (e[a][d] if b == c else zero) - (e[c][b] if d == a else zero)
        check("general_linear_relation", eqmat(e[a][b] * e[c][d] - e[c][d] * e[a][b], rhs))
    for a, b in product(range(n), repeat=2):
        check("generator_adjoint", eqmat(e[a][b].conjugate().T, e[b][a]))
    q = minor_function(e)
    inds = tuple(range(n))
    cap = q(inds, inds, u)
    highest = s.eye(dim)[:, 0]
    eigen = s.prod(u - a + lam[a] for a in range(n))
    check("highest_weight_polynomial", eqmat(cap * highest, eigen * highest))
    for a, b in product(range(n), repeat=2):
        check("centrality", eqmat(cap * e[a][b], e[a][b] * cap))
    negative = s.zeros(dim)
    for perm in permutations(range(n)):
        term = s.eye(dim)
        for a in range(n):
            term *= ((u + a) * s.eye(dim) if perm[a] == a else zero) - e[perm[a]][a]
        negative += parity(perm) * term
    check("negative_convention", eqmat(negative, (-1) ** n * cap.subs(u, -u)))
    check("negative_highest_weight", eqmat(negative * highest, s.prod(u + a - lam[a] for a in range(n)) * highest))
    for degree in range(n + 1):
        for rows, cols in product(combinations(range(n), degree), repeat=2):
            for val in (s.Rational(-2), s.Rational(3, 2), 2 + s.I):
                check("minor_adjoint",
                      eqmat(q(rows, cols, val).conjugate().T, q(cols, rows, s.conjugate(val))))

for n in (2, 3, 4):
    e = fundamental(n)
    p = s.eye(n)
    for a in range(n - 1):
        p[a, a + 1] = a + 1
    lower = s.eye(n)
    lower[n - 1, 0] = 2
    p = lower * p
    r = p.inv()
    ep = transform(e, p)
    q, qp = minor_function(e), minor_function(ep)
    for degree in range(n + 1):
        sets = list(combinations(range(n), degree))
        detp = {(aa, ii): p.extract(aa, ii).det() for aa, ii in product(sets, repeat=2)}
        detr = {(jj, bb): r.extract(jj, bb).det() for jj, bb in product(sets, repeat=2)}
        for ii, jj in product(sets, repeat=2):
            for val in (s.Rational(0), s.Rational(3, 2)):
                rhs = sum((detp[aa, ii] * detr[jj, bb] * q(aa, bb, val)
                           for aa, bb in product(sets, repeat=2)
                           if detp[aa, ii] and detr[jj, bb]), s.zeros(n))
                check("all_minor_covariance", eqmat(qp(ii, jj, val), rhs))
    a, ap = p[:, 0], p[:, 1]
    beta = 2 * r[0, :] + 3 * r[1, :]
    betap = -r[0, :] + 5 * r[1, :]
    determinant = (beta * a)[0] * (betap * ap)[0] - (beta * ap)[0] * (betap * a)[0]
    tail = tuple(range(2, n))
    for val in (s.Rational(-2), s.Rational(0), s.Rational(3, 2)):
        lhs = contraction(e, q, val, a, ap, beta, betap)
        check("adapted_complementary_contraction", eqmat(lhs, determinant * qp(tail, tail, val)))

# Rational Lorentz boosts: G=16/9, all complements and signs are exact.
for n in (2, 3, 4):
    k = n - 1
    h = s.diag(*([1] * k + [-1]))
    g = s.eye(n)
    g[0, 0] = g[n - 1, n - 1] = s.Rational(5, 3)
    g[0, n - 1] = g[n - 1, 0] = s.Rational(4, 3)
    check("unitary_boost", eqmat(g.T * h * g, h))
    x = s.eye(n)[:, n - 1]
    y = g.inv() * x
    beta, betap = y.T * h, x.T * h
    p = s.Matrix.hstack(y, x, *(s.eye(n)[:, a] for a in range(1, n - 1)))
    e = fundamental(n)
    q = minor_function(e)
    ep = transform(e, p)
    qp = minor_function(ep)
    tail = tuple(range(2, n))
    for yy in (-2, 0, s.Rational(3, 2)):
        val = yy + s.Rational(k - 2, 2)
        entry = -contraction(e, q, val, y, x, beta, betap)
        check("actual_terminal_sign_and_shift", eqmat(entry, s.Rational(16, 9) * qp(tail, tail, val)))

# Idempotents on evaluated maps, including an unused negative eigenvalue.
nodes = [-1, 2]
c = s.diag(-1, 2, -100)
f = s.Matrix([[1, 2 + s.I, 0], [-s.I, 3, 0]])
projections = []
for rho in range(2):
    ell = (c - nodes[1 - rho] * s.eye(3)) / (nodes[rho] - nodes[1 - rho])
    projections.append(f * ell)
check("evaluated_projection_sum", eqmat(sum(projections, s.zeros(2, 3)), f))
hs = lambda a, b: s.simplify(s.trace(b.conjugate().T * a))
check("evaluated_projection_orthogonality", hs(projections[0], projections[1]) == 0)
weights = [3, 5]
lhs = hs(sum((weights[i] * projections[i] for i in range(2)), s.zeros(2, 3)), f)
rhs = sum(weights[i] * hs(projections[i], projections[i]) for i in range(2))
check("exact_positive_decomposition", s.simplify(lhs - rhs) == 0)
check("unused_spectrum_may_be_negative", s.Rational(2, 3) * (-100) + s.Rational(11, 3) < 0)

# A few exact scalar parameters check margins and all signs in the recursion.
uu, vv = [30, 10, -10], [24, 4, -16]
lo = [max(uu[i + 1], vv[i + 1]) + s.Rational(1, 2) for i in range(2)]
hi = [min(uu[i], vv[i]) - s.Rational(1, 2) for i in range(2)]
rho_sets = [[a + j for j in range(int(b - a) + 1)] for a, b in zip(lo, hi)]
q0 = lambda y: -s.prod((y + s.Rational(1, 2) + a) * (y + s.Rational(1, 2) + b)
                       for a, b in zip(uu, vv))
for ell in range(3):
    center = -s.Rational(uu[ell] + vv[ell], 2)
    for rho in product(*rho_sets):
        pp = lambda y: (-1) ** (3 - (ell + 1)) * s.prod(y + rr for rr in rho)
        for shift in (-1, 0, 1):
            check("interlacing_signed_value", pp(center + shift) > 0)
        check("interlacing_q_value", q0(center) > 0 and q0(center - 1) > 0)
check("self_adjoint_is_not_positive", s.Rational(-1) < 0)
check("distinct_parameters_do_not_prevent_pole", s.Rational(1) - 0 - 1 == 0)

result = {
    "arithmetic": "exact rational and Gaussian-rational matrix/polynomial arithmetic using SymPy",
    "models": [name for name, _, _ in models],
    "checks": dict(COUNTS),
    "total_checks": sum(COUNTS.values()),
    "status": "passed",
    "scope": "Finite convention controls only; the general identities and positivity are proved in the TeX fragment.",
}
(OUT / "theta_radial_positivity_checks.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
