"""Exact controls for the regular full-group spectral coefficient.

All matrices use rational Gaussian entries.  The universal assertions are
proved in theta_radial_spectral_lift.tex; these cases check conventions.
"""
from itertools import permutations
from pathlib import Path
import hashlib
import json
import random
import sympy as sp

rng = random.Random(20261121)
counts = {}


def clean(A):
    if isinstance(A, sp.MatrixBase):
        return A.applyfunc(sp.cancel)
    return sp.cancel(A)


def check(name, a, b=0):
    v = clean(a-b)
    ok = v == sp.zeros(*v.shape) if isinstance(v, sp.MatrixBase) else v == 0
    assert ok, (name, v)
    counts[name] = counts.get(name, 0)+1


def data(k, r):
    n = 2*r+k+1
    H = sp.zeros(n)
    for i in range(r):
        H[i, r+k+1+i] = H[r+k+1+i, i] = 1
    for i in range(k):
        H[r+i, r+i] = 1
    H[r+k, r+k] = -1
    e = sp.eye(n)
    z = e[:, r+k]
    f = e[:, :r].row_join(z)
    return H, z, f


def cayley(H, seed):
    n = H.rows
    A = sp.zeros(n)
    i, j = seed % n, (seed*3+1) % n
    if i == j:
        j = (j+1) % n
    A[i, j] = [sp.Rational(1, 3), sp.I/3, (1+sp.I)/4][seed % 3]
    X = H*(A-A.conjugate().T)
    return clean((sp.eye(n)-X).inv()*(sp.eye(n)+X))


def geom(k, r, g):
    H, z, f = data(k, r)
    Z = clean(f.conjugate().T*H*g*f)
    D, d = clean(Z.det()), clean(Z[:r, :r].det())
    G = clean(D*sp.conjugate(D)-d*sp.conjugate(d))
    L = clean(f*Z.adjugate()[r, :].conjugate().T)
    y = clean(H*g.conjugate().T*H*L)
    om = y[r:r+k, 0]
    return Z, D, d, G, L, y, om


def positive_compact(k, r, seed):
    H, z, f = data(k, r)
    h = sp.eye(H.rows)
    U = cayley(sp.eye(k), seed) if k > 1 else sp.Matrix([[sp.I]])
    h[r:r+k, r:r+k] = U
    return h, U


def unipotent(k, r, seed):
    H, z, f = data(k, r)
    n = sp.eye(H.rows)
    if r == 0:
        return n
    i = seed % r
    J = sp.diag(*([1]*k+[-1]))
    v = sp.Matrix([sp.Rational((seed+j) % 3-1, 3)+sp.I*sp.Rational(j % 2, 4)
                   for j in range(k+1)])
    top = clean(-v.conjugate().T*J)
    for j in range(k+1):
        n[i, r+j] = top[j]
        n[r+j, r+k+1+i] = v[j]
    n[i, r+k+1+i] = clean(-(v.conjugate().T*J*v)[0]/2+sp.I/5)
    check("unipotent_unitary", n.conjugate().T*H*n, H)
    return n


def sign_perm(p):
    return (-1)**sum(p[i] > p[j] for i in range(len(p)) for j in range(i+1, len(p)))


def minor(k, rows, cols, u):
    out = sp.zeros(k)
    for p in permutations(range(len(rows))):
        term = sp.eye(k)
        for a, j in enumerate(cols):
            i = rows[p[a]]
            E = sp.zeros(k); E[i, j] = 1
            term = term*((u-a)*int(i == j)*sp.eye(k)+E)
        out += sign_perm(p)*term
    return clean(out)


def cap(k, om, G, Y):
    out = sp.zeros(k)
    for i in range(k):
        for j in range(k):
            rows, cols = [a for a in range(k) if a != i], [a for a in range(k) if a != j]
            out += (-1)**(i+j)*sp.conjugate(om[i])*om[j]*minor(k, rows, cols, Y+sp.Rational(k-2, 2))/G
    return clean(out)


def inverse_polynomial(k, Y, sig):
    X = sp.Symbol("X")
    weights = [[0]*(k-1)]
    if k > 1:
        weights.append([1]+[0]*(k-2))
    eigen = [sp.prod(Y+sp.Rational(k-2, 2)-a+mu[a] for a in range(k-1)) for mu in weights]
    P = sp.prod(X-sig*p for p in eigen)
    return sp.Poly(sp.cancel((1-P/P.subs(X, 0))/X), X)


for k in range(1, 4):
    for r in range(3):
        H, z, f = data(k, r)
        n = H.rows
        # A radial cell followed by rational Cayley transformations.
        g = sp.eye(n)
        for j in range(6):
            g = clean(g*cayley(H, rng.randrange(1, 200)))
        Z, D, d, G, L, y, om = geom(k, r, g)
        check("group_unitary", clean(g.conjugate().T*H*g), H)
        check("cofactor_pairing", clean(f.conjugate().T*H*y),
              sp.Matrix([0]*r+[sp.conjugate(D)]))
        check("cofactor_norm", (y.conjugate().T*H*y)[0], -d*sp.conjugate(d))
        check("projected_norm", (om.conjugate().T*om)[0], G)
        assert sp.re(G) >= 0 and sp.im(G) == 0

        hL, _ = positive_compact(k, r, 7)
        hR, U = positive_compact(k, r, 12)
        nL, nR = unipotent(k, r, 3), unipotent(k, r, 8)
        gp = clean(hL.inv()*nL.inv()*g*nR*hR)
        Zp, Dp, dp, Gp, Lp, yp, omp = geom(k, r, gp)
        for j in range(r+2):
            check("leading_minor_invariance", Zp[:j, :j].det(), Z[:j, :j].det())
        check("cofactor_covariance", omp, clean(U.inv()*om))
        if G != 0:
            Y = sp.Rational(9, 2)
            C, Cp = cap(k, om, G, Y), cap(k, omp, Gp, Y)
            check("compact_capelli_covariance", Cp, clean(U.inv()*C*U))
            check("compact_capelli_self_adjoint", C, C.conjugate().T)
            for sig in [1, -1]:
                q = inverse_polynomial(k, Y, sig)
                qC = sp.zeros(k)
                for (j,), a in q.terms():
                    qC += a*(sig*C)**j
                check("spectral_inverse_fundamental", clean(qC*(sig*C)), sp.eye(k))

        # Independent direct radial-cell identities, including complex phases.
        c = [sp.Rational(j+2, 2)+sp.I/3 for j in range(r)]
        b = sp.eye(n)
        for j, v in enumerate(c):
            b[j, j] = b[r+k+1+j, r+k+1+j] = 0
            b[r+k+1+j, j] = v
            b[j, r+k+1+j] = 1/sp.conjugate(v)
        J = sp.diag(*([1]*k+[-1]))
        mw = cayley(J, 1)*cayley(J, 3)
        m = sp.eye(n); m[r:r+k+1, r:r+k+1] = mw
        gc = clean(b*m)
        Zc, Dc, dc, Gc, Lc, yc, omc = geom(k, r, gc)
        a = sp.prod(c)
        zet = (z.conjugate().T*H*m*z)[0]
        check("radial_cell_Z", Zc, sp.diag(*c, zet))
        check("radial_cell_Gram", Gc, clean(a*sp.conjugate(a)*(zet*sp.conjugate(zet)-1)))
        check("radial_cell_vector", omc, clean(sp.conjugate(a)*(m.inv()*z)[r:r+k, 0]))

# The allowed point with vanishing intermediate minor.
k = r = 1
H, z, f = data(k, r)
g = sp.Matrix([[0, sp.Rational(1,2), sp.Rational(1,2), 0],
               [1, 0, 0, sp.Rational(1,2)],
               [1, 0, 0, -sp.Rational(1,2)],
               [0, 1, -1, 0]])
check("singular_minor_group", g.T*H*g, H)
Z, D, d, G, L, y, om = geom(k, r, g)
check("singular_minor_Z", Z, sp.Matrix([[0,-1],[-1,0]]))
check("singular_minor_d", d, 0)
check("singular_minor_positive_Gram", G, 1)
check("singular_minor_vector", om, sp.Matrix([1]))

out = Path(__file__).resolve().parent
result = dict(arithmetic="exact rational Gaussian matrices in SymPy",
              counts=counts, total=sum(counts.values()),
              manuscript_sha256=hashlib.sha256((out/"theta_radial_spectral_lift.tex").read_bytes()).hexdigest(),
              status="All controls passed; the general assertions rest on the displayed proofs.")
(out/"theta_radial_spectral_lift_checks.json").write_text(json.dumps(result, indent=2)+"\n")
print(json.dumps(result, indent=2))
