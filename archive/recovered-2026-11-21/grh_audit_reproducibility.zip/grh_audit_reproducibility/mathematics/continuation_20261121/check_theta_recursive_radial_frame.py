#!/usr/bin/env python3
"""Exact checks of the Gauss identities and recursive radial congruence.

These controls are supplementary finite calculations, not a Lean kernel replay.
The first family uses noncommuting finite matrices.  The second uses genuine
two-variable differential operators and their formal adjoints.
"""
from pathlib import Path
import hashlib
import json
import sympy as s

BASE = Path(__file__).resolve().parent
counts = {}


def checked(name, condition):
    if not condition:
        raise AssertionError(name)
    counts[name] = counts.get(name, 0) + 1


def zm(A):
    return all(s.cancel(v) == 0 for v in A)


E = {}
for i in range(2):
    for j in range(2):
        M = s.zeros(2)
        M[i, j] = 1
        E[i, j] = M


def finite_t(u):
    return [[u*s.eye(2)+E[0, 0], E[0, 1]],
            [E[1, 0], u*s.eye(2)+E[1, 1]]]


def mat_product(A, B):
    return [[sum((A[i][j]*B[j][k] for j in range(2)), s.zeros(A[0][0].rows))
             for k in range(2)] for i in range(2)]


def finite_two_site(u):
    I = s.eye(2)
    A = [[s.kronecker_product(v, I) for v in row] for row in finite_t(u)]
    B = [[s.kronecker_product(I, v) for v in row]
         for row in finite_t(u-s.Rational(1, 3))]
    return mat_product(A, B)


def gauss(t, q, u):
    T = t(u)
    tau = T[1][1]
    l = tau.inv()*T[1][0]
    m = tau.inv()*T[0][1]
    H = q(u)*tau.inv()*t(u+1)[1][1].inv()
    return T, tau, l, m, H


for t, q in [
    (finite_t, lambda u: u*(u+2)),
    (finite_two_site, lambda u: u*(u+2)*(u-s.Rational(1, 3))*(u+s.Rational(5, 3))),
]:
    for u, v in [(s.Rational(5, 2), s.Rational(2, 3)),
                 (s.Rational(7, 3), s.Rational(4, 3)),
                 (s.Rational(4), s.Rational(5))]:
        T, tau, l, m, H = gauss(t, q, u)
        V, tv, lv, mv, Hv = gauss(t, q, v)
        um = gauss(t, q, u-1)
        up = gauss(t, q, u+1)
        D = u-v
        eta = (l-lv)/D
        mu = (m-mv)/D
        for i in range(2):
            for j in range(2):
                for k in range(2):
                    for h in range(2):
                        checked("finite RTT",
                            zm(D*(T[i][j]*V[k][h]-V[k][h]*T[i][j])
                               -T[k][j]*V[i][h]+V[k][j]*T[i][h]))
        checked("Gauss shift m", zm(up[3]-T[0][1]*tau.inv()))
        checked("Gauss shift l", zm(l-up[0][1][0]*up[1].inv()))
        checked("Schur plus", zm(T[0][0]-T[0][1]*tau.inv()*T[1][0]
                                -q(u)*up[1].inv()))
        checked("Schur minus", zm(T[0][0]-T[1][0]*tau.inv()*T[0][1]
                                 -q(u-1)*um[1].inv()))
        checked("tau l commutator", zm(tau*lv-lv*tau+tau*eta))
        checked("tau m commutator", zm(tau*mv-mv*tau-tau*mu))
        checked("l l commutator", zm(l*lv-lv*l-eta*(l-lv)))
        checked("mixed commutator", zm((D-1)*(m*lv-lv*m)-Hv+um[4]))

    for u, a in [(s.Rational(5), s.Rational(2)),
                 (s.Rational(3), s.Rational(6))]:
        T, tau, l, m, H = gauss(t, q, u)
        A, ta, la, ma, Ha = gauss(t, q, a)
        am = gauss(t, q, a-1)
        n = tau.rows
        I, Z = s.eye(n), s.zeros(n)
        D = u-a
        eta = (l-la)/D
        L = s.BlockMatrix([[I,Z],[la,I]]).as_explicit()
        U = s.BlockMatrix([[D*tau,Z],[-T[1][0],(D-1)*tau]]).as_explicit()/(D-1)
        V = s.BlockMatrix([[(D-1)*T[1][0],-tau],[Z,D*T[1][0]]]).as_explicit()/(D-1)
        target_tau = s.diag(D*tau/(D-1), tau)
        target_l = s.BlockMatrix([[l-eta,-I/D],[Z,l+eta]]).as_explicit()
        checked("finite plus tau", zm(L*U-target_tau*L))
        checked("finite plus lower", zm(L*V-target_tau*target_l*L))
        d = a-u
        M = s.BlockMatrix([[I,Z],[ma,I]]).as_explicit()
        U = s.BlockMatrix([[d*tau,Z],[-T[0][1],(d-1)*tau]]).as_explicit()/(d-1)
        V = s.BlockMatrix([[d*T[1][0],Z],[-T[0][0],(d-1)*T[1][0]]]).as_explicit()/(d-1)
        target_tau = s.diag(d*tau/(d-1), tau)
        target_l = s.BlockMatrix([[l,Z],[-am[4]/(d-1),l]]).as_explicit()
        checked("finite minus tau", zm(M*U-target_tau*M))
        checked("finite minus lower", zm(M*V-target_tau*target_l*M))

# The mixed identity needs u-1,u,v,v+1, but not u+1.
# At u=-2 the latter inverse is genuinely singular in the first model.
for t,q in [
    (finite_t, lambda u: u*(u+2)),
    (finite_two_site, lambda u: u*(u+2)*(u-s.Rational(1,3))*(u+s.Rational(5,3))),
]:
    u,v=s.Rational(-2),s.Rational(2)
    Tu,Tv=t(u),t(v)
    mu=Tu[1][1].inv()*Tu[0][1]
    lv=Tv[1][1].inv()*Tv[1][0]
    Hv=q(v)*Tv[1][1].inv()*t(v+1)[1][1].inv()
    Hum=q(u-1)*t(u-1)[1][1].inv()*Tu[1][1].inv()
    checked("mixed identity without upper inverse",
            zm((u-v-1)*(mu*lv-lv*mu)-Hv+Hum))


# Exact Weyl algebra in two independent complex coordinate symbols.
z, zb = s.symbols("z zb")
vars_ = (z, zb)


class DO:
    def __init__(self, coeffs=None):
        self.c = {a: s.cancel(v) for a, v in (coeffs or {}).items() if v != 0}
        self.c = {a: v for a, v in self.c.items() if v != 0}

    @staticmethod
    def asdo(x):
        return x if isinstance(x, DO) else DO({(0, 0): x})

    def __add__(self, other):
        other = self.asdo(other)
        d = self.c.copy()
        for a, v in other.c.items():
            d[a] = d.get(a, 0)+v
        return DO(d)

    __radd__ = __add__

    def __neg__(self):
        return DO({a: -v for a, v in self.c.items()})

    def __sub__(self, other):
        return self + (-self.asdo(other))

    def __rsub__(self, other):
        return self.asdo(other) + (-self)

    def __mul__(self, other):
        other = self.asdo(other)
        d = {}
        for a, f in self.c.items():
            for b, g in other.c.items():
                for j in range(a[0]+1):
                    for k in range(a[1]+1):
                        h = (a[0]-j+b[0], a[1]-k+b[1])
                        d[h] = d.get(h, 0) + f*s.binomial(a[0],j)*s.binomial(a[1],k)*s.diff(g,z,j,zb,k)
        return DO(d)

    def __rmul__(self, other):
        return self.asdo(other)*self

    def star(self):
        ans = DO()
        for (a,b), f in self.c.items():
            fc = f.xreplace({z:zb,zb:z})
            ans += DO({(b,a):(-1)**(a+b)})*DO({(0,0):fc})
        return ans

    def zero(self):
        return not self.c


one, zero = DO.asdo(1), DO()
Dz, Db = DO({(1,0):1}), DO({(0,1):1})
G = z*zb-2


def dmat(A):
    return [[DO.asdo(x) for x in row] for row in A]


def dprod(A, B):
    return [[sum((A[i][j]*B[j][k] for j in range(len(B))), zero)
             for k in range(len(B[0]))] for i in range(len(A))]


def dstar(A):
    return [[A[j][i].star() for j in range(len(A))] for i in range(len(A[0]))]


def dcheck(name, A, B):
    for ar, br in zip(A, B):
        for a, b in zip(ar, br):
            checked(name, (a-b).zero())


def wt(u):
    l = -Dz-(u+s.Rational(1,2))*zb/G
    m = Db-(u-s.Rational(1,2))*z/G
    tau = DO.asdo(G)
    q = -2*(u+s.Rational(1,2))**2
    a = tau*m*l+q/G
    return [[a,tau*m],[tau*l,tau]], l, m, q


for u,v in [(s.Rational(2),s.Rational(4)),
            (s.Rational(3,2),s.Rational(-1)),
            (s.Rational(3),s.Rational(2))]:
    T, l, m, q = wt(u)
    V, _, _, _ = wt(v)
    dcheck("Weyl Hermiticity", T, dstar(T))
    for i in range(2):
        for j in range(2):
            for k in range(2):
                for h in range(2):
                    checked("Weyl RTT",
                        ((u-v)*(T[i][j]*V[k][h]-V[k][h]*T[i][j])
                         -T[k][j]*V[i][h]+V[k][j]*T[i][h]).zero())
    Tp, _, _, _ = wt(u+1)
    checked("Weyl determinant", (Tp[0][0]*T[1][1]-Tp[1][0]*T[0][1]-q).zero())


for plus,a,u in [(True,s.Rational(2),s.Rational(9,2)),
                 (True,s.Rational(-2),s.Rational(0)),
                 (False,s.Rational(3),s.Rational(-2)),
                 (False,s.Rational(-3),s.Rational(2))]:
    T,l,m,q = wt(u)
    Ta,la,ma,qa = wt(a)
    tau = DO.asdo(G)
    kap = zb/(z*G)
    weight = z*zb/G
    if plus:
        D = u-a
        C = dmat([[1/z,0],[0,G/zb]])
        L = dmat([[1,0],[la,1]])
        F = dprod(C,L)
        den = dmat([[weight*qa,0],[0,weight]])
        R = Ta
        Ut = dmat([[D/(D-1)*tau,0],
                   [-T[1][0]*(1/(D-1)),tau]])
        Ul = dmat([[T[1][0],-tau*(1/(D-1))],
                   [0,D/(D-1)*T[1][0]]])
        xn = dmat([[D/(D-1),0],[0,1]])
        en = dmat([[2/zb,-1/D],[0,0]])
    else:
        D = a-u
        C = dmat([[1/zb,0],[0,G/z]])
        L = dmat([[1,0],[ma,1]])
        F = dprod(C,L)
        qam = wt(a-1)[3]
        den = dmat([[weight*qam,0],[0,weight]])
        R = [[Ta[j][i] for j in range(2)] for i in range(2)]
        Ut = dmat([[D/(D-1)*tau,0],[-T[0][1]*(1/(D-1)),tau]])
        Ul = dmat([[D/(D-1)*T[1][0],0],[-T[0][0]*(1/(D-1)),T[1][0]]])
        xn = dmat([[D/(D-1),0],[0,1]])
        en = dmat([[0,0],[-qam/(D-1),2/zb]])
    ln = [[(l if i==j else zero)+kap*en[i][j] for j in range(2)] for i in range(2)]
    tn = [[G*x for x in row] for row in xn]
    dcheck("Weyl recursive congruence", R, dprod(dprod(dstar(F),den),F))
    dcheck("Weyl recursive tau", dprod(F,Ut), dprod(tn,F))
    dcheck("Weyl recursive lower", dprod(F,Ul), dprod(dprod(tn,ln),F))
    Fi = dprod(dmat([[1,0],[-(la if plus else ma),1]]),
               dmat([[z if plus else zb,0],[0,zb/G if plus else z/G]]))
    dcheck("Weyl inverse", dprod(F,Fi), dmat([[1,0],[0,1]]))
    dcheck("Weyl inverse", dprod(Fi,F), dmat([[1,0],[0,1]]))
    # Missing the scalar term TT'/bar(zeta) gives a false lower identity.
    bad = [row.copy() for row in ln]
    idx = 0 if plus else 1
    bad[idx][idx] -= kap*(2/zb)
    diff = dprod(F,Ul)
    rhs = dprod(dprod(tn,bad),F)
    checked("altered scalar term rejected",
            any(not (diff[i][j]-rhs[i][j]).zero() for i in range(2) for j in range(2)))


report = {
    "scope": "Exact finite matrix and genuine differential operator controls; not a kernel replay",
    "checks": counts,
    "total": sum(counts.values()),
    "status": "PASS",
    "fragment_sha256": hashlib.sha256((BASE/"theta_recursive_radial_frame.tex").read_bytes()).hexdigest(),
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
}
(BASE/"theta_recursive_radial_frame_checks.json").write_text(json.dumps(report,indent=2)+"\n")
print(json.dumps(report,indent=2))
