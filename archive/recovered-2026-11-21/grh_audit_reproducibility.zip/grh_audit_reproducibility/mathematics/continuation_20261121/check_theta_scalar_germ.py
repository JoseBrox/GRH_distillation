"""Exact symbolic and rational controls for the scalar orbital reduction.

The general proof is in theta_scalar_germ.tex.  These checks independently
form the relevant small matrices, determinants and coordinate Jacobians.
No floating-point approximation is used.
"""
import json
from pathlib import Path
import sympy as S


def hessenberg(m, t, rho, x, y):
    n = m+1
    return S.Matrix(n, n, lambda i, j:
                    ([rho]+list(x))[i] if i == j else
                    y[i, j] if i < j else t if i == j+1 else 0)


def symbolic_case(m):
    t, rho, D = S.symbols("t rho D")
    x = S.symbols(f"x1:{m+1}")
    y = {(i,j): S.Symbol(f"y{i}{j}")
         for i in range(m+1) for j in range(i+1,m+1)}
    H = hessenberg(m, t, rho, x, y)
    determinant = S.expand(H.det())
    P = S.prod(x)
    diagonal = [rho]+list(x)
    predicted = -sum(y[i,i+1] * S.prod(diagonal[j]
                         for j in range(m+1) if j not in (i,i+1))
                     for i in range(m))
    assert S.expand(determinant.coeff(t,1)-predicted) == 0
    tail = H[1:,1:]
    A = S.expand(tail.det())
    B = determinant.subs(rho,0)
    assert S.expand(determinant-rho*A-B) == 0
    g = y[0,1]/x[0] + D/P*sum(y[i,i+1]/(x[i-1]*x[i])
                               for i in range(1,m))
    numerator, denominator = S.cancel(A*(D/P+t*g)+B-D).as_numer_denom()
    polynomial = S.Poly(numerator,t)
    assert polynomial.coeff_monomial(1) == 0
    assert polynomial.coeff_monomial(t) == 0
    eta = S.symbols(f"e0:{m}")
    c = S.Symbol("c")
    # Scaled upper coordinates are recovered from the lower rows of H.
    U = S.eye(m+1)
    for i in range(m):
        for j in range(i+1,m+1):
            U[i,j] = (x[i] if j == i+1 else y[i+1,j])/t
    first_row = [sum(eta[i]*t*U[i,j] for i in range(m))
                 + (c if j == m else 0) for j in range(m+1)]
    jacobian = S.Matrix(first_row[1:]).jacobian(eta)
    assert jacobian == tail.T
    assert first_row[0] == t*eta[0]
    full = S.Matrix([first_row]+[list(t*U[i,:]) for i in range(m)])
    operation = S.eye(m+1)
    for i in range(m):
        operation[0,i+1] = -eta[i]
    transformed = S.simplify(operation*full)
    assert list(transformed[0,:]) == [0]*m+[c]
    assert transformed[1:,:m].is_upper
    assert S.prod(transformed[i+1,i] for i in range(m)) == t**m
    return {"m":m, "linear_determinant_coefficient_verified":True,
            "rho_remainder_has_order_at_least_two":True,
            "affine_jacobian_equals_transposed_tail":True,
            "orbital_determinant":f"(-t)^{m}*c"}


def valuation(q, p):
    q = S.Rational(q)
    if q == 0:
        return "infinity"
    a,b = int(q.p), int(q.q)
    v = 0
    while a % p == 0:
        a //= p; v += 1
    while b % p == 0:
        b //= p; v -= 1
    return v


def rational_case(p,m,N):
    t = S.Integer(p)**N
    D = S.Integer(1+p)
    x = [S.Integer(i+1) for i in range(1,m+1)]
    y = {(i,j): S.Rational(i+j+1,p)
         for i in range(m+1) for j in range(i+1,m+1)}
    r = S.Symbol("rho")
    H = hessenberg(m,t,r,x,y)
    A = H[1:,1:].det()
    B = H.subs(r,0).det()
    rho = S.cancel((D-B)/A)
    P = S.prod(x)
    x0 = D/P
    g = y[0,1]/x[0]+x0*sum(y[i,i+1]/(x[i-1]*x[i])
                            for i in range(1,m))
    assert H.subs(r,rho).det() == D
    ratio_v = valuation(A/P,p)
    phase_v = valuation((rho-x0)/t-g,p)
    entry_v = valuation(rho-x0,p)
    assert ratio_v == 0
    assert phase_v == "infinity" or phase_v >= 0
    assert entry_v == "infinity" or entry_v >= 1
    return {"p":p,"m":m,"N":N,
            "tail_determinant_over_diagonal_product_valuation":ratio_v,
            "discarded_phase_valuation":phase_v,
            "first_entry_change_valuation":entry_v}


if __name__ == "__main__":
    result = {
        "scope":"Exact finite controls; the displayed proofs establish the general identities.",
        "symbolic_cases":[symbolic_case(m) for m in range(1,5)],
        "rational_cases":[rational_case(p,m,12)
                          for p,m in [(2,1),(2,3),(3,2),(3,3),(5,4)]],
    }
    output = Path(__file__).with_name("theta_scalar_germ_checks.json")
    output.write_text(json.dumps(result,indent=2)+"\n")
    print("Passed four symbolic matrix identities and five exact rational small-parameter controls.")
