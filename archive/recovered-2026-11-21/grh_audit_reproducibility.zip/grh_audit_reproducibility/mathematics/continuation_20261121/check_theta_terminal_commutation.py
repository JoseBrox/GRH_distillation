"""Exact tests of the full bordered expansion and actual terminal RTT.

Every E_ab is an actual polynomial differential operator, and coefficient
multipliers are differentiated during compositions.  No RTT relation is
used to evaluate either side.
"""
from pathlib import Path
import ast
import hashlib
import json

HERE=Path(__file__).resolve().parent
tree=ast.parse((HERE/"check_theta_terminal_quantum_determinant.py").read_text())
defs=[a for a in tree.body if isinstance(a,(ast.Import,ast.ImportFrom,ast.FunctionDef))]
exec(compile(ast.Module(body=defs,type_ignores=[]),"polynomial_differential_definitions","exec"))
counts={}

def tf(n,a,b,u,F):return add(E(n,a,b,F),scale(u,F)) if a==b else E(n,a,b,F)

for d in (1,2,3):
    n=d+2;e=0;f=n-1;I=tuple(range(1,n-1))
    one={(0,)*(2*n):Q(1)}
    Fs=[one,mulvar(mulvar(one,e),n+f),
        add(mulvar(mulvar(mulvar(one,1),n+1),e),mulvar(one,n+e))]
    for U in (Q(-1),Q(5,2)):
        for F in Fs:
            actual=D(n,U,F)
            want=tf(n,e,e,U,minor(n,I,I,U-1,tf(n,f,f,U-d-1,F)))
            for i,j in product(I,repeat=2):
                Ii=tuple(a for a in I if a!=i);Jj=tuple(a for a in I if a!=j)
                v=E(n,f,j,tf(n,e,e,U,minor(n,Ii,Jj,U-1,E(n,i,f,F))))
                want=sub(want,scale((-1)**(i+j),v))
                v=E(n,i,e,minor(n,Ii,Jj,U-2,tf(n,f,f,U-d-1,E(n,e,j,F))))
                want=sub(want,scale((-1)**(i+j),v))
            for i,ip,j,jp in product(I,repeat=4):
                if i==ip or j==jp:continue
                Ii=tuple(a for a in I if a not in (i,ip));Jj=tuple(a for a in I if a not in (j,jp))
                sg=(1 if i<ip else -1)*(1 if j<jp else -1)*(-1)**(i+ip+j+jp)
                v=E(n,i,e,E(n,f,j,minor(n,Ii,Jj,U-2,E(n,e,jp,E(n,ip,f,F)))))
                want=sub(want,scale(sg,v))
            want=add(want,scale((-1)**(d+1),E(n,f,e,minor(n,(e,)+I,I+(f,),U-1,F))))
            for i in I:
                Ii=tuple(a for a in I if a!=i)
                want=add(want,scale((-1)**(i+d),E(n,i,e,minor(n,Ii+(f,),I,U-1,E(n,e,f,F)))))
            check("full_bordered_Capelli_including_corrections",actual,want)

def terminal(n,a,b,u,F,x,xi):
    v=u+Q(n-1,2)
    if (a,b)==(0,0):return D(n,v,F)
    if (a,b)==(1,0):return scale(-1,total(scale(xi[q],HY(n,q,v,F)) for q in range(n)))
    if (a,b)==(0,1):return scale(-1,total(scale(x[p],HE(n,p,v-1,F)) for p in range(n)))
    return scale(-1,total(scale(xi[q]*x[p],H2(n,q,p,v-1,F)) for q,p in product(range(n),repeat=2)))

for n in (2,3):
    x=[Q(j+1) for j in range(n)];xi=[Q((-1)**j*(j+2)) for j in range(n)]
    one={(0,)*(2*n):Q(1)}
    Fs=[one,mulvar(mulvar(one,0),n-1),add(mulvar(one,n),mulvar(mulvar(one,1),n+1))]
    for u,v in ((Q(3,2),Q(-1)),(Q(2),Q(1)),(Q(1),Q(1))):
        for F in Fs:
            for a,b,c,d in product(range(2),repeat=4):
                lhs=scale(u-v,sub(terminal(n,a,b,u,terminal(n,c,d,v,F,x,xi),x,xi),
                                 terminal(n,c,d,v,terminal(n,a,b,u,F,x,xi),x,xi)))
                rhs=sub(terminal(n,c,b,u,terminal(n,a,d,v,F,x,xi),x,xi),
                        terminal(n,c,b,v,terminal(n,a,d,u,F,x,xi),x,xi))
                check("terminal_RTT_actual_variable_coefficients",lhs,rhs)

result=dict(arithmetic="Exact rational polynomial differential operators",
            counts=counts,total=sum(counts.values()),
            manuscript_sha256=hashlib.sha256((HERE/"theta_terminal_commutation.tex").read_bytes()).hexdigest(),
            status="All controls passed; the general proofs are in the manuscript.")
(HERE/"theta_terminal_commutation_checks.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
