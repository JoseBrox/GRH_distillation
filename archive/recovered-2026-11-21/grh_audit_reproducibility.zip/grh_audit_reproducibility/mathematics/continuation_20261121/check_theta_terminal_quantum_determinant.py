"""Exact controls in the polynomial representation on a vector and covector.

E_ab = -y_b d/dy_a + eta_a d/deta_b.  Thus all coefficient
commutators are evaluated by actual differentiation, not assumed during
the determinant calculation.  The proofs remain those in the manuscript.
"""
from fractions import Fraction as Q
from itertools import permutations, product
from pathlib import Path
import hashlib
import json

counts={}
def add(A,B):
    C=A.copy()
    for e,c in B.items():C[e]=C.get(e,Q(0))+c
    return {e:c for e,c in C.items() if c}
def scale(c,A):return {e:c*v for e,v in A.items() if c*v}
def sub(A,B):return add(A,scale(-1,B))
def mulvar(A,i):
    B={}
    for e,c in A.items():
        f=list(e);f[i]+=1;B[tuple(f)]=c
    return B
def deriv(A,i):
    B={}
    for e,c in A.items():
        if e[i]:
            f=list(e);f[i]-=1;B[tuple(f)]=c*e[i]
    return B
def E(n,a,b,A):
    return add(scale(-1,mulvar(deriv(A,a),b)),mulvar(deriv(A,n+b),n+a))
def sgn(p):return (-1)**sum(p[i]>p[j] for i in range(len(p)) for j in range(i+1,len(p)))
def minor(n,I,J,u,F):
    ans={}
    for p in permutations(range(len(I))):
        v=F
        for b in reversed(range(len(I))):
            i,j=I[p[b]],J[b]
            v=add(E(n,i,j,v),scale(u-b,v)) if i==j else E(n,i,j,v)
        ans=add(ans,scale(sgn(p),v))
    return ans
def D(n,u,F):return minor(n,tuple(range(n)),tuple(range(n)),u,F)
def C(n,i,j,u,F):
    return scale((-1)**(i+j),minor(n,tuple(a for a in range(n) if a!=i),
                                  tuple(a for a in range(n) if a!=j),u,F))
def N(n,i,q,j,p,u,F):
    if i==q or j==p:return {}
    c=(1 if i<q else -1)*(1 if j<p else -1)*(-1)**(i+q+j+p)
    return scale(c,minor(n,tuple(a for a in range(n) if a not in (i,q)),
                         tuple(a for a in range(n) if a not in (j,p)),u,F))
def total(it):
    ans={}
    for v in it:ans=add(ans,v)
    return ans
def check(name,A,B):
    assert A==B,(name,sub(A,B))
    counts[name]=counts.get(name,0)+1
def HY(n,q,u,F):return total(mulvar(C(n,q,j,u,F),j) for j in range(n))
def HE(n,p,u,F):return total(mulvar(C(n,i,p,u,F),n+i) for i in range(n))
def HYY(n,u,F):return total(mulvar(mulvar(C(n,i,j,u,F),j),n+i)
                           for i,j in product(range(n),repeat=2))
def H2(n,q,p,u,F):return total(mulvar(mulvar(N(n,a,q,c,p,u,F),c),n+a)
                              for a,c in product(range(n),repeat=2))

for n in (2,3):
    zero=(0,)*(2*n);one={zero:Q(1)}
    Fs=[one,mulvar(mulvar(one,0),n-1),
        add(mulvar(mulvar(one,1),n),scale(2,mulvar(mulvar(one,n+1),n+1)))]
    for F in Fs:
        for a,b,c in product(range(n),repeat=3):
            check("actual_vector_commutator",
                  sub(E(n,a,b,mulvar(F,c)),mulvar(E(n,a,b,F),c)),
                  scale(-int(a==c),mulvar(F,b)))
            check("actual_covector_commutator",
                  sub(E(n,a,b,mulvar(F,n+c)),mulvar(E(n,a,b,F),n+c)),
                  scale(int(b==c),mulvar(F,n+a)))
        for u in (Q(-2),Q(5,2)):
            for i,q,j,p in product(range(n),repeat=4):
                lhs=sub(C(n,i,j,u+1,C(n,q,p,u,F)),C(n,q,j,u+1,C(n,i,p,u,F)))
                rhs=D(n,u+1,N(n,i,q,j,p,u,F))
                check("signed_quantum_Jacobi",lhs,rhs)
            for p,q in product(range(n),repeat=2):
                lhs=add(D(n,u+1,H2(n,q,p,u-1,F)),HY(n,q,u+1,HE(n,p,u-1,F)))
                rhs=HYY(n,u,C(n,q,p,u,F))
                check("contracted_quantum_determinant",lhs,rhs)
            for j in range(n):
                check("cofactor_covector_shift",
                      total(mulvar(C(n,i,j,u-1,F),n+i) for i in range(n)),
                      total(C(n,i,j,u,mulvar(F,n+i)) for i in range(n)))

# A precise negative control for deleting the spectral shift.
n=2;one={(0,0,0,0):Q(1)};u=Q(1)
wrong=sub(C(n,0,0,u,C(n,1,1,u,one)),C(n,1,0,u,C(n,0,1,u,one)))
wrong=sub(wrong,D(n,u,N(n,0,1,0,1,u,one)))
check("unshifted_false_identity_residual",wrong,one)

out=Path(__file__).resolve().parent
result=dict(arithmetic="Exact rational polynomial differential operators",
            counts=counts,total=sum(counts.values()),
            negative_control="Deleting the +1 shift in quantum Jacobi gives residual 1 for n=2,u=1 on the constant polynomial.",
            manuscript_sha256=hashlib.sha256((out/"theta_terminal_quantum_determinant.tex").read_bytes()).hexdigest(),
            status="All controls passed; the universal proofs are in the manuscript.")
(out/"theta_terminal_quantum_determinant_checks.json").write_text(json.dumps(result,indent=2)+"\n")
print(json.dumps(result,indent=2))
