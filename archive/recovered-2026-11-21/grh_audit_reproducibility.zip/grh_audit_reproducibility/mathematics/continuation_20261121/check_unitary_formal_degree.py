"""Exact controls for the formal-degree constants and minimum-type shifts.

This does not test or reprove the imported representation theorems.
All arithmetic below is integral or rational; no numerical integration is used.
"""

from fractions import Fraction as Q
from itertools import product
from math import factorial, prod
from pathlib import Path
import hashlib
import json


def det(a):
    a = [[Q(x) for x in row] for row in a]
    ans = Q(1)
    for i in range(len(a)):
        j = next((j for j in range(i, len(a)) if a[j][i]), None)
        if j is None:
            return Q(0)
        if j != i:
            a[i], a[j] = a[j], a[i]
            ans = -ans
        pivot = a[i][i]
        ans *= pivot
        for j in range(i + 1, len(a)):
            c = a[j][i] / pivot
            for k in range(i + 1, len(a)):
                a[j][k] -= c * a[i][k]
    return ans


def sf(n):
    return prod(factorial(j) for j in range(n))


def vand(lam):
    return prod(abs(lam[i] - lam[j])
                for i in range(len(lam)) for j in range(i + 1, len(lam)))


counts = {"complexification_Jacobian": 0, "matrix_ball_constants": 0,
          "compact_dual_constants": 0, "minimum_type_integrality": 0,
          "minimum_type_dominance": 0, "excluded_lower_types": 0}

# Real Jacobian of (X,Y) -> X+iY on one off-diagonal pair, for both signs.
for eps in (-1, 1):
    a = [[1, 0, 0, -1], [0, 1, 1, 0],
         [-eps, 0, 0, -eps], [0, eps, -eps, 0]]
    assert abs(det(a)) == 4
    counts["complexification_Jacobian"] += 1

for p, q in product(range(1, 6), repeat=2):
    n = p + q
    # J_{p,q}(n)/pi^(pq), independently integrated one column at a time.
    grassmann_volume = Q(1)
    current_u = n
    for _ in range(q):
        grassmann_volume *= Q(factorial(current_u - p - 1),
                              factorial(current_u - 1))
        current_u -= 1
    compact_density = Q(sf(n), sf(p) * sf(q))
    assert grassmann_volume * compact_density == 1
    counts["compact_dual_constants"] += 1

    for s in range(n, n + 6):
        # I_{p,q}(s-n)/pi^(pq), using the successive column recursion.
        ball_volume = Q(1)
        alpha = s - n
        for _ in range(q):
            ball_volume *= Q(factorial(alpha), factorial(alpha + p))
            alpha += 1
        bergman_degree = 1 / ball_volume
        cross_roots = prod(s - i - j + 1
                           for i in range(1, p + 1)
                           for j in range(1, q + 1))
        assert bergman_degree == cross_roots
        highest = [0] * p + [s] * q
        hc = [Q(highest[i]) + Q(n - 1 - 2 * i, 2) for i in range(n)]
        assert vand(hc) == sf(p) * sf(q) * cross_roots
        assert bergman_degree / compact_density == vand(hc) / sf(n)
        # Rescaling Haar by 2 must divide the formal degree by 2.
        assert 1 / (2 * ball_volume) == bergman_degree / 2
        counts["matrix_ball_constants"] += 1

# All sign orders and integral adjacent gaps 1 or 2 in ranks at most 6.
# Check the exact shifts and the strict norm inequality used by the
# Parthasarathy converse, including the smallest regular parameters.
for n in range(1, 7):
    rho = [Q(n - 1 - 2 * i, 2) for i in range(n)]
    for gaps in product((1, 2), repeat=n - 1):
        lam = [Q(n - 1, 2)] * n
        for i in range(n - 2, -1, -1):
            lam[i] = lam[i + 1] + gaps[i]
        for signs in product((0, 1), repeat=n):
            rhoc = [Q(sum(signs[j] == signs[i] for j in range(i + 1, n))
                      - sum(signs[j] == signs[i] for j in range(i)), 2)
                    for i in range(n)]
            rhon = [rho[i] - rhoc[i] for i in range(n)]
            mu = [lam[i] + rhon[i] - rhoc[i] for i in range(n)]
            assert all(x.denominator == 1 for x in mu)
            counts["minimum_type_integrality"] += 1
            for i in range(n):
                for j in range(i + 1, n):
                    if signs[i] == signs[j]:
                        assert mu[i] >= mu[j]
                        assert lam[i] + rhon[i] > lam[j] + rhon[j]
                        counts["minimum_type_dominance"] += 1
                    else:
                        alpha = [Q(int(t == i) - int(t == j)) for t in range(n)]
                        base = [mu[t] + 2 * rhoc[t] for t in range(n)]
                        lowered = [base[t] - alpha[t] for t in range(n)]
                        difference = sum(x*x for x in lowered) - sum(x*x for x in base)
                        assert difference == -2 * (lam[i] + rho[i] - lam[j] - rho[j]) + 2
                        assert difference < 0
                        counts["excluded_lower_types"] += 1

root = Path(__file__).resolve().parent
artifact = root / "unitary_formal_degree.tex"
result = {"arithmetic": "exact integer and rational arithmetic",
          "counts": counts, "total": sum(counts.values()),
          "manuscript_sha256": hashlib.sha256(artifact.read_bytes()).hexdigest(),
          "status": "All controls passed. The general results rest on the written proofs and explicitly named classical theorems."}
(root / "unitary_formal_degree_checks.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps(result, indent=2))
