"""Exact small-field controls for the primitive-frame density formula.

The enumeration checks both the degenerate Gram cases and characteristic
two. It is independent of the product formula, and is not its proof.
"""
from collections import Counter
from fractions import Fraction
from itertools import product
from pathlib import Path
import json


class QuadraticField:
    def __init__(self, p):
        assert p in (2, 3)
        self.p = p
        # x^2 + a*x + b, irreducible for the indicated prime.
        self.a, self.b = ((1, 1) if p == 2 else (0, 1))
        self.elements = list(range(p*p))
        self.add_table = [[self.encode((x % p+y % p) % p,
                                      (x//p+y//p) % p)
                           for y in self.elements] for x in self.elements]
        self.mul_table = [[self.multiply_raw(x, y) for y in self.elements]
                          for x in self.elements]
        self.neg_table = [self.encode(-(x % p) % p, -(x//p) % p)
                          for x in self.elements]
        self.conj_table = [self.power(x, p) for x in self.elements]
        self.inverse = {x: self.power(x, p*p-2) for x in self.elements if x}

    def encode(self, x, y):
        return x+self.p*y

    def multiply_raw(self, x, y):
        p = self.p
        x0, x1, y0, y1 = x % p, x//p, y % p, y//p
        return self.encode((x0*y0-self.b*x1*y1) % p,
                           (x0*y1+x1*y0-self.a*x1*y1) % p)

    def add(self, x, y):
        return self.add_table[x][y]

    def mul(self, x, y):
        return self.mul_table[x][y]

    def power(self, x, n):
        out = 1
        while n:
            if n & 1:
                out = self.mul(out, x)
            x = self.mul(x, x)
            n //= 2
        return out

    def rank(self, rows, m):
        a = [list(row) for row in rows]
        r = 0
        for j in range(m):
            pivot = next((i for i in range(r, len(a)) if a[i][j]), None)
            if pivot is None:
                continue
            a[r], a[pivot] = a[pivot], a[r]
            inv = self.inverse[a[r][j]]
            a[r] = [self.mul(inv, v) for v in a[r]]
            for i in range(len(a)):
                if i == r:
                    continue
                factor = a[i][j]
                a[i] = [self.add(u, self.neg_table[self.mul(factor, v)])
                        for u, v in zip(a[i], a[r])]
            r += 1
            if r == len(a):
                break
        return r


def prime_rank(rows, m, p):
    a = [list(row) for row in rows]
    r = 0
    for j in range(m):
        pivot = next((i for i in range(r, len(a)) if a[i][j] % p), None)
        if pivot is None:
            continue
        a[r], a[pivot] = a[pivot], a[r]
        inv = pow(a[r][j], -1, p)
        a[r] = [v*inv % p for v in a[r]]
        for i in range(len(a)):
            if i != r:
                factor = a[i][j]
                a[i] = [(u-factor*v) % p for u, v in zip(a[i], a[r])]
        r += 1
        if r == len(a):
            break
    return r


def density(p, eta, n, m, c):
    if m+c > n:
        return Fraction(0)
    out = Fraction(1)
    for j in range(n-m-c+1, n+1):
        out *= 1-Fraction(eta**j, p**j)
    return out


def matrix(flat, n, m):
    return [flat[i*m:(i+1)*m] for i in range(n)]


def target(m, c):
    return tuple(int(i == j and i < m-c) for i in range(m) for j in range(m))


records = []
for p in (2, 3):
    field = QuadraticField(p)
    # Check the field implementation, including every nonzero inverse and
    # every conjugation involution, before using it for enumeration.
    assert all(field.mul(x, field.inverse[x]) == 1 for x in field.inverse)
    assert all(field.conj_table[field.conj_table[x]] == x for x in field.elements)
    for n in range(4):
        for m in range(min(n, 2)+1):
            if p == 3 and n*m > 4:
                continue
            inert = Counter()
            for flat in product(field.elements, repeat=n*m):
                x = matrix(flat, n, m)
                if field.rank(x, m) != m:
                    continue
                gram = []
                for i in range(m):
                    for j in range(m):
                        value = 0
                        for a in range(n):
                            value = field.add(value, field.mul(field.conj_table[x[a][i]], x[a][j]))
                        gram.append(value)
                inert[tuple(gram)] += 1
            frames = []
            for flat in product(range(p), repeat=n*m):
                x = matrix(flat, n, m)
                if prime_rank(x, m, p) == m:
                    frames.append(x)
            split = Counter()
            for x in frames:
                for y in frames:
                    gram = tuple(sum(x[a][i]*y[a][j] for a in range(n)) % p
                                 for i in range(m) for j in range(m))
                    split[gram] += 1
            for eta, counts in [(-1, inert), (1, split)]:
                for c in range(m+1):
                    got = counts[target(m, c)]
                    want = p**(2*n*m-m*m)*density(p, eta, n, m, c)
                    assert want.denominator == 1
                    assert got == want, (p, eta, n, m, c, got, want)
                    records.append({'q': p, 'eta': eta, 'n': n, 'm': m,
                                    'corank': c, 'enumerated_count': got,
                                    'density': str(density(p, eta, n, m, c))})

assert next(x['enumerated_count'] for x in records if
            (x['q'],x['eta'],x['n'],x['m'],x['corank']) == (2,-1,2,1,1)) == 9
assert next(x['enumerated_count'] for x in records if
            (x['q'],x['eta'],x['n'],x['m'],x['corank']) == (2,1,2,1,1)) == 3

result = {'scope': 'Exact enumeration in F_4, F_9, F_2 and F_3 for the displayed dimensions, not a general proof.',
          'checks': len(records), 'results': records,
          'negative_controls': {
              'dropping_gram_corank': 'At q=2,n=2,m=1, isotropic counts 9 and 3 differ from nondegenerate count 6.',
              'dropping_primitivity': 'For n=m=1 and zero Hermitian Gram matrix the zero vector contributes one nonprimitive solution, while the primitive count is zero.'}}
path = Path(__file__).with_name('unitary_mass_densities_checks.json')
path.write_text(json.dumps(result, indent=2)+'\n')
print(json.dumps({'checks':len(records),'all_passed':True,'output':str(path)}))
