# Independent review of class_period_integrality.tex

Reviewer: formal_verification subagent. Date: 21 November 2026.

## Scope and conclusion

I read all 341 lines of the fragment. I also reread the coefficient transport/duality and contravariance identities in `coefficient_duality.tex`, and read `arithmetic_classes.tex` lines 360–649 for the actual row-class, inverse-character, coefficient-lattice, evaluation, and metric conventions. No mathematical defect was found.

The only requested edit is cosmetic: the displayed coordinate expression for the Riesz representative has `\overline{J(h)}^{,t}`; the intended transpose spacing is `\overline{J(h)}^{\,t}`.

## Mathematical checks

- Restriction of the invariant nondegenerate bilinear pairing to both finite-stabilizer invariant subspaces remains nondegenerate in characteristic zero. The averaging argument is used only over the field. It is not used to assert integral surjectivity or perfect duality of invariant lattices.
- Equivariant evaluation at finitely many orbit representatives gives exactly the invariant lattice intersections. Clearing denominators proves they are full lattices. There is no hidden saturation assumption.
- The common denominator can be the least common multiple of the finite stabilizer orders. Empty orbit sets and zero spaces cause no exception. The local valuation is exactly v_w(D)=e_w v_p(D), with the ramification factor retained.
- The actual normalized Fock pairing is bilinear, with transported lattices D(M-dual) and N(M). The earlier coefficient proof gives their exact integral duality, including negative determinant weights and all coefficient primes. Covariant and inverse-transpose actions preserve this pairing; inverse finite-order level characters are required and used.
- The period recovers the class polynomials at the identity frame with the same determinant power removed. Embedding commutes with the normalized polynomial pairing because it is a finite rational-coefficient expression. The algebraicity statement is therefore explicit and not inferred from an analytic comparison.
- Class restrictions are orthogonal projections for the positive class-sum metric. With the inner product conjugate-linear in its first variable, the Riesz map from the row variable is conjugate-linear. This is consistent with the displayed bilinear period.
- Multiplication by the stabilizer order removes exactly the class weight, giving the embedded integral coefficient pairing. The column estimate follows only after the additional containment for the column map is supplied. The fragment correctly leaves that stronger containment unresolved.
- The global fractional-ideal reformulation has the correct sign, including negative shift exponents.
- Both boundary examples are valid and violate the precisely identified omitted hypothesis.

## Exact source comparison read independently

Paths relative to `sources/lean/src/`:

- `Development/AbelianVarietyTheory/Definitions/AutomorphicMembership/PredMemGamRanks.lean`, lines 455–585: `PerIn.Ok` explicitly includes equivariance and `ext_inj`; `per` is the normalized finite class sum; `ipP` is conjugate-linear in its first argument; `stabMap` and `stabMap_inj` give the actual conjugated stabilizer injection.
- `Development/AbelianVarietyTheory/Proofs/GlobalInterpolation/IsClassSumPairingOfIsFormsOf.lean`: complete file. This checks Lsh=N at the row, the bijection of class descriptions, equality of stabilizer cardinalities, the inverse character, compatibility of the polynomial embedding and normalized pairing, and the actual period-to-class-sum identity for row embeddings.
- `Development/AbelianVarietyTheory/Proofs/GlobalInterpolation/ClassPairingIntegralFormRowIsIntegral.lean`: complete file. This checks the class restrictions, the two slots of the Hermitian form, and the cancellation of the stabilizer weight in the integral class contribution.
- `VAddNonnegOfInt.lean` was searched for declaration references only, not independently read in full in this review. No claim of full coverage of its transitive providers is made.

The fact that the generic source row space allows equivariance under a subgroup causes no mismatch here: the actual integral row embedding read in the provider satisfies the full row transformation law used for these finite class sums. No counterexample satisfying the actual hypotheses was found.
