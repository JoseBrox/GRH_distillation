# Initial class-period integrality: source comparison

Date: 21 November 2026. Mathematical fragment: `class_period_integrality.tex`.

## Proved result and precise limit

The fragment proves the actual initial period bound with denominator the common multiple of the last-column stabilizer orders. A stronger abstract version replaces that multiple by the least common multiple of the row stabilizer orders. The general equivariant class pairing is nondegenerate, with integral values after multiplication by this denominator. The normalized contribution of one class is exactly the integral bilinear Fock pairing. Valuations are normalized by v_w(p)=e_w, so the loss is exactly e_w v_p(D_Gamma).

This is a proof for the actual final polynomial period. It does not supply the deeper divisibility of an iterated theta column, the integral compatibility of its intervening lowering map, or the estimates at the level prime and the two type primes. The deduction from such a column containment is stated and proved separately, with that containment a visible hypothesis.

## Identification with the source

- `PredMemGamRanks.lean`455–585 defines `PerIn.per` as the finite sum of the normalized bilinear polynomial pairings, each divided by the order of the row stabilizer. Thus the algebraic period identity is definitional here; it is not an unproved comparison with an analytic integral.
- The abstract `PerIn.Mt` can impose invariance only under a subgroup. In the actual input, `LatAtLattice.lean`70–130 sets that subgroup to the full group. The full equivariant-function description used in the proof therefore has the correct scope.
- `IsClassSumPairingFormsLat.lean` and `IsClassSumPairingOfIsFormsOf.lean` identify actual polynomial class restrictions and their metric. The polynomial normalization is the same rational Fock normalization used in `coefficient_duality.tex`; no factorial or determinant character is omitted.
- `arithmetic_classes.tex` supplies the row class identification and the inverse relation between its two level characters. The extra local frames change neither orbit classes nor stabilizer orders. Their residue-preimage condition is retained in that proof.
- The Riesz representative is conjugate-linear in the row variable under the convention that the Hermitian form is conjugate-linear in its first variable. Orthogonal restriction to one class gives the exact contribution, and multiplying by its stabilizer order leaves the bilinear polynomial pairing.
- The source's `stabMap` is induced by the group injection `ext_inj`; it injects the row stabilizer into the last-column stabilizer. The denominator therefore divides the supplied positive common multiple. This argument does not assert that any of these stabilizers is trivial.
- The twisted class-period wrappers sometimes extend class contributions outside the polynomial point subspace. The valuation conditions are evaluated inside that subspace, where the extension agrees with the actual finite class sum. This is not a replacement of the period on its tested domain.
- `ExistsTrueColsRowInt.lean` builds finite spanning sets from the integral row lattice. Clearing denominators in the fixed coefficient spaces supplies fullness. Averaging by the stabilizer order is used only over the coefficient field to prove nondegeneracy, not as an assertion that averaging preserves the integral lattice.
- `PerIntOnAmb.lean` and `AdmissiblePeriodOfPeriodInt.lean` specify the exact valuation normalization and fractional-ideal shifts. The fragment proves the resulting local-to-global integrality equivalence, allowing negative exponents and zero period values.

## Read scope and checks

`class_period_integrality_source_manifest.json`, reproducible by `build_class_period_manifest.py`, records24 complete source files and two specified source intervals. It is a conservative reading record, not a formal dependency closure. The supplied arithmetic-class and coefficient-duality proofs have their own provenance and independent reviews.

The formal-verification agent independently reviewed the complete mathematical fragment, the relevant coefficient identities, the class identification, the actual period definition, and both main class-pairing providers. It found no mathematical defect. A transpose-spacing typo was corrected afterwards, without changing a statement.

The examples with a trivial action of a group of order two and with equal cubic characters show why the denominator and inverse-character hypotheses cannot be dropped. They do not satisfy the corresponding qualified source assertions and are not counterexamples to the submitted proof. No counterexample satisfying the actual hypotheses was found in this portion.
