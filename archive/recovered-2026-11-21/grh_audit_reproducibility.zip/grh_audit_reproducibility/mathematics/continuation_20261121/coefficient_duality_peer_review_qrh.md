# Independent review of the coefficient-lattice duality

Reviewer: `/root/qrh_mathematics`. Reviewed 21 November 2026.
Target: `coefficient_duality.tex`, all 600 lines.

Follow-up review: checked the final 623-line version's additions concerning
the field of definition of the rational-basis matrices, the identity
h_G(rho(g)F,rho(g)F')=h_(g*Gg)(F,F'), and the nonprincipal rank-one example.
All three are correct under the existing hypotheses and conventions.

## Conclusion

No mathematical defect was found. The proof establishes the stated integral
duality over characteristic-zero fields and number-field integer rings,
including small residue characteristics, negative determinant weights,
tensor products, nonfree transported lattices, conjugation, and ramified
scalar extension. It uses the actual coefficient-module definitions and
normalization at the source ranges listed below.

The result does not establish the existence, unimodularity or uniform
estimates for the arithmetic input lattices. It does not assert that the
polynomial inclusions remain injective after reduction modulo a prime, or
that the same proof works over arbitrary positive-characteristic rings.

## Main proof checks

1. **Integral restriction.** Column elimination produces X=LU after
   localizing at the product of initial minors. Each pivot is a ratio of
   two such minors, so no integer has been inverted. A polynomial identity
   for column additions remains valid for parameters in the localization.
   The intersection Q[X] with Z[X,Delta^(-1)] is Z[X], because Delta is
   nonzero modulo every prime. This is a coefficient statement, not a
   statement about integer-valued polynomial functions.
2. **Extremal weight.** On the lower-triangular slice, the specified row
   and column degrees leave only the diagonal monomial. The restriction
   lemma therefore identifies that row-weight space with Q H_nu.
   Orthogonality of different row degrees gives the evaluation identity
   with precisely C_nu=[H_nu,H_nu]. No hook-length product or denominator
   integrality is assumed.
3. **Adjoints.** The polarization identity establishes the Fock adjoint
   for arbitrary rational row matrices, including singular ones. Comparing
   the polynomial parameter gives the divided-row adjoint, including the
   diagonal binomial operator. Reversal and transposition preserve the set
   of all operator words.
4. **Recovery of coefficients.** The product of lower elementary
   matrices, ordered by increasing column, has no cross terms: a nonzero
   E_(a,s) E_(b,t) with s<=t and b>t would require s=b>t. Its first n
   columns are exactly the stated unit lower-triangular matrix. Expansion
   recovers every restricted coefficient as a word evaluation. Restoring
   arbitrary diagonal entries by column homogeneity creates no collision
   between distinct off-diagonal monomials. Possible negative diagonal
   exponents must have zero coefficient because the original restriction
   is a polynomial.
5. **Full lattices and double dual.** The dual-Weyl lattice is finite free
   over Z and spans the rational solution space. If the divided-word lattice
   had smaller rational span, its normalized dual would contain all rational
   multiples of a nonzero rational polynomial, contradicting the equality
   already proved with the integral polynomial lattice. The rational Gram
   matrix then proves double duality and perfection. This does not assume
   that the divided-word lattice is saturated.
6. **Scalar extension.** Smith normal form of the finite integral
   coefficient-equation matrix correctly computes the kernel after
   extension to either a number field or its integer ring. A nonzero Smith
   entry remains a nonzerodivisor. The integral dual bases extend, so no
   restriction on primes dividing C_nu is necessary.
7. **Determinant character.** The transpose reverses the order of
   substitutions and makes rho a representation. The adjoint is rho(g^t),
   with the same integer determinant exponent, and the paired inverse
   transpose removes that factor exactly. Negative powers are allowed
   because g is invertible. Stability of the second lattice follows from
   its exact dual description.
8. **Tensor product.** The factorial weight and the normalizing constant
   both factor over disjoint variable blocks. The polynomial realization
   agrees with the tensor product of the two dual bases; there is no extra
   multinomial factor.
9. **Local transport.** Local bases differ on the right by an integral
   invertible matrix. The source definition by preimage under the inverse
   action is exactly the image rho(B) of the standard local module. The
   finite-primary-component patching argument does not assume globally
   free input lattices. It proves the exact prescribed localizations and
   independence of all local-basis choices. Local duals use B^(-t).
10. **Conjugation and Hermitian dual.** Conjugating the coefficient
    lattice sends a basis at the conjugate prime to a basis at the given
    prime. The identity h(F,F')=B(bar(F),rho(G)F') gives
    N(M)^#=rho(G^(-1))D((bar M)^vee), exactly D(M^#). The order and the
    conjugation are correct. The inverse-transpose Gram matrix for ordinary
    dual input lattices yields (M^vee)^#=(M^#)^vee.
11. **Extension of input lattices.** Finite projective modules over a
    Dedekind domain have duals commuting with flat scalar extension.
    The pairing is extended as a field-valued pairing, so no trace or
    different ideal is inserted. Ramification does not change this claim.

## Adversarial checks and edge cases

- n=0, the zero partition and an empty tensor index set all give the
  rank-one trivial module with normalizing scalar one.
- Binary quadratics give Delta=<x^2,2xy,y^2>, distinct from its saturation.
  Replacing Delta by that saturation really makes the claimed integral
  pairing false at 2. The displayed warning is mathematically necessary.
- For a rank-one full fractional ideal I and any integer weight a,
  local transport gives N(I)=D(I)=I^a, with inverse ideal powers for a<0.
  If the base Gram scalar is g, its Hermitian dual is
  g^(-a) (bar I)^(-a), equal to the coefficient lattice of
  I^#=g^(-1)(bar I)^(-1). This checks arbitrary nonprincipal ideals as well
  as negative weights without choosing a global generator.
- The source normalized Hermitian pairing conjugates the first argument;
  the proof uses that convention throughout. Blocks are not permuted by
  coefficientwise conjugation. Scalar extensions require, and the actual
  square/round source packages supply, compatibility of the field embedding
  with the involutions.
- No finite computation substitutes for the proof. The independent exact
  small-case controls in the companion file were not rerun in this review;
  they are supplementary evidence only.

## Source ranges independently read

Paths are relative to `sources/lean/src/`. These ranges were read directly;
no claim is made here to have rechecked every upstream imported theorem.

- `Formalism/GradedWeylDivisibility/StatementA.lean`, lines 1--150:
  formal column identities, row action and divided generators, highest
  polynomial and word span. Source rowDiv(a,b,k) equals the manuscript's
  D_(b,a)^(k), which gives the identical span because all indices occur.
- `Formalism/LocalRingCardinality/DataCoeff.lean`, lines 1--100:
  dominant integer weights, last-part determinant shift, polynomial
  partition, square and round actions, normalized Fock scalar.
- `Formalism/LocalToGlobal/Divisibility/CoefMod.lean`, lines 1--240 and
  275--340: factorial form, tensor blocks, action, normalization, local
  bases and preimage intersection, bilinear/Hermitian input duals, scalar
  extensions and square/round package definitions.
- `Formalism/LocalToGlobal/Divisibility/CoefModLemmas.lean`, lines 128--160:
  the exact NabDelDual hypotheses and conclusion, and the ordinary-dual
  input identity. The manuscript matches full lattice and nondegenerate
  Hermitian matrix hypotheses; it is not claiming a statement for a
  deficient-rank input submodule.
- `Formalism/LocalToGlobal/Columns/CoefModB.lean`, lines 1--100 and
  312--350: bilinear normalization and the exact conversion of pairP to
  the coefficientwise-conjugate bilinear form.
- `Formalism/LocalToGlobal/Columns/CoefCol.lean`, lines 45--86:
  exact square/round packages.
- `Formalism/LocalToGlobal/Columns/RowFormsGood.lean`, lines 100--190:
  involution-compatible scalar extension, unimodular input hypotheses,
  and how the coefficient duality supplies the square/round duality.
