# Cyclotomic interval review, 21 November 2026

## Conclusion and limitations

No counterexample satisfying the actual hypotheses was found. The companion
section `cohomological_intervals.tex` supplies an ordinary proof of the
cyclotomic descent, the uniform generator bound in the two varying quadratic
extensions, the torsion-preserving determinant and exceptional-weight bounds,
and the common-interval construction. The final summed estimate is explicitly
conditional on the displayed coarse H^2 estimate. It is not a proof of all of
`VWin`: the other prime and character components remain to be reconstructed.

The Ferrero--Washington theorem is a classical imported theorem, in its
precise consequence that the p-ranks of class groups in a fixed abelian
cyclotomic tower are bounded. Its original 1979 paper was not reproved in
this continuation. The primary Annals bibliographic record and Sharifi's
own theorem statement were checked. Poitou--Tate duality is used only through
the explicitly stated inequality between the strict Selmer length and H^2.

## Source-to-mathematics mapping

Paths below are relative to
`sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/`,
except where a different root is written. The full source archive is pinned
by the hash in the audit. A separate JSON manifest identifies these files.

| Source | Role and read scope |
|---|---|
| `../CharacterBoxes/ExistsPageN.lean` | Full target definitions `VVle`, `WinPair`, `PageN`, `VWinAt`, `VWin` read. Exact local conditions and finiteness guards retained. |
| `StmtFields.lean` | Full definitions of abelian fields, conductor, layers, exceptional prime set and minus-part polynomial read. |
| `HeightAndVanishing/Counts.lean` | Full arithmetic counting interfaces read, with exact character/weight cases. |
| `HeightAndVanishing/LayerLe.lean` | Full fixed-exceptional-prime layer and combination definitions read. |
| `HeightAndVanishing/FinalLe.lean` | Full finite-sum, character-loss and exponent bookkeeping read. This alone is not the arithmetic counting proof. |
| `HeightAndVanishing/PointArith.lean` | Full combination over exceptional and other primes read. |
| `HeightAndVanishing/ThmHV.lean` | Full passage to a common interval read. |
| `PrimeSetBoundDataOfPrimitiveChar.lean` | Full definitions of the common interval, aggregate generator bound, J, and joint bounds read. |
| `CMFieldExponentialBounds/AdmissibleOfPageN.lean` | Full final absorption into the VWin bound read. |
| `HeightAndVanishing/JointWinOfCounts.lean` | Full dependency combination read; its upstream arithmetic theorems remain distinct inputs. |
| `PublishedTheorems/FerreroWashington.lean` | Exact published theorem formulation read. |
| `GeneratorCountTuples/LemmaK.lean` | Full coarse H^2 estimate definition read. This is the explicit conditional input of the new ordinary interval theorem. |
| `LayeredIsomorphisms/SecondBound.lean` | Full definitions of ABound, FirstBound, SecondBound, TwoIn, FixedIn, Good and point bounds read. |
| `LayeredIsomorphisms/Near1.lean`, `Exc.lean` | Full p-adic integer separation and exceptional-set proofs read. |
| `LayeredIsomorphisms/Window1.lean`, `Window.lean` | Full finite-obstruction interval induction read. Reproved with J improved by a factor of 2 for [Y,Y^2], and generalized to [Y,Y^b]. |
| `LayeredIsomorphisms/ThmBabOf.lean`, `ThmBabOfLemmaK.lean` | Full assembly from the same union of exceptional sets read. |
| `AdditiveValuationNorms/ABoundOfIsTower.lean`, `ABoundOfDescends.lean` | Full passage from actual cyclotomic modules to the p-adic bounds read. |
| `NumberFieldTowers/XTwApplyApply.lean` | Full definitions of the dual module, action, twists, generator condition and IsTower read. IsTower does not assume torsion-freeness. |
| `QuadraticExtensions/IsAlgClosureRat.lean` | Full uniform two-adic and fixed-prime generator argument read; bound is 4(g+6[M:Q]). |
| `AdditiveValuationNorms/ExistsCentresLevel.lean`, `CokLenLeOfRangeLe.lean`, `XUnip.lean` | Full module/determinant and unipotence combination read. |
| `AdditiveValuationNorms/DetBound.lean`, `Growth.lean`, `PadicUnitsDistanceLeMax.lean` | Full determinant-centre, layer growth and distance proofs read. The new proof uses a nearest point in a compact set instead of the source's ultrametric ball-intersection lemma. |
| `QuadraticExtensions/QuadStep.lean`, `CharStep.lean`, `IdxTwo.lean`, `InvTwo.lean`, `OrbTwo.lean` | Full mod-2 character, tame ramification, restriction obstruction and prime-orbit proofs read. |
| `QuadraticExtensions/GenOfRk.lean`, `LevUAnti.lean`, `LevelRk.lean` | Full passage from finite-layer character ranks to the compact dual's generators read. |
| `GaloisLibrary/KummerTheory/Mk0IdMapCongr.lean` | Definitions through line 215 read, including XDual, Dinf and Xinf. Not the whole file. |
| `GaloisLibrary/KummerTheory/XdualExt.lean` | Full descent of local character conditions read. |
| `AdditiveValuationNorms/Descends.lean`, `NumberFieldTowers/ExistsDescends.lean` | Full exact descent interface and its combination read; ordinary proof given independently using inflation--restriction. |
| `LayeredIsomorphisms/PartA.lean`, `PartB.lean`, `Kexp.lean`, `Layerdisc.lean` | Full small-weight, discriminant, fixed-layer and final absorption arguments read. |
| `QuadraticExtensions/ShaTwo.lean` | Full restriction bound read; ordinary proof of the kernel bound supplied. |
| `AdditiveValuationNorms/ShaLeV.lean` | Full use of the Poitou--Tate subgroup identity read. |
| `GaloisLibrary/GaloisCohomologyLength/LevelInertiaLeLevelDec.lean` | Definitions of ShaAbs and shaInv, and local-condition equivalences read; not the whole file. |
| `sources/lean/src/Formalism/GaloisCohomology/Statement.lean` | Exact coefficient twists, Sha, shaLen, VLen and Sha2Zl definitions read. |
| `GeneratorCountTuples/Bridge.lean`, `Reduction.lean`, `LemmaKOfPublished.lean`, `HermiteNormalForms/TorsMain.lean` | Full coarse-estimate interfaces and reduction to integral homology torsion read. The geometric torsion bound and comparison theorem themselves have not been reconstructed. |
| `ModularityArgument/ClassCounting/LemmaKOfSteps.lean` | First 110 lines only: BOdd and chain/comparison interfaces. This is not a full review of this file. |

## Independent proof choices and actual improvements

1. The negative twist is Q_p/Z_p(-e), not an integral coefficient module.
   Every local vanishing condition uses the full decomposition group at p.
2. The cyclotomic module may contain finite torsion. A free cover, not a
   torsion-free quotient, gives the determinant upper bound.
3. If (h-1)X is contained in p^2X and Q=1+h+...+h^(p-1), then
   QX=pX by Nakayama, so (h^p-1)X=p(h-1)X. This proves layer growth
   without dividing an endomorphism by p on a torsion module.
4. The fixed starting layer can be j=1+ceil(log_p R), improving the
   source's conservative floor(log_p R)+3. The new proof uses only this
   smaller layer; it does not claim a changed formal source theorem.
5. The exceptional balls use a strict inequality. Their cardinality bound
   is false with weak inequality, as the explicit two-integer example shows.
6. The interval lemma is generalized to [Y,Y^b], J=b^(R+1)(C_t/eta)^R.
   All exceptional sets are united first. The source likewise uses a common
   union; no invalid intersection of independently chosen intervals occurs.
7. The varying-field fixed-layer discriminant bound is proved directly by
   adjoining two square roots to a fixed cyclotomic field. No conductor-
   discriminant identity is needed for this bound.

## Adversarial peer review

The divisor-review agent read the complete 605-line initial mathematical
draft and independently checked the torsion argument, determinant-centre
direction, index-two dimension bound, full-local-condition descent, and
common-interval quantifiers. No mathematical error was found. Its two
requested clarifications concerning the character extension and the nested
compact sets were incorporated. The root also clarified the use of each
prime's own exceptional set when counting exceptional terms with
multiplicity. This is mathematical peer review within the session, not a
kernel verification of the written manuscript.

## Still open in this reconstruction

- Complete the coarse H^2 estimate with a single absolute exponent C_K.
  The later homology_torsion.tex proves the permutation-complex torsion
  deduction, the mod-3 stabilizer bound, an improved numerical exponent
  conditional on the geometric orbit estimate, and the final local
  Selmer-to-H^2 passage. The geometric complex and the intervening global
  class count remain open in this reconstruction. homology_source_trace.md
  identifies the actual class-counting assembly and distinguishes it from
  the archive's separate, conditional KBridge interface.
- Reconstruct Counts I, II, III, IV, V, Vs and the minus-part comparison
  for the actual varying characters and fields; the separate restricted
  vanishing and Bernoulli-unit results already proved do not replace them.
- Combine with the actual integral theta family and its uniform global
  estimates. The interval mechanism alone does not establish Dirichlet GRH.
