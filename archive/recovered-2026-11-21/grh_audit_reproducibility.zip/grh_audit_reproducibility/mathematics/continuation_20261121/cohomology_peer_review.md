# Adversarial review of the cohomological interval section

Reviewed `cohomological_intervals.tex` in full (the 605-line version preceding the author's final clarifications). The five requested points below have no identified mathematical error. This is a conventional mathematical review, not a new formal verification or a claim that all source dependencies have been reconstructed.

## 1. Finite torsion and the Nakayama argument

The proof does not discard the finite torsion subgroup of the Iwasawa module. If `X` is finitely generated over `Z_p`, the operator `h-1` takes `X` into `p^2 X`, and the auxiliary operator `Q` satisfies `(Q-p)X` contained in `p^2 X`, then

`pX = QX + p(pX)`.

The finitely generated module `pX/QX` therefore equals its multiple by `p`; Nakayama gives `QX=pX`. Since `Q` commutes with `h-1`, the desired identity for `(h^p-1)X` follows. Finite torsion causes no exception. The subsequent estimate for `A/pA` uses the generator bound on a subquotient of a finitely generated `Z_p`-module, not a torsion-free replacement.

## 2. Centres for the determinant factors

For each algebraic eigenvalue parameter, compactness of the image of `Z_p` gives a nearest point. If `s` is a minimizing parameter, the ultrametric inequality gives the stated direction of the comparison with the factor at `e-s`. Thus the roots need not lie in the parameter image. The construction retains multiplicities; roots outside the image cannot make a determinant factor smaller than the resulting comparison permits. Exceptional centres must be combined over the finite collection before choosing the interval, as the section does.

## 3. Uniform bound from characters modulo 2

The decomposition indices are uniform: the congruences `q=3 mod 8` and `d=7 mod 16` give indices two and four in the relevant cyclotomic tower. The quadratic discriminants `-q` and `-d` are odd, so neither quadratic adjunction introduces ramification at two. The two quadratic restriction steps cost at most a factor four in the character count. Requiring the characters to be everywhere unramified and split at two only shrinks the group. These points support the claimed `4(g+6[M:Q])` bound under the stated hypotheses.

## 4. Selmer descent and restriction

For `e>=1`, the nonzero cyclotomic scalar acts surjectively on the divisible coefficient group, giving the required vanishing of the first cohomology of the procyclic quotient. The second cohomology vanishes by its cohomological dimension. At the primes over `p`, the local cyclotomic quotient remains open and nontrivial, so the asserted local restriction injection follows. The twist on the dual module has the stated sign.

For a quadratic extension, the restriction kernel lies in `H^1(C_2,B)`. It is killed by two, and the relevant rank-one `Q_2/Z_2` coefficient group gives size at most two. The same argument should not be stated for an arbitrary coefficient module of unbounded rank; the section retains the rank-one hypothesis.

## 5. Quantifiers and the conditional coarse estimate

The finite exceptional sets are united before selecting a common interval. The threshold in the large variable is uniform in the auxiliary primes where claimed; the later constant `Y` is allowed to depend on them. The fixed-layer discriminant estimate and the comparison of the exponents `epsilon/2 + epsilon/4 = 3 epsilon/4 < 4 epsilon/5` are consistent. The coarse `H^2` estimate is explicitly a hypothesis, and the text does not claim to prove the full source lemma or all other-prime counting estimates.

## Optional clarifications communicated to the author

Two proof details can be made more explicit without changing a result:

1. In the extension of a character from `H` to `HN`, note that `[n,h]` belongs to `N intersect H`, which is killed by the character; this supplies invariance under `N` and makes the extension well defined.
2. For the inertia compactness argument, fix the compact union of conjugates of the finitely many inertia groups at the initial finite layer. If nontrivial restrictions persisted at every later layer, the nested nonempty compact sets obtained by intersecting this union, the later Galois groups, and the nonzero character fibre would meet the limiting group `H`, a contradiction.

No correction to a theorem statement was required. The remaining limitations are the ones stated by the author: the coarse second-cohomology estimate, the full original lemma, and the other-prime estimates are not supplied by this section.
