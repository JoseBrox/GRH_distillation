# Column dimensions and finite-group fixed spaces: source trace

## Mathematical scope

`column_dimensions.tex` proves the abstract column evaluation, the exact fixed-space count with its character hypotheses, the Weyl dimension formula from the previously proved compact branching law, and the actual decorated-lattice dimension and diamond norm-kernel counts. The mass is defined only as the finite weighted sum of lattice classes. Neither its product formula nor its recurrence, the archimedean formal degree, or an ambient automorphic dimension is inferred from this packet.

The proof reuses the conventional arguments in `compact_branching.tex`, `arithmetic_lattices.tex`, and `arithmetic_classes.tex`. It does not assume that a theorem name or a wrapper is a mathematical proof. No Lean compilation, independent kernel replay, or full transitive source read was performed for this fragment. Read scopes below refer to text actually displayed during this continuation, including the immediately preceding context retained in the continuation summary.

## Exact statement and convention matches

All source paths in this section are relative to `sources/lean/src/`.

| Source | Scope read | Role |
|---|---:|---|
| `Formalism/LocalToGlobal/SiegelLatticeTheory/SiegelMassRatios/ColsDim.lean` | Entire file, in successive chunks | `Forms`, `Cols`, `Equi`, `Sharp`, `StabTriv`; evaluation on double cosets; exact column rank. The source's Hermitian convention is conjugate first, so its Riesz map has inverse level character and is conjugate linear. The conventional proof explicitly retains this distinction. |
| `Formalism/LocalToGlobal/SiegelLatticeTheory/SiegelMassRatios/ClassAct.lean` | Entire file | Normalization of the level subgroup, conjugation-invariant character, character trivial on the intersection, and the actual `FixedDim` statement. |
| `Formalism/LocalToGlobal/SiegelLatticeTheory/SiegelMassRatios/DiamondFree.lean` | Entire file | Abstract free finite action and exact `DiamondFreeCols`/`FixedDimCols` interfaces. The reconstruction proves the count by orbit fibers, without a characteristic-zero averaging argument. |
| `Formalism/PeriodIntegrals/UnitaryGroupMassFormula/FixedDimensionCount/ExistsSemidirectDecomposition.lean` | Entire file | The concrete `DK` subgroup, extension of the level character, fixed forms as forms of larger level, and the exact class-fiber count. |
| `Formalism/LocalToGlobal/Columns/AtTRank.lean` | Entire file | Actual auxiliary residue-unit action, free action on decorated classes, norm operators, and `finrank_MramV_mul`. Its use of a large first level prime is replaced by the already proved two-distinct-primes stabilizer argument, whose hypotheses also hold in the actual construction. |
| `Formalism/LocalToGlobal/Columns/ColFormsLemmas.lean` | 125–195 | Actual `colFree`, `finrank_MfV`, integral evaluation and positive-rank consequence. |
| `Formalism/LocalToGlobal/Columns/CmUnramifiedOfFieldConditions.lean` | 462–690; 715–775 | `UniCl`, finite isometry groups, `massC` as the weighted sum, raw-decoration count, finite unipotent-level quotient, `card_formCl`, `massk`, `IpiC`, `dimC`, `dstarC`, `finrank_colV`, `card_colCl`, `finrank_MfV_eq`; then the exact shift from `wSeq` to the Harish–Chandra parameters. The generic orbit-count theorem located earlier at line 376 was not read in this pass; the manuscript supplies its elementary orbit proof independently. |
| `Formalism/LocalToGlobal/Columns/LevGCount.lean` | 1–145 | `HX_zero` identifies the actual level-zero subgroup with the full upper triangular unipotent group; `lamX_zero` identifies its character. Thus the quotient is neither by a Borel subgroup nor by scalar matrices. |
| `Formalism/LocalToGlobal/Columns/AbelianHostFieldConditions.lean` | 1–275 | CM degree `2f`, the two distinct rational level primes, the selected sets of size `f`, their exact residue cardinalities, and the distinct auxiliary rational prime `T`. Only one half of each conjugate-prime pair is selected. |
| `Formalism/LocalToGlobal/Columns/Inputs.lean` | 55–88 | `wSeq` and `WeylDim`; the source defines the latter through the cardinality of its tableau index set. The ordinary proof computes the coefficient-module dimension directly by branching; it does not assert that this pass independently reconstructed the tableau basis theorem in every characteristic. |

## Minimal source-to-manuscript identifications

1. `cd-column-decomposition` proves the submitted abstract `ColsDim` formula under the exact trivial-stabilizer condition. `cd-riesz-character` checks the inverse character and the conjugate linearity of the Riesz passage.
2. `cd-fixed-dimension` proves `FixedDim`. Its hypotheses include normalization, invariance of the character under conjugation, and triviality on `D ∩ K`; none is silently dropped. Two small counterexamples show why the stabilizer and intersection-character assumptions are substantive.
3. `cd-weyl-dimension` follows from the already proved compact branching theorem `ib-compact-branching`. The binomial determinant calculation proves the scalar product formula without using a Weyl character formula or assuming a dimension identity.
4. `cd-decoration-count` uses the actual frame modulo upper unipotent group and the actual nonzero auxiliary covector. Full projective lattices are locally free; no global basis is assumed. Automorphisms are finite by positive definiteness, and unipotent reduction at two distinct rational primes forces them to be trivial by `al-two-primes`. The actual extension is unramified at every finite place and the ambient space is standard. The proved local norm and orthonormal-basis statements `acl-local-norm`/`acl-local-basis` therefore put every unimodular lattice in the standard genus, identifying this weighted sum with exactly the genus mass used in `md-section`.
5. `cd-source-dimension` therefore supplies the actual source-space formula previously displayed as `as-column-assumption`, when its mass is the weighted class sum. Identifying this mass with an analytic Euler product remains a separate task.
6. `cd-diamond-free` uses the same two-prime argument before concluding that scaling a nonzero auxiliary covector is free. Evaluation at representatives of the free action makes the module regular in the residue-unit factors, with no stabilizer character omitted.
7. `cd-norm-kernel-dimensions` gives the exact fixed-space and simultaneous norm-kernel ranks. The proof uses the onto sum functional and a splitting by the indicator of one group element; it is valid even when the coefficient characteristic divides the group order. The endpoint `T = 2` gives zero norm kernel as it should.

## Conventional dependencies and read scope

The current pass read `compact_branching.tex` 130–285 to check that branching was established by highest-vector elimination and unitary decomposition, not by a dimension formula, so the dimension calculation is not circular. It read `arithmetic_lattices.tex` 160–255 for the finite-order reduction and two-prime argument, and `arithmetic_classes.tex` 1–115 and 510–550 for local orthonormal bases and the previously proved exact class-evaluation isomorphism. The established finiteness argument for lattice classes in `arithmetic_lattices.tex` is reused from the earlier complete reconstruction and its peer review; no claim of rereading that whole fragment is made here. The relevant column-size display in `theta_archimedean_sizes.tex` was read, but that entire file was not audited in this pass.

## Outcome

No counterexample satisfying the actual hypotheses was found. The two counterexamples in the text concern explicitly weakened abstract statements. The complete mathematical proof is distinct from source-text inspection and from typesetting verification. The manifest records source hashes and exact read intervals; the compile record concerns only XeLaTeX.

The root agent independently read the complete original 452-line fragment and found no mathematical defect. Its requested identification of the class sum with the standard genus mass has been inserted using the previously proved local orthonormal-basis theorem. A second review is queued with the QRH agent; it is not yet reported as completed.
