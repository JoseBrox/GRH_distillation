# Independent review: compact_branching

Date: 2026-11-21. Reviewer: qrh_mathematics.

Read all 300 lines of `compact_branching.tex`, SHA256 `0b1b8d8e1260e326f73a9d7d2cfc5a37079e1db59fb14457942379fc7890f3b2`.

I independently read the entire fragment, including the full elementary highest-weight and branching proofs. No mathematical defect was found.

The rational-kernel argument correctly extends the cyclic divided-row span to C. The orthogonal-projection proof of irreducibility uses the one-dimensional extremal weight space, rather than an unproved highest-weight classification. The Gram-matrix ordering argument terminates by word length and inversion number; raising words vanish on a highest vector and nonempty lowering words have strictly smaller lexicographic weight. It gives a well-defined intertwiner and uniqueness from the displayed gl relations and adjoints. Integral torus weights and dominance are justified.

The lower unipotent row invariance and upper unipotent column invariance have the correct orientations for rho(g)F(X)=F(g^t X). On the open LDU cell the simultaneous degrees force the stated monomial in diagonal and last-row coordinates. The minors Delta_i and S_i are pairwise nonassociate irreducibles in the full polynomial ring; the cofactor induction includes size one. Consequently negative exponents cannot cancel. This proves the precise interlacing criterion and multiplicity one, not merely an upper bound. The determinant twist gives the correct last-circle character and handles negative smallest weights. The N=1 case is explicit.

The proof uses the already reconstructed polynomial duality and extremal-vector results. I did not re-audit every source import during this conventional peer review.
