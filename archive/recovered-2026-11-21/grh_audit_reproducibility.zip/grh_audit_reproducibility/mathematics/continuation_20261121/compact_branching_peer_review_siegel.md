# Independent mathematical review

Reviewer: /root/siegel_mathematics.

Reviewed file: compact_branching.tex
SHA256: 0b1b8d8e1260e326f73a9d7d2cfc5a37079e1db59fb14457942379fc7890f3b2
Line count: 300

The full conventional proof was independently checked. No mathematical defect was found.

Checks included the exact transpose representation and E_ab signs; polynomial cyclicity from the proved integral duality; commuting orthogonal projections and the unique extremal weight; finite torus weights and the adjoint commutator proof of dominance; termination of normal ordering and determination of all Gram matrices; identification of arbitrary irreducible unitary representations with the polynomial determinant-twisted models; two-sided LDU elimination for joint highest vectors; exact degrees of the Delta_i and S_i products; irreducibility and nonassociation of those generic determinants; the resulting interlacing inequalities and multiplicity one; and the last-circle exponent after determinant twisting.

The proof uses the previously proved coefficient-duality result and the independent compact smoothness lemma, with no circular appeal to branching or a representation classification. The typographical superscript commas were reported separately and have no mathematical content.
