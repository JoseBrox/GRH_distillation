# Compact branching: conventional reconstruction

The complete proof is in `compact_branching.tex`. The manifest records
the source interfaces and exact line intervals examined. This is an
independent ordinary proof, not a claim to have read every line of the
large Lean branching development.

The representation convention is the actual polynomial row action
`rho(g)F(X)=F(g^t X)`. Divided lowering operators are the coefficient
operators of elementary row substitution. The previously proved
coefficient duality makes the highest vector cyclic. The positive Fock
pairing then gives irreducibility for the compact group.

For completeness, the proof classifies finite-dimensional continuous
irreducible representations of U(r). The required smoothness is supplied
by the independent convolution argument in the radial-positivity
fragment. A lexicographically maximal torus weight is dominant by the
adjoint relation for matrix units. Normal ordering shows that all Gram
matrices of lowering words are determined by that weight; comparison
with the polynomial model proves uniqueness, including determinant
shifts. There is no invocation of an unstated classification theorem.

The U(n+1) to U(n) branching law is then computed by two Gaussian
eliminations. Simultaneous highest vectors are forced to be the products
of the initial minors and the minors with the last row substituted.
Primality and nonassociation of those determinants imply precisely the
interlacing inequalities. Each highest space is one-dimensional, and
the final circle acts by the degree difference.

This proves the ordinary mathematics underlying `BranchingLawGL`, the
interlacing polynomial, and the relevant block restriction. The integral
normalization, which is additional information, is proved in
`integral_branching.tex`. Independent reviews by the QRH and radial
agents are recorded beside the fragment. No counterexample to the
branching theorem under its hypotheses was found.
