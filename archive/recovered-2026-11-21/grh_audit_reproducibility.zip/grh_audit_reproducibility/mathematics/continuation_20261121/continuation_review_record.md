# Continued mathematical audit — 21 November 2026

## Status

No fatal flaw in the submitted Dirichlet-GRH proof has been established.
The complete source development has not been exhaustively reconstructed
in ordinary mathematics. The two deliverables distinguish the formal
evidence, proved ordinary lemmas, conditional reductions, and work that
remains. In particular, this manuscript is NOT a completed proof of GRH.

The former complete export inventory and canonical statement comparison
were not rerun. The public MIT verification page was checked again: its
displayed last update remains 20 November 2026, 19:45 UTC, with the same
nanoda acceptance and the additional comparator/export-kernel checks
still in progress. No new independent-kernel verdict is claimed.

## New mathematical sections and independent review

| Section | Completed contribution | Explicit boundary | Review |
|---|---|---|---|
| quadratic_selection.tex | Full finite family of quadratic twists selected on a whole interval, with conductors, imprimitive factors, progression correlations and maximal second moments | Uses the stated October QRH half-plane; does not reconstruct the whole QRH proof | Root and real-zero/theta reviewer |
| cohomological_intervals.tex | Exact strict-local-condition descent; uniform generator bound; finite torsion retained in determinant bounds; exceptional weights and one common interval | Coarse H^2 input is now proved in k_theory_coarse.tex; other prime/character components remain; Ferrero--Washington and duality are classical inputs | Root author; independent divisor reviewer |
| homology_torsion.tex | Integral boundary and finite-stabilizer torsion bounds; mod-3 stabilizer proof; improved numerical exponent; exact local H^0 bound and Selmer-to-H^2 deduction | The original SFew construction remains separate; the independent K-theory route now supplies the coarse cohomological bound | Root author; independent QRH reviewer |
| arithmetic_complex.tex | Actual ordered normal-cone nerve; closed-convex exactness proof; common minimal columns; scaled-inverse integral matrix reduction; full orbit estimate | Geometric result; the alternative coarse cohomology route is in k_theory_coarse.tex | Root independent review; additional QRH review recorded separately |
| selmer_layer.tex | Minkowski ideal count and class number; cyclotomic degree/discriminant estimate; strict Selmer monotonicity and parameter selection | Applies to the stated cyclotomic tower, not arbitrary p-extensions | Root author; independent formal reviewer |
| selmer_unit_count.tex | Full unit theorem; exact determinant quotient; Kummer p-rank; Hilbert90; weighted norm and SCount | SFew remains the original route's separate input | Root author; independent formal reviewer |
| selmer_comparison_proofs.tex | Strict Selmer descent to equivariant ideal-class characters with all local conditions; conditional exponent86/88 | Hilbert class field reciprocity and duality explicitly imported | Root independent review |
| selmer_detection.tex and selmer_homology_cycles.tex | Degree-one-prime detection, actual cyclic bar cycle and relation | Chebotarev explicitly imported; finite-field functional and arithmetic classes remain separate | Root independent review |
| selmer_lattice_isomorphisms.tex and selmer_character_interpolation.tex | Exact determinant-prescribed ideal-lattice isomorphism and integral cyclic-character interpolation | Finite-field transfer and arithmetic cycle assembly remain separate | Root independent review |
| k_theory_coarse.tex | Exact Hurewicz-kernel/order comparison and coarse H2 and strict Selmer exponent14 | Quillen, Borel, stability, Quillen–Lichtenbaum, Mathew and duality explicitly stated classical inputs; not a proof of SFew | Root independently checked primary references and all deductions |
| selection_assembly.tex | Field and character identification; all relevant conductor/size comparisons; fixed order of choices; degree rescaling and interval compatibility | All-odd-prime eigenspace bounds and other arithmetic inputs are not inferred from fixed-prime estimates | Root and QRH reviewer |
| coefficient_duality.tex | Integral polynomial Weyl/dual-Weyl duality by elimination and divided row operators, including determinants, tensors, local transport, conjugation and ramified scalar extension | The particular underlying arithmetic lattices and their quantitative construction remain to be supplied | Root and independent QRH reviewer |
| divisor.tex | Exact quotient covolume identity with nonnegative defect; conjugate-prime indices; actual finite-group dual exponent; rectangular chain bounds and integral pairings | Particular local divisibility/exponent estimates, spectral maps and global operators remain | Root and divisor reviewer |
| arithmetic_maps.tex | Actual coefficient ideals, exact elementary divisors and singular values, Fock normalization and slope cancellation | Actual period maps and complete class-coordinate identification remain separate | Root and formal independent reviews |
| arithmetic_lattices.tex | Explicit initial decoration; kernel degree; two-prime stabilizers; Gaussian transference and short Hermitian dual vectors; finite decorated class set | Quantitative automorphic class/dimension formulas and actual coordinate comparison remain separate | Root and formal independent reviews |
| integral_period_pairings.tex | Rational integral cut commutes with field extension; projector denominator and all-vector valuation extension | Does not prove the initial actual period valuation bound | Root author; independent QRH review |
| theta_estimates.tex | Local Gaussian/Morse/stationary-phase formulas; finite Gram positivity; Fourier averaging and limit; convolution normalization; unfolding; combination of exact global input estimates | Weighted seed integrability/nonvanishing and global orbital/energy estimates remain | Root and independent QRH reviewer |
| theta_orbital_identity.tex | Actual finite orbital sums, representative independence, uniform local constancy and inverse-parameter support; root-fiber Haar formula and cancellation; truncated identity | Its germ input is proved in the later sections; global bounds remain separate | Root and independent QRH reviewer |
| theta_germ_uniformity.tex | Finite marked-cokernel types from bounded determinant range; finitely many scalar germs imply the full kernel germ uniformly over arbitrary comparisons | A reduction, used with the now-proved scalar formula | Root and independent real-zero/theta reviewer |
| theta_scalar_germ.tex and theta_head_reduction.tex | Exact Hessenberg oscillatory reduction, critical amplitude, compact-parameter uniformity, and finite block-matrix reduction against arbitrary marked targets | Local result, without global energy estimates | Root and reciprocal independent reviews by the two authors |
| theta_germ_assembly.tex | Full actual kernel germ and truncated identity, with arbitrary comparison size and all required uniformity | No additional local germ assumption remains | Root and both local reviewers |
| theta_parseval.tex | Actual bordered-cokernel isomorphism count, exact single-block Parseval, minor support, unrestricted diagonal and full majorant induction | Global orbital sums and arithmetic divisibility remain separate | Root author; independent QRH reviewer |
| global_theta_estimates.tex | Strong ideal sum; exact unramified period/dual/lift indices and covolumes including2; continuous-product-decay Poisson with exact normalization | Actual Fourier coefficients and remaining global orbital contributions remain | Root and QRH independent reviews |
| theta_archimedean_sizes.tex | Vandermonde perturbation, boundary constant80, critical scale, normalized widths and improved power range | Precise mass/dimension/formal-degree identities are assumptions; actual test-function coefficient identities remain | Root and QRH independent reviews |

The source trace files give the exact semantic links to the submitted
definitions. Their hash manifests distinguish entire-file reading,
selected ranges and declaration searches. An entire assembly file being
read does not imply that all its transitive providers were reviewed.

## Corrections and simplifications made during this review

- Replaced the earlier shorthand involving three quadratic characters by
  the actual fixed finite family of base characters and all its three
  nontrivial quadratic twists.
- Kept finite torsion in the cyclotomic module, using a free cover rather
  than its torsion-free quotient. The exceptional p-adic balls are strict.
- Selected one cohomological interval from the union of exceptional
  weights; did not intersect independently chosen intervals.
- Traced the final coarse-cohomology route through global class counting.
  The separate conditional KBridge interface is not a proof of that route. A later independent proof in k_theory_coarse.tex supplies the coarse input from checked classical theorems, not from that interface.
- Proved coefficient duality by lower-triangular restriction and
  localization, avoiding the imported tableau argument for this step.
- Converted squared-norm heights and covolumes to ordinary slopes
  simultaneously, retaining both factors of two.
- Retained the self-dual measure for the nonmaximal split order and
  every determinant factor at residue characteristics dividing 2(m+1).
- Required a common analytic radius and coefficient-norm bound for
  uniform Morse coordinates, rather than coefficientwise boundedness.
- Corrected the coefficient conjugation in the finite Gram quadratic
  form and made the actual global D_* normalization and row factor explicit.
- Proved support by a finite-module character argument using partial
  column modules; no principal-ideal-domain assumption is used.
- Constructed the actual ordered normal-cone nerve and bounded all its
  orbits using scaled inverses modulo the norm determinant; no ideal
  class-number estimate is needed for this geometric component.
- Reduced the scalar germ to the first-order expansion of a Hessenberg
  determinant; retained the full affine Jacobian and compact-parameter
  uniformity, including residue characteristics dividing 2(m+1).
- Proved the single-block formula through a pullback module preserving
  the vector and functional; retained both cokernel-order factors.

## Counterexamples and exact controls

The explicit examples disprove omitted hypotheses or changed statements:
too many forced small splitting primes in the second moment; discarding
finite cyclotomic torsion; replacing strict p-adic balls by closed balls;
ignoring finite stabilizers; localizing a Hermitian basis at one of two
conjugate primes only; turning the non-CM quotient inequality into an
equality; inferring a least singular value from bounds on spanning lines;
multiplying determinantal ideals in the wrong direction; saturating the
Weyl lattice; dropping the Fock or determinant normalization; ignoring
Gaussian admissibility or self-dual measure; and deleting the support
condition in the mixed critical-term cancellation.

None is presented as a counterexample to a source theorem satisfying all
its actual hypotheses.

The prime-sum certificate uses exact rational arithmetic. The coefficient
controls construct two integer lattices independently and check a perfect
normalized pairing in twelve cases. The local theta controls use exact
cyclotomic-polynomial reduction, including residue characteristic 2 and
primes dividing m+1. Six exact finite marked-module kernel controls
compare the unrestricted and triangular isomorphism sums at p=3 and 5;
four representative-change controls check the omitted-support example.
Twenty-eight independent bordered-kernel comparisons and eight Parseval
totals are verified by enumerating actual module maps over Q_2, Q_3 and
Q_5. Four symbolic determinant/Jacobian cases and five rational valuation
cases check the scalar-germ calculation, including small primes.
The general claims rest on the written proofs, not
on extrapolation from these computations.

## Concrete next mathematical obligations

1. Complete the actual archimedean coefficient, mass/dimension, and global energy arguments, all four orbital-sum
   estimates, the diagonal term and the ambient-dimension estimate for the
   particular automorphic maps.
2. Audit the remaining original SFew class construction and complete the other prime and character cohomology estimates. The coarse H2 bound is now supplied by the independent K-theory route.
3. Identify the actual automorphic class-coordinate lattices and prove their local period divisibility/exponent and spectral estimates with constants
   uniform in the growing chain length.
4. Assemble those estimates into the fixed smoothed prime combination.
   The final analytic implication to Dirichlet GRH is already written.

The alternative shorter-range mean-square route remains conditional.
The original QRH papers also have not been fully independently
reconstructed here; their stated zero-free input is never treated as a
proof of the critical-line conclusion.

## Further counterexamples and exact checks

The new complete arguments retain: the roots of unity needed for power detection (16 is an eighth power modulo every odd prime but not in Q); the prime-power modulus in the unit-coefficient relation (vectors3,2 modulo6); positive definiteness and two distinct residue characteristics in the stabilizer lemma; integrality for the short-dual estimate; unramifiedness for the exact parity-lattice covolume; and rationality/faithful complexification for the integral cut. The global sum has a necessary logarithmic loss at full decay, witnessed by units of Q(sqrt(2),i). None is an actual counterexample to the source's qualified theorems. The new global-lattice script has41 exact controls, recorded separately; the Gaussian numerical constants are certified by rational inequalities.

The archimedean size script records10124 exact finite controls of binary Vandermonde coefficients, polynomial factorizations, finite-level exponents, and interior/terminal normalizations. These check the recorded finite identities; the general inequalities are proved in the manuscript.
