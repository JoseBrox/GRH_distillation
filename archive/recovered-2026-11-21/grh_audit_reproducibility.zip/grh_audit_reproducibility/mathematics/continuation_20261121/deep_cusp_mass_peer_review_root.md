# Independent review of the deep-cusp mass estimate

Root review, 2026-11-21. All 877 lines of deep_cusp_mass.tex were read
at SHA-256 566e780863949980822ccc34388f6655f0126e7cfb2d766b890bc54feb847d15.
The ordinary mathematical proof passes independent review. A final
explicit ambient multiplicity corollary and a positive-rank clarification
have been requested; their final hash will be recorded separately.

The Hecke functional equation gives the stated boundary bound at
Re(s)=-1/2. The gamma quotient is exactly |1/4-it/2|. Dividing by
(s+2)^f and using the rectangle maximum principle gives
L_F(1,chi) <= 3^f |D_F|^(1/4). The volume bound uses the already
checked Hilbert--Schmidt Haar normalization; the principal congruence
index is bounded by the cardinality of the full endomorphism ring,
including for projective lattices.

Ideal multiplication scales each normalized sublattice or quotient
size by the norm of the ideal to the power 1/(2f). The Hom trace dual
has Riesz vector 2U*, whereas the skew-Hermitian central trace lies
in F and has no factor 2. The local diagonal trace-zero generator at
a dyadic unramified inert prime has unit square; the trace equation
forces the second coefficient to be divisible by 2. Thus the asserted
central perfect pairing is valid at dyadic and split primes alike.
The extension argument for greatest quotient size uses saturation
and quotient metrics. The selected slope gap produces a radical
fundamental domain of the stated radius. Its central fibers may be
affine; their covering radius is unchanged. No integral orthogonal
Witt splitting is silently assumed.

The local cusp theorem applies to U(p,q) through its compact central
cover. Kernel columns may be unfolded along a compact adelic unipotent
quotient because AK supplies absolute locally uniform convergence.
Their finite-dimensional span gives cuspidality of every basis vector.
Unipotent approximation identifies the finite-level constant term
with the real compact radical quotient; right translates and Lie
derivatives retain zero constant terms.

The sign in the Casimir energy is 2 Omega_K - Omega_G. Compact weights
in V_P are bounded using the weights of at most P adjoint factors,
and each fixed orthonormal derivative in the product basis is supported
at one real place. This avoids an unnecessary extra f in the Sobolev
word estimate. For product coordinates, mixed derivatives in increasing
index order are exactly the corresponding ordered Maurer--Cartan
operators. Direct differentiation of the product confirms the absence
of omitted coefficient-derivative terms in that ordered identity.
The chart is injective by its derivative bound, its Haar density is
at least 2^(-N), and the arithmetic quotient multiplicity follows from
the already proved product packing inequality. Fixed words, rather
than vectors depending on the chart point, are used in the L2 bound.

The zero-average iteration controls the entire small radical domain,
not only its center. Nearby metrics have least size at least tau/2.
The explicit evaluation bound is X^(13N) tau^(-4N) D/vol(K_f(g)).
After 8qN iterations its tau exponent is 12N. At tau<X^(-11q),
integration costs at most X^(3N), giving X^((-52q+16)N)D and hence
X^(-36N)D <= exp(-N)D. The numerical comparison for beta is already
valid for n>=100, well below log(n)>=20.

Primary-reference checks by the root:

- Bost--Kuennemann, author preprint 11 January 2007, printed p.46,
  Theorem 3.7.2, equation (3.54), and its definitions of covering radius
  and Euclidean dual: https://epub.uni-regensburg.de/13828/1/MP77.pdf .
- Zaman, arXiv:1502.05679v4, section 2.1, equations (2.1)--(2.3) and
  Lemma 2.1: https://arxiv.org/pdf/1502.05679 . The functional equation,
  entire completion for the nontrivial character, and polynomial
  growth supply exactly the qualitative import used here.
- Khare--Larsen--Savin, arXiv:math/0610860v3, section 4.1, checked in
  the preceding root review: the discrete-series cusp coefficient
  and the Poincare-series constant-term unfolding.

The prior AMB, AK, RV and NU proofs and their hypotheses were compared
again at the uses above. This is a mathematical reconstruction and
source review, not a new complete Lean kernel replay. It closes the
deep-cusp input only with the stated classical local cusp theorem,
Euclidean transference theorem, and Hecke analytic theorem retained.

Final version reviewed: SHA-256
da39087df84eb57538bb4850e7f1c95f940e64550aa7c39a2aea068cf34195a9.
The positive-rank clarification and the entire added corollary and
proof were read. The corollary checks the shared hypotheses of AK,
RV, NU and the distant-term estimate, then applies the exact AMB
absorption argument. The root independently reran
check_deep_cusp_constants.py: all 20,672 exact assertions passed
against this final fragment hash.
