# Deep-cusp mass estimate: exact statement and reading scope

Reader/author: /root/formal_degree_review, 21 November 2026.

Mathematical fragment: deep_cusp_mass.tex.
Initial frozen review SHA-256:
566e780863949980822ccc34388f6655f0126e7cfb2d766b890bc54feb847d15.
The root independently read all 877 lines, checked the primary statements,
and reported a mathematical PASS.

At the root's request, two tracked additions were made: the general Hom
covering lemma explicitly requires positive ranks, and a corollary
assembles the complete complex ambient multiplicity comparison.
Final SHA-256:
da39087df84eb57538bb4850e7f1c95f940e64550aa7c39a2aea068cf34195a9.
No preceding mathematical argument was otherwise altered.
The root then reviewed these final additions and independently reran
all 20,672 exact assertions successfully at the final hash.

## What is proved

For the actual complex projection kernel and multiplicity already constructed
in automorphic_projection_kernel.tex, the fragment proves

    integral_{least(x)<X^(-11q)} K(x,x) dx <= exp(-n^2 f) D,
    X = n f r_E g b.

The hypotheses are the same CM field, self-dual Hermitian lattice, archimedean
discrete series, and finite congruence level as AMB/AK, with
log n >= 20, q >= 1, q^2 <= n, b >= 2, g >= 1, and
|lambda_(v,i)| <= b^2. The gap required for AK's kernel convergence
and finite-rank construction is inherited explicitly. No upper bound on
log b, f, g, or r_E is used in this additional deep-cusp estimate.

This supplies AMB equation amb-deep-input. The final corollary combines
the actual kernel, rare-cusp, near-unipotent, deep-cusp, and distant-orbit
results to prove |D-D_*| <= exp(-n f log n/16) D_* under their common
explicit hypotheses. It does not assert verification of the whole GRH
argument or a full Lean kernel replay.

## Matching the actual source declarations

All paths in the numbered list are relative to
sources/lean/src/Development/AbelianVarietyTheory unless specified.

1. BlockTheory/SiegelWeilLocal/DeepSetBound.lean, all:
   deepSet is a fundamental-domain subset with least < tauStar.
   DeepBound integrates the nonnegative real kernel diagonal and
   bounds it by D exp(-n^2 f). This is exactly the target proved.

2. BlockTheory/SiegelWeilLocal/DeepKernelBound.lean, all:
   dimN=n^2 f, radRh=n^2 sqrt(f) g r_E (2 tau)^(1/q)/4,
   and the iteration exponent 16 q dimN match our proof.
   Our derivative constant and Sobolev bound are deliberately coarser
   than stepBe and the source pointwise expression. We prove the
   final DeepBound directly, not its sharper intermediate inequality.

3. BlockTheory/SiegelWeilLocal/CoveringRadii.lean, all:
   InNil, InCen, nilO, cenO, normX, and nextSize specify the
   radical, center, integral structures, Hilbert--Schmidt norm,
   and final endpoint 1/2. The hypotheses tau_i/nextSize <= R
   and tau_i^2 <= R/4 match the chosen consecutive gap.
   Our quotient argument reduces the projected coordinate and
   then the central affine fiber, using an integral trace-one lift.

4. Proofs/FlagMeasures/DeepPointBoundCuspidalIsometricIntertwinerFamily.lean,
   all, and its Statement file, all:
   the source iterates 2 rho sqrt(f) beta down from 8 q n^2 f.
   Our vector-valued proof establishes this from actual smooth
   isometric intertwiners and zero averages.

5. Proofs/FlagMeasures/DeepPointKernelBoundOfPointwiseBound.lean, all:
   the source identifies the diagonal with the norm square of the
   intertwiner family, using cuspidality and finite-dimensionality.
   Our proof uses the independently reviewed pointwise AK identity.

6. Proofs/FlagMeasures/DeepRegionKernelDiagonalBound.lean, all:
   combines the pointwise estimate, volume, index, and exponent
   absorption. Our independent absorption gives
   X^((-52q+16)N) D <= X^(-36N) D.

7. Statements/CuspFrameWeights/ConvolutionSmoothL2.lean, all:
   CoefCusp, KernelA, KernelB, CuspCont, and Cuspidal specify the
   actual coefficient and constant-term interfaces. We derive
   the needed global cuspidality from the classical local theorem
   and the absolutely convergent Poincare-kernel unfolding.

8. Definitions/SemilocalFrames/HermitianFormUnitaryOneOne.lean,
   lines 1--65; and, relative to the overall source root,
   Formalism/SharpRestriction/CuspSpanNormBounds/GlobAut.lean,
   lines 125--165:
   both IsIsoC and IsIsot require a NONZERO isotropic subspace.
   There is no unintended vanishing along the trivial radical.
   NW, InUnipRad, and NA describe the same two-step radical.

9. Definitions/SemilocalFrames/PosPartUnitaryMul.lean,
   lines 80--117:
   IsSqIntIrr includes completeness, nontriviality, unitarity,
   irreducibility, and square integrability. No altered notion of
   discrete series is used for the local cusp import.

10. Statements/CuspFrameWeights/SameKindIsometric.lean, all;
    Definitions/SemilocalFrames/DefClassNum.lean, lines 30--49:
    AbsoluteVolume is more generally quantified in an auxiliary X.
    Our lemma proves the precise application X=n f r_E g b from
    the exact RV volume and an explicit Hecke estimate; it does
    not assert that more general source declaration for every X.
    gaugeVol includes the archimedean gauge factors and division
    by the finite stabilizer volume, removed by our stated Haar
    normalization. RankTwoClasses is unnecessary in this route.

BlockTheory/PoincareCuspForms/SmallUnipotentElements.lean was also
inspected while locating the route; its balanced-point result is unused.
This is an exact reading list, not a complete transitive dependency review.

## Classical imports and verified primary passages

* Banaszczyk, Theorem 2.2: arbitrary real Euclidean lattices satisfy
  covrad(L) lambda_1(L^dual) <= dim(L)/2.
  The original theorem and surrounding text were inspected in an
  available original-paper text mirror. The constant and conventions
  were independently checked in Bost--Künnemann, Theorem 3.7.2,
  equation (3.54), printed p. 46. That page was rendered and visually
  checked; selected pp. 46--48 were read, not the whole preprint.

* The classical Harish--Chandra cusp-Schwartz theorem for compact-finite
  coefficients of real discrete series. Discrete Series II, section 33,
  Lemma 65 and Corollary 1 were read for the Schwartz assertion.
  Khare--Larsen--Savin section 4.1, pp. 14--15 of v3 was read for the
  cusp assertion and constant-term unfolding; p. 15 was visually checked.
  Their global theorem concerns a quasi-split simple group and is NOT
  directly applied to U(p,q). Our proof imports the classical local
  theorem, passes through U(1) x SU(p,q) -> U(p,q), and performs its own
  global unfolding from AK. The alternative global Wallach-spectrum
  route quoted by Urban was investigated but is not used.

* The classical Hecke continuation, functional equation, and qualitative
  polynomial growth on fixed vertical strips. Zaman v4, section 2.1,
  equations (2.1)--(2.3) and Lemma 2.1, pp. 6--7, were read; p. 6 was
  rendered to check the conjugation in the functional equation.
  We apply these with conductor one and all real parity parameters one,
  then prove L_F(1,chi) <= 3^f D_F^(1/4) by a strip maximum principle.
  No zero-free region or Siegel-zero exclusion is used.

The exact unitary volume and integral splitting are supplied by the
reviewed RV fragment, with its explicit Tamagawa and local-classification
imports. The parameter, compact type, and actual projection construction
come from the reviewed FD, AMB, and AK fragments.

## Controls, compilation, and remaining scope

check_deep_cusp_constants.py passed 20,672 exact assertions:
trace-one lifts and full unitary matrix identities over Z[omega],
central trace Gram determinants at a dyadic unramified quadratic
place, noncommuting mixed chart derivatives, averaged fundamental-
theorem identities, chart/Sobolev constants, and rational parameter
and exponent controls. There are no floating-point verdicts.
These finite controls do not prove the imported analytic theorems
or replace the written mathematical proofs.

The companion wrapper compiled twice with exit status zero and no
overfull boxes. Unresolved references belong only to the other
fragments. The Sobolev page and final assembly corollary
were rendered and visually checked.
The final manifest records the current exact page count and hashes.
The ordinary mathematical theorem is conditional only on the named
classical theorems, not on an additional unpublished cusp estimate.
