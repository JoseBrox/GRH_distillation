# Independent review: degenerate flags and off-diagonal orbital vanishing

Verdict: PASS for the stated geometric normal form and the vanishing of
absolutely convergent off-diagonal orbital operators.

Reviewed manuscript SHA-256:
`ba8132d8fefab0c1f51dfcf79b6c94518460b597650e7c713ddaebc86f360e68`.
Root read the complete original 536-line draft, then checked the final
compact-open subgroup condition, explicit external tensor products, and
the direct torus-weight proof replacing an unnecessary classification input.

## Mathematical checks

The rank-two skew endomorphism argument gives the successor relation for
common flag vectors. Iteration forces equal levels and a unique scalar
ratio, using negativity of the distinguished vector. The nondegenerate
cross-pairing and the reverse Cauchy--Schwarz equality in signature (k,1)
give the asserted normal form, including the case of zero intersection.
The positive k-dimensional common complement identifies both compact
quotients and hence both compact-group actions.

The arithmetic common stabilizer is a cocompact lattice in the real
unipotent intersection. The proof first integrates over that real
unipotent quotient. Compact conjugation preserves its Haar measure,
because its positive modulus is a continuous character of a compact group.
The compact group is not assumed to preserve the arithmetic lattice.
This is essential to the validity of the change of variables.

For irrelevant flags the nontrivial character has zero integral on the
compact unipotent quotient. For relevant degenerate flags the orbital
operator intertwines the two compact actions. Taking matrix entries in
the other tensor factors and applying Schur's lemma proves vanishing.
The rank-one operator convention includes the necessary conjugation on
the second factor.

The highest weights are lambda-rho, with rho_a=(k-1)/2-a. An isomorphism
would make each highest weight dominate the other in the positive-root
cone. The functional sum_a (k-a)x_a is strictly positive on every positive
root, so that cone contains no nonzero vector together with its negative.
This proves inequivalence directly from the source's weight condition.

## Source comparison by root

Root read `RelevantZeroGramTerms.lean` lines 1--110, including `IsKTypeOf`
and `IsHCTypeU`; `StatementDS.lean` lines 1--55, including `lowK`;
`RealPlaceAnalysis/StatementA.lean` lines 25--48 for both root sums;
the complete `SchurNFCOf.lean`; and `DistinctWordsDistinctParameters.lean`
lines 715--750 for the active distinct-word implication. These confirm
the highest-weight shift, the tensor factors and the actual parameter
inequality used for the off-diagonal conclusion. The drafting review's
larger source-reading scope is separately recorded in its manifest.

## Limits

Absolute convergence is a hypothesis of this vanishing theorem. Neither
the diagonal amplitude estimate nor the weighted lattice-pair count is
proved here. The finite exact controls supplement, and do not replace,
the general geometric proof. No complete Lean kernel replay is asserted.
