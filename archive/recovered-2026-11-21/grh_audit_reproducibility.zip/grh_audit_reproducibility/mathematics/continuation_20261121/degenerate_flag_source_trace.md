# Degenerate flag orbits: source trace and scope

Author: `/root/formal_degree_review`.
Mathematical fragment: `degenerate_flag_orthogonality.tex`.
Final mathematical SHA-256: `ba8132d8fefab0c1f51dfcf79b6c94518460b597650e7c713ddaebc86f360e68`.

## Result proved in ordinary mathematics

The fragment proves the normal form of a relevant pair of isotropic flags with vanishing degenerate Gram determinant, constructs a common compact group isomorphic to the product of the positive quotient groups U(k), and proves vanishing of the absolutely convergent off-diagonal orbital operator when the compact parameters differ at one real place. It also proves the cancellation for nonrelevant flags by integration over the common real unipotent group modulo its arithmetic lattice.

The proof handles nonzero intersection of the isotropic subspaces directly. Its main identity is obtained from the rank-two skew-Hermitian operator

    A_(x,v)(y) = h(v,y)x - h(x,y)v.

The identity forces equal levels for common vectors, a suffix of common levels, a common leading-coefficient ratio, and the negative-vector relation modulo the sum of the isotropic subspaces. For disjoint flags, the zero Gram determinant gives equality in the reverse Cauchy–Schwarz inequality on signature (k,1), yielding the same normal form. This is an ordinary mathematical reconstruction, not a line-by-line rendering of the source proof.

The quotient argument first disintegrates the integral over Gamma\G through Gamma\R and R\G. Only after this step is compact-group invariance used. The compact group need not normalize the arithmetic lattice Gamma. All Haar-volume factors are retained in the disintegration; their values are immaterial to vanishing.

The fragment does **not** establish the diagonal Kpp estimate, the orbital amplitude bounds, the lattice-pair count, or absolute convergence of every actual theta term. Absolute convergence remains an explicit input from the analytic construction. No full transitive dependency audit or Lean replay is asserted.

## Exact target and geometry

All paths below are relative to `sources/lean/src/`.

- `Formalism/SharpRestriction/CuspSpanNormBounds/NonGenericAndKTwoTheorems.lean`: the complete file was read. Lines 35–61 define KTwoHypotheses, Conclusion2, and PointsLemma. PointsLemma includes all terms with Gterm=0, including the identity term if present off the diagonal. Conclusion2 is a separate nonidentity diagonal estimate.
- `Formalism/SharpRestriction/CuspSpanNormBounds/BlockEnds.lean`: the complete file was read. FlagG, the character differential, relevance, determinants and G fix the flag conventions. The source uses a conjugate determinant convention in one intermediate model; the squared modulus and vanishing are unchanged.
- `Formalism/SharpRestriction/CuspSpanNormBounds/KappaEndpoints.lean`, lines 1–230: the source translation into the normal-form model, Hermitian-form conjugation, relevance, and positivity were read. No claim is made to have read the rest of this file for this record.
- `Formalism/FlagUnipotentLattices/MemOfOrthogonalAnisotropic.lean`, lines 1–200: the common subspace, signature arguments, and NFFull definitions were read.
- `Formalism/FlagUnipotentLattices/MinkowskiFactorialBounds/ExistsHasLeadingCoeffOfMemSpanBelow.lean`, lines 335–639: the rank-two operator, successor relation, suffix of common levels, scalar uniqueness, and nonzero-intersection case were read. The later source proofs of the disjoint case and the full normal form were not read in this pass; the fragment supplies its independent proof.
- `Formalism/FlagUnipotentLattices/AutBoundOfMinkowskiBound.lean`: the complete short normal-form wrapper was read.
- `Formalism/LocalToGlobal/SiegelLatticeTheory/CokernelGLCounts/RankPointCounts/SubOneMulVecFix.lean` and `CplxNF.lean`: both complete files were read for the compact embedding and the source complex normal-form interface.

## Actual operators and active route

- `Formalism/LocalToGlobal/SiegelLatticeTheory/ClosedLocalOrbits/TermOp.lean`, lines 1–60 and 110–170: rank-one operator conventions, OO, and the arithmetic integration domain were read.
- `Formalism/LocalToGlobal/SiegelLatticeTheory/ClosedLocalOrbits/GaugeLatticeShifts/Vanish.lean`, lines 175–240: the common character, its triviality on the arithmetic subgroup, and quotient invariance were read.
- `Formalism/SharpRestriction/CuspSpanNormBounds/IsPrimitiveSub.lean`, lines 245–285: the integral flag unipotent group NLam was read.
- `Formalism/LocalToGlobal/SiegelLatticeTheory/CokernelGLCounts/RankPointCounts/KappaOffDiagonal.lean`: the complete file was read. It records the older CovRepC interface, SchurNFC, words_differ, and the zero-operator-to-zero-term assembly. The older interface alone is not treated as a theorem provider.
- `Formalism/LocalToGlobal/SiegelLatticeTheory/CokernelGLCounts/RankPointCounts/FixedDecomposition.lean`, lines 1–150 and 650–779: the actual quotient-disintegration and covariantRepZero route was read. Lines 151–649 were not read in this pass. The fragment gives its own quotient-averaging proof.
- `Formalism/LocalToGlobal/SiegelLatticeTheory/ClosedVolumeStatements/FullExistsTiedHolds.lean`, lines 1–55: the active KppOffC provider uses FixedDecomposition; orbital integrability is supplied separately.
- `Formalism/LocalToGlobal/SiegelLatticeTheory/CokernelGLCounts/RankPointCounts/SchurCoreA.lean`, `SchurNFCOf.lean`, and `KppOffCOfSteps.lean`: all three complete files were read. They use external tensor-product data, local irreducible compact representations, and the active finite-term assembly. Irreducibility is of each local factor, not of the full tensor product restricted to one factor.

## Compact parameter: no shift or duality ambiguity

The actual definition is `IsHCTypeU` in `Formalism/SharpRestriction/CuspSpanNormBounds/RelevantZeroGramTerms.lean`, lines 94–96. It requires a nontrivial finite-dimensional unitary representation and `IsKTypeOf(allPos,lowK(allPos,u),top)`. Lines 49–65 define weights and the highest-weight condition: a nonzero vector of that weight exists, and every other weight is below it by a nonnegative integral combination of positive roots.

`Formalism/FormalDegreeBessel/StatementDS.lean`, lines 10–24, defines

    lowK(epsilon,lambda) = lambda + rhoN(epsilon) - rhoC(epsilon).

`Formalism/RealPlaceAnalysis/StatementA.lean`, lines 34–41, gives the root counts. For allPos, rhoN=0 and rhoC(j)=(k−1)/2−j, with j numbered from zero. Consequently the actual highest weight is lambda−rho, exactly as in the fragment. The independent duplicate definitions in `Formalism/PeriodIntegrals/UpqRep.lean`, lines 201–231, agree, and `Formalism/HermitianCurvature/HermitianCurvatureProofs/LowKAllPos.lean`, lines 49–59, explicitly proves the same formula for that duplicate model. The comparison does not silently identify unrelated parameter conventions.

`SchurNFCOf.lean`, lines 21–31, passes the actual spaces `X.Vloc u v`, the actual representations `X.piLoc u v`, their specification `X.piLoc_type`, and the parameters `(D.hcW u (X.pl v)).u`. The source tensor maps have the product inner-product identity and span property, hence identify the spaces with external tensor products. The common compact actions are related by positive quotient isometries, giving inner conjugation of U(k), with no contragredient or complex conjugation.

No representation-classification theorem is needed for this last comparison. An isomorphism preserves the diagonal-torus weights. By the actual highest-weight condition, each specified highest weight therefore differs from the other by a nonnegative integral combination of positive roots. The functional ell(x)=sum_a(k−a)x_a is strictly positive on every positive root, so opposite such combinations must both be zero. This proves inequivalence directly. Schur's lemma itself is proved in the fragment by kernel and image.

## Distinct words: every real place

`Formalism/SharpRestriction/CuspSpanNormBounds/DataS.lean`, lines 13–32, contains the actual datum fields: Delta>0, the injective boolean letter map, and

    u_(l+1)(w,tau) = v_l(tau) - 1/2 - Delta * 1_(letter(w,l)).

The v parameters are independent of the word by `D.hcW_v`. Thus two different words differ in a letter; the same compact coordinate differs by plus or minus Delta at **every** tau. Subtracting the fixed rho does not change this inequality.

This exact argument is implemented, without an extra standing-hypothesis assumption, in `Formalism/LocalToGlobal/SiegelLatticeTheory/ClosedLocalOrbits/GaugeLatticeShifts/DistinctWordsDistinctParameters.lean`, lines 727–745. The short exported theorem is at lines 844–845. These two intervals, rather than the entire 898-line file, were read for this verification.

The same proof was independently read in `Formalism/SharpRestriction/CuspSpanNormBounds/StandingHypothesesHoldFamily.lean`, lines 770–783. Lines 1537–1546 show its insertion as data8 in StandingNumericalData. `StandingNumericalData.lean`, lines 84–104, lists the every-place property; `CntPartners.lean`, lines 33–34, includes it in Hyp0; and `KappaOffDiagonal.lean`, lines 59–62, extracts it from KTwoHypotheses. The source therefore provides a stronger condition than the one-place condition used in the mathematical corollary.

## Exact finite controls and limitations

`check_degenerate_flag_orthogonality.py` uses exact Gaussian-rational matrices and rational nullspaces. It checks 160 normal forms, 36 common Lie algebras, the compact rho shift, and a counterexample to the statement with relevance removed. In the negative control, r=k=1, the two isotropic lines coincide, z'=2z+w for a unit positive vector w, and G=0; nevertheless the character differentials differ and no common positive quotient complement of the asserted dimension exists. This does not contradict the actual assertion: the nontrivial common character makes the orbital integral zero before the compact-group argument is used.

The final result file records 2,399 exact assertions. These are finite controls of the formulas and hypotheses, not a proof for all parameters. The general proof is the TeX fragment. The initial script compared unevaluated Gaussian-rational products syntactically; expanding matrix entries removed that script-only issue before the recorded successful run.

The parent independently read the mathematical draft and requested two precision edits: specify a compact open **subgroup**, and explicitly state the external tensor-product spaces and actions. Both edits are included in the final SHA above. At the parent's agreement, the compact highest-weight classification import was subsequently removed and replaced by the direct pointed-positive-root-cone proof just described; the shift lambda−rho remains explicit. The parent's review record, compilation logs, and source hashes are included in the accompanying manifest when present.
