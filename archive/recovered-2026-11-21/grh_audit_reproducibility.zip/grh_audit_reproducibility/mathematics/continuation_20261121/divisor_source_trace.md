# Divisor and integral-chain reconstruction: source trace

## Result and scope

`divisor.tex` gives a conventional proof of the determinant, covolume, dual-lattice, local patching, and matrix-norm portions of the submitted divisor construction. It also derives the actual ambient dual exponent from the finite class sets, stabilizer groups and character projectors. It does **not** assert that the particular automorphic family has been fully constructed in ordinary mathematics.

There is no newly identified counterexample to a reviewed source theorem with all its actual hypotheses. Several tempting simplifications are false. The fragment proves explicit counterexamples to: replacing the non-CM quotient inequality by equality; using a basis at only one prime instead of the simultaneous localization at a prime and its conjugate; replacing a full cross-pairing spectral identity by separate norm estimates on spanning subspaces; bounding the local index of a rectangular product from the individual minor ideals in the wrong direction; and omitting the scalar normalizing the Fock form. None is presented as a defect in the source, which retains the relevant hypotheses or normalization.

The companion `divisor_read_scope.json` lists file hashes and the exact source intervals read during this continuation. A listed dependency outside those intervals is a trace target, not a claim to have read or verified its complete proof. No new Lean compilation, export scan, independent-kernel run, or canonical comparison was performed for this mathematical reconstruction.

## 1. From the final divisor statement to the actual inputs

- `Formalism/LocalToGlobal/Divisibility/ConstantGeTwentyEight.lean` defines the divisor inputs, the resulting clauses and the height-chain step. Its argument combines earlier bounds. It is not the construction of those inputs.
- `Formalism/LocalToGlobal/InpAtOf.lean` builds the inputs by unpacking a `RowsU` instance into its column chain, exact tie, frames, pointwise final-pairing bound and coupled kernel data.
- `PtKOfReal.lean` makes the contents of `RowsU` explicit. `FiniteTOf.lean` packages a uniform supply of such rows. `RecBridgeSel.lean` still takes a hypothesis supplying the rows/divisor inputs. These wrappers must not be mistaken for a proof of the kernel bounds or of the arithmetic row construction.
- In `Divisibility/Inputs.lean`, a column chain is made of actual rectangular matrices, compatible frames and a final pairing. Its factorization is an equality for the actual chain. The coupled-bound data include the finite class sets, positive weights, norm-preserving realizations, phase factors and the operators whose norms are bounded.

## 2. The two quotient-metric assertions

`QuotientMetricDivisors/Statement.lean` specifies the quotient metric, the algebraic quotient Gram matrix and the simultaneous local bases. Its `LemmaRa` is the local determinant estimate from an ambient dual containment; `LemmaRb` compares the actual quotient covolume with the weighted finite Gram determinants.

The ordinary proof in the fragment is shorter than the implementation:

1. The quotient metric of a surjection `P` with ambient Gram matrix `H` is `(P H^{-1} P*)^{-1}` at a complex embedding, proved by its unique minimal-norm lift.
2. Algebraically, `J=H^{-1}P* Gamma` satisfies `PJ=1` and transfers the quotient dual into the ambient dual. Thus `a M^#` contained in `M` implies `a(PM)^#` contained in `PM`.
3. A simultaneous local basis at `p` and its conjugate gives the Gram valuation as `ord_p det H + a_p(L)+a_bar(p)(L)`. Ordinary localization at only `p` is insufficient.
4. At an embedding `v`, put `tau(v)=conj composed with v composed with the field involution`. The rationality condition on `H` implies `H_tau(v)=H_v`. Determinant Cauchy--Schwarz compares the mixed matrix `P_v H_v^{-1} P_tau(v)*` with the two positive Gram matrices. Summation over the permutation `tau` proves the covolume inequality.

This is precisely the mechanism in `HermitianTwistDivisors/ReductionLemmaSecond.lean`. `ReductionLemmaFirst.lean` delegates the local assertion to a long auxiliary proof in `Development/AutomorphicArithmetic/IntegralCasts/CapelliIdentities/SelectionLemmas.lean`; only its opening and final proof intervals were read, not the whole file.

The fragment strengthens the covolume inequality to an exact identity with an explicit nonnegative archimedean defect. A degree-six example `Q(cuberoot(2),zeta_3)`, with quotient row `(1,cuberoot(2))`, makes the inequality strict. Consequently it would be a real mistake to apply the CM equality to arbitrary coefficient fields; the actual source uses the inequality.

## 3. The finite-group dual exponent is constructed

`Divisibility/ClassSum.lean` supplies a finite class set, coefficient Hermitian spaces, finite stabilizers, and two coefficient lattices. The forms are stabilizer-fixed functions with the class-sum pairing weighted by reciprocal stabilizer orders. Its `Good(s)` hypothesis includes the coefficient containment `s Nab^#` contained in `Del`, as well as integrality and invariance conditions.

`GoodPartHermitianSpec.lean` constructs the good subspace by the product of an isotypic central idempotent and a subgroup-character projector. It scales the restricted class-sum form by the reciprocal of the subgroup order. `RowLat.lean` defines the actual ambient lattice by cutting the `Nab` lattice with this subspace. `RowLatLemmas.lean` proves its dual containment and obtains the quotient Gram bound from it.

The fragment proves every finite-group step explicitly:

- For a nondegenerate subspace `W`, the dual of the saturated cut `N intersect W` is the orthogonal projection of `N^#`. The proof uses projectivity of the torsion-free quotient over the Dedekind domain, so no integral extension-of-functionals hypothesis is hidden.
- Averaging over each stabilizer, together with the reciprocal stabilizer weight in the form, gives `s N^#` contained in the class-sum `Del` lattice. The stabilizer order cancels exactly.
- The central and character projectors are orthogonal idempotents; their product has integral coefficients after multiplication by `|G||P|` because finite-group character values are algebraic integers.
- Scaling the good-part form by `1/|P|` gives `M^#=|P| e N^#`. The previous containment and projector denominator imply `|G|s M^#` contained in `M`. The ambient exponent is therefore `|G|s`, not `|G||P|s`.
- The local Gram bound and the weighted global bound `log(|G|s)` now follow from the proved quotient lemma and the product formula.

The existence of rational bases follows by Gaussian elimination over the field of matrix and character coefficients. For this explanation the field is first enlarged by the character values; they must not silently be assumed to belong to an initially chosen coefficient field. Complex irreducible characters suffice: no unproved assumption that every such representation is realizable over `K` is used.

## 4. What the initial coefficient lattices actually are

This remaining input is concrete, not an arbitrary lattice hypothesis:

- `Divisibility/CoefMod.lean` defines the coefficient space as a tensor of dual-Weyl polynomial spaces. The Fock pairing is diagonal on monomials, with factorial weights. The Hermitian pairing is twisted by the Gram matrices and divided by the product of the Fock norms of the chosen extremal polynomials.
- The standard `nabStd` and `delStd` lattices are tensor products of the integral dual-Weyl and Weyl lattices. For a tuple of base lattices, `transLat` intersects the transports of these standard lattices over every finite prime and every local basis. `nabK` and `delK` are their restrictions to the coefficient space.
- `CoefModLemmas.lean` states exact duality: the Hermitian dual of the transported `nabla` lattice is the transported `delta` lattice of the Hermitian-dual input lattices, and conversely.
- `Columns/CoefficientsModP.lean` obtains that result from `NabDual.lean`, bilinear duality and descent under conjugation. `NabDual.lean` was read in full: it transports the bilinear duality through conjugation and the Gram matrix. `PairBDual.lean` transfers standard duality through the local-basis construction. The final standard-basis calculation in `StdDual.lean` gives Kronecker pairings between the two tensor bases.
- The representation-theoretic boundary is the identification of the Weyl lattice with the integral dual of the dual-Weyl lattice, proved in the source by `weyl_eq_dual_nabla_holds` in `WeTransposeWordTransposeWord.lean`. That proof and the full standard-monomial development have not been rewritten in this continuation.
- `Columns/RowFormsGood.lean` applies the exact duality to unimodular input lattices. The square and round coefficient packages then have the required `DualP` property. This reduces the initial scalar in those cases to the actual normalized pairing, not a free choice of an arbitrary scale.
- `Columns/ColForms.lean` constructs the automorphic class data from the unitary rational action, finite level subgroup and the coefficient package. Its lattices are the `Nab` and `Del` integral automorphic forms; they are not introduced only by their desired numerical bounds.

The symmetric-square example in the fragment records why omitting the normalizing scalar can invalidate the ambient dual containment. The polynomial duality was outstanding at the time of this initial trace; coefficient_duality.tex now supplies a complete direct proof by lower-triangular restriction and divided row operators. The later arithmetic_maps.tex supplies the concrete coefficient maps, their image ideals, exact spectral bounds and normalization. These later results do not expand the original read ranges recorded here.

## 5. Local indices and the exact divisor identity

`HermitianLattices/StatementLat.lean` distinguishes ordinary single-prime localization from the conjugation-stable semilocal localization used for Hermitian bases. The signed local index is the difference of two finite lengths. `LcvBasis.lean` relates the index to the covolume. The relevant portion of `ConjugateWeightLatticeOfGeneral.lean` combines the local determinant identity, conjugate-prime pairing and the global patching step.

The fragment independently constructs the patched lattice from finitely many prescribed local lattices, using primary decomposition of a finite module. It then proves an exact formula for its normalized covolume. The formula has the ambient Gram valuation, two conjugate local comparison indices, the Hermitian dual index of the auxiliary lattice, fixed auxiliary covolumes, the determinant scaling at infinity, and the explicit nonnegative quotient defect. The usual scalar divisor inequality is a direct corollary after inserting the actual local error estimates.

`TwistedPlaceEtaSumLeExtended.lean` identifies those error terms in the construction. The ambient term comes from `GmOf_le`. The auxiliary Hermitian index is bounded by `LiftLatLemmas.jw_le`, with the auxiliary local containment exponent, the group denominator and the coefficient scalar. A further hypothesis bounds the actual exponent by the supplied `Jn` and then by the uniform ramified-prime expression. The global error uses a divisibility bound for the group denominator and the product formula.

The fragment does not infer that exponent bound from finite rank alone. It leaves the actual local congruence estimate and the uniform bounds for the exceptional-prime sums to the arithmetic construction.

## 6. The elementary prime error

`BaseLevelBoundsWithCovolumeHolds.lean` and `PlaceSumSquares.lean` bound the error attached to `ell_p = p/sqrt(e_p)` by the universal rational-prime sum. The fragment proves

`sum_prime_ideals 2 w_p / ell_p^2 = 2 sum_rational_primes log(p)/p^2 < 99841/100000 < 1`.

The field-degree cancellation is exact, using `sum_{p over rational p} e_p f_p = [K:Q]`. The tail is bounded by the two residue classes modulo six, and the finite head is checked using rational upper bounds for the logarithm. `check_prime_sum.py` uses only integer and rational arithmetic for its decisive comparisons; `prime_sum_certificate.json` records the resulting bounds. This is an independent elementary proof, slightly sharper than the `0.999` estimate used in the source. No conjecture about prime distribution is needed.

## 7. Operator chains and integral maps

`ThetaSupremumBounds/StatementCB.lean` states the exact coupled-bound assumptions: positive weights, class counts, norm-preserving realizations and the intertwining relation with the actual lifted operators. `PerEmbeddingCoupledBound.lean` applies weighted Cauchy--Schwarz and multiplies the step bounds. The fragment proves the sharper positive-matrix estimate

`||A|| <= ||(sqrt(beta_t alpha_s) a_ts)||_2`,

which implies the class-count bound by the Hilbert--Schmidt norm. Rectangular dimensions and empty class sets cause no exception. This does not supply bounds on the actual kernel entries; those are a separate theta argument.

The source spectral statement controls the pairing against **every** vector in the ambient quotient, not only against vectors in the same summand. The fragment derives both determinant compatibility and the smallest-singular-value bound from this precise hypothesis. Its two-line counterexample shows why the cross-pairing condition cannot be dropped.

`DivisionHeightBoundStatement.lean` combines the exact final-pairing factorization, the chain bound and the quotient metric. The fragment gives the ordinary proof by taking the unique minimum-norm lift, applying the lower singular-value bound, and estimating the actual rectangular product. The scalar conversion is stated explicitly: `c(R)/D = 2 mu(R^vee)` and `h_2(B)=2h(B)`. Both inequalities must be divided by two together before using the conventional slope comparison.

Finally the fragment proves the integral-map step directly from valuations on every vector of the actual local source and target lattices. Flooring the exponents and multiplying by the resulting fractional ideal gives a map to the ordinary dual lattice. The product-minor counterexample explains why one cannot substitute a bound for the individual factors for this actual local pairing estimate.

## Remaining work, with the dependency boundary stated precisely

The next ordinary-mathematics reconstruction should prove, for the actual family rather than an abstract package:

1. The underlying decorated arithmetic lattices and their short dual vectors. Standard polynomial duality and integral transport, including the normalizing scalar, are now proved in coefficient_duality.tex; the concrete coefficient bounds are proved in arithmetic_maps.tex.
2. The particular comparison maps and spectral decomposition proving all determinant identities, and their quantitative lower eigenvalue bounds.
3. The exact automorphic kernel factorization and the operator-entry and final-pairing bounds; the theta lane addresses part of this.
4. The local divisibility inequality and the bounds for the selected local containment exponents and their error sums.

The quasi-Riemann and exceptional-zero arguments may improve the supply of auxiliary primes. They do not directly prove these lattice identities, operator factorizations, or all-vector valuation inequalities. No claim that the whole GRH proof has been translated into conventional mathematics follows from the present component.
