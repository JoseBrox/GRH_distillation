# Hermitian flag scalar rigidity: source trace and read scope

## Mathematical scope

`flag_rigidity.tex` proves the actual `RelevScalar`, `NormRoot` and `RootModP` inputs, then their `IdCellFrame` conclusion. All definitions are given in ordinary mathematics. The trace-pairing nondegeneracy is proved directly in the number-field setting. The unit-norm assertion includes a complete finite-polynomial proof of the required root-of-unity criterion, so that no unproved Kronecker theorem is imported. The odd-prime reduction argument uses the exact condition p in P but not P².

The conclusion is **T = T′ and every scalar c_i = 1**. It does not assert equality of the ordered flag frames. A final example explains why lower flag terms can persist even under the full hypotheses. This distinction matches the submitted statement exactly and is relevant to the requested audit of incorrect or altered propositions.

## Source text actually read

All paths below are relative to `sources/lean/src/`. Files marked “entire” were displayed in full during this continuation; the machine-readable manifest records their exact lengths and hashes. Imported files not listed were not thereby read or verified.

| Source | Read scope | Exact use |
|---|---:|---|
| `Formalism/LocalRingCardinality/DataSpaces.lean` | 1–80 | `HSpace`: finite-dimensional space, conjugate-first/linear-second Hermitian form, nondegeneracy and basis. Its additional lattice/signature fields are not needed in the scalar argument. |
| `Formalism/SharpRestriction/CuspSpanNormBounds/BlockEnds.lean` | Entire file | `FlagG`, `fvec`, `Xa`, `X`, coefficient convention, `LieU`, `LieN`, `ell`, `dpsi`, `Relevant`, and `xv`. The later specialization definitions were read but are not independently reconstructed here. |
| `Formalism/LocalToGlobal/SiegelLatticeTheory/SiegelMassRatios/IdCell.lean` | Entire file | Exact quantified statements `StarIsConj`, `TraceNondeg`, `SameFlag`, `RelevScalar`, `NormRoot`, `RootModP`, `IdCellFrame`, and their assembly. |
| `Formalism/PeriodIntegrals/UnitaryGroupMassFormula/FlagScalarRelevance/DualExists.lean` | Entire file | The concrete dual-vector and coordinate interfaces. |
| `Formalism/PeriodIntegrals/UnitaryGroupMassFormula/FlagScalarRelevance/DualExistsAlt.lean` | Entire file | Actual proof of existence of the Hermitian dual vector. The manuscript instead solves an invertible Gram system after extending the independent tuple to a basis. |
| `Formalism/PeriodIntegrals/UnitaryGroupMassFormula/FlagScalarRelevance/CoefXOfMem.lean` | Entire file | Coefficient additivity, scalar multiplication, basis coordinates, and vanishing below the relevant flag level. |
| `Formalism/PeriodIntegrals/UnitaryGroupMassFormula/FlagScalarRelevance/CNeZeroOfSame.lean` | Entire file | Independence of the extended flag tuple, nonzero triangular diagonal and equality of all prefix spaces. The manuscript gives the shorter invertible triangular-matrix proof. |
| `Formalism/PeriodIntegrals/UnitaryGroupMassFormula/FlagScalarRelevance/XvMemLieN.lean` | Entire file | Rank-two skew-Hermitian endomorphism, membership in both nilpotent sets, and both exact character evaluations. |
| `Formalism/PeriodIntegrals/UnitaryGroupMassFormula/FlagScalarRelevance/Assemble.lean` | Entire file | The actual relevance-to-equal-scalars argument, including the ratio c_(i+1)/c_i, trace pairing and adjacent-index chain. |
| `Formalism/PeriodIntegrals/UnitaryGroupMassFormula/UnitNormRoot/UnitNormRootMain.lean` | Entire file | Norm shift T′ = conjugate(ζ) ζ T; unit norms; equality of T and T′; all-embedding absolute value one; root-of-unity conclusion. The source invokes Mathlib's Kronecker consequence, which the manuscript proves independently. |
| `Formalism/PeriodIntegrals/UnitaryGroupMassFormula/RootsOfUnityModPrime/RootUnitModPMain.lean` | Entire file | Primitive-root product, q in P^(q−1), equality of rational primes by Bézout, and contradiction to p not in P². |
| `Formalism/PeriodIntegrals/OrbitalBoundsConclusion/FlagRelevScalar.lean` | Entire file | Public provider assembled from the concrete dual and coordinate proofs. |
| `Formalism/PeriodIntegrals/OrbitalBoundsConclusion/UnitNormRoot.lean` | Entire file | Public provider of `NormRoot`. |
| `Formalism/PeriodIntegrals/OrbitalBoundsConclusion/RootUnitModP.lean` | Entire file | Public aliases of the exact odd-prime assertion. |
| `Formalism/LocalToGlobal/SiegelLatticeTheory/ClosedVolumeStatements/DensInertDisplayHolds.lean` | 1–105 | Actual assembly aliases `RelevScalar_holds`, `NormRoot_holds`, `rootModP₂`, `IdCellFrame_holds`; contextual column/mass wrappers. No claim of validating all the other imported providers in this file is made here. |

## Exact convention checks

1. The source form is conjugate linear in its first argument. Its rank-two map is Y(y) = h(v,y)e_i − h(e_i,y)v, with no misplaced conjugation. The proof expands the skew-Hermitian identity explicitly.
2. The prefix space X_a spans e_0 through e_(a−1). Under the actual same-flag condition, the triangular transformation has nonzero diagonal and preserves each X_a. This supplies membership in both actual LieN sets.
3. Choose h(v,f_j) = a δ_(j,i+1). The unprimed character is a and the primed one is (c_(i+1)/c_i)a. All other terms vanish for one of two different reasons: low-index images are zero, and high-index coordinates are zero. The proof does not assume the two frames are equal.
4. The source defines coordinates of vectors outside X to be zero. On the LieN sets used in the relevance condition, all vectors whose coordinates occur are actually in X. Therefore the restricted conventional definition gives exactly the submitted functional.
5. The source permits an arbitrary field K embedded in E; it need not be fixed by the involution. The proof treats LieN as a set of E-linear endomorphisms and does **not** assert that it is a K-vector space. Since E is a number field, E/K is finite of characteristic zero, so trace(b b^(-1)) = [E:K] proves the needed trace-pairing property.
6. StarIsConj is retained at **every** embedding. The unit condition is retained before taking norms. Neither is replaced by a single complex absolute-value condition.
7. The residue lemma retains both p ≥ 3 and p not in P². The displayed examples at p = 2 and at the ramified prime of Q(ζ_3) concern only weakened statements and are not counterexamples to the source.
8. The source conclusion fixes the scalars, not all lower flag coefficients. Replacing z by z + e_0 preserves the actual character because Y e_0 = 0; thus the stronger ordered-frame conclusion would be false.

## Validation status

No counterexample satisfying the actual hypotheses was found. This packet is a complete conventional proof of the stated inputs, with a focused source-statement comparison. It is not a new source compilation or kernel verification, and it does not claim that the remaining global orbital or period estimates follow just from scalar rigidity. The companion compile record concerns typesetting only. The parent independently reviewed the complete mathematical proof and reported no defect; the subsequent change corrects only a TeX spacing command in the Gram-system display. A second independent review remains separate.
