# Independent review: Fock hook normalization

Reviewer: qrh_mathematics. Date: 2026-11-21.
Reviewed the entire 236-line conventional fragment.
SHA256: `c8c9d6952c11379b5c6e8f9056f4257e8ea452f8e33dcd24a1bed56e6aa696a1`.

## Result

No mathematical defect found. The proof discharges the exact local Weyl/dual-Weyl equality needed by the sharp column kernel estimates, under a condition weaker than the actual source bound. This review concerns the written ordinary mathematical proof, not a fresh Lean kernel compilation.

## Decisive checks

- In the exterior normal-ordering induction, a derivative hitting the t-th tail factor contributes the combined sign (-1)^t(-1)^(t-1)=-1. There are h-j such contributions, exactly cancelled by +(h-j)e_j. The ordered product is increasing in j, with operators acting from the right. The top exterior coefficient is det(X)det(partial), without a factorial.
- For the highest polynomial, E_ij with i<j differentiates addition of row i to row j and kills every initial-minor product. Choosing the greatest nonfixed column of a nonidentity permutation puts a raising operator immediately to the left of diagonal factors. The scalar is precisely the product of nu_i+h-i.
- Removing the first full column yields H_nu=det(X)H_(nu-1). Fock adjointness of multiplication and differentiation gives the exact recurrence for C_nu, including the degree-zero and extra-unused-variable cases. The resulting hook product agrees with the first-column hooks and leaves all other hooks unchanged.
- Perfect normalized Fock duality proves C_nu*nabla subset Delta directly: B(C_nu F,G)=[F,G] is integral for all integral F,G. No semisimplicity modulo p, unproved irreducibility, or dimension-only identification is used.
- The canonical determinant-twisted partition has final part zero, hence at most N-1 positive parts. The maximum hook is at most width+N-2; width+N-1<=p makes every hook strictly below p. Constant weights, N=1 and N=0 are handled explicitly.
- Coefficient extension and common local-basis transport preserve equality. The original source uses the stronger spread=width+N<p, correctly distinguished in the fragment. The Sym^2 counterexample at p=2 is exact.

## Dependency scope

Uses the already independently reviewed coefficient duality and its integral bases. The differential Capelli identity is proved directly here and does not import the radial Capelli theorem. The theta moment theorem and incidence identity remain separate arithmetic dependencies of the column application.
