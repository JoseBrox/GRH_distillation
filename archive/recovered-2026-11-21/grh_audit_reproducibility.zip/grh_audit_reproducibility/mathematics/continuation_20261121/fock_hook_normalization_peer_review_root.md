# Root review: exact Fock norm and the local lattice equality

The full fragment was read independently. The exterior-algebra induction
has the correct negative sign for each derivative hitting a tail factor;
the h-j shift cancels those terms exactly. The ordered determinant then
acts on the highest vector by the stated product, since the greatest
nonfixed permutation index supplies a raising operator. Fock adjointness
gives precisely the first-column hook recurrence. This proves the exact
normalizer without a representation-theoretic dimension formula.

The integral-duality argument gives C_nu*nabla inside Delta, not a stronger
unjustified rational-to-integral conclusion. When the canonical partition
has final part zero, every hook is at most width+N-2. Thus width+N-1<=p
implies the source local equality, and covers its stricter spread<p
hypothesis. Determinant twists, the constant case, and common local
transport preserve the assertion. The p=2 quadratic example correctly
refutes unrestricted equality. All mathematical claims in the fragment
pass; no source defect is asserted.

Reviewed SHA-256: c8c9d6952c11379b5c6e8f9056f4257e8ea452f8e33dcd24a1bed56e6aa696a1
