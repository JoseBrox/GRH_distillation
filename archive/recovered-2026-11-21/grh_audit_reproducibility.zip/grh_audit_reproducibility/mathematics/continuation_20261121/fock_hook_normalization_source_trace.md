# Source trace: exact Fock normalization and local lattice equality

Date: 21 November 2026. Fragment: `fock_hook_normalization.tex`.

## Mathematical result and exact source target

The fragment proves the integral differential identity det(X) det(∂)=coldet(E_ij+(h−j)δ_ij), with increasing column order and E_ij=Σ_a x_ia∂_ja. It uses exterior generators and checks every derivative-hit sign; it does not invoke a differential Capelli theorem. Applying this identity to the actual highest polynomial gives C_ν=∏_i(ν_i+h−i)C_(ν−1^h), where h is the number of positive parts. Peeling columns proves the exact formula C_ν=∏ hook lengths.

The previously proved normalized Fock duality then gives the universal integral inclusion C_ν ∇_ν(Z)⊂∆_ν(Z). Thus C_ν itself is a clearing integer. For the source's canonical partition ν_i=λ_i−λ_N, ν_N=0; every hook is at most λ_1−λ_N+N−2. Consequently the local lattice equality follows if λ_1−λ_N+N−1≤p. Constant weights and ranks zero and one have C_ν=1.

The exact source target is `Formalism.BasicNotions.NablaMemDeltaLocallyAtLargePrime`. Its hypothesis is **λ_1−λ_N+N<p**, because `DomWeight.spread` includes N. It asks, for every integral dual-Weyl polynomial f, for a nonzero-mod-p integer c with cf in the integral Weyl lattice. The present proof supplies the same c=C_ν for every f and proves a wider sufficient prime range. The proof does not assert modular simplicity or identify all polynomial invariants over a residue field.

The source's published reduction assumes `InducedSimpleLowestAlcove`, applies it to the mod-p Weyl submodule, lifts generators and uses a finite-module argument to obtain c. The new ordinary proof replaces that route for the local lattice assertion. No implication that every other use of the modular simplicity theorem is thereby audited is intended.

## Source text actually read

- `sources/lean/src/Formalism/LocalRingCardinality/DataCoeff.lean`: all 139 lines, read in overlapping intervals. This fixes detShift, natW, the exact spread, nablaSq, delSq, extremal, determinant action, normalized Fock form, integral duality target and the local-prime statement.
- `sources/lean/src/Development/AbelianVarietyTheory/PublishedTheorems/GlobalTheta/WeylDualWeylLatticesAgreeOfLowestAlcove.lean`: all 131 lines. This is the actual reduction from simplicity to local lattice equality, including the quantified group-scheme submodule statement and the lifting argument.
- `sources/lean/src/Formalism/GradedWeylDivisibility/StatementA.lean`: lines 9–77, reread in the current spanning work. This fixes the polynomial modules, divided row generators, initial minors and highest polynomial.
- `sources/lean/src/Formalism/GradedWeylDivisibility/StatementB.lean`: lines 10–17, exact rational Fock pairing and product-minor span definition.
- `sources/lean/src/Formalism/GradedWeylDivisibility/FockSpaceTableaux/FockQHW.lean`: complete file, 68 lines. This identifies the highest-vector evaluation pairing in the submitted development; the new hook recurrence is independently proved rather than inferred from that evaluation identity.
- `sources/lean/src/Formalism/LocalToGlobal/Columns/CoefModB.lean`: lines 1–42. This confirms the actual coefficient pairing is the same monomial factorial pairing, with no extra total-degree factorial.

The current `coefficient_duality.tex` definitions and perfect duality are used as proved previous results. The exterior determinant identity is compatible with the ordered-minor convention in `theta_radial_positivity.tex`; it is independently proved here with integer coefficients. No transitive modular-linkage source audit, Lean compilation or export check was performed for this fragment.

## Boundary and normalization checks

Unused rows and zero columns contribute only exponent-zero variables to the Fock norm, hence no factors. The hook recursion uses the positive height h, not the original ambient dimension. This distinction is essential for the prime range. The exterior sign is −1 for every hit because e_j crosses t odd factors and the initial ξ crosses t−1. The shifts are therefore h−j with the displayed increasing product order. The eigenvalue computation takes the largest nonfixed permutation index, so the annihilating factor is genuinely a raising operator.

The proof clears the denominator in the normalized pairing by multiplying by C_ν before invoking duality. It does not claim that the unnormalized integral pairing is unimodular. The example λ=(2,0), p=2 has C_ν=2 and unequal Weyl/dual-Weyl lattices; it lies outside the proved sufficient prime range. Negative determinant shifts do not alter the polynomial normalizer, and common local-basis transport preserves the proved equality. No counterexample satisfying the actual hypotheses was found.

The qrh_mathematics agent independently read the complete 236-line fragment and confirmed the differential identity, hook recurrence, annihilator and exact source hypothesis. The review is recorded in `fock_hook_normalization_peer_review_qrh.md`. The standalone document compiled twice with XeLaTeX, exit code zero, three pages and no overfull boxes.
