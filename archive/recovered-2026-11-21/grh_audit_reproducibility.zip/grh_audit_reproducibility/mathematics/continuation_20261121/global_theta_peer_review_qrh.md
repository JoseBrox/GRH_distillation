# Independent review of the global ideal-sum component

Reviewer: QRH mathematics agent. Date: 21 November 2026 (UTC).

I read all 525 lines of global_theta_estimates.tex and found no mathematical defect. This is a review of the conventional proof; the source trace is supplied by its author. No new formal-kernel claim is made.

## Checks

- For a fractional ideal a, alpha O_E contained in a gives |Norm alpha| >= N(a), also for every nonzero difference. The packing bound is valid even if the full point set has not first been proved finite: apply it to finite subsets. A nonempty box forces the scale a in the proof to be at most one, so the constant 9^f is justified.
- The layer-cake identity has the factor K at every complex place and exponent -K-1. The box estimate and t=exp(u) give exponent -(K-2) in the integral, not -(K-1). The simplex volume is u^f/f!, and the exact tail is (K-2)^(-f) exp(-(K-2)L) times the polynomial of degree f-1. This proves exactly the displayed constant (9K/(K-2))^f and power Theta^(-Kf), including f=1.
- The simpler bounds use q <= Theta^(-f), s=3 or s=2+1/(1+log Theta). The written hypothesis K>=3 makes both admissible. The constant 81 follows from 27e<81. The exact upper bound and the two simplified bounds decrease with the scale for scale>=1, justifying replacement by Theta/A in the subgroup corollary. Zero widths are handled separately and correctly.
- The trace dual is for Tr(xy/g). From g^2 D^nu contained in P one gets g x in D^(-nu-1), hence P dual contained in g^(-1) D^(-nu-1). The lower containment and both lift containments use only conjugation invariance of the different and integrality of the positive integer g. No odd-prime or unramified hypothesis is tacitly used.
- Norm(D)=|disc E| and N(g O_E)=g^(2f) yield the exact square-root norm exponents, including negative nu. The identity l_(b,s)=a_(b,s+1) is exact. The dual width with s=1 is matched to exponent 2r+3-2b.
- At K=5, using A=2 for both groups gives constants 15, 27*16=432, and81*32=2592. The estimate holds separately for every block, so there is no omitted union factor.
- The Q(i) example gives a harmonic lower bound at K=2. In Q(sqrt(2),i), the distinct powers of1+sqrt(2) with |n|<=logTheta/log(1+sqrt(2)) all have q=Theta^(-2), proving the need for a logarithmic loss at the full power in degree four. The excluded-zero and difference-separation examples correctly attack false generalizations only.

## Scope

This closes the ideal-summation and elementary period-lattice containment component. It does not prove the actual width inequalities, global Poisson normalization, finite-place mass identities, the other orbital contributions, diagonal estimate, or ambient-dimension comparison. The manuscript states these boundaries correctly. No counterexample to a theorem with its written hypotheses was found.

## Expanded independent review: exact covolumes and Poisson summation

Read the full expanded fragment through its actual Poisson corollary and final scope paragraph (current 899 lines; SHA-256 d29a3f847f45a4acc13e69d528f292db8b0378a39236b014727a72c8d01712a1). The added quadratic-etale local kernel calculation, both signs at primes above two, absolute/relative different normalization, lattice indices, exact parity-shifted trace dual, Euclidean Fourier dual, and continuous-function Poisson theorem all check. In residue characteristic two the unit omega-tau(omega)=2omega-t forces the trace coefficient t to be a unit, so no illicit division by two occurs. The Fourier factor is exactly 2/(gc), including negative real c. The reverse trace-dual inclusion follows from equal covolumes only under the stated unramifiedness hypothesis. Uniform periodization, Fourier absolute convergence, and Fejer uniqueness justify the exact Poisson identity for the stated product decay; the normalized error retains the factor 1/V. No mathematical correction is required.
