# Global theta estimates: source trace and exact scope

## Status

The fragment `global_theta_estimates.tex` proves a substantial global component, not the four complete orbital energy estimates. It proves the smoothed fractional-ideal sum with a stronger bound, identifies the actual period/lift/trace-dual lattices and their different exponents, proves their exact indices and covolumes in the source's actual range (including primes above2), and proves the continuous product-decay Poisson summation step with the exact frequency and measure normalization. Root and the QRH reviewer have independently checked the mathematical arguments; their records distinguish initial and expanded drafts.

The actual archimedean test functions still require their Fourier-coefficient and width bounds. The finite-place mass identities, remaining global summations, diagonal estimate and ambient-dimension comparison are not proved by this fragment. No counterexample to the actual source statements treated here was found. Counterexamples in the text concern explicitly omitted hypotheses or stronger false variants.

## Position in the actual energy argument

`StatementPB.lean` defines `GlobalCores` at346ff. Its scalar-energy branch explicitly requires the ideal sum `Formalism.SA.C.BoxSum`, the period-lattice facts, the exact normalized Fourier frames and Poisson statements, and `InstLatticeSums`. `HermitianCurvatureProofs/SecondDerivativeHolds.lean` supplies these using named concrete providers; this is not an inference from suggestive theorem names.

`StatementJ.lean` fixes the actual exponent to **K=5** in `Inst`, and the lift widths have factor **2** in `InstSizes`. The first sum is over `LadB`, the dual of `perLat` with the trace pairing divided by g. The second is over `LapB`, the parity-restricted lift lattice. The exact definitions of all three are at119ff; the product-size assumptions are in `IdealSizes` at69ff. The finite-sum predicate is `TA.LatSum`, not a sum including the zero element.

The four global branches inspected at the statement/interface level are the scalar generic corank-one sum, the nonscalar generic corank-one sum, the higher-corank sum, and the nongeneric corank-one sum. `RowsConc.lean`, `RowsOther.lean`, and `NonGenericAndKTwoTheorems.lean` expose their concrete coefficients, dimensions, normalized formal-degree term, and diagonal bounds. Their deeper imported global providers are not claimed as read or proved merely because these interfaces were inspected.

## Smoothed ideal sum: independent replacement

The exact original statement is `Formalism/LatticeRigidity/StatementC.lean`, `BoxSum`. It assumes a nonzero fractional ideal in a totally complex field, positive widths, Θ>2, real K≥3, and a finite set of nonzero ideal elements. Its conclusion is `(C Θ^{-(K−5/2)})^f`.

The full421-line provider `HeightMinimum/SqrtAbsNormLeProd.lean` was read. It proves the norm minimum, a box bound with100^f, a dyadic cubic moment with800^f, and then the final result. Crucially, the final proof already reaches `800^f A^{-(K−1)}` before deliberately relaxing the exponent to K−5/2. Retaining K−1 is therefore a strengthening of the stated theorem, not a correction to an invalid proof.

The new conventional proof uses the product minimum for differences, volume-packing with constant9^f, and a direct integral representation of the product of minimum functions. It gives, for K>2 and Θ≥1,

`(9K/(K−2))^f Θ^(−Kf) Σ_{j=0}^{f−1} ((K−2)f logΘ)^j/j!`.

The elementary integral over a simplex gives the polynomial exactly. Interpolation at exponent3 gives `[27 Θ^{−(K−1)}]^f`; interpolation at2+1/(1+logΘ) gives `[81(1+logΘ) Θ^−K]^f` for K≥3. The source's actual K5/liftfactor2 then gives the common error `[432 Θ^−4]^f`, or the sharper displayed logarithmic expression. This improvement has been proved in the conventional text; the source archive has not been modified, and downstream constants have not silently been replaced in a formally checked theorem.

The new Q(√2,i) unit example shows that the logarithmic loss cannot be removed altogether at the full decay power in degree4. The Gaussian lattice shows divergence at K=2. Neither example violates the source's K5 hypotheses.

## Actual lattices and exact normalization

`PrimeToDifferent.lean` defines the absolute different `dd`, `perLat`, `liftLat`, `dualIdl`, `liftIdl`, and `dualLat`. In ordinary notation:

* `P_{ν,s}={y∈gD^ν : y−(−1)^s ȳ∈g²D^ν}`.
* `L_{ν,s}={x∈g^−1D^−ν : x−(−1)^s x̄∈D^−ν}`.
* The trace dual uses `Tr(xy/g)∈Z`.
* The block exponent is exactly `ν(r,b,s)=2r+3−2b−s`.

The simple inclusion `g²D^ν⊂P` proves `P^{∨,g}⊂g^−1D^{−ν−1}` immediately from the codifferent. The lift containment is part of its definition. These containments need neither relative unramifiedness nor an odd-prime assumption. They give the exact ideal norms in `StatementJ.BlockLattices`; the norm and adjacent-ideal source proofs were read in full in `PeriodLatticeFactsSplitOfGeneral.lean`.

For the exact indices and volumes, the new proof assumes only that E/F is unramified above g. This is implied by the source's stronger global unramifiedness condition and also by its selected completely split level primes. The key finite quadratic-ring kernels have cardinality `#A/gA` for both signs. At residue characteristic2 the trace is surjective because the trace of a residue-field generator is a unit; no division by2 is used. The argument gives both period indices g^f and the lift index g^f. The Q(i),g2 counterexample shows these exact index formulas fail if the local unramifiedness condition is removed.

For standard Lebesgue measure on C^f, the ideal covolume is `2^−f√|Δ_E| N(a)`. Hence the period scaled by `rd(E)^−ν` has covolume `(rd(E)/2)^f g^(3f)`. This is exactly `StatementJ.BlockFrame`.

The exact Fourier frequency attached to x in the scaled trace dual is

`2/(g c) · conjugate(σ(x))`,

since its real inner product with `cσ(y)` is `Tr(xy/g)`. The inverse trace-dual parity shifts from `1−ε conjugation` to `1+ε conjugation`, giving `P_{ν,s}^{∨,g}=L_{ν+1,s+1}` in the unramified range. The normalized trace-dual covolume is `(rd(E)/(2g))^f`. The full401-line provider `DualCovolumeChangeOfVariables.lean` was read and checked against these formulas.

## Poisson step: actual regularity, not an added Schwartz hypothesis

`LevelRecursionCondNeeded.lean`, `PoissonStepText`, assumes continuity and a product decay bound with exponent3 in every complex coordinate, together with absolute summability of the Fourier coefficients. `StatementJ.PoissonJoint` adds the actual embedding and dual-frequency map and obtains a finite nonnegative sum bound.

The new proof establishes the required locally uniform periodization from disjoint small polydiscs and the integrability of `(1+|z|)^−3` on C. It unfolds the Fourier coefficients over a fundamental domain and uses finite products of Fejér kernels to prove uniqueness of the continuous Fourier expansion. It therefore proves the exact Poisson step under the source's actual regularity. The full295-line `PoissonSummationDecay.lean` provider was read, including the product-decay summability proof. The final concrete `PoissonJoint` argument was also read in full.

The application corollary combines this with the proved ideal sum and exact trace-dual map. Its remaining assumptions are explicit: the particular actual test function must obey the displayed Fourier-coefficient majorant and the product-width inequality. These are the still-unproved analytic inputs `EstWave`, `EstLift`, and the later size estimates; they have not been hidden in a claim of a completed orbital energy theorem.

## Exact controls and compilation

`check_global_theta.py` performs41 reproducible checks using integer, rational, and symbolic arithmetic:

* Both quadratic involution kernels over Z/p^e for p2,3,5, in the split and unramified field cases.
* Actual Gaussian-field period and trace-dual covolumes for g3,5, both parities, and ν from−2 through2; the Fourier factor2/(gc), including negative c.
* The excluded ramified g2 counterexample.
* The exact simplex-tail coefficient formula in dimensions1 through6.

The results are in `global_theta_checks.json`. These calculations are finite controls, not evidence for the unreconstructed global energy estimates. All general assertions rely on the displayed proofs. The standalone `global_theta_check.tex` was compiled with XeLaTeX; the current integrated proof fragment is10 pages before later additions. The parent document owns the final pagination and delivery.

## Coverage discipline

`global_theta_source_manifest.json` records SHA256 hashes, line counts, and conservative read intervals. The builder is `build_global_theta_manifest.py`. Full-file coverage is asserted only where the entire file was read, possibly across several sequential calls. A declaration-index search is not counted as reading its proof bodies. Imported dependencies that were not independently inspected are not included in the mathematical completion claim. Source versions remain those of the archive already identified by the main audit.
