# Independent review: Gram determinant volumes

Reviewer: `/root/formal_degree_review`.
Verdict: **PASS**, within the explicit Euclidean volume scope.
Final manuscript SHA-256:
`4e68cddc81e84ce32189746e602b9bc54b5f43265ee5fbe448cc4e27baeb0ccf`.

## Reading scope

The complete initial mathematical text was read and checked. The final
editorial amendments clarify the brackets in GV1, remove a stray plus sign
in the GV7 set, and repair split/tag placement; they do not change the
mathematical content. The final hash is bound to those amendments.

Independently inspected source passages:

- `Definitions/SemilocalFrames/UpperOff.lean`, lines 72–87, including the
  exact definition of `gramProj` as the square root of the absolute Gram
  determinant after orthogonal projection.
- `Proofs/FlagMeasures/MeasurePreservingMulVec.lean`, lines 160–228,
  including the determinant-one consequence of the indefinite unitary
  equation and the complete submitted `vol_gram` assertion/proof.
- `Proofs/FlagMeasures/VolumeGramConditionCodimTwoThree.lean`, complete file.
- `Proofs/FlagMeasures/FibreGramNumberNullAndCutoffIntegralBound.lean`,
  lines 1–110 and 218–255 only, for the coordinate-volume interface.

All paths above are relative to
`sources/lean/src/Development/AbelianVarietyTheory/`.
This is not a transitive dependency audit or a Lean replay.

## Decisive checks

1. The one-vector beta integral has the exact factor
   pi^n R^(2(n-a))/(n-a)! times (h-a-1)!/(h-1)!.
   It holds at h=n and a=0; the zero-dimensional complement has volume one.
2. Conditioning on the first i-1 projected vectors leaves projection rank
   d-i+1. Its ball integral depends only on that rank. Tonelli and the
   independently proved nullity of dependent tuples justify the iterated
   negative-moment identity without an unproved integrability assumption.
3. The negative moment at a=d-j is finite, whereas a>=d-j+1 diverges.
4. The stronger sublevel bound integrates the final q=d-j+1 perpendicular
   coordinates first, then applies the finite exponent-q negative moment
   to j-1 columns. Its constant, all powers of R and t, and the endpoint
   cases j=1 and j=d check out.
5. The lower bound restricts the preceding vectors to a positive-volume
   family and the last perpendicular coordinates to a ball of radius t/C.
   The other components have uniformly positive allowed volume; hence the
   resulting t^(2q) lower bound proves optimality of the exponent.
6. Increasing projection rank can only increase the Gram determinant, by
   Cauchy–Binet. The real Jacobian of a complex linear map is |det A|^2.
7. Expanding the exact submitted constants confirms that GV8 improves
   `vol_gram` by the factor 2((j+2)!)^j. GV9 removes the submitted factor
   4 M^(2r) and supplies the additional divisor ((r+3)!)^r.

No mathematical flaw was found. The sole correction requested was removal
of the stray plus sign in GV7, now resolved. This review establishes neither
the flag-coordinate identities nor their coordinate-size bounds, and does
not establish the common-unipotent measure normalization or the full
orbital amplitude estimate. Those limits are stated in the manuscript.
