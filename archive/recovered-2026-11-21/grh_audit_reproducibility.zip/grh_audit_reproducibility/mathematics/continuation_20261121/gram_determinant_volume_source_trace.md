# Projected Gram determinant volume

The independent proof in `gram_determinant_volume.tex` computes exact
negative moments of projected Gram determinants over products of complex
balls. It supplies the two actual volume leaves with improved constants
and also obtains the optimal small-threshold exponent by direct integration
in the last perpendicular component.

## Submitted source inspected by root

All paths below are relative to `sources/lean/src`.

- `Development/AbelianVarietyTheory/Definitions/SemilocalFrames/UpperOff.lean`,
  lines 1--110: exact `gramProj`, the positive projection and the first
  orbital volume definitions. The Gram quantity is the square root of
  the norm of the Gram determinant, as in GV1.
- `Development/AbelianVarietyTheory/Definitions/SemilocalFrames/IsNormalFormStabilizerMeasure.lean`,
  complete file: normalized Gram ratio, common stabilizer measure and
  the degenerate volume bound.
- `Development/AbelianVarietyTheory/Proofs/FlagMeasures/MeasurePreservingMulVec.lean`,
  complete 228 lines: determinant-one change of variables, projection
  reduction, `vol_le`, the factorial inequality, and `vol_gram`.
- `Development/AbelianVarietyTheory/Proofs/FlagMeasures/VolumeGramConditionCodimTwoThree.lean`,
  complete 52 lines: the codimension-three volume and zero-locus assertions.
- `Formalism/FlagUnipotentLattices/MinkowskiFactorialBounds/MeasurePreservingPiCompProd.lean`,
  lines 650--720 and 780--915 only: the ordinary Gram sublevel set and
  the source's full inductive volume theorem. The rest of this large
  implementation is not claimed as read in this review.

Root also read the complete `FlagUnipotentGramNullAndFibreVolumeNormalForm.lean`
and its wrapper, and the complete wrapper
`FlagGramEqGramDetProjectionNormalFormStatement.lean`, to locate the precise
role of these volume leaves. Their independent geometric proofs are not
claimed completed by GV. The coordinate-size and flag-projection identities
remain separately named obligations.

## Exact comparison

With n=k+1, d=k-1, c=2 and s=k-1-j, GV8 is at most the source's
`vol_gram` right side divided by 2((j+2)!)^j. Both use the same powers
M^(2j^2+4j) and (2y)^(2(k-1-j)). The determinant of a Hermitian isometry
has absolute value one, so the source's m^(-1) substitution preserves
the full product measure, without an omitted Jacobian.

With d=k-2, c=3 and j=r, GV9 additionally removes the factor 4M^(2r)
from the source's codimension-three bound and inserts ((r+3)!)^(-r).
It bounds the whole sublevel set and therefore the requested shell.

The integral at the first excluded negative-moment exponent diverges.
This is not a counterexample to the stronger sublevel bound GV6, whose
proof integrates the last small ball directly. A matching positive
lower bound proves that the exponent 2(d-j+1) in GV6 cannot be increased
uniformly in the threshold. All these statements have general proofs;
no numerical integration is used as decisive evidence.
