# Independent review of the homology and local cohomology section

Reviewer: `/root/qrh_mathematics`. Reviewed 21 November 2026.
Target: `homology_torsion.tex`, read in full (about 405 lines).

## Conclusion and scope

No mathematical defect was found in the elementary proofs or their stated
conditional conclusions. This review does not establish the geometric
complex, its orbit bound, the global class count, or the strict-Selmer
comparison input beyond the expressly cited duality statements. In
particular, a small homology exponent is not claimed to prove the full
arithmetic cohomological estimate.

The root's separate source trace identifies the final source route as
`ClassCounting/LemmaKOfLitN` and `DenseThresholdCases/KFinal`, not an
established provider of the `KBridgeOfKPublished` package. This review
checks the mathematical fragment, not those two full upstream files.

## Proof checks

1. **Bounded integer columns.** The independent-column sublattice and a
   nonzero coordinate minor correctly bound the saturation index, including
   an infinite original generating family and rank zero.
2. **Finite groups.** Inserting and summing an initial coordinate in the
   homogeneous bar complex gives a well-defined homotopy killing positive
   homology by the group order. Its degree-j chain rank is exactly s^j.
3. **Permutation complex.** The first-quadrant double complex and Shapiro
   identification are valid without a free group action. The bound on the
   bottom-row torsion is preserved because no differential of page r >= 2
   enters (m,0). This subgroup argument is necessary; an arbitrary quotient
   could create new torsion. The finite filtration then gives the displayed
   product of orders.
4. **Resolution wording.** I requested that the proof choose the free
   right bar resolution explicitly, rather than choose an arbitrary free
   resolution and then call its tensor complex the bar complex. The root
   applied this clarification. I checked the resulting text.
5. **Finite stabilizers.** The binomial proof that the kernel of reduction
   modulo 3 has no finite-order elements works for a possibly noncommutative
   ring with torsion-free finite-rank additive group. Only powers of a single
   element occur. It gives the stated bound 3^(n N^2). Positivity and the
   discreteness of the integral matrix lattice make the relevant stabilizer
   finite.
6. **Conditional numerical exponent.** With x=2En >= 4, the inequalities
   m+1 <= x, d=nN <= 5x, and N <= (5/2)x imply the displayed exponent 13
   bound from the assumed geometric orbit count. The finite-stabilizer
   contribution is included. No geometric existence assertion follows from
   this calculation.
7. **Local invariants.** For the cyclotomic image of local index I, the
   element (1+p^2)^I gives the valuation 2+v_p(I)+v_p(e), including p=2.
   Since I <= [F_v:Q_p] <= n, the stated local H^0 length bound follows.
8. **Global H^2.** Given the stated global and local duality identifications,
   the strict-Selmer bound and the sum of local H^0 lengths imply the claimed
   finite H^2 bound. The hypothesis that the Selmer group is finite is not
   suppressed. The inequality p-1 <= n when mu_p is contained in F correctly
   gives the final polynomial absorption.

## Adversarial points

- The cyclic-group example confirms that the orbit count alone cannot
  replace the stabilizer bound.
- Ordered simplices, and therefore permutation modules with trivial
  stabilizer coefficients, are retained; an orientation character cannot
  be discarded.
- The proof does not assume quotients preserve torsion bounds.
- Local cohomology at p=2 is included explicitly.
- No computation or finite test is substituted for any of these arguments.
