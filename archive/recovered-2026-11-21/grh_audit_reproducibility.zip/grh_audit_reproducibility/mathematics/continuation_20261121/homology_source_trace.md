# Arithmetic homology and the final local cohomology terms

## Scope and result

The ordinary proofs are in homology_torsion.tex. They establish:

1. The determinant bound for torsion in the cokernel of an integral
   matrix, including an infinite generating family.
2. The finite-group homology bound, by an explicit homogeneous bar
   contraction.
3. The exact orbit/stabilizer bound
   B^A s^(A sum_{j=1}^m s^j) <= B^A s^(m A s^m)
   for an augmented exact permutation complex.
4. The actual stabilizer bound 3^(n N^2) by reduction modulo 3.
5. Conditional on the source's exact geometric complex and orbit estimate,
   the homology torsion bound with exponent 13. The source's later
   numerical bound uses exponent 24; the new numerical improvement
   uses n>=2, which holds for totally imaginary fields.
6. The local invariant bound
   length H^0(F_v,Q_p/Z_p(-e)) <= 2 + v_p(I_v) + v_p(e),
   and the passage from a strict Selmer estimate with exponent C>=1
   to an H^2 estimate with exponent C+2.

The geometric acyclicity/orbit estimate was an input to this initial
fragment and is now proved in arithmetic_complex.tex. The later
selmer_layer.tex, selmer_unit_count.tex and selmer_comparison_proofs.tex
prove the class-number estimate, SLayer, SCount and SSha. SFew remains
the separate finite-field homology construction/detection input.
The general Poitou--Tate and local Tate duality theorems are classical
imported inputs, stated in their exact form. The cyclic finite-group
example disproves deletion of the stabilizer term; it does not
contradict the source.

## A distinction in the source dependency route

GeneratorCountTuples/Bridge.lean defines KBridge. It is a finite
module mapping onto the Galois H^2 group and into completed integral
homology, with a specified bound on the exponent of the second map's
kernel. Reduction.lean and LemmaKOfPublished.lean prove consequences
CONDITIONAL on that interface.

The file named TensorHomCubes/KBridgeOfKPublished.lean contains a
structure collecting published K-theoretic assertions; it does not
prove KBridge. No claim that the file name establishes the missing
comparison is made.

The assembly inspected here actually uses
ModularityArgument/ThresholdArguments/DenseThresholdCases/KFinal.lean,
whose lemmaK_litN_alt invokes the class-counting route.
WindowBoundOfLiteratureLevel.lean explicitly passes that result to
the cohomological counting assertions and then to VWin.
SmallClassNumbers/CorGKOf.lean is a second explicit consumer.
The route is:

- ClassCounting/LemmaKOfLitN.lean assembles the concrete providers.
- ClassCounting/LemmaKOfSteps.lean specifies the full intermediate
  assertions and their composition.
- ClassCounting/ExponentLe.lean supplies the integral homology
  torsion input through HermiteNormalForms/Assembly.lean.
- ClassCounting/SFinal.lean converts the resulting strict Selmer
  bound to the required Galois H^2 bound, using the local invariants.

This is a correction to the precision of our earlier dependency
description, not a detected defect in the formal development.

## Exact mathematical hypotheses that remain visible

The permutation-complex argument uses an actual augmented exact
complex, not just an orbit count. Its stabilizers act trivially on the
basis vectors; this is automatic for the ordered tuples used in the
source. It does not silently replace an oriented cellular module by
an unsigned permutation module.

For the bottom row of the homological spectral sequence, the later
terms are subgroups of E^2_(m,0), since no higher differential enters
that position. This fact is essential: arbitrary quotients of a free
abelian group can create arbitrarily large torsion.

The local cohomology calculation uses the full local cyclotomic image,
whose index is at most the local field degree. The element
(1+p^2)^I_v is in that image, including at p=2. Keeping v_p(e)
instead of the coarse bound e gives the sharper stated local term.
The strict Selmer local conditions are the same full vanishing
conditions used in cohomological_intervals.tex.

## Read coverage

The accompanying homology_source_manifest.json records individual
hashes and conservative read ranges. Full-file reading of an assembly
or definition file is not a claim that all its imported proofs have
been audited. Declaration searches were used only to locate the
dependencies; they were not treated as proof review.

This continuation did not run a new Lean compilation, a new export
inventory, or a new proof-kernel replay. It adds mathematical reading
and independently written ordinary proofs.
