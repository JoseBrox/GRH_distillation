# Independent review: exact integral branching

Date: 21 November 2026. Reviewer: formal_verification.

I independently read the complete integral_branching.tex and found no mathematical defect. The integral initial-minor input is now proved in polynomial_minor_spanning.tex, not an outstanding hypothesis.

## Delicate points checked

The integral lift removes a minor of height s only where mu_s>mu_(s+1). In the first case mu_s>lambda_(s+1) ensures the new lambda remains a partition and satisfies the changed lower boundary. In the second case mu_s=lambda_(s+1)>mu_(s+1) implies s<n, lambda_(s+1)>=1, b_(s+1)>=1, and preservation of the new upper and lower interlacing inequalities. Appending the last row has Laplace leading coefficient +1 at z_(s+1). All other last-row weights decrease strictly, so multiplication by the inductive lift preserves the asserted triangular form. The base mu=0 gives exactly z_1^(lambda_1), which is invariant under all relevant column additions.

The negative Capelli convention has the required one-step shift: C(u)=B_n(u+1) acts by product_j(u+j−eta_j). Every competing interlacing eta of the same total degree lies in the intervals R_i. The factor C(eta_i−i) therefore kills that summand, while its scalar on the target is exactly the source's cBr. For j<i and j>i the inequalities place v−i strictly on the correct side of mu_j−j, so no factor vanishes. Repeated partition entries and empty products cause no exception.

The coefficient map need not carry the entire ambient polynomial module into the dual-Weyl module; the proof only needs it on J(V_mu), where equivariance and its highest-vector value show that it is J's inverse. This distinction is respected. Coefficient extraction commutes with the integral top-row operator Z, so [z^b]ZG=cf and ZG=cJf. This proves integrality without dividing by c in the coefficient ring. Division by the nonzero c occurs only in the rational projection argument.

For the normalized Fock forms, the unnormalized monomial identity has the factor b!, and the adjoint of phi is C_lambda/(b! C_mu) times the projected multiplication by z^b. Together with kappa=[xi,xi]/C_lambda this gives the displayed ioStd coefficient c[xi,xi]/(b! C_mu). The Weyl containment follows from the already proved perfect integral duality. In particular, primes dividing a factorial or a Gram normalization have not been excluded. The same argument extends to characteristic-zero coefficient domains by the integral generators and perfect bases; no residue-field invariant-base-change assertion is being substituted for this.

The norm squared is exactly c^2 kappa. There are n D1 nonzero factors in c, each at most M+n−1 in absolute value. The zero-base case has n=1, M=0 and D1=0. Schur averaging of the orbit of a normalized highest vector gives kappa/dim(V_lambda). The evaluation identity reduces the matrix coefficient to the value of xi on a unitary frame, up to inverse and transpose; those changes preserve the orthonormality of the relevant columns. Each displayed minor has modulus at most one, proving kappa<=dim(V_lambda).

The determinant shift is legitimate under the actual SameShift hypothesis. It changes the last-circle exponent from the polynomial degree d to d+s=|lambda|−|mu|. With R(g)=rho(g^(-t)), substituting B=diag(B',t^(-1)) gives exactly the stated local basis identity, including the conjugate uniformizer in the arithmetic application. The tensor-product scalar is the product over embeddings.

The example lambda=(2,1,0), mu=(2,0) gives J(x_1 x_2)=x_2 D_13−x_3 D_12/2 and cBr=4. Its coefficient −1/2 is correct. It disproves omission of the normalization, not the actual source assertion.

## Exact independent read scope

- All of integral_branching.tex.
- compact_branching.tex, lines 1–285: polynomial convention, highest-weight intertwiners, joint highest vector and compact branching law used by the fragment. This review is not claimed as a separate fresh audit of every transitive input of compact branching.
- theta_radial_positivity.tex, lines 167–199, reread for the negative Capelli convention. The complete radial fragment was independently reviewed earlier and has a separate review record.
- coefficient_duality.tex, integral-duality theorem and coefficient-ring extension, reread; its full proof was already independently developed and reviewed earlier.
- sources/lean/src/Formalism/LocalToGlobal/Columns/FiniteSumNonzeroLargeDepth.lean, lines 1–155: aBr, bBr, Interlace, SameShift, d0, rSet, cBr, nBr, Gram projection, coefficient extraction, xiBr, kapBr, brStd and brAt.
- sources/lean/src/Formalism/LocalToGlobal/KernelLattices/InterlaceAll.lean, lines 1–65: raising monomial, factorial product, ioConst, ioStd, and the exact transpose, highest-vector and equivariance assertions. Additional later text was viewed for context but is not counted as an independent proof audit.

No counterexample satisfying the actual hypotheses was found. No mathematical correction is requested. This is a conventional mathematical and source-definition review, not a new Lean compilation or kernel certification.

Reviewed TeX SHA256: `9ceb58cec653ce2ca222cbc87111304b8ca33674e5f7bbcc34bc591f34d67525`.
Reviewed line count: 391.
Recorded UTC: 2026-11-21T01:21:24.732237+00:00.
