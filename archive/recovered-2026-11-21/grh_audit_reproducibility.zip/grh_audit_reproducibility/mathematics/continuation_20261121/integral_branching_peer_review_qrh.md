# Independent review: integral_branching

Date: 2026-11-21. Reviewer: qrh_mathematics.

Read all 391 lines of `integral_branching.tex`, SHA256 `9ceb58cec653ce2ca222cbc87111304b8ca33674e5f7bbcc34bc591f34d67525`.

I independently read the entire fragment and checked the stated maps against the actual definitions `FiniteSumNonzeroLargeDepth.lean:1--150` and `KernelLattices/InterlaceAll.lean:1--170`, read directly. The proof is sound conditional on the separately supplied integral initial-minor spanning theorem. I did not treat that theorem as already reconstructed in this review.

* In the integral-lift induction, removing a height-s factor preserves partitions and interlacing in both cases. In the second case mu_s=lambda_(s+1)>mu_(s+1) gives b_(s+1)>=1, and the last-row Laplace leading term is exactly z_(s+1) times the desired minor with coefficient +1. The weighted monomial order is strict under multiplication and keeps the required last-row degree.
* The central projection polynomial uses the negative Capelli convention with the additional shift u+1. Its scalar is exactly product_j(u+j-eta_j). Every interlacing eta with the fixed total degree lies in the displayed intervals. The factors kill all other summands. The inequalities for j<i and j>i prove c nonzero, including repeated weight entries and empty products.
* Coefficient extraction commutes with top-row operators. The c-scaled projection of any integral lift equals cJ, independently of the lift. No assertion that the unscaled highest-vector normalization is integral is made.
* The normalized Fock adjoints have the factors C_lambda/(b! C_mu) and kappa=[xi,xi]/C_lambda in the correct directions. The exact formulas for brStd and ioStd match the source. Integral duality passes integrality from the dual-Weyl map to its Weyl transpose without excluding primes dividing a factorial or Gram denominator.
* The exact squared norm is c^2 kappa. The factor count nD1 and base M+n-1 are correct, including n=1,M=0. Schur averaging and the evaluation identity bound kappa by dim(V_lambda); every replaced-row minor of a unitary frame has modulus at most one.
* The determinant shift changes the last-circle exponent to |lambda|-|mu|. Substitution R_lambda(g)=rho_lambda(g^(-t)) gives the stated B_t coordinate identity, with t=bar(pi_T) in the arithmetic application. Tensoring and localization introduce no additional scalar.
* The lambda=(2,1,0), mu=(2,0) counterexample is correct: J(x1*x2)=x2*D13-(x3*D12)/2, and the specified product gives c=4. It refutes deletion of the scalar, not the actual submitted map.

No mathematical defect was found in these arguments. The source scan here does not constitute a transitive import audit or a fresh Lean kernel certification. The only additional conventional input not independently proved in this review is the integral initial-minor span; its proposed elementary reconstruction is being separately reviewed.

## Subsequent closure of the spanning input

I then independently reviewed all 299 lines of `polynomial_minor_spanning.tex`; the detailed positive review is `polynomial_minor_spanning_peer_review_qrh.md`. Its complete elementary proof supplies the only input retained above, so the integral-branching proof is now closed within the conventional fragments.
