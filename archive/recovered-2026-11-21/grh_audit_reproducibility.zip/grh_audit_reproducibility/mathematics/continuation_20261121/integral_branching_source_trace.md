# Exact integral branching: source correspondence

The proof is in `integral_branching.tex`; independent full mathematical
reviews are in the QRH and formal review records. The source manifest
identifies exact files and read intervals and deliberately does not
claim that every line of `BranchMap.lean` has been read.

## Integral map and scalar

The partitions are the actual shifted partitions in `DataCoeff` and
`PrimeDegreeVariant`, with lambda of length n+1 ending in zero. The
integers a_i=mu_i-lambda_(i+1), b_i=lambda_i-mu_i, D0, D1 and the
truncated integer intervals agree with `cBr`. The zero factors omitted
from its definition are exactly those indexed by mu_i, and no other
factor vanishes under interlacing.

An integral lift for last-row coefficient extraction is proved by
induction on products of initial-column minors. The integral spanning
assertion is proved independently in `polynomial_minor_spanning.tex`.
Applying ordered row Capelli operators projects this lift to the mu
summand with scalar exactly cBr. This replaces the longer source
column-operator filtration, and proves cBr*J is integral on the actual
dual-Weyl lattices. It does not assume that the unscaled J is integral.

## Exact normalization and covariance

`FiniteSumNonzeroLargeDepth` defines kappa as the Fock norm ratio and
`brStd` as cBr*kappa times projected last-row coefficient extraction.
`InterlaceAll` defines the opposite map using the norm of the interlacing
polynomial divided by the highest-vector norm and the last-row
multi-index factorial. The proof derives these constants directly from
the Fock adjoint; the opposite map is exactly cBr*J. Perfect integral
duality then gives the actual Weyl-lattice integrality statement.

The Schur orthogonality bound kappa <= dim(V_lambda), followed by the
literal count of scalar factors, implies the source norm bound. Common
determinant shifts are retained. With R(g)=rho(g^(-t)) and
B=diag(B',t^(-1)), the covariance formula is
R_mu(B'^(-1))*B_t = brStd*R_lambda(B^(-1)), where
B_t=t^(-degree)*brStd. Taking t equal to the conjugate uniformizer is
the source convention of `RhoVrBrAtEqBrStd`. This identity is used in
the all-twist arithmetic lowering reconstruction.

## Counterexample to deleting the scalar

For lambda=(2,1,0), mu=(2,0), with D_ij=x_i*y_j-x_j*y_i, the normalized
map sends x_1*x_2 to x_2*D_13-(1/2)*x_3*D_12. This is not an integral
polynomial. The actual cBr is 4, and the submitted map retains it.
Thus the example refutes a tempting simplification, not the submitted
theorem. The fragment proves the displayed identity exactly.

The initial divisibility obtained here does not by itself prove the
stronger level-prime column gain; that arithmetic input remains
separately identified in the manuscript.
