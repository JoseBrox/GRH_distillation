# Independent review: integral subspaces and period pairings

Reviewer: qrh_mathematics. Date: 2026-11-21.

Read the full current fragment (205 lines, SHA-256 646c02b1bb97ed1cc33c1191cce6ac10ebda3cce47ca4defdb4590086ff290e7). No mathematical defect was found.

The denominator condition forces the complex idempotent to preserve the original rational vector space. The local Smith normal form proof correctly computes the kernel after extension to the localized integral closure, including ramification: every nonzero diagonal entry remains a non-zero-divisor. Faithful complexification is then used to identify the tensor module with its specified complex image; it is not inferred from torsion-freeness. The local-to-global argument for the kernel and cokernel is valid.

The finite-group projector coefficients are integral after multiplying by the displayed group-order denominator, including nontrivial one-dimensional characters. This denominator is used to form an integral endomorphism; it is not an extra multiple of every vector in the intersection. The proof of the valuation extension therefore correctly has no additional denominator loss. The nonnegative valuations of the integral coefficients, the ultrametric triangle inequality, and the injectivity of the field embedding give the claimed bound and uniqueness. Localized coefficients obey the same argument.

The Q(sqrt2) irrational-subspace example, the nonfaithful-complexification example, and the local-principal-generator convention in the final scaling statement all check. The fragment correctly leaves the initial theta-period valuation estimates unresolved rather than deriving them from scalar extension alone.
