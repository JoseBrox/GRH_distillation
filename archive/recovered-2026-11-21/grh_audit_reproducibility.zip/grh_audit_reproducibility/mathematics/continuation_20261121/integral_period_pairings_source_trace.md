# Integral intersections and period valuation: exact scope

The fragment integral_period_pairings.tex proves the coefficient-extension intersection and the algebraic passage from integral period tests to all target vectors. It does not prove the initial period valuation bound.

## Exact source connection

- Divisibility/TiedLemmas.lean:72–310, relative to Formalism/LocalToGlobal, defines and proves the base-change kernel equality, faithful complexification hypothesis OForm, and cut_tensorUp_row. Its integral endomorphism is N(1-e); the fragment gives a direct local Smith-normal-form proof. The source does not assume flatness without justification: its Dedekind domain and torsion-free extension supply it. The ordinary proof states number-field coefficient rings and checks the relevant kernel directly, including ramified primes.
- GroupLattices/JointServices/LevelOperatorFixesImage.lean proves that the actual projector fixes the target image and that its integral membership criterion is the transported coefficient-lattice criterion. The finite-group projector and denominator facts were already proved in divisor.tex. All of this source file was read.
- GroupLattices/JointServices/ValIntNonneg.lean gives perCol_lin, cutUpOfOTie, perToVal2, and val2AllAtR. The full file was read. Its proof expands the test vector in the original cut lattice, then uses integral span induction in the source. The source valuation includes zero as a separate disjunct; the mathematical fragment uses v(0)=infinity, which is the same statement.
- GroupLattices/ServJointF.lean gives the corresponding family version. The full file was read. Its Tied structure records the actual complex period identity and the integral-image conditions; it is not itself the provider of the period estimate.
- Formalism/SharpRestriction/Divisibility/LocalQuadraticParts.lean:206–226 defines the rounded and unrounded period valuation conditions. The actual rounded lower bound is floor(ur*sg). No stronger ceiling statement has been substituted.
- GroupLattices/AdmissibleAtGeneratorPlaces.lean was read in the intervals recorded by the manifest. It distinguishes the level prime, the two auxiliary primes, and the remaining primes; its assembly takes genuine period and column-lattice estimates as inputs. Those inputs have not been inferred from the algebraic cut lemma. The related AdmissibleOfInclusion and DivisionAdmissibleFamilyOfData wrappers were read in full and retain these hypotheses.

## Counterexamples and review

The sqrt(2) idempotent example disproves intersection/base-change without rationality. The complexification of Z+Z sqrt(2) shows why torsion-freeness alone does not supply an integral form. Neither example satisfies all source hypotheses. The QRH reviewer independently read the whole mathematical fragment and found no defect. The source manifest records hashes and exact intervals; it is not a formal-kernel verification record.
