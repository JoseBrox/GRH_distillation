# Independent review: Fourier decay of the actual Jacquet integrals

Verdict: PASS for the stated Fourier decay, compact slice regularity and
terminal compactness, with the separate full-matrix obligation retained.

Root read all 654 lines of `jacquet_fourier_decay_actual.tex`, SHA-256
`02d41e972aead11a950d661ae86c00789e0e6526ca65304d58e83334564715b2`.

## Mathematical review

- Rational inverse open-cell coordinates give a locally uniform polynomial
  bound for the integrating nilpotent coordinates. Arbitrarily high decay
  of every derivative then supplies the stated pointwise smoothness and
  differentiation under the integral, rather than only almost everywhere
  convergence.
- Reduction of the Haar formal adjoint uses invariant vertical frames,
  unimodularity, unitary characters and the exact radial Haar density.
  Multiplication by gamma is the required isometry. This does not equate
  formal algebraic adjoints with analytic adjoints without justification.
- The four operators are the previously reconstructed genuine group lifts.
  The inverses used on the full group have powers only of the full Gram
  polynomial in their denominators; intermediate leading minors need not
  be nonzero on the support of the group coefficient.
- The shifted Toda identity and telescoping preserve operator order. The
  terminal Gauss terms cancel with their proved shifted adjoints, giving
  theta_0^* f_s theta_1 - theta_2^* f_s theta_3 = s f_s.
- The global pairing-adjointness result from JP supplies the analytic
  integration by parts. The initial bound comes from unit-modulus radial
  multiplication and Cauchy--Schwarz, so it is uniform in s. No seminorm
  estimate with concealed s-dependence is used. Iteration gives every
  inverse power; polynomial first-minor insertions justify every Fourier
  derivative and give the full Schwartz assertion.
- The one-pair compact family has exactly |t|^(2r+k), and full Gram support
  becomes |t|^2 times lower-rank Gram support. Rational inverse coordinates
  give common compact support and a positive Gram bound on each compact
  subset of t != 0. Taylor estimates and the already proved JP seminorm
  bound give smoothness as a Hilbert-space valued family.
- Fourier inversion alone supplies an almost everywhere representative.
  Independent continuity of the compact-input density identifies that
  representative at every nonzero t, and hence gives the asserted smooth
  extension. The proof does not assume this pointwise identification.
- Bounded terminal invariant and positive Gram cutoff give compact
  terminal support after fixing nonzero outer parameters. Generated local
  slices retain the compact-family description. This is not a claim of
  global L2 after arbitrary inverse-coordinate multiplications.

## Source comparison

Root read `StatementJC.lean` lines 12--43 for NiceCoef, the complete
`HerGenC.lean` and `CutSERDAsm.lean`, and `CutSH2.lean` lines 15--85 for
GoodFam and the exact sliceFam normalization. Root also rechecked the
statements and relevant bounds in the previously reviewed JP fragment.
The drafting review's 19-file manifest specifies its additional read scopes.

## Remaining obligation

The full initial matrix Q_0 and its complete successive restriction identity
are not consequences of the four Fourier lifts. The manuscript explicitly
leaves them open. This review does not certify the final residue-pairing
assembly, the full GRH proof, or a complete local Lean kernel replay.
