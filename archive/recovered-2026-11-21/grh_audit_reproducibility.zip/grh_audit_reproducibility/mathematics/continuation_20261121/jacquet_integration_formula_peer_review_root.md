# Independent review of the Jacquet integration formula

Reviewed by the root agent on 2026-11-21. Every mathematical step was
read, followed by the final clarification of almost everywhere strong
measurability and the typography edits. Reviewed SHA-256:
3d69cb549250b8eddb819d73db9eef3b1eda27ea1abd82ca9c40178756677550.

The shell construction gives the invariant measure on the negative unit
hyperboloid, with density one half of du dtheta. The radial substitution
changes r^(2k-1)dr to (rho^2-1)^(k-1)rho drho, including k=1. The compact
double-coset description accounts for the complete fibre at each zeta;
any permitted smooth section gives the same averaged integral. Boundary
circles and the complement of the open Bruhat cell have measure zero.

The induction through the outer isotropic pairs retains the complex
radial exponent 2(M_a-2). The nilpotent coordinate changes have determinant
one. The resulting integration identity fixes the normalization of Haar
measure; it is not claimed for arbitrary independently scaled measures.

The L1 proof retains the sum M(m)^2+|c|^2+|c|^(-2) before integrating the
radial variable. This is essential to reach the actual threshold
A>2(k+r)(r+1). The two radial ranges give the stated bounds, and the
induction lowers A by D+1, exactly the difference between successive
thresholds. Tonelli is used before finiteness, and the final vector-valued
conclusion includes almost everywhere strong measurability.

The dilation sends each nilpotent coordinate and each radial c_a to the
stated power of t. The two pushforward measures both have exponent
-kappa_r. Their combination is consistent with the factor appearing in
the Jacquet norm identity. The case r=0 gives exponent zero.

The root compared the relevant definitions and quantifiers in
StatementB.lean, StatementBF.lean and StatementRP.lean, as recorded in
the prior reading log; the author-agent's wider source coverage is
separately specified in the manifest. The exact control script was also
rerun independently; its result is retained in the checks JSON. These
finite checks supplement the proofs and do not establish them by
sampling. No mathematical defect was found in this fragment. No complete
Lean kernel replay is claimed.
