# Integration formula and dilation measure: source trace

The conventional proof is jacquet_integration_formula.tex. Its exact hash,
source hashes, read scopes, dependencies, and available root review are
recorded by build_jacquet_integration_formula_manifest.py.

## Exact statements reconstructed

- The source has k at least one and negative z,z', with T=-h(z,z) and
  T'=-h(z',z') positive. Its Hermitian form is linear in its first
  variable. These hypotheses and this convention are retained.
- StatementBF defines Mdim at a as 2(r-a)+k+1 and the radial density as
  product |c_a|^(2(Mdim_a-2)) times (|zeta|^2-TT')^(k-1).
  The entire density is recovered from two actual Jacobian calculations:
  the previously proved one-pair Haar Jacobian and the hyperboloid
  quotient measure at the terminal group.
- StatementRP's IsSection requires smoothness and the exact equation
  h(mu(zeta)z',z)=zeta only in the exterior region. The proof constructs
  one such section explicitly and proves independence of all other
  permitted sections by transitivity of the compact double orbit.
- WeylElementCommutesLevelOne states the intermediate integration formula
  with a positive constant and then IntNorm. The manuscript likewise
  rescales the group Haar measure by that constant; it never claims the
  normalized formula for arbitrarily and independently chosen measures.
- StatementB's IntFormula uses k_1^(-1)n_1^(-1)g_q n_2 k_2 and the product
  measures in that order. Inversion and the required compact conjugations
  are accounted for in the proof.
- GNIntSharp and CCIntegrable are proved at the exact source bound
  A >= 2(k+r)(r+1)+1; in fact the proof gives the open range
  A > 2(k+r)(r+1). The final corollary explicitly permits almost everywhere
  strong measurability, as the source does.
- StatementB's aDil and kap are matched exactly. The unipotent and radial
  maps both have a positive coordinate Jacobian, so their pushforward
  measures both have the negative exponent. This is checked explicitly.

## Independent simplifications

The terminal quotient is computed by invariant coarea measure on
|w|^2-||u||^2=1. The measure is one half du dtheta, up to the chosen
normalization. Polar coordinates then give the precise power k-1.
No unproved compact double-coset integration formula is invoked.

The L1 bound is proved by induction using the one-pair open cell. Retaining
|c|^2+|c|^(-2) in the right Heisenberg estimate makes its complex radial
integral lower the decay exponent by exactly 2k+4r, which matches the
difference between successive sharp thresholds. The left variable has
an integrable weight in real dimension 2d+1 with exponent 2d+2.

## Checks and limits

check_jacquet_integration_formula.py uses exact rational and algebraic
arithmetic to check the coarea density, the genuine terminal unitary
section for k=1 and higher k, noncompact changes of negative frame, the
full real unipotent Lie algebra dilation determinant, character scaling,
big-cell scaling, radial scaling, and strict convergence inequalities.
These finite checks supplement the proofs. They are not a Lean build.

The source manifest deliberately lists only the source lines actually
read. In particular no complete line-by-line read of every archived
geometric implementation file is claimed. The replacement mathematical
proof uses the reviewed JK, JU and JM fragments as explicit proved
dependencies. No counterexample under the actual hypotheses was found.
