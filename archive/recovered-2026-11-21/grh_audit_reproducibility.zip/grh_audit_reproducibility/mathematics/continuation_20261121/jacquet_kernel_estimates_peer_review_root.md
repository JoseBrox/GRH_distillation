# Independent review of the Jacquet coordinate integrals

Reviewer: root mathematical audit.
Reviewed file: jacquet_kernel_estimates.tex, all 616 lines.
Reviewed SHA256: 5ffec5646855aee97029538955ee8a05b31572025983c925d0f3a9a9ca56a5ec.

Result: the mathematical argument passes this review.

The review checked the gamma factor in the rank-zero integral, the completed
square and every Jacobian in the recursion. Tonelli's theorem gives the
necessity as well as the sufficiency of both sets of strict inequalities.
The tail reduction retains arbitrary real alpha. The quadratic sublevel
estimate, its integration, the complex Riesz estimate, and the comparison
of slowly varying real weights have the stated exponent ranges.

The weighted subcritical integral uses the correct shifted exponents.
In the oscillatory estimate both averages preserve measure; the reciprocal
scaling changes the positive kernel by a uniformly bounded factor. The
condition on the first coefficient of the second complex block is retained,
as are the strict total-loss bound and the decay in the constant term.
The examples of divergence violate specified hypotheses and are not
counterexamples to the source's actual assertions.

The reviewer independently read the entire source file
ReciprocityTheory/ReductiveGroups/DiscreteSeries/TailIntegrals/TailInt.lean.
Its definitions of CH, TailFin, C1, SUB, KER, SLOW, and OS agree with the
manuscript, including the index shift in OS and the Pi norm in SUB.
The other source scopes are recorded as the contributing agent's reads,
not as additional independent reads by this reviewer.

The reviewer reran check_jacquet_kernel_estimates.py. All 1,400 exact
controls passed. They verify finite algebraic and normalization instances,
not the universal analytic assertions, which are justified by the proofs.

This result does not establish the geometric induction, a majorant for the
full group integral, or the Jacquet pairing identity. It is not a Lean kernel
replay and does not certify the full submitted proof.
