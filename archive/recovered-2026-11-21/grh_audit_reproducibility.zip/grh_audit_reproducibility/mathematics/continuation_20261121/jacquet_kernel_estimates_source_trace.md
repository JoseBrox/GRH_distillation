# Jacquet coordinate estimates: source correspondence

## Deliverable and mathematical status

jacquet_kernel_estimates.tex is a complete ordinary mathematical proof of the
coordinate assertions CH, TailFin, C1, SUB, KER, SLOW, and OS as they are actually
defined in the submitted archive. It uses Lebesgue measure in the displayed
real and complex coordinates. CH and TailFin are strengthened to exact values
and necessary and sufficient convergence conditions.

The argument is not a kernel replay. It does not assume an asserted Jacquet
majorant, conclude the full group estimate from the coordinate calculation
alone, or treat finite computational checks as a proof of a universal result.

## Exact definitions

All paths below are relative to sources/lean/src/.

ReciprocityTheory/ReductiveGroups/DiscreteSeries/TailIntegrals/TailInt.lean
was read in full. Its definitions match as follows:

| Source | Conventional manuscript |
|---|---|
| Xp p m | X_(p,m) |
| Lsq, bco, rhoSq, de | L_l, B_l, R_l, d_l |
| s0N | sigma_l |
| CHInt, CHCond, CH | I_(p,m), its open convergence cone, exact evaluation theorem |
| tailPt, TailInt, TailFin | first b-coordinate zero, T_(p,m), exact reduction |
| C1 | displayed completed-square identity |
| SUB | quadratic sublevel estimate and its weighted consequence |
| KER | the two dimensional Riesz weight estimate |
| SLOW | the one dimensional weighted integral comparison |
| linF, OSInt, OS | ell, final weighted integral, final theorem |

The indexing in OS is P=p+1, so the final theorem has P+1 norm factors on
X_(P,m). All exponent restrictions and the condition eta'_0 != 0 are retained.
The maximum of the three quadratic coefficient moduli is the Pi norm appearing
in the source's SUB definition.

## Proof portions compared directly

The following source files were read completely, including their actual
statements and proof bodies:

- TailIntegrals/Imports.lean: the two transformations rho, rot, scl.
- TailIntegrals/CriticalExponentSucc.lean: integration of the first complex
  coordinate and the CH-to-Tail reduction.
- TailIntegrals/TailFinOf.lean: convergence inequalities, C1, and induction.
- TailIntegrals/LintegralInsertFiberLe.lean: precise powers of L and d_0 after
  the Riesz-weighted integration.
- TailIntegrals/DeZeroBounds.lean: d_1 <= sqrt(L)d_0, the real coordinate
  bound, and the uniform scale A_l >= L needed for SLOW.
- TailIntegrals/ExponentConditionNeg.lean: the exact exponent shift and the
  finite weighted integral used by OS.
- TailIntegrals/RhoMulStar.lean: measure preservation, kernel invariance, and
  the quadratic formula for the first average.
- TailIntegrals/RhoSqNonneg.lean: reciprocal scaling, the norm lower bound,
  and the quadratic formula for the second average.
- TailIntegrals/OscillatoryBound.lean: the complete assembly of OS.

Here TailIntegrals/ abbreviates
ReciprocityTheory/ReductiveGroups/DiscreteSeries/TailIntegrals/.

The definitions in TailIntegrals/InductiveHeisenbergInputs.lean were also read
in full. They identify the distinct remaining group-theoretic and analytic
inputs: FormulaF, AAt, BAt, TBoth, DET, CoefStep, and XiIntStep. This manuscript
does not claim to prove all of those assertions.

## Independent simplifications and strengthening

1. The basic integral is evaluated explicitly as a gamma factor times a finite
   product of rational linear denominators. Tonelli and exact one-coordinate
   integration prove the necessity of every displayed inequality.
2. The removed-coordinate integral is reduced exactly to the basic integral
   for arbitrary real alpha, including negative alpha.
3. A direct three-point interpolation proof gives SUB, with explicit constant
   30 for the exponent range actually used.
4. Elementary partitions of the complex plane prove KER, and comparison of
   the weight on two adjacent intervals proves SLOW.
5. Both averages in OS are given explicitly, with the Jacobians, coordinate
   invariances, and polynomial coefficients proved. No oscillatory
   cancellation or unproved absolute convergence is inserted.

## Counterexamples and their limits

The manuscript proves divergence at every boundary or exterior point of the
CH convergence cone. It also proves divergence of the unweighted kernel
below the critical exponent, and hence divergence when the linear form
vanishes. These are counterexamples to altered statements with omitted
hypotheses. None is a counterexample to the actual assertions above.

## Verification

check_jacquet_kernel_estimates.py performs exact rational and symbolic
controls of the coordinate identities, changes of variables, exponents,
boundary examples, and low dimensional normalizing constants. The recorded
result is in jacquet_kernel_estimates_checks.json. These checks address
finite algebraic and normalization risks, not the general analytic proof.

The isolated wrapper jacquet_kernel_estimates_check.tex compiles this section
with its bibliography. The complete report remains responsible for the
subsequent geometric induction and Jacquet pairing arguments.
