# Independent review of the full-group Jacquet majorant

Reviewer: /root. Date: 21 November 2026.

Reviewed fragment: `jacquet_majorant.tex`, SHA-256
`174d257a61fe9f43d6bcb6b882314967c7555333d60957b12db7c415885f2570`.

**PASS.** I read the complete fragment and checked the following
points independently. The preceding coordinate-integral and
unipotent-decay proofs had already passed separate full reviews.

1. The compact flag factor is the product of the diagonal entries
   of the triangular change of frame. Consequently the two factors
   in the two-sided identity are evaluated at x and y, rather than
   their inverses. All minors used are leading minors. This remains
   an identity of nonnegative integrals before finiteness is known.
2. At rank zero the ball measure has exponent -k-1. The fractional
   linear Jacobian, Frobenius-norm bound, spherical gamma quotient,
   and Poisson integral give the claimed finiteness for A>2k and
   0<s<k. The proof includes k=1, where the sphere is a circle.
   Fatou first gives an integrable limiting singularity; dominated
   convergence then proves its stated value without circularity.
3. The one-pair cell coordinates reconstruct the actual matrix
   blocks. Left Heisenberg directions contribute |c|^(2d+2), and
   the diagonal complex direction contributes |c|^(-2), giving
   |c|^(2d) with planar dc. Connectedness and real analyticity
   justify discarding the complement of this cell.
4. The right-Heisenberg integral uses two different lower bounds
   for the Frobenius norm. Their Jacobians give |c|^(-2d-1) and
   |c|^(-1), respectively. Taking their minimum is justified.
   The subsequent compact factorization gives precisely the
   exterior ratios delta_(j+1)/delta_0.
5. The induction threshold has difference D+1, where D=2d+1.
   The complex radial integral converges exactly under the two
   inequalities 1<sigma<2d+1 used in the proof. After integrating
   it, the remaining coordinate parameters are
   nu_0=e_0+2 sum_(j>=1)e_j and nu_l=-e_l. Both families of strict
   convergence inequalities from the previously proved exact
   gamma-product integral hold. This is why negative later
   parameters cause no divergence here.
6. Exterior Cauchy–Schwarz gives |D_l(g)|<=M(g)^(l+1).
   The positive-exponent hypotheses and M(g)>=1 then give the
   determinant majorization in the stated direction. Conjugation
   by H changes the primed frame to the unprimed frame and yields
   the actual coefficient bound. Haar null sets remain null under
   both translations, so almost-everywhere strong measurability
   is sufficient for the source's quantifier.
7. The stabilizer of a negative vector is compact, even when it
   is not contained in the chosen Euclidean compact subgroup.
   The proof correctly uses a uniform operator-norm bound in
   that case. Conjugation preserves both the unipotent Haar
   measure and its character. The same exponent window works
   for the two negative vectors. The zero extension outside
   the closed matrix group supplies the ambient measurable
   witness required by the source.

## Source statement checks

I independently read all 118 lines of
`TailIntegrals/InductiveHeisenbergInputs.lean`, and the definitions
of gN, AB, CoefBound, XiInt, XiExists and the relevant RealPlaceData
fields in `Formalism/HermitianCurvature/StatementB.lean`.
In particular RealPlaceData includes k_pos, so the k>=1 assumption
does not narrow the source application. The source permits real c
and c'; its pointwise decay inequalities at the identity force
both to be nonnegative, as in the conventional formulation.
I also checked the source's inverse-left convention in the one-step
cell. Inverting a Heisenberg element preserves its Lebesgue measure.

The other source read scopes belong to the author manifest. This
review does not claim a fresh complete reading of them. The 274
exact controls are finite checks of the algebra and Jacobians,
not an independent proof of the integration argument. The final
regularized pairing, dominated unfolding, and Jacquet adjointness
are separate and are not established by this fragment alone.
