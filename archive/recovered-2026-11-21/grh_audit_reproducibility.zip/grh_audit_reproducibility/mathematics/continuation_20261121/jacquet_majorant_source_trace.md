# Full-group integral and Jacquet majorant: source correspondence

## Mathematical status

jacquet_majorant.tex proves the actual AAt assertion and then constructs the
majorant required by XiExists, including both CoefBound and XiInt. It uses the
previously reconstructed coordinate and unipotent estimates. Its final scope
statement explicitly leaves the later regularized pairing, dominated
unfolding, and adjointness arguments separate.

No Lean kernel replay is claimed. The proof is conventional mathematics,
with independent derivations of the Haar density and the rank zero case.

## Exact source definitions

In Formalism/HermitianCurvature/StatementB.lean:

- gN at line 230 is exactly the Frobenius norm used here.
- AB at line 243 is exactly 2(k+r)(r+1)+1.
- CoefBound at 313-320 is the separated integral estimate proved here.
  The manuscript allows almost everywhere strong measurability, as does the
  source. Its nonnegative constants impose no additional assumption: any real
  constant satisfying the source decay inequality is nonnegative at the
  identity.
- XiInt at 322-327 is exactly the compact-stabilizer/unipotent integral with
  exponent 2, for z and z'.
- XiExists at 439-442 is the existence of a nonnegative measurable function on
  ambient matrices with those properties. The manuscript defines the function
  continuously on the closed group and extends it by zero. All measures in the
  target are supported on the group, so this is a valid witness to the actual
  existential assertion.

ReciprocityTheory/ReductiveGroups/DiscreteSeries/TailIntegrals/InductiveHeisenbergInputs.lean
was read in full. Its AAt, FsE, fsR, JInt, TLeft, TBoth, DET, CoefStep, and
XiIntStep match the roles in the manuscript. For TLeft/TBoth the manuscript
proves precisely the positive exponent range needed for AAt and XiExists;
it does not claim to have reconstructed every arbitrary-real-exponent variant.

## Open cell and norm

Formalism/HermitianCurvature/WeylElementCommutesLevelOne.lean, 195-263,
was read directly. The actual oneStep uses the inverse of the left
Heisenberg element. Replacing (v,t) by (-v,-t) gives the manuscript's
convention, preserves Lebesgue measure, and changes no exponent.

The manuscript proves the Haar density |c|^(2 dim_C W) by computing the full
Maurer--Cartan differential and its real Jacobian. The calculation includes
the inverse-square factor from dc/c; it does not omit the complex c Jacobian.

It proves the right-Heisenberg integral by the exact block Frobenius norm.
The two valid lower bounds separately give |c|^(-2d-1) and |c|^(-1),
and taking their minimum produces the actual source estimate.

## Source proof portions compared

Under the TailIntegrals prefix above:

- TLeftH.lean and XphiLinInd.lean were read in full. The triangular compact
  flag factors, their side conventions, and both Haar substitutions match.
- EIntBound.lean was read in full, including the actual exponents and the
  c-integrability interval.
- AStepFin.lean was read in full. The loss of 2d+1 in A, the c-exponent, the
  first shifted CH exponent, and the remaining negative losses match.
- InnerCLe.lean was read through line 125. The exact norm weight and scaling,
  and the beginning of the inner integral bound, were compared. The remainder
  of that file is not claimed read.
- HeisenbergRankOneDecomposition.lean and Phi2.lean were read in full. The
  manuscript reconstructs their needed decomposition directly by sending
  the first isotropic vector to the standard one and then using its stabilizer.
- XiRNonneg.lean was read from line 50 through the end. In particular the
  H-conjugation converting fsR to xiR is included explicitly; the proof does
  not confuse the two isotropic reference flags.
- XiIntH.lean and XiExists2.lean were read in full. Compact conjugation,
  the uniform exterior-norm bound, the comparison of exponents 2 and 1/2,
  and the common exponent window for z and z' all agree.

## Independent rank zero proof

The rank zero proof is an alternative derivation of the same actual AAt
target, not a claim that all the source's rank zero proof files were read.
It gives the exact compact angular integral

    integral |1-zeta_1|^(-s) d omega
      = Gamma(k) Gamma(k-s) / Gamma(k-s/2)^2,  0<s<k,

from elementary complex sphere moments and a beta integral. The same moment
calculation gives the Poisson-kernel normalization needed for Jensen.
The invariant ball measure and the displayed boost matrix then prove the
Frobenius-norm integral for A>2k. This handles k=1 as well.

## Verification and limits

check_jacquet_majorant.py performs exact rational full-matrix controls of:

- the Hermitian group equations and open-cell coordinate inversion;
- all tested singular-minor factors, including both Heisenberg sides;
- the exact Frobenius norm formula;
- the full real Lie-algebra Jacobian in dimensions 16 and 25;
- independent planar evaluations of two angular constants;
- the exact rank-step thresholds and remaining CH convergence inequalities.

The original symbolic implementation was interrupted when unreduced rational
complex expressions caused slow expansion. The final implementation expands
exact rational entries and uses domain Gaussian elimination; it performs the
same checks and completed successfully. No numerical approximation or sampled
integral is used as proof of an analytic assertion.

These finite controls complement the complete mathematical arguments. They
do not establish an independent kernel check, nor the subsequent Jacquet
pairing identities which remain to be reconstructed.
