# Independent review of Jacquet regularization and adjointness

Reviewed by the root agent on 2026-11-21. All 681 lines of the conventional
argument were read, with the final typography changes included.
Reviewed SHA-256:
9983a1430ad0adc2a20388e9d755589c32070beb82f1f9cbd1d8ae10274c747e.

The group law for rho, the order of both compact factors, and the
linear-in-the-first-variable Hilbert--Schmidt pairing agree. The local
orbital L1 assertion is only almost everywhere in the radial variable,
on a common set for all positive characters. No stronger pointwise
absolute-convergence assertion is used.

Four derivatives suffice for the regularized bracket, including the
mixed derivative (2,2). Translating both functions changes the dilation
of the group parameter into derivatives of the functions with a proved
integrable majorant. Fourier averaging is first performed for fixed p;
the later change of variables supplies absolute integrability before
Fubini. This avoids an unjustified unweighted interchange.

The fixed-orbit unfolding is absolutely convergent. Its orbital L1 norm
squared is not assumed integrable over the radial variable. Instead,
Fourier decay and the full-group coefficient estimate justify that
integration. Almost everywhere equality of the diagonal pairings gives
an everywhere upper bound by Fatou. The fifth derivative then gives
continuity of dilation in the four-derivative norm. The two exact Haar
Jacobians yield the Jacquet norm dilation formula, hence equality at
every positive character. Complex polarization is applicable only after
these finite diagonal norms have been established, as done here.

Integration by parts is proved from the fundamental theorem of calculus
and Haar invariance under the actual L1 hypotheses. At each transfer,
the three required products are particular cases of the full IntClause.
The derivative word reverses, and derivatives act on the adjoint
coefficient. Closed support inside the stable open set justifies smooth
extension by zero. The polynomial coefficient criterion verifies all
four decay-class memberships and every case of IntClause.

The root compared StatementB.lean lines 186--565 directly, in addition
to its previously read setup, and StatementG.lean lines 60--90 for the
minors and invariant polynomial. Thus the actual conclusions and
operator hypotheses, not only an abstract analogue, were checked. The
author-agent's helper-file reading scopes remain separately recorded in
the manifest. The exact controls were independently rerun and include
negative controls for word order and coefficient derivatives.

The analytic theorem passes review. Its commutation, support, and
regularity assumptions still must be verified for every operator and
vector used in the recursive construction. No complete Lean replay or
verification of the final global theorem is claimed here.
