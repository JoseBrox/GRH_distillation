# Independent review of weighted unipotent integrability

Reviewed manuscript: jacquet_unipotent_decay.tex, in full.
Final SHA256: 8b117863f0b07043ef6fa1e38376b60dda3722d82ab38eab09e3efd4b2e5b663.

Result: the mathematical proof passes review.

The reviewer checked the flag definition of the unipotent group, the global
Heisenberg coordinates and both Haar Jacobians, the exact Gram determinant
after the column subtraction, and compact orthogonalization in the positive
and negative eigenspaces. The involution H lies in the compact group and
interchanges the two isotropic frames, so the stated primed-frame source
assertion also follows. The source's mixed sign and coordinate conventions
agree with the character lambda = 2 Im ell.

The coefficient in the one-step oscillatory bound is exactly
h(phi_0,f_z)/Delta_0(m). It equals the stated nonzero constant before the
last rank, and its nonvanishing at rank zero follows from the negative norm
of z. That assumption has not been omitted. The delta/4 change, gamma loss
in the first lower exponent, and every strict inequality in the inductive
window were checked. The window is independent of z; the bound itself
may depend on z. Every use of Tonelli has a nonnegative integrand.

The reviewer independently read all of
ReciprocityTheory/ReductiveGroups/DiscreteSeries/TailIntegrals/InductiveHeisenbergInputs.lean
and lines 1–150 of Formalism/FormalDegreeBessel/StatementG.lean.
The definitions of FormulaF, IW, BAt, Nset, ell, Tz and the matrix form
match the reconstruction. Other source scopes in the companion manifest
are the contributing agent's reads.

The reviewer reran the 387 exact full-matrix and exponent-window controls.
They all passed for revision b49e591fce67be4252f66965b961da32df791e5435bfa7285de4f596eef16d05.
The only later amendment is the explanatory H_r primed-frame sentence
requested in this review; it changes no formula.

The full-group AAt integral, separated matrix coefficient bound and
dominated Jacquet pairing remain distinct assertions. No full transitive
source audit or independent Lean kernel replay is claimed.
