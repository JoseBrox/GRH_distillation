# Weighted unipotent integrability: source correspondence

The manuscript jacquet_unipotent_decay.tex proves the actual BAt assertion,
including FormulaF and isotropic compact orthogonalization IW, in conventional
mathematics. It assumes only the already reconstructed coordinate estimate in
jacquet_kernel_estimates.tex and standard Lebesgue and Haar measure theory.

## Definitions checked

The Hermitian form is linear in its first variable. The recursive spaces have
signature (k+r,r+1), with k>=1, and their coordinate order agrees with Hpk in
Formalism/FormalDegreeBessel/StatementG.lean. The flags use f_0,...,f_(r-1) and
(u_1+u_-)/sqrt(2); the paired flag is obtained by Hpk.

The defining flag conditions on N_r agree exactly with Nset. The negative vector
z lies in the fixed terminal space V_0, corresponding to inWb and Tz>0.
The character lambda=2 Im ell agrees with cStd=-2i and
lam=(cStd*ell).re. No different character or positivity hypothesis is substituted.

## Source proof portions read

Paths below the short prefix TailIntegrals/ mean
ReciprocityTheory/ReductiveGroups/DiscreteSeries/TailIntegrals/.

- InductiveHeisenbergInputs.lean: full file, including actual phiV, phiV',
  Del, s0, xiR, IInt, BAt, IW, and FormulaF definitions.
- StatementG.lean: lines 1-150, including the form, exact matrix indices,
  Nset, character, and fvec definitions.
- Formalism/HermitianCurvature/StatementB.lean: actual lam definition at 135.
- Formalism/HermitianCurvature/WeylElementCommutesLevelOne.lean: 90-165,
  including the Heisenberg formulas, conjugation, and recursive Haar assertion.
- TailIntegrals/DelFormula.lean: 1-225, 229-269, and 451-end. These contain
  the form and orthogonal basis calculations, exact Gram identity, and final
  FormulaF norm identity. The intervening coordinate index proofs are not
  claimed read in full.
- TailIntegrals/IndexEmbeddingBijective.lean: 1-155 and 165-end, including
  the unitary coordinate change, permutation, real shear, and final measure
  preservation. Lines 156-164 are not claimed read.
- TailIntegrals/LevelDeterminantOfTriangularChange.lean: 240-end, including
  the exact lev_data statement and its full proof.
- TailIntegrals/InnerBound.lean: full file, including nonvanishing at rank zero,
  the actual coefficient eta'_0, and all factors in the lower rank estimate.
- TailIntegrals/BStepSuccOf.lean: full file, including the exponent window,
  delta/4 and first-exponent gamma shifts, and Haar induction.

## Independent proof and checks

The manuscript replaces the long component computation of FormulaF by one
column subtraction and the determinant of I+aa*. It proves the compact flag
orthogonalization by Euclidean Gram--Schmidt and separate unitary changes in
the positive and negative eigenspaces of H.

The nonvanishing coefficient is proved explicitly: it is 1 before the last
rank, and a nonzero pairing of an isotropic vector with the negative vector z
at the last rank. The theorem retains that negative norm hypothesis.

check_jacquet_unipotent_decay.py checks full exact rational matrices, rather
than only the abstract norm recurrence. It uses nontrivial compact rotations,
an interchange of isotropic partners, and non-diagonal triangular factors.
The finite checks complement the general proofs; no kernel replay is claimed.

The AAt group integral, matrix coefficient majorant, and final Jacquet
unfolding are distinct subsequent assertions and are not inferred from BAt.
