# Source trace: a direct coarse cohomology bound from algebraic K-theory

Date: 21 November 2026. Fragment: `k_theory_coarse.tex` (330 lines at recording).

## Status and scope

This is an alternative conventional proof of the coarse cohomology input. It does not claim to reconstruct or validate the source-specific assertion SFew. It combines the arithmetic-group homology bound proved in `arithmetic_complex.tex` and `homology_torsion.tex` with explicitly stated classical comparison theorems. It proves exponent 14 for H², and the same bound for the strict Selmer group by the already stated duality consequence. The larger classical theorems are cited inputs, not claimed to be reproved.

The hypotheses include that the number field is totally imaginary and contains the p-th roots of unity. At p=2 the first condition is needed for the cited comparison without real-place modifications. No assumption of fourth roots of unity is used in this alternative. The finiteness of the even K-group is supplied before taking the Hurewicz image in homology torsion.

## Primary references actually inspected

1. Charles Weibel, *The K-book*, chapter IV:
   https://sites.math.rutgers.edu/~weibel/Kbook/Kbook.IV.pdf
   - IV, Corollary 1.14.1: integral homology stability, N at least max(2m+1,m+sr(R)). The chapter's page 11 was read through the extracted text lines 510–615, together with the nearby Borel statements.
   - IV, Theorems 1.17–1.18: Borel's rank theorem, in particular rank zero in positive even degrees for number rings.
   - IV, Theorem 6.9: finite generation of the K-groups of number rings. Extracted text lines 3010–3042 read.
   - The manuscript proves the needed stable-range bound sr(O_L)≤2 directly by Chinese remainders. It uses N=4E+6, safely inside the stated stable range for degree 2E.

2. Weibel, chapter VI:
   https://sites.math.rutgers.edu/~weibel/Kbook/Kbook.VI.pdf
   - VI, Theorem 8.2: the positive even K-group / étale H² comparison on p-primary groups; the p=2 version is used only for totally imaginary fields.
   - VI, Theorem 8.3: the corresponding finite-coefficient statement was also checked as a consistency check, but is not needed to hide any rank loss in the proof.
   - VI, equation (8.1.1): the Brauer local-invariant sequence over O_L[1/p].
   - Extracted text lines 2540–2668 read.
   - The finiteness of K_{2E}(O_L) is taken from the correct statements in chapter IV, not from the informal wording about K-groups in chapter VI's Classical Data paragraph.

3. Akhil Mathew, *Torsion exponents in stable homotopy and the Hurewicz homomorphism*, Algebraic & Geometric Topology 16 (2016), 1025–1041:
   https://msp.org/agt/2016/16-2/agt-v16-n2-p12-s.pdf
   - Theorem 6.3, printed page 1036, PDF page 12: the unstable Hurewicz kernel for a connected infinite-loop space, taking the connectivity parameter m=1.
   - Exact exponents copied into the fragment: at p=2, ceil((j−1)/2)+3; at odd p, ceil((j+2)/(2p−2))+1. At j=2E both are at most E+3.
   - Extracted text lines 68–103 and 532–569 read. The earlier stable formulation was checked as context, but the proof uses Theorem 6.3 directly.
   - The base component of the K-theory infinite-loop space is explicitly identified with the infinite-loop space of the connected cover. No connectivity hypothesis is silently added.

4. J. S. Milne, *Arithmetic Duality Theorems*:
   https://www.jmilne.org/math/Books/ADTnot.pdf
   - II, Proposition 2.9, printed page 170: étale / Galois comparison for locally constant constructible coefficients of invertible order on an affine ring of integers. The statement was read from the PDF page image, not merely inferred from a search snippet.
   - II, Proposition 2.13: finite H¹ for finite coefficients; independently checked by the parent reviewer.
   - The fragment also explains finite H¹ by restriction to a cyclotomic field and the Kummer sequence, then checks the Mittag–Leffler condition before passing to inverse limits.

Local copies of the Weibel and Mathew PDF files and layout-preserving extracted text are in `standard_references/`. The accompanying manifest records their hashes. Milne was read through the official web PDF; no claim of a local PDF copy is made.

## New elementary deductions

- A p-rank bound from the multiplication-by-p exact sequence, Kummer theory, the class group, and the Brauer local-invariant sequence.
- A complete stable-range-two argument for a Dedekind number ring.
- A bound on a subgroup of a finite p-group killed by p^b in terms of its p-rank.
- The Hurewicz comparison with its finite image, followed by the explicit exponent-14 numerical estimate.

No computational test substitutes for these proofs. The isolated XeLaTeX check only verifies typesetting. Parent `/root` independently read the complete proof and the essential primary reference statements and found no defect.

## Later status update (21 November 2026)

The mathematical finite-set comparison SFew is now proved in `selmer_finite_set_bound.tex`, Theorem sw-few, using the independently proved arithmetic cycles and the explicitly classical rational homology inputs in `selmer_homology_count.tex`. It has the improved scalar exponent and implies the original source statement. The earlier modular conditional exponent propositions are retained, with their hypothesis now supplied. This does not retrospectively enlarge this trace's source read scope or certify the original differential-form proof of BOdd.
