# Independent root review of the coarse K-theory bound

Date: 21 November 2026. Reviewer: root.

Read the complete argument and checked the named primary statements directly: Weibel IV 1.14.1, 1.17–1.18, 6.9 and VI 8.2–8.3, (8.1.1); Mathew Theorem 6.3; Milne Arithmetic Duality Theorems II 2.9 and 2.13. The connected infinite-loop hypothesis, stable rank, finite even K-group, integral-ring localization, totally imaginary hypothesis at 2, finite inverse-limit H1, Kummer rank, finite Hurewicz image, exponent E+3, and absorption into exponent 14 all check. Large classical inputs are explicit and their proofs are not claimed as reconstructed. This bypasses SFew for the coarse bound, but is not a verification of SFew itself.

Snapshot SHA256: db3a67d239f688b0dc6530f2aad3ec2ba6654b6443f9dde121fecc9a7bf2a5fc
