# Independent review of the opposite-parity Selmer estimate

Reviewer: /root/formal_degree_review.

Reviewed deliverable: minus_selmer_classical.tex, SHA-256
a99b77f1b3b698346a0753ce724c5b212274a15ee577c94a2b6f700b2373ca05.

**Conclusion: PASS within the explicitly stated classical inputs.**
No mathematical correction is required. The parent subsequently inserted the missing closing math delimiter after (1-j)/2; this is a typographic amendment only, and the reviewed hash above includes it. The proof gives the asserted bound
for every abelian CM field and every odd prime, including primes dividing
the degree of the field. It does not prove the complementary-parity bound,
certify the submitted characterwise proof, or certify the complete GRH
argument.

## Scope and evidence

The complete TeX fragment was read, including the final expansion of the
finite-coefficient Poitou–Tate argument. The review checked the assertions
against the following actual source excerpts:

* Formalism/GaloisCohomology/Statement.lean: all of the file, including
  LData, qzTw, Sha, Sha2Zl, and the local restriction maps.
* Development/AutomorphicArithmetic/AutomorphicVarieties/LengthEqAddEigen.lean:
  lines 1–140, including cAct, ShaPlus, ShaMinus, minusLen, and
  VVminusLe.
* Development/AutomorphicArithmetic/AutomorphicVarieties/PartsSign.lean:
  the complete file.
* Development/AutomorphicArithmetic/AutomorphicVarieties/PartsConj.lean:
  lines 130–180 and 245–275, including the negative twist, action of a
  lift of conjugation, and the local-kernel description.
* Development/AutomorphicArithmetic/AutomorphicVarieties/PrimeSetBoundDataOfPrimitiveChar.lean:
  lines 1–150, including ThmBc, ThmBcFree, and their quantifiers.
* Development/AutomorphicArithmetic/AutomorphicVarieties/StmtFields.lean:
  lines 55–77, including the complete definition of minusBound.

These paths are relative to sources/lean/src. Reading these excerpts
does not amount to checking their transitive dependencies or replaying
Lean's kernel.

The primary Greither–Popescu PDF inspected was
primary_minus/greither_popescu_1103.3069v1.pdf, SHA-256
d1180bc14d03f73e33417d029e222f7a9c3638cf45bc38c46588e03728e4c096.
The review read the conventions at the beginning of §6.2, the finiteness
discussion, Lemma 6.9, Theorem 6.11, and Lemma 6.12 on printed pages
38–40. It did not independently reprove their equivariant main conjecture
or read the whole article. Ferrero–Washington is used as the named
classical theorem, not reproved here.

Milne, *Arithmetic Duality Theorems*, second edition, was independently
consulted at the author's PDF
https://www.jmilne.org/math/Books/ADTnot.pdf: the conventions and
Theorem I.4.10(a), printed pages 55–57, and the explicit cup-product
description of the pairing on printed page 65. Only these relevant
passages, not the entire book, were checked.

## Decisive checks

### 1. The coefficient twist and the eigenspace are the actual ones

The source defines qzTw D e by the character D.chi ^ (-e).
Consequently its coefficient module is
\(\mathbb Q_p/\mathbb Z_p(-e)\), not the positive twist.
LData.hS fixes the local set to the places above \(p\); Sha is the
kernel of restriction at these places. Changing the auxiliary lifts and
algebraic closures gives the usual naturally isomorphic cohomology
objects.

The source defines ShaMinus by the eigenvalue
\((-1)^{e+1}\) for the action which also acts on the coefficient module.
This is precisely \((-1)^m\) for \(m=e+1\). In particular replacing it
by the negative eigenspace independently of \(e\) would be incorrect.
The draft does not make that replacement.

### 2. Poitou–Tate preserves, rather than exchanges, the two signs

For the finite modules
\(A_a=\mathbb Z/p^a(1-m)\) and
\(T_a=\mathbb Z/p^a(m)\), the twists add to one, so these are Cartier
duals. Milne I.4.10(a) pairs their degree-one and degree-two local
restriction kernels. The local invariant of a Brauer class is unchanged
by a field isomorphism. In Milne's explicit formula the pairing is a sum
of such invariants; conjugation merely permutes the terms. The target
therefore has trivial conjugation action.

If \(x\) and \(y\) have eigenvalues \(\alpha,\beta\in\{1,-1\}\), their
pairing satisfies
\(\langle x,y\rangle=\alpha\beta\langle x,y\rangle\). At odd \(p\),
opposite signs pair to zero, and perfectness restricts to a perfect
pairing of the same signs.

The final direct/inverse limit paragraph is valid. Discrete continuous
cohomology commutes with filtered direct limits. There are finitely many
local places, so direct limits commute with the relevant kernels.
Finite global and local finite-coefficient cohomology groups satisfy
the Mittag–Leffler condition; their first derived inverse limits vanish.
Thus compact degree-two cohomology and its restriction kernel are the
required inverse limits. Pontryagin duality gives the asserted
discrete/compact perfect pairing. Since \(E\) is CM, no real-place
correction is present.

### 3. Enlarging the set of allowed ramification gives an injection

For a removed prime \(v\nmid p\), the preceding term in the étale
localization sequence for degree two is
\(H^0(\kappa(v),\mathbb Z_p(m-1))\). It is zero because \(m-1>0\) and
arithmetic Frobenius acts as multiplication by
\((Nv)^{m-1}\ne1\) on a torsion-free rank-one module. This is an
integral assertion, not an assertion that the finite-coefficient
invariants vanish. The draft correctly uses the integral group.
All maps are conjugation equivariant.

### 4. Greither–Popescu applies exactly as stated

For \(E/F\), the group is \(C_2\), \(F\) is totally real, and all real
decomposition involutions are the same \(j\). The field \(E(\mu_p)\)
is abelian over \(\mathbb Q\); the required cyclotomic \(\mu\)-vanishing
is consequently supplied by Ferrero–Washington.

The set \(S\) contains every place ramified in \(E/F\). It need not
contain the places above \(p\): the theorem uses
\(\mathcal O_{E,S}[1/p]\), and Lemma 6.12 explicitly removes any
additional \(p\)-Euler factors by units in \(\mathbb Z_p[C_2]\).
Thus the draft's fixed, \(p\)-independent choice of \(S\) is allowed.

The ring \(\mathbb Z_p[C_2]\) is the product of two copies of
\(\mathbb Z_p\). Projection of the Fitting ideal is legitimate by
base change. Projection of the annihilator of the cyclic torsion
module is \((p^{v_p(w_p)})\) in its only nonzero eigenspace.
The projected ideal equality therefore gives exactly (MS6).
Only division by two occurs; no assumption \(p\nmid n\) has entered.

### 5. Artin factorization and denominators

The trivial and nontrivial characters of \(C_2\), induced to
\(\operatorname{Gal}(E/\mathbb Q)\), are respectively the sums of all
even and all odd characters of that group. Induction of Artin
\(L\)-functions gives the product in (MS5), with all rational primes
dividing \(N\) removed. Using imprimitive characters modulo \(N\)
therefore gives the correct common set of Euler factors.

The selected character set is stable under automorphisms of its
field of values, so the product is rational. Nonvanishing follows
from parity, the functional equation, and the nonzero Euler product
at \(m>1\); the removed factors cannot vanish.

The Bernoulli calculation is correct. In particular multiplication
by \(m(m+1)!N\), rather than by a conductor-free denominator, really
clears \(N^m\) after the factor \(N^{m-1}/m\) in (MS11).
The formal Stirling-number identity supplies the stated denominator
bound. The Fourier estimate includes both endpoints and is valid
for \(m=2\).

The proof sums valuations of the actual nonzero integer
\(I=w_{\mathrm{odd}}D_m^{n/2}R_m\). It does not incorrectly bound the
sum of odd valuations by \(\log|R_m|\), which can be negative.
Thus denominators, including powers of two, have been accounted for.

### 6. Torsion and the numerical constant

For odd \(p\), the group \((\mathbb Z/p^a)^\times\) is cyclic.
An invariant of order \(p^a\) forces the cyclotomic image over \(E\)
to have exponent dividing \(m\), hence order at most \(m\).
Its index is at most \(n\), giving
\(p^{a-1}(p-1)\le nm\) and \(p^a\le3nm/2\).
This proves both finiteness and the estimate for
\(w_{\mathrm{odd}}\). The count of at most \(nm/2\) possible odd
integers uses correctly that \(n\) is even.

The elementary inequalities hold in the smallest permitted cases
\(N=3,m=2\); the factorial bound does not lose a power of \(m\) or
\(N\). The contribution at each \(m\) is at most
\(2nm\log(mN)\), giving
\(n(t^2+t-2)\log(tN)\). Finally
\[
 \frac98t^2-(t^2+t-2)=\frac18(t-4)^2\ge0.
\]
The maximum ratio is attained at \(t=4\), so the displayed \(9/8\)
constant is the correct uniform consequence of this calculation.

With minusBound as actually defined, setting its additional
constant to zero leaves \(3nt^2\log(tN)\). The proved stronger bound
therefore supplies ThmBcFree for the abelian CM composita in the
source.

## Limits of this review

This is an independent mathematical review of the replacement
argument and its stated interface. The classical inputs remain
imported theorems. No assertion is made that the source's distinct
characterwise proof, all of its Lean dependencies, the analytic
complementary-parity estimate, or the complete claimed proof has
been verified.
