# Opposite-parity Selmer groups: independent classical route

The source's negative twist is Qp/Zp(-e). Its ShaMinus is the eigenvalue
(-1)^(e+1) of the strict p-local restriction kernel. Taking m=e+1 matches
the idempotent in Greither--Popescu's Theorem6.11.

The proof applies that theorem to E/E+, whose Galois group has order2.
Every odd prime therefore admits the integral idempotent, even when it
divides [E:Q]. The required cyclotomic mu vanishes by Ferrero--Washington
because the relevant field remains abelian over Q. The S-set contains
the infinite places and the primes over the rational conductor. It need
not separately contain p: the theorem is stated with O_{E,S}[1/p], and
Lemma6.12 checks the omitted p-Euler factors are units.

Finite-coefficient Poitou--Tate duality and exact limits identify the
strict kernel's dual with the degree-two local kernel. Naturality makes
the conjugation sign the same. Localization injects the original H2
into the S-enlarged H2 because H0 of a finite residue field with
Zp(m-1) coefficients is zero. This is a subgroup comparison, not an
unjustified equality of the two cohomology groups.

The rational product of n/2 imprimitive Dirichlet values is cleared by
[m(m+1)!N]^(n/2). The proof of that denominator bound uses the integer
Stirling-number formula for Bernoulli numbers. Higher roots of unity
are bounded directly using the cyclic group (Z/p^a)^times at odd p.
An actual nonzero integer controls the sum of odd valuations, retaining
possible denominators at2. The resulting bound is
n(t^2+t-2)log(tN) <= (9/8)n t^2 log(tN).

This proves the full mathematical estimate requested by ThmBcFree with
its extra constant C=0, using named established classical theorems.
It does not certify the submitted characterwise proof or the
complementary parity, and is not a Lean kernel verification.
The exact finite computation checks special-value denominators and
higher roots in imaginary quadratic fields; it does not compute Selmer
groups or serve as a proof of the imported theorem.
