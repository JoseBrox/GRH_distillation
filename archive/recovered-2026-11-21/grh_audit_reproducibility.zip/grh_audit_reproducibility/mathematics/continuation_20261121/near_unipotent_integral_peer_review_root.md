# Independent review of the near-unipotent integral

Reviewed by the root agent on 2026-11-21. The entire mathematical proof
was read. Reviewed SHA-256:
8d5bee8d8a9676c721f4ec7249cb92fbbd3513fdbc06592daa2a13e86e1b2ac7.

The canonical minimum submodule is chosen with maximal rank. The strict
inequality for the minimum of the quotient proves its uniqueness and
the strict increase of the successive sizes. The isotropy and duality
arguments give the asserted self-dual quotient and final minimum at
least one half. A sufficiently small integral automorphism preserves
the resulting flag and induces the identity on every graded piece.
Thus it belongs to the actual unipotent radical; this step is not a
count of arbitrary matrices near the identity.

For the packing estimate, the independent blocks, real dimensions, and
separation scales were checked individually. If two matrices agree at
lower heights, their difference at the first nonzero height induces an
integral map on the graded lattices even when the orthogonal splitting
is not rational. The adjoint relation determines the paired blocks.
The skew-adjoint diagonal block has real dimension j_i^2, not twice that
dimension. The resulting total dimension and all exponents telescope
to the stated layer product.

Iterated unfolding counts all primitive isotropic flags and so is a
valid upper bound for the canonical flags. The quotient measure is the
probability measure used in the rare-cusp calculation. Its constants
telescope exactly. The pointwise cancellation between the radial density
and the layer product leaves the uniform factor bounded by e. The
ordered logarithmic integration region is bounded by its enclosing box;
the assumptions on g, b, f, r_E and n imply the claimed logarithmic
bound. Summing the 2^(J-1) possible compositions gives the stated
exp(-nf log(n)/4) estimate. The compact case q=0 is separate and valid.

The root read the actual NearNonzeroTerms.lean target and the needed
LayerProd and class-number definitions. The previously proved
near-identity unipotence theorem is required to apply this count to the
singular-value condition; that dependency is explicit. The finite
control script was independently rerun, with its full result retained
in the checks JSON. No counterexample or missing inequality was found.
This review does not settle the separate deep-cusp estimate and does not
claim a complete independent kernel replay.
