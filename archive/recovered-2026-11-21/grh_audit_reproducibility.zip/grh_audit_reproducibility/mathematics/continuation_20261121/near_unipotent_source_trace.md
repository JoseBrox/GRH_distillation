# Source trace: integrated near-unipotent contribution

Fragment: near_unipotent_integral.tex.
Frozen SHA-256:
8d5bee8d8a9676c721f4ec7249cb92fbbd3513fdbc06592daa2a13e86e1b2ac7.

## Mathematical scope

The fragment proves the actual integrated near contribution required by
the ambient comparison. It uses the conventional lattice sizes and
map-separation proof already written in ambient_multiplicity.tex, and
the single-sublattice unfolding with its explicitly named classical
inputs in rare_cusp_volume.tex. It does not assume the source's full
flag measure bound, its near-point count, or its NearModerate result.

The unique maximal-rank minimum sublattice is constructed directly.
Iteration in self-dual quotients produces a canonical isotropic flag.
For small integral isometries, the first different matrix block is an
integral map on the associated graded. The geometric-mean separation
bound and real normed-space packing then give the product estimate.
This uses the ordinary upper block filtration, including the
skew-Hermitian diagonal blocks of the radical.

The unrestricted flag measure is obtained by repeating the already
proved single-sublattice disintegration. Its coefficient and its radial
density are explicitly identified with kapBd and dens. The proof
then integrates over the truncated size region and sums over all
compositions. Its explicit sufficient large-rank hypotheses are
log n >= 20 and n >= 4 log(Cg+3); these imply the existential
large-rank threshold in NearModerate.

## Exact source correspondence

The relative source root is
sources/lean/src/Development/AbelianVarietyTheory.

* Definitions/SemilocalFrames/LayerProd.lean:
  layerProd, least, nearSet, CountHyp, epN, tauStar and the actual
  definitions of finite-level support and archimedean distances.
  Read in full for this continuation.
* Definitions/SemilocalFrames/DefClassNum.lean:
  dimN, kapBd, dens and simplexH. Read in full.
* BlockTheory/SiegelWeilLocal/NearNonzeroTerms.lean:
  moderate, nearAbs, nearBound and the full NearModerate quantifiers.
  Read in full.
* Statements/CuspFrameWeights/SameKindIsometric.lean:
  lines 95--114, the FlagMeasureBound and ConstantBound interfaces.
  The prior rare-cusp manifest also records its wider reading.
* Statements/CuspFrameWeights/ConvolutionSmoothL2.lean:
  lines 136--145, the actual NearUnip statement, including
  delta=3 sqrt(n ep), finite integrality and delta<1/4.
* Proofs/FlagMeasures/OneTypeArith.lean:
  read in full. This was used to compare the source's final
  composition summation and quantifiers; its proof is not imported.
* Proofs/FlagMeasures/CanonicalFlagExistsUniqueSemistable.lean:
  lines 1--90 only in this continuation. This is contextual source
  reading, not a claim to have audited the complete canonical-flag
  dependency tree.

The output does not require proving that its directly constructed
flag equals every formal representation of the source's stepLe
filtration. It proves the original near-count conclusion independently.
The precise final near-set conversion is the previously proved
ambient near-unipotence proposition, not a replacement by an
arbitrary small-distance assertion.

## Verification and limitations

The root independently read all 692 lines and reported mathematical
PASS at the frozen hash, including the quotient-size argument,
integral block maps, repeated disintegration and numerical absorption.
The root's written review is linked in the manifest when present.

check_near_unipotent_constants.py passes 12,829 exact assertions.
The finite ranges and each assertion family are recorded in
near_unipotent_constants_checks.json. These controls check
telescoping exponents and exact small matrix relations; they are
not substitutes for the mathematical proof.

The standalone XeLaTeX wrapper compiles twice to seven pages.
Only references to other manuscript fragments remain unresolved
in the standalone wrapper. No full Lean kernel replay, complete
transitive dependency reading, or deep-cusp mass proof is claimed.
