# Independent review: dyadic summation for the degenerate orbital integral

Reviewer: /root/ordinary_theta_completion.

## Verdict and frozen manuscript

PASS for the ordinary mathematical theorem, its recovery of the exact submitted summation bound, and the counterexample obtained by deleting the determinant–size hypothesis.

- Manuscript: work/continuation_20261121/orbital_dyadic_summation.tex.
- Final SHA256: 275c15adf1cc48996ee53b73a795713f5f02f8c6ad9230476ac38e4a25aa6967.
- All manuscript mathematics was read independently. Two missing \quad backslashes and the scope wording for the reciprocal determinant bound were reported to root and corrected before this final hash. They were not mathematical objections.

## Source comparison actually performed

The following submitted files were read in full:

- sources/lean/src/Development/AbelianVarietyTheory/Proofs/FlagMeasures/DyadicSummationWithDecay.lean (241 lines).
- sources/lean/src/Development/AbelianVarietyTheory/Proofs/FlagMeasures/DyadicSummationWithDecayStatement.lean (the full wrapper statement and proof).

The source hypotheses explicitly include D <= (S*S')^r, the product condition Y*Y'*D <= 2^j, the separate size upper bounds, the sigma bound and both one-sided square-integral estimates. Its original exponent is q−e−4r−1 and its factor is 16. The reconstruction retains all these hypotheses and proves the claimed stronger result; the source wrapper is recovered at exactly its stated range q≥e+4r+2. The proof does not infer any of the geometric hypotheses from the summation argument.

## Decisive calculations checked

On the shell indexed by i,i', u=2^(i+i') and R=2Hu give S*S' <= u(2H)^2 and sigma<=u^r. The upper bound for max(S,S') is R, so each positive Y,Y' lies in exactly one downward dyadic interval. The use of closed upper and open lower endpoints makes the intervals disjoint, including values on boundaries.

For each nonempty piece, w=yy'=M^2*2^(−a−b−2) is at most N=2^j/D. The determinant–size condition gives N^(−1)<=2^(−j)u^r(2H)^(2r). Hence, for every real m≥1,

w^m <= N^(m−1) w <= N^m 2^(−j−2)(2H)^(4r)u^(3r)Delta^2 2^(−a−b).

Cauchy–Schwarz contributes R^e u^(−q). Setting n=q−e−3r−1 leaves u^(−1−n), and u^(−n)<=sigma^(−n/r) also when n=0. The four remaining geometric sums equal 16; their factor changes 2^(−j−2) into 4*2^(−j). Thus the improved exponent and constant are exact. Finite local square integrals justify Cauchy–Schwarz, and countable monotone summation needs no local compactness or finite-measure assumption.

The original bound has one less power of sigma^(−1) and a constant larger by 4*2^j. Both comparisons use only sigma≥1 and j≥0.

## Counterexample check

For L≥512, the specified Y and Y' are reciprocal finite strings of distinct powers of two with product N. Every interval (y,2y] contains at most one of those powers, so A=Y/2 and B=Y'/2 satisfy the full one-sided inequalities for every y>0; the i≥1 shells are empty. The remaining size and sigma conditions hold exactly.

The normalized integral is (2L+1)/4. At L=512 it is 1025/4, strictly greater than the normalized proposed upper bound 256. Therefore deleting only D<=(S*S')^r makes the original assertion false. The example satisfies the source's integer and exponent restrictions, including q=6=e+4r+2. It is explicitly not a counterexample to the submitted theorem, which retains the missing condition.

## Limits

This review does not verify the geometric Gram-determinant or one-sided orbital estimates which must be supplied before applying the theorem. It is not a Lean kernel replay. No substantive flaw in the reviewed summation was found.
