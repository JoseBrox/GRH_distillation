# Dyadic summation for a degenerate orbital integral

The manuscript `orbital_dyadic_summation.tex` gives an independent proof
with a smaller constant, one extra power of decay, and real exponents
m >= 1 and q >= e + 3r + 1. The original statement follows as a corollary.

## Submitted source inspected

Root and the independent reviewer both read in full:

- `Development/AbelianVarietyTheory/Proofs/FlagMeasures/DyadicSummationWithDecay.lean`
- `Development/AbelianVarietyTheory/Proofs/FlagMeasures/DyadicSummationWithDecayStatement.lean`

Paths are relative to `sources/lean/src`. The source explicitly includes
all four geometric inequalities in (OD2), including D <= (S S')^r,
and the two one-sided square-integral estimates. The source's conclusion
has constant 16 and exponent (q-e-4r-1)/r. Its hypotheses require
q >= e+4r+2, so the stronger theorem applies to its full stated range.

The application is visible in the first 220 lines of
`AmplitudeDegenerateOperatorNormLeRealPlace.lean` in the same directory,
which root read. There m = k-1-j and e = 16r^3. These parameters and the
definitions of the Gram ratios and size functions motivate the final
paragraph of the manuscript; their geometric and representation-theoretic
estimates are not inferred from dyadic summation.

## Important checks

The product estimate is S S' <= 2^(i+i') (2H)^2, with only one power of
2^(i+i'). The proof retains that power and the factor 2^(-j) in D/2^j.
The four disjoint dyadic partitions give four geometric sums of value 2.
The endpoint q = e+3r+1 is valid because the residual exponent is zero.

The example with L=512 disproves only the assertion with the
determinant--size hypothesis removed. It satisfies every other stated
hypothesis, for all real shell parameters y > 0. Its normalized integral
is 1025/4 > 256. This is an exact finite calculation proved in the text,
not a floating-point experiment, and not a counterexample to the submitted
theorem. No separate numerical test is needed for this comparison.

## Scope

This closes the final measure-theoretic summation once the geometric
one-sided inputs have been supplied. It does not prove those inputs,
the global lattice count, or the full degenerate amplitude estimate.
The independent review is `orbital_dyadic_summation_peer_review_theta.md`.
