# Independent review of ordinary moments and CM theta laws

Reviewed artifacts and SHA256:

- ordinary_theta_moments.tex: d82f0f56210dee239f55cfd95ada3d9c8e286af7f364efcb9a40811971c69d0a
- cm_theta_integrality.tex: 2b11abf1ea65b5f526fd3caee040bccbfefc28e099862f2f510cc26838a52716

The root reviewer read both complete mathematical fragments, including the final exposition changes. The ordinary moment proof was checked in two consecutive continuation contexts: its first 180 lines in the previous context, and all remaining lines in this one. The complete CM section was read in this context.

The checked arguments include multivariable Mahler expansion and the binomial-moment boundedness criterion, the formal logarithm substitution, tensor-power descent, the integral functional-equation recurrence, and the bounded elliptic quotient argument. The power-moment counterexample uses the binomial polynomial with index p^a for arbitrarily large a, as required to prove unboundedness.

For the CM section, the review verified the even theta semicharacter and zero divisor, the discriminant-normalized common period, the unit minor proving saturated global expansions over arbitrary C_p coefficients, and integral preservation by torsion line-bundle lifts. It checked the connected torsion character and the complete elliptic-quotient proof of the exact selected p-power translation, including the sign e^(pi i |y|^2). The two requested clarifications were incorporated: the abstract field embedding is fixed throughout, and the multiplicative formal coordinate need not be defined over a finite extension of Q_p.

The root independently retrieved Bannai--Kobayashi arXiv math/0610163v4 and read Proposition 2.15 and Corollary 2.16(i), with their displayed hypotheses and statements. The source author also verified Lemma 2.7 and Section 3.1 as recorded in the companion manifest; this record does not imply a new review of all proofs of that classical paper.

Independent exact source comparison covered all of ThetaLawsUnitPeriod.lean and lines 1--145 of CmLatticeCommutatorPairingPowEqOneOfGoodLift.lean, including IsTh, Good, MChart, all three ThetaLaws, and the precise discriminant and period scaling. The ordinary proofs match those three laws at the actual large split primes p>=5. They do not claim the source's separate p=2 or p=3 cases from the cited elliptic theorem.

Status: passed. The existence and integral theory of a good ordinary CM model are explicitly imported classical results. The higher-dimensional normalized theta identity, its unit scalar, actual column-kernel support, and incidence are separate obligations; no conclusion about these is inferred merely from one-dimensional theta laws. This review is mathematical and source-statement review, not a Lean kernel replay.
