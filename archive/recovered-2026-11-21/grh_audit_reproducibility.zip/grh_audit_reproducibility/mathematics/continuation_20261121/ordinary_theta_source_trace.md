# Ordinary theta moments and the classical CM normalization

## Scope

The fragment ordinary_theta_moments.tex proves the multivariable Mahler theorem,
the exact bounded-measure criterion, its formal logarithmic form, descent from
arbitrary positive tensor powers, an integral functional equation, and the
bounded elliptic-quotient step. It distinguishes these statements from existence
of the geometric CM model. The counterexamples concern false weakenings:
bounded power moments, noninvertible linear substitution, lack of contraction,
lack of a bounded reciprocal, and the two-adic torsion exception.

The fragment cm_theta_integrality.tex matches the actual even theta function to
a translated reduced odd theta function. It imports the stated classical
ordinary CM integrality theorem, fixes one abstract field embedding, and proves
the discriminant-normalized unit period, integrality of every prime-to-p
translate, norm preservation for arbitrary finite linear combinations,
normalization of the connected torsion character and the exact selected
p-power translation phase. All of this is at p >= 5.

## Primary reference

Bannai--Kobayashi, arXiv:math/0610163v4, is the version used. Proposition 2.15 and
Corollary 2.16(i), printed pp.28-29, are the translated reduced-theta integrality
input; Lemma 2.7, printed p.24, identifies the exact exponential in Mumford
translation; section 3.1, printed pp.35-36, gives the integral formal group
isomorphism and its unit period. These statements were opened directly and
compared with the fragment. This does not claim a fresh audit of all proofs in
the 55-page reference. The downloaded PDF's exact digest is in the manifest;
the source is cited with version and published DOI in ordinary_theta_references.tex.

The formal coordinate may require a completed unramified extension or O_Cp.
The finite valuation ring used in the global-section argument is only the ring
over which the good model and a finite collection of its line bundles and
torsion points are defined. Arbitrary Cp coefficients are covered by an integral
unit minor in the coefficient matrix of a finite section basis.

## Comparison with the submitted source

The definitions IsTh, U1, W1, Good, and ThetaLaws appear in
Definitions/Jets/CmLatticeCommutatorPairingPowEqOneOfGoodLift.lean.
The three theta laws require respectively all prime-to-p translated integral
series, the exact good-lift Weyl-translation identity, and preservation of every
common bound on a finite linear combination of theta powers. These are the
three assertions established in the CM fragment, with the original stronger
conjugate divisibility p^(2n) retained.

The conventional phase computation in CT26--CT31 uses a CM element epsilon
which is even, is one at the chosen prime modulo p^n, and zero at its conjugate.
It proves that epsilon*y - y is integral, bar(epsilon)*y is in twice the lattice,
and the phase differs from norm(y) by an even integer. The resulting factor is
exactly exp(pi*i*norm(y)); it is not replaced by an arbitrary root of unity.
The script check_cm_theta_phase.py verifies these arithmetic identities over
rational numbers for finitely many explicit split-prime examples. The
mathematical proof, rather than the finite controls, establishes the general
identity.

LawsAndChart.lean and ThetaLawsUnitPeriod.lean assemble the matching period
normalization. WeilOperatorThetaTranslateShiftPrimeToQ.lean uses the scaled
elliptic quotient for general prime-to-p translates, which agrees with the
route in CT32--CT33. CmEvenThetaSeriesChartCoeffIntegral.lean uses the same
contractive functional equation as the one proved in the OT fragment.

The full source route to lattice moments is not silently absorbed into this
one-dimensional theorem. CmThetaBaseVectorTranslatesIntegral.lean invokes a
fourth tensor identity, a locally standard rational isometry, and the unit
normalization of its scalar. NormalizedVectorTranslatesPrimeOrderIntegral.lean
then uses two finite lattice translation sums and rational unitary
approximation. The outer UnitPeriodTranslatesMomentsFinite.lean also uses
algebraic Taylor coefficients and the actual good-lift/support identities.
These remain separate reconstruction steps. Source read intervals are
conservatively recorded in ordinary_theta_source_manifest.json; imported
provider names alone are not counted as proofs of their content.

## Verification

Root read the complete OT and CM mathematical fragments and requested two
exposition clarifications concerning the field embedding and the field of
definition of the formal chart; both are applied. The combined 14-page wrapper
output/ordinary_theta_check.pdf compiles with two XeLaTeX passes. It has no
undefined references or citations, overfull boxes, or missing glyphs. The
fragment has not yet been counted as a full Lean replay or an exhaustive audit
of all its transitive source dependencies.
