# Independent review of integral initial-minor spanning

Date: 2026-11-21. Reviewer: qrh_mathematics.

I read all 299 lines of `polynomial_minor_spanning.tex`, SHA256 `f68a3183d76771f2828df37ff8fd427739292bd95a4e6f5bdf07a01e163cc8b6`. No mathematical defect was found. In particular, this proof supplies the integral spanning input used by `integral_branching.tex` over every characteristic-zero coefficient domain needed in the arithmetic construction.

## Delicate steps checked

The monomial factorial form gives E*=F with the correct coefficients. On V_(h+2), EF-FE=H gives ||Fv||^2=||Ev||^2+(h+2)||v||^2, so F is injective and E on V_h is onto. The resulting kernel dimension difference is valid for h>=0, including absent weight spaces and zero total degrees.

The Laurent character product coefficient is exactly 1+min(a,b,t,a+b-t) in its stated range. Iteration counts paths beta_i<=min(d_i,h_(i-1)); the coefficient difference selects exactly paths ending at h. Rearranging h_(i-1) proves that these path restrictions are exactly the displayed ballot inequalities, not a weaker condition.

In the bracket construction, each replacement of an unpaired x_j preserves its leading x_j and adds the required leading y_i, since j<i. Later replacements preserve all earlier leading x exponents. Thus the final row degrees and leading exponent array are exactly the prescribed ones. Every bracket and remaining x factor is killed by E. Distinct arrays give distinct monic leading terms, so the greatest participating leading monomial in any nonzero linear combination cannot cancel. Comparing their number to the dimension proves the leading-term lemma for every kernel vector. Extension to any characteristic-zero field preserves matrix rank.

For several columns, the derivative E_j preserves the monomial in all other columns and every combined two-column row degree d_i. Therefore it kills each such component separately; the component containing the global leading monomial has the correct two-column leading monomial after removing the fixed outside factor. Column homogeneity makes its weight mu_j-mu_(j+1)>=0. No cancellation across components is possible.

Sorting row-index lists and using the strict ballot bound gives w_j(t)<w_(j+1)(t). The resulting initial-column minors have exactly the specified height multiplicities. In the chosen column-first lexicographic order the determinant diagonal is monic and greatest. The iterative subtraction of the leading coefficient times this product stays in the invariant module and terminates in the finite set of fixed-column-degree monomials. No inversion of an integer or a coefficient is used.

The empty product and zero parts are handled. The positive-characteristic derivative counterexample y^p is correct; the theorem explicitly does not infer the stronger arbitrary-characteristic source statement from the characteristic-zero argument. All actual coefficient fields and discrete valuation domains here have characteristic zero, even at primes above 2 or other small primes.

This is a conventional proof review, not a transitive source-import audit or fresh Lean kernel certification.
