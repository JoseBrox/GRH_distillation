# Review of integral spanning by initial-column minors

Reviewer: root. Date: 21 November 2026.

The entire fragment was read. No mathematical defect was found.

The Fock adjoint relation E*=F and [E,F]=H give surjectivity E:V_h -> V_(h+2) exactly in the stated range h>=0. The rational rank is unchanged by complexification. The elementary character-product identity has the displayed coefficient count, and its iterated paths are precisely the exponent arrays satisfying the prefix inequalities. The construction pairs each new y_i with an available earlier x_j. Replacing that unpaired factor by x_j y_i-x_i y_j preserves all prior leading x exponents and creates the required y exponent. Every resulting product is monic for the stated column-major lexicographic order.

Distinct admissible leading monomials give linearly independent kernel elements; their number equals the computed kernel dimension. Consequently every kernel element has an admissible leading monomial. For several columns, fixing the other-column monomial and each adjacent row-pair degree is legitimate because the differential operator preserves those data. The component containing the leading monomial retains the same restricted order. Sorting its column lists and matching equal positions produces strictly increasing row sequences, exactly by the prefix inequalities.

The product of the corresponding initial-column minors has the original leading monomial with coefficient one. Subtracting its coefficient decreases that monomial within a finite set, so the procedure terminates without division. Extension to any characteristic-zero domain follows from its fraction field and the unchanged rank of rational matrices. No positive-characteristic differentiation argument is asserted; the displayed y^p example correctly marks that limitation. All application coefficient domains have characteristic zero.

This supplies the previously pending input sm-initial-minors in the integral branching proof. It is a mathematical replacement proof, not a full reading of the source's stronger arbitrary-characteristic theorem.
