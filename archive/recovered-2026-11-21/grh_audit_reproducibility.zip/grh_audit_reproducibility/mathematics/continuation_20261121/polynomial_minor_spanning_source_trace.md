# Source trace: integral spanning by products of initial minors

Date: 21 November 2026. Fragment: `polynomial_minor_spanning.tex`.

## Exact assertion proved

For an N by r matrix, N≥r≥1, and a partition μ of nonnegative column degrees, define ∇μ(R) by those column degrees and invariance, as polynomial identities in t, under adding t times an earlier column to a later column. Theorem `sm-initial-minors` proves that ∇μ(Z) is spanned over Z by products of initial-column minors with exactly μ_s−μ_(s+1) factors of height s. It also proves the same assertion for every characteristic-zero integral domain R, using the identical integral generators. Empty weight and zero parts are included; no columns gives constants and the empty product.

The definitions match `dualWeyl`, `colAddGen`, `initMinor`, `bideterminant`, and `shapeDeg` in the source. The column-major lexicographic order agrees with `colLex`; the displayed prefix inequality is exactly `InterlacedAt 0` for consecutive columns. The shape condition fixes the number of factors of each positive height. Height-zero source factors are 1 and can be discarded. The exact integral assertion is `StandardMonomialSpan` in StatementA, restricted to the matrix dimensions used here. The source's stronger `StandardMonomialSpanDomain` and `SSBasis` assertions allow arbitrary domains and characteristic; this reconstruction does not claim that additional scope.

## Ordinary proof and source relation

The replacement two-column proof uses only finite-dimensional linear algebra. Over Q, a diagonal factorial inner product after complexification makes E=sum x_i∂/∂y_i adjoint to F=sum y_i∂/∂x_i. The commutator gives surjectivity of E from weight h to h+2 for h≥0. The kernel dimension is therefore the difference of two weight multiplicities. The elementary Laurent-polynomial identity χ_aχ_b=sum_(0≤s≤min(a,b))χ_(a+b−2s) counts this difference by the same exponent arrays as the source's prefix inequalities. One monic product of brackets x_j y_i−x_i y_j (j<i) and unpaired x variables is constructed per array. The distinct leading monomials prove independence and therefore a basis of the rational kernel. Matrix rank is unchanged in any characteristic-zero field.

The subsequent argument follows the mathematical structure of `LeadInterlaced` and `SSBasis`, with a direct sorted-list construction replacing recursive tableau peeling. Differentiation of the source's full polynomial identity gives the adjacent-column operator; its invariant components fix all other-column monomials and the two-column degree in each row. The two-column lemma applies to the component containing the leading monomial. Sorting the row labels in each column then gives a product of initial minors with that leading monomial and coefficient 1. Repeated monic subtraction terminates because the prescribed column degrees permit only finitely many monomials. No factorial, hook-length, determinant, or scalar is inverted in the integral subtraction. No classical representation-theoretic spanning or decomposition theorem is imported.

## Source text actually read for this fragment

Paths are relative to `sources/lean/src/Formalism/GradedWeylDivisibility/`.

| File | Read scope | Role |
|---|---|---|
| `StatementA.lean` | Lines 1–110 and 218–237 | Exact polynomial actions and integral module; initial minors and their shape degrees; exact integral spanning target. |
| `StatementC.lean` | Complete, 160 lines | Column-major order, prefix inequalities, leading-term and two-column assertions, and spanning assembly statements. |
| `StatementD.lean` | Lines 1–75 | Exact `SSBasis` claim, including arbitrary-domain scope and monic leading terms; lattice transport declarations are read only for context. |
| `FockSpaceTableaux/TwoColumn.lean` | Complete, 215 lines | Source proof from the four peeling inputs, including the degree-in-t bound. The auxiliary peeling files were not reread for this replacement proof. |
| `FockSpaceTableaux/LeadInterlaced.lean` | Complete, 64 lines | Full polynomial invariance gives degree zero in t; extraction of the component containing the leading monomial. |
| `FockSpaceTableaux/SSYTExists.lean` | Complete, 64 lines | Source recursive construction of a product of minors; replaced here by sorted row lists. |
| `FockSpaceTableaux/SSBasis.lean` | Complete, 69 lines | Monic leading-term cancellation and basis assembly. |
| `FockSpaceTableaux/BideterminantMem.lean` | Complete | Product membership and shape degree. Its imported determinant lemmas were not reread in this phase; their needed fact is proved directly in the fragment. |
| `FockSpaceTableaux/ColLexInitMinor.lean` | Complete | Determinant expansion and diagonal leading coefficient one. Its auxiliary permutation-order assertion is proved directly in the fragment. |
| `FockSpaceTableaux/ColumnLexBideterminant.lean` | Complete | Multiplication of monic leading terms. |
| `FockSpaceTableaux/SMSAssembly.lean` | Complete | Exact source spanning induction from the intermediate assertions. |
| `FockSpaceTableaux/StandardMonomialSpanOf.lean` | Complete | Specialization from arbitrary domains to Z. |

The definition subsection of `coefficient_duality.tex` was also reread. The source files' hashes, lengths and exact intervals are recorded in the manifest. Reading an import line is not counted as reading its transitive dependency, and no source compilation or export recheck was performed.

## Adversarial checks and limits

The proof retains h=μ_j−μ_(j+1)≥0 exactly where the adjoint injectivity is used. Empty weight, zero row degrees, a vanishing target weight space, and a characteristic-zero coefficient domain with nonunits are all covered. Brackets pair only earlier row indices j<i, so their asserted leading term has the correct sign and coefficient. A fixed monomial in the other columns prevents cancellation between distinct components. Distinct leading monomials prevent cancellation in the dimension argument. Integrality comes from leading coefficient one, not from the rational kernel calculation alone.

The full polynomial-in-t identity is essential to the source's meaning. In characteristic p, the polynomial y^p is killed by x∂/∂y but is not invariant under y↦y+tx. This is a counterexample to replacing the source's definition by infinitesimal invariance in characteristic p, not a counterexample to the source theorem. The present proof explicitly restricts its replacement argument to characteristic zero. It does not prove a basis theorem in positive characteristic, arbitrary-ring base change, or any branching denominator identity by itself.

No counterexample satisfying the actual hypotheses of the proved integral assertion was found. The parent independently read the complete fragment and confirmed the dimension count, component extraction, sorted-row construction and integral subtraction. A separate peer-review record is maintained by the parent.

The qrh_mathematics agent independently reviewed all 299 lines of the final fragment and reported no defect. Its detailed record is `polynomial_minor_spanning_peer_review_qrh.md`. The standalone XeLaTeX check completed twice with exit code zero, four pages and no overfull boxes; this checks typesetting, not mathematical truth.
