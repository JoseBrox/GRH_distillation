# Selected quadratic characters: source trace and independent reconstruction

Date: 21 November 2026. All source paths below are relative to
`sources/lean/src/`. This is a scoped continuation of the audit, not an
exhaustive certification of the original archive or the QRH papers.

The mathematical deliverable is `quadratic_selection.tex`. It contains no
Lean proof text. Its simultaneous-selection theorem is explicitly conditional
on zero-freeness of every primitive Dirichlet L-function in Re(s)>11/12,
with the principal pole at 1 allowed. That is the exact October QRH conclusion;
the underlying QRH proof has not been completely reconstructed in this review.

## 1. Correction to the earlier description of the target family

There are two different requirements.

1. `Formalism/SizeWindowBrackets/GrowthBoundGivesRiemannHypothesis.lean`,
   definition `ValuesAtX`, concerns three additive characters: `psC`, `chC`,
   and `chpsC`. Their ordinary Dirichlet characters are chi_q, chi_d and
   chi_q chi_d. The correspondence is stated in `HostQuadChars` and
   `ValuesIff` in `SmoothedRemainderRealIntegralFormula.lean`.
2. The full Dirichlet-GRH route is larger. In
   `Development/AutomorphicArithmetic/PrimitiveCosets/SigALe.lean`,
   `sigA_le` sums over `PsiA \ keptA`. The number of characters is at most
   4o. Each bound is obtained from `EAtH.bdG`, not from `ValuesAtX` alone.
   `charsA.lean` uses the corresponding `EAtH.bdL` bounds. `CoreGm.lean`
   uses both facts to remove this bounded family while retaining the fixed
   character family that occurs in the final one-sided analytic sum.

Thus references to just “three selected quadratic-character sums” describe
the RH subcase, not the entire Dirichlet-GRH construction. The revised
QRH contribution and new section state this distinction explicitly.

## 2. Exact reduction to fixed characters and two new quadratic characters

`Formalism/SharpRestriction/RamificationFrobenius/TotientGaloisClasses/Analytic.lean`:

- `HostRaw.Bounded` consists of characters trivial on the indicated first
  factor, excluding kept characters in the plus part and including the minus
  part.
- `HostRaw.BoundedCharsPointwise` asks for the actual primitive character
  attached to each such group character and a bound
  |gChi(chi,x)| <= x^(1/2+eps).
- `An.gChi` treats the principal character separately. For a nonprincipal
  character it equals the smoothed von Mangoldt sum plus x L'/L(1).
- `An.Induces.unique` proves uniqueness of a primitive character from its
  values on integers coprime to a nonzero comparison modulus.

`.../ExplicitFormulaErrorOfHostConditions.lean`, structure `EAtH`, has six
fields: the order equality, inclusion of kept characters, the exceptional
character condition, shares of the chosen set, `bdG`, and `bdL`.

`Development/AutomorphicArithmetic/CharacterBoxes/BoundedTw.lean`:

- `boundedTw_key` uses `TwistForm` to express any bounded primitive character
  as the primitive character induced by xi(n)(n/q)^i(n/d)^j, where xi is a
  fixed-modulus character and (i,j) is not (0,0).
- The nonzero pair follows from the definition of kept characters in the
  plus part and the sign at the distinguished involution in the minus part.
- The modulus conditions `psi.N | H.QS` and “every prime dividing H.QS
  divides 2*psi.N” are used to transfer agreement on units. They are not
  decorative assumptions.
- `boundedTw` then reads the uniform bounds directly from `PairGood`, with
  the exponent eps/2 weakened to eps at the current scale.

`Development/AutomorphicArithmetic/CharacterBoxes/PairGood.lean`:

- For every fixed positive M, eps in (0,1/52), and A>=1, `PairEx` asks for
  q,d and `PairGood M eps Y (Y^A) q d` for every sufficiently large Y.
- q has logarithm in (Y^(eps/5)/2,Y^(eps/5)], q=3 mod8.
- d has logarithm in
  (Y^(eps/5)(log Y)^2/2,Y^(eps/5)(log Y)^2], d=7 mod16.
- q and every odd prime <=Y^(eps/5) divide d+1; qd is coprime to M.
- For every Dirichlet character xi modulo M, and (i,j) in {(1,0),(0,1),(1,1)},
  every primitive inducer has |gChi(chi,y)|<=y^(1/2+eps/2) and
  |L'/L(1,chi)|<=4log y throughout Y<=y<=Y^A.
- The real primitive characters of conductor dividing 8M, with the same
  quadratic twists, must have no zeros in Re(s)>399/400 up to the specified
  conductor-sized height.

The integer-valued expression `tw` omits factors with exponent zero. The
new TeX states this convention explicitly, rather than using principal
characters at unnecessarily enlarged moduli. It also states the exact
Euler-factor correction for the centered sum of an imprimitive character.

`Development/AutomorphicArithmetic/ShortNorms/supplyOfAdmOf.lean` reads
`QH.pairEx` through `winPairs`, constructs the field/host, and finally calls
`boundedTw` to supply the last two fields of `EAtH`. This shows that an
existence theorem for `PairGood` is sufficient at this point. A replacement
need not reproduce the source's unweighted positive-density statement.

## 3. The source's actual selection argument

The relevant files are in
`Development/AutomorphicArithmetic/MeanSquareBounds/`.

- `PrimeSetTwoBounds.lean` defines the finite sum S with coefficient
  Lambda(n) min(1,y/n), the mean-square property uniform over *every bounded*
  sequence kappa, the finite zero-free box, and the first and second prime
  sets. The mean-square property does not require multiplicativity of kappa.
- `twistK.lean` obtains uniform small quadratic correlations in the prime
  progression for every odd squarefree s up to a fixed power of Y, with at
  most one exceptional s. It uses the source's relative prime number theorem
  in progressions, the usual zero-free region, and an across-moduli Page
  argument. Its target correlation is Y^(-B) times the prime count.
- `MeanSqAbs.lean` groups prime powers by their outside squarefree part.
  It retains a forced part R from even powers and the prime factors of the
  progression modulus. It allows one exceptional correlation, costing at
  most 2B^2+2BR, where B bounds the single-prime coefficient sums.
- `meanSqK.lean` proves the mean-square estimate uniformly for
  y in [Y,Y^K], with truncation (Y^K)^400. The prime factors of the
  progression modulus must be either <=Y^(eps/5) or larger than the
  truncation. This condition bounds the forced part by O(sqrt y).
- `BadShare.lean` proves a maximal estimate using the derivative of the
  finite sum and dyadic intervals. Its derivative step applies the same
  mean-square statement to kappa(n)1_{n>y}, which explains why uniformity
  over arbitrary bounded coefficients is essential. The source finally
  bounds the exceptional proportion by a constant times Y^(-tau).
- `TailKExp.lean` and `BoxOfS.lean` turn the sharp finite polynomial into
  Gchi using a finite zero-free box and a truncation-tail estimate.
- `Kappa4Loglog.lean` proves a bound
  |L'/L(1,chi)| <= 1000 loglog Q+C for the good boxes, then uses
  eps<1/52 to deduce 4log Y. This explains that numerical restriction in
  this analytic branch.
- `CountBadCore.lean` injects bad primes into primitive characters with a
  zero in the box and uses the source's zero-density bound O(Q^(1/4)).
  The injection uses q>F, where the other conductor factor is <=F.
- `StagePow.lean` discards both bad boxes and large finite sums.
- `Stage1Succ.lean` applies this simultaneously to the finite family of
  primitive inducers of all base characters modulo N0.
- `CharOf.lean` constructs the second-stage finite family xi and xi*chi_q.
  Although its conductor bound grows with q, its cardinality is at most
  2*phi(N0). The second prime is selected uniformly in the previously
  chosen q.
- `PairShare.lean`, `PairExists.lean` and `pairEx.lean` assemble the result,
  put N0=8M, strengthen the logarithmic derivative to 4log Y, and transfer
  the primitive characters using their agreement on units.

The older RH-only definitions in
`Formalism/GL3MeanSquares/SecondEstimateOfIntervalHypothesis.lean` and
`PrimePairOfBoxAndWeakMeanSquareHypotheses.lean` describe the same underlying
three quadratic-character selection. The generalized path above is the one
needed for the full fixed Dirichlet-character family.

## 4. What the new ordinary proof proves

Theorem `qs-selection` in the TeX gives the complete simultaneous result
for every primitive base character of conductor dividing 8M. This is slightly
stronger than the bound component of `PairGood`, and includes its real-box
component. Its only additional analytic assumption is the exact fixed QRH
half-plane Re(s)>11/12.

The proof establishes every conductor dependence used:

1. The logarithm-on-a-disk argument gives
   |L'/L(v+it,chi)| <= C log((Q+3)(|t|+3)) for 23/24<=v<=2,
   with C independent of conductor. Removed Euler factors contribute only
   O(log Q). Principal characters are handled by removing their pole.
2. A fixed cutoff w=1 on [0,1], w=0 on [2,infinity) has a Mellin transform
   with only a simple pole at 0. Contour shifting proves
   Fchi(1)=sum Lambda(n)chi(n)w(n/Z)/n+O(Z^(-1/24)log(Q+3)).
   For y<=Z the resulting identity is
   Gchi(y)=-sum Lambda(n)chi(n)min(1,y/n)w(n/Z)
   +O(y Z^(-1/24)log(Q+3)). The signs were checked independently.
3. A second application with Z=(log(Q+3))^48 gives
   |L'/L(1,chi)|<=192loglog(Q+3)+C. This implies 4log Y in the actual
   conductor range with ample margin when eps<1/52.
4. Smooth positive weights on the auxiliary primes give weighted
   correlations with error
   O(phi(m)[U^(-1/24)log(mN^2+3)+U^(-1/2)(log(2U))^2]).
   No extra phi(m) appears before normalization by the prime mass.
5. The first modulus is 8 and U=exp(z). The second is 16q*primorial(z),
   with log m<=log16+5z, whereas log U=z(log Y)^2. Thus all needed
   correlations are <=Y^(-L), for every fixed L, uniformly in q.
6. The finite second-moment lemma is unconditional once its explicit
   correlation hypothesis is given. It also tolerates one exceptional
   squarefree correlation. Prime-power grouping proves the contribution
   of the forced local conditions is O(sqrt t), not an unestimated bias.
7. The maximal lemma gives the sharper explicit failure bound
   O_tau(Y^(-2tau)log Y), uniformly in the entire interval length, and
   simultaneously for any fixed finite number of bounded sequences.
8. With Z=Y^(48(A+1)), the smoothing error is o(1) uniformly for
   y in [Y,Y^A] and all selected twists. No conductor-dependent constant
   is hidden in this step.
9. The ordinary contour for the kernel 1/[s(s-1)] gives
   |Gchi(y)|<=C y^(23/24)log(Q+3), with the principal double-pole term
   subtracted explicitly. At exponentially larger y this supplies the
   source's small relative-error condition as well.

The moment estimate, maximal estimate, primitive-product calculation,
Chinese remainder construction, and explicit missing-local-factor formula
are fully proved in the TeX. The fixed zero-free half-plane is not promoted
to an unconditional theorem by this review.

## 5. Counterexample checks and limitations

- If the progression modulus is allowed to force splitting at every prime
  <=t, then every selected quadratic character is 1 on every n<=t.
  Taking the exact source coefficient Lambda(n) and N=t gives a mean square
  psi(t)^2, which is >>t^2, not O(t log t). The TeX gives a full elementary
  lower bound via the central binomial coefficient. This shows why the
  stated small-prime condition cannot be removed. It is not a flaw in the
  actual source, which has that condition.
- M=1, a principal base character of conductor 1, eps approaching either
  endpoint, A=1, imprimitive fixed base characters, and the possibility of
  large primes dividing the progression modulus were checked explicitly.
- All selected twists are nonprincipal because at least one new prime
  divides their primitive conductor. No undefined L'/L(1) is used.
- The new weighted argument proves existence. It is not asserted to give
  the source's unweighted proportion of good primes, which is not needed
  for the `PairGood` replacement identified above.
- Fixed prime-character estimates of exponent 11/12 or 7/8 are not
  substituted for the required exponent 1/2+eps. The latter is obtained
  by selection over new large-conductor twists.
- The ordinary Dirichlet conclusion does not supply a prime theorem in
  varying imaginary-quadratic ray classes, nor any automorphic theta-map,
  local minor, operator norm, or cohomology estimate.

No counterexample to the actual selected-character theorem was found in
this continuation. Its conventional reconstruction is complete conditional
on the stated QRH conclusion. Without that imported theorem, the classical
prime-progression/exceptional-character and zero-density inputs remain an
alternative analytic route not fully independently reconstructed here.

## 6. Read coverage and independent verification

The listed small `PrimitiveCosets`, `PairGood`, `BoundedTw`, and generalized
`MeanSquareBounds` files were read in full. `BadShare.lean` was reread in
separate ranges after a bulk output truncation. The relevant definitions,
rather than every subsequent theorem, were read in the two larger
`SmoothedRemainderRealIntegralFormula.lean` and
`SecondEstimateOfIntervalHypothesis.lean` files. The underlying proofs of
the relative PNT and zero-density input were not certified in this pass.

The Siegel review agent independently read the complete new TeX and checked
the Mellin signs, principal residue, conductor estimates, prime-power
grouping, forced local terms, maximal inequality, and two-stage selection.
It found no mathematical defect. A subsequent notation edit made explicit
that exponent-zero factors are omitted, and an exact imprimitive Euler-factor
correction was added. The combined TeX compiles after two XeLaTeX passes;
the new mathematical section has no overfull boxes in the isolated check.
The final notation and imprimitive-factor edits were included in a fresh
two-pass compile: exit status zero on both passes, with all references
resolved after the second pass. The 20-page combined check contains earlier
QRH sections as well; its remaining small layout warnings belong to those
older sections and their bibliography.
