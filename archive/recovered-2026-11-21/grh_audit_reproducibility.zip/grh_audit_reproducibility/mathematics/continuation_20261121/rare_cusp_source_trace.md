# Source trace: volume of the region with small least size

The mathematical fragment is rare_cusp_volume.tex. Its exact hash and
the inspected source hashes are in rare_cusp_source_manifest.json.
At creation this is a new conventional proof awaiting independent
root review. It is not a report of a full Lean kernel replay.

## Result and route

For a CM extension E/F unramified at finite places, a self-dual
Hermitian lattice of constant signature (p,q), and
log(n) >= 15, q^2 <= n, log(r_E) <= exp(n), the fragment proves

    Probability(least size < 1/2) <= exp(-n f log(n)/3).

The proof uses one primitive isotropic sublattice at a time.
It does not assume the source's full flag-unfolding theorem.
A lattice of least size is semistable; the restricted Hermitian
pairing shows that it is isotropic when its size is less than one.
The mean value of the number of primitive isotropic rank-j
sublattices of size less than T is then calculated exactly.

The normalized covolume is c_E^(-rank) times real covolume,
where c_E = 2^(-f) sqrt(|D_E|). The root discriminant is
r_E = |D_E|^(1/(2f)), and finite unramifiedness gives
c_E = (r_E/2)^f. These are the source's definitions, as already
traced in ambient_multiplicity_source_manifest.json.

## Exact source interfaces

All paths below are under
sources/lean/src/Development/AbelianVarietyTheory.

* Definitions/SemilocalFrames/LayerProd.lean:
  lamX, frm, least, stepLt, and the source quantitative hypotheses.
  The frame convention agrees with the inverse-frame positive
  metric in the conventional text; it is not multiplication by
  the forward frame when measuring a vector.
* Definitions/SemilocalFrames/DefClassNum.lean:
  sphV, volU, dimN, kapBd, dens, and the general linear Haar measure
  and volume of the determinant-norm slab. For one rank increment,
  the source density is 2fj T^(2fj(n-j)-1).
* Definitions/SemilocalFrames/IsGaugeAll.lean:
  IsGaugeAll, cIw, rankFac, and the primitive isotropic flag
  convention. The Hilbert–Schmidt gauge is the actual local
  normalization, including the compact subgroup scaling.
* Statements/CuspFrameWeights/SameKindIsometric.lean:
  GenLinVolume, VolumeRatio, IwasawaFormula, RadicalCovolume,
  UnfoldBound, FlagMeasureBound, ConstantBound, NonzeroFlagBound.
  These statements were read to match the exact endpoint and
  constants. The fragment independently proves the specialized
  mean value it uses rather than treating these statements as inputs.
* Proofs/FlagMeasures/IsotropicFlagProbabilityBoundOfVolumeRatio.lean:
  the source assembly of volume, unipotent, general linear, and
  Iwasawa factors. This is a normalization cross-check.
* Proofs/FlagMeasures/IsotropicFlagUnfoldingBound.lean:
  only lines 1–180 were read. No claim is made to have read this
  whole proof or its full dependencies.
* Proofs/FlagMeasures/FlagRareOfNonzeroFlagBound.lean and
  BlockTheory/SiegelWeilLocal/RareFlags.lean:
  the precise rare-set endpoint and its use in the ambient theorem.

The least-size minimum also has largest quotient size no greater
than its size. Hence the source set stepLt(1/2) != 0 is exactly
the set least size < 1/2. The final theorem supplies the actual
NonzeroFlagBound and the weaker rare-volume input in the ambient
comparison. The additional source hypothesis log(f) <= sqrt(n)
is unnecessary for this proof.

## Constants and nonfree modules

The unipotent radical has real dimension d = 2j(n-2j)+j^2 at
each real place. Its integral quotient volume is

    r_E^(f d/2) H(P)^(n-j).

This is proved using a global integral element of trace one;
division by two in the integral coordinates is avoided.
The proof separately counts the skew-Hermitian diagonal
coordinates. Primitive projective modules are included,
with their ideal and metric determinants explicitly calculated.

The real Iwasawa constant is

    2^(-j(j+1)/2) S_p S_q / (S_(p-j) S_(q-j) S_j),

with the embedded general linear factor contributing 2^(j^2).
The latter factor and the exact determinant-norm slab volume
are both retained. In the marked-lattice unfolding, the
unipotent factor H(P)^(n-j) cancels its reciprocal from the
radial integral. Omitting projective classes or replacing
the determinant norm by the determinant modulus would
give a different answer.

The resulting kappa_j is algebraically identical to the
source's kapBd for a one-step flag. The proof then bounds
it by exp(-jnf log(n)/2). The elementary identity

    sum_(l>=2) (zeta(l)-1) = 1

slightly shortens the Euler-product estimates.

## Explicit classical inputs and actual primary reading

1. The unitary Tamagawa-number theorem and special linear
   Tamagawa number one. Weil, La formule de Siegel et les
   groupes classiques (1965), primary PDF in primary_cusp.
   Read: type (I_2) in section 27, sections 53–54 and 57,
   relevant printed pages 40–41, 81–82, 85–86.
   Printed pages 41 and 82 were also visually checked.
   The unitary parameter is e = 1/2, so the dimension
   threshold in section 54 is positive dimension.
   The entire article and its proof are not claimed as read.
2. Analytic class-number formula. This is a named classical
   input to the general linear determinant-torus volume,
   with its exact measure conversion displayed in the text.
3. Unitary mass formula and finite local densities. The
   previously written unitary_mass_densities.tex is used.
   Its finite-field and dyadic lifting arguments are
   referenced directly, as is its explicitly stated
   classical global mass formula.
4. Local-global principle for Hermitian spaces. Kirschmer,
   Theorem 2.4.1, printed pages 19–20, read from the primary
   author thesis already stored in primary_mass. This is
   a theorem about rational spaces, not an assertion that
   every lattice genus has one isometry class.
5. Louboutin (2001), Theorem 1(1), printed page 1195.
   The primary journal PDF is stored in primary_cusp.
   The theorem is unconditional and applies to every
   number field of degree greater than one. Only the
   stated theorem and its conventions were checked;
   its proof and the whole article are not claimed as read.

## Verification and limitations

The standalone TeX wrapper compiled twice to
output/rare_cusp_volume_check.pdf, 11 pages, with no overfull
boxes and only expected references to the ambient and mass
fragments. Its Iwasawa formula page was visually inspected.

check_rare_cusp_constants.py independently computes exact
real tangent Gram determinants in several signatures and
parabolic ranks. It also checks non-diagonal congruence
determinants, compact-volume factors, and discriminant
exponents. The resulting JSON record describes the finite
scope. These controls do not establish the imported
Tamagawa theorems or turn finite examples into universal proofs.

The integrated near-unipotent count and the deep-cusp mass
estimate are not proved by this fragment. The root is
separately treating the finite-rank projection/kernel input.
No fatal flaw in the claimed proof is asserted here, and
the result does not complete the global GRH argument.
