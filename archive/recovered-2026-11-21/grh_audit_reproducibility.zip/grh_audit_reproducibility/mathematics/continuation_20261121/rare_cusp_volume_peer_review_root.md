# Independent review of the small-minimum cusp volume

Reviewer: /root. Date: 21 November 2026.

Reviewed fragment: `rare_cusp_volume.tex`, SHA-256
`57a92fb9c8a5d41cb915568cfea7fea7830abf1a7abd187eb29fb047e4417107`.

**PASS within the stated hypotheses and explicitly imported classical
theorems.** The entire mathematical fragment was read. No counterexample
or missing hypothesis was found. The proof establishes the rare-volume
input; it does not establish the near-unipotent or deep-cusp estimates.

## Mathematical checks

The infimum defining least normalized size is attained: saturation
decreases covolume, and primitive sublattices of a fixed real rank inject
up to sign into the corresponding exterior lattice. A norm-bounded set
there is finite. For a minimizer, multiplicativity of normalized
covolumes proves the claimed bound on every torsion-free quotient.
Restriction of the integral Hermitian form gives a map into the conjugate
dual. Its operator norms are at most one. Comparing the quotient size
at most s with the image size at least s^(-1) excludes a nonzero map
when s<1. Thus the sublattice used for the count really is isotropic.

I checked the exact Haar conversions, including the factors of two in
the compact unitary volume, the general-linear radial variable, and
the radical. The check in rank one over Q(i) gives the expected
general-linear logarithmic-slab volume pi/4. The radical has real
dimension 2mj+j^2 per real place. Its covolume contributes
r_E^(fd/2) H(P)^(n-j); the radial integral contributes the reciprocal
power of H(P), so no ideal-class-dependent covolume is left over.
The diagonal skew-Hermitian coordinates and the off-diagonal complex
coordinates have different powers of two, as retained in the text.

The global splitting of an integral isotropic direct summand uses a
trace-one element and therefore does not divide by two at dyadic
places. Unramifiedness supplies that element. The classification used
after this splitting is a statement about rational Hermitian spaces,
not the false assertion that a genus has only one integral class.
All projective-module classes and complementary-lattice classes are
included in the unfolding.

The exact mean value has factor
kappa_j T^(2fj(n-j))/(n-j). The source density has the same radial
exponent and constant after writing vInv=r_E/2. The compact-volume
factorial estimate, the residue bound, and the Euler products give
log kappa_j <= -jnf log(n)/2 with the printed hypotheses. Summation
over 1<=j<=q gives the asserted exponent -nf log(n)/3.
The case q=0 is separately correct: lambda_x=1 and the exceptional
set at tau_0=1 is empty. No assumption on log f is used.

## Independent source and reference checks

I read the complete `DefClassNum.lean`, `LayerProd.lean`, and
`IsGaugeAll.lean` definition files, and the relevant statements in
`SameKindIsometric.lean` (lines 58–131). These checks include cIw,
kapBd, the least-size and stepLt definitions, the count hypotheses,
and NonzeroFlagBound. The other source scopes in the author manifest
belong to that author; this review does not claim a second complete
reading of those files.

The previously reviewed local unitary-density and compact mass
calculation supplies the measure normalization. I independently read
Weil's relevant passages in sections 27, 54 and 57 and visually
checked printed pages 41 and 82: the quadratic-unitary case is type
(I2), epsilon=1/2, and the Tamagawa number is independent of the
Hermitian form and positive rank. Section 57 records the special
linear Tamagawa-number-one input. The norm-one torus value and the
analytic class-number formula remain stated classical inputs, as
does the unitary Tamagawa theorem itself.

I independently read Kirschmer, Theorem 2.4.1, and the immediately
following distinction between rational isometry and integral genus.
I also checked Louboutin, Theorem 1(1), with the notation on printed
page 1195. Its bound is unconditional for degree greater than one;
the argument uses precisely that bound. No claim of having reread
the proofs or the whole of these primary works is made.

The 1,680 exact controls were rerun locally at the reviewed hash and
all passed. They check finite Jacobian, congruence, compact-volume and
discriminant identities. They do not replace the general proofs or
verify the imported Tamagawa theorems. This is not a full Lean-kernel
replay or a verification of the final GRH implication.
