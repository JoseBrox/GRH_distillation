# Prime selection and common-interval assembly audit

Companion mathematical section: `selection_assembly.tex`.
Date: 21 November 2026. The source archive and the 28 files used here are
pinned in `selection_assembly_source_manifest.json`.

## Result

No false quantifier interchange or counterexample to the actual assembly
was found. The new section proves the field identification, stabilization
of the field degree, the finite required character family, the real-character
conductor reduction, the scale comparisons, the common-interval rescaling,
and the final elementary absorption of the remaining cohomological bounds.
It does not prove the QRH theorem, the coarse H^2 input, all-prime arithmetic
counting, or the global theta construction.

The reconstructed cohomological interval covers the two-adic contribution
and specified fixed odd-prime fields. It is not silently promoted to the
source's full `VWin`. The exact missing all-odd-prime estimates, including
finiteness, are displayed in the new TeX.

## Exact source chain and quantifiers

Paths below are relative to `sources/lean/src/`.

1. `CharacterBoxes/ExistsPageN.lean` fixes a function e(x) with
   x^(2+8eps) <= 2^e(x) <= 2x^(2+8eps), and defines VWinAt with a J fixed
   before X and before q,d. For every sufficiently large X and EVERY
   WinPair at X^(1/J), it returns a common interval [W,W^2]. The selected
   q,d are fixed throughout this interval. The full statement controls
   all coefficient primes and all weights less than floor(x^Ct).
2. `CharacterBoxes/WinPairs.lean` calls PairEx with M=psi.N and A=J at
   U=X^(1/J). Its analytic bounds therefore already hold on [U,X] before
   the cohomological subinterval is chosen. The fixed degree factor c is
   absorbed using k=c^(1/(2+8eps)), Z=kW and x'=x/k. The inequalities
   W>=k^3 and W>=k^400 give (kW)^(3/2)<=W^2 and x^400<=x'^401.
   This is the actual use of the exponents 3/2, 400 and 401.
3. `CharacterBoxes/OrdAny.lean` proves eventual ord=c*2^e with
   1<=c<=order(psi). `FieldChi.lean` chooses e above that stabilization
   threshold, 2, 4M and 64*order(psi), all fixed constants. The new
   conventional field proof identifies c=[Kpsi:Kpsi intersect R_infinity]
   and proves stabilization already for e>=max(v_2(M)-2,0).
4. `FieldChi`, `KerChiAny` and `IsChiField` retain exactly the simultaneous
   fixed-subgroup conditions: a=+-1 mod 2^(e+2), psi(a)=1, and the two
   quadratic symbols equal to 1. The new Gauss-sum/Galois proof identifies
   the field as Kpsi Q(mu_(2^(e+2)))^+(sqrt(-q),sqrt(-d)). Its degree is
   4c*2^e, because each nontrivial quadratic subfield introduced by q,d
   ramifies outside the fixed cyclotomic modulus.
5. `FieldChi`, `KerChiAny`, and the host tower condition give M|QS,
   2^(e+2)|QS, QS|lcm(2^(e+2),M); together these force equality. In
   particular, no new odd prime enters QS. The assembly only uses the
   weaker QS<=4M*ord and support/divisibility statements.
6. `TwistAny` and `BoundedTw` show that characters trivial on the growing
   cyclotomic subgroup have base factor in <psi>, a fixed finite family.
   Excluding retained characters or using the distinguished involution
   forces a nonzero q or d exponent. The new ordinary family has 3*order(psi)
   members. All are covered by the earlier theorem with primitive base
   conductors dividing 8M; no varying 2-power family is averaged.
7. `RealBox.lean` splits every real character into a base of conductor
   dividing 8*oddpart(QS), and q,d factors. The new elementary proof uses
   that real characters modulo odd prime powers factor modulo the prime,
   and that every unit 1 mod 8 is a square modulo any 2-power. Its
   conductor bound is uniform in e. PairRows also obtains the six
   quadratic box conditions with the extra conductor-8 character.
8. `ShortNorms/supplyOfAdmOf.lean` chooses C0>=J, order(psi), 8M only after
   J is fixed. The host-supply constants then depend on these fixed data,
   and their thresholds are absorbed before taking X large. The lower
   prime window eventually gives q>3 and the splitting cutoff >=4M;
   the rank exponent satisfies t<=x^400. No constant is chosen using a
   later unknown q or d.
9. The actual additional level primes and integral host data are supplied
   by the separate hypotheses in `ShortNorms/hostOfFieldOf.lean`. They
   are not extra congruences imposed retrospectively on q,d. The new
   section does not claim to reconstruct those short-norm/prime-supply
   inputs or the theta maps.

In items 1--8, `CharacterBoxes/` and `ShortNorms/` mean the corresponding
subdirectories of `Development/AutomorphicArithmetic/`.

## Coherent combination with the reconstructed cohomology

- In `AutomorphicVarieties/StmtFields.lean`, the fixed exceptional set is
  Bchi(psi) = {3} union the odd prime divisors of
  order(psi)*M*pK(psi)*hStar(psi)*pOne(psi). All these quantities depend
  only on psi. The fixed odd-prime field is Q(mu_(p*M)).
- `PrimeSetBoundDataOfPrimitiveChar.lean` defines a single J from the
  sum of the generator bounds for that entire finite family. Its
  jointWin_of proof chooses ONE interval from ThmBab and applies the
  height/vanishing theorem on that same interval. No intersection of
  independently chosen intervals occurs.
- `HeightAndVanishing/ThmHV.lean` applies the pointwise arithmetic estimate
  after the fixed odd-prime bounds have been supplied. It also requires
  q,d>2X^401+1 and domination of a fixed list of primes/integers. The
  exponential lower prime windows imply all these conditions. The
  proof itself uses the interval range only to obtain x>=2 and x<=X;
  the particular formula for J is not a new arithmetic hypothesis.
- The source fixed layer is floor(log_p R_p)+3. The new cohomology
  section uses 1+ceil(log_p R_p). They differ by one or two for R_p>=1.
  The growth lemma transfers to the source layer at cost <=2R_p per
  weight. Applying the new interval theorem with eps0=9eps/10 gives
  exp(x^(18eps/25)), leaving enough margin to absorb that polynomial
  cost into exp(x^(4eps/5)).
- The same eps0 gives log(qd)<=X^(eps0/(4J)) because the prime-window
  exponent is eps/5 and eps0/4=9eps/40>eps/5. The prime selection still
  uses eps, and the rank exponent remains 2+8eps. The cohomological
  proposition is uniform over every h<=6(1+log x), so no false PageN
  assertion with eps0 is made.
- The source original J need not equal the optimized J of the new
  interval lemma. The new proposition proves the ordinary compatibility
  directly with any fixed J>=J0; it does not claim literal substitution
  into a source interface with a different numeric J. A separate paragraph
  proves the original full-VWin rescaling with exactly its own J.
- `LengthEqAddEigen.lean` uses complex-conjugation eigenvalues (-1)^e
  and (-1)^(e+1), not unqualified eigenvalues +1 and -1. The new TeX
  retains these signs and proves the direct sum for odd coefficient primes.
- `CMFieldExponentialBounds/AdmissibleOfPageN.lean` combines the two-adic,
  all-prime plus, and minus estimates. `ErrorTermsLeSqrtExpRpow` absorbs
  them using log(conductor*t)<=2x^(eps/4). This numerical absorption is
  reproved with an explicit sufficient threshold in the new corollary.
- `HeightAndVanishing/JointWinOfCounts.lean` displays the remaining
  arithmetic inputs: CountI, CountII, CountIII, CountV, CountZ, their
  auxiliary counts, duality/local finiteness, and the coarse bound.
  These, together with the separate minus-part estimate, are not proved
  merely by the finite-prime common-interval theorem.

## Adversarial checks

- Replacing the fixed selection scale U by x is false: for fixed J>1
  and x=U^J, the upper bound log q<=U^(eps/5) violates the proposed
  lower bound log q>x^(eps/5)/2 once U is large. The actual source
  keeps U and only requires x^(1/J)<=U<=x.
- The d congruences are reduced and compatible by CRT: modulo 16 and
  distinct odd primes, including q. No congruence modulo a full prime
  power dividing M is needed by FieldChi's splitting conditions.
- The varying fields do not alter the fixed base conductor in the
  square-root selection. A demand for every character modulo the growing
  power of 2 would be stronger; the actual bounded-character family
  is explicitly trivial on the growing cyclotomic subgroup.
- The common cohomological interval is chosen after q,d but its exponent
  J and uniform threshold are chosen before them. The selected pair is
  already good over the entire possible ambient interval.
- Finite lengths are retained explicitly. An infinite cardinality is not
  converted to zero through an integer conversion in the ordinary proof.

## Read scope and peer review

All 28 manifest files were read in full except `ShortNorms/hostOfFieldOf.lean`,
whose first 180 lines were read. The new mathematical compatibility section
and both earlier fragments were read as well. Upstream proofs of the
remaining arithmetic counting, ordinary and quadratic ray-class prime
supplies, and automorphic constructions were not certified in this pass.

The root independently read the entire initial 378-line new section and
reported no mathematical defect. Its two requested notation corrections
(the missing backslash in qquad and a uniform conductor bound in prose)
were applied. The earlier selected-character and cohomological sections
already have their independent reviews recorded in their own source traces.

The new section and its earlier QRH, prime-selection and cohomological
dependencies were compiled twice with XeLaTeX in the internal
`selection_assembly_check.tex` wrapper. The result is 32 pages, with no
undefined references or compilation errors. A pre-existing 2.69-point
overfull line in an earlier included section is the only overfull warning.
