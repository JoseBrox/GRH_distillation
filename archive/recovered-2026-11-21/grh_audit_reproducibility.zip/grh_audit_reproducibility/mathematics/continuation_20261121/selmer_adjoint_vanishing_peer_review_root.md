# Independent review: adjoint Selmer vanishing

Verdict: PASS for the stated classical implication, with the limitations below.

Reviewed mathematical text: `selmer_adjoint_vanishing.tex`, SHA-256
`a7902c6568226b94f89f7dfe1a449a04157683b5d3f4dfa5dcab7e8e4ed29dda`.
The root read the entire 425-line original draft, checked its arguments, and
then read the final corrected comparison and symplectic-projection sections.
The final changes correct the exponent of the quadratic character and replace
formal identifiers in the mathematical exposition by ordinary terminology.

## Mathematical checks

- The compact-image argument uses countably many closed finite coefficient
  fields, Baire's theorem, and finitely many coset representatives. Applying
  it to the block representation includes the cocycle as well as the action.
- The coefficient projection is linear over the chosen finite field. Its
  algebraic tensor extension commutes with the action and descends a single
  crystalline coboundary; continuity of that projection is not assumed.
- The polarized adjoint action has the essential minus sign at complex
  conjugation. The pairing is unique up to scalar by irreducibility, so the
  arbitrary pairing in the formal conclusion gives the same adjoint action.
- The exact image of the cyclotomic kernel under the quotient map is proved
  by lifting an element and applying both characters. Ordinary irreducibility
  is not substituted for irreducibility on this kernel.
- The Frobenius comparison is semisimple and uses the stated inverse of
  arithmetic Frobenius and the factor q^((n-1)/2). The finite-dimensional
  algebra proof of the trace criterion is valid in characteristic zero.
- The source's local group of compatible global and local automorphisms is
  identified with the local absolute Galois group. The local conditions agree
  with inertia coboundaries away from p and crystalline coboundaries at p.
- The symplectic projection (X-X*)/2 is equivariant for the twisted adjoint
  extension, including at p=2 over the rational coefficient field. Applying
  it to a primitive retains the primitive in the symplectic Lie algebra.

## Primary theorem and source comparison

The root independently read Thorne's Theorem 6.1 and surrounding hypotheses
on printed page 24 of arXiv:2207.04925v1. The subsequent split, unramified and
Iwahori hypotheses are proof reductions, not extra theorem hypotheses.
The root also checked Newton--Thorne's normalization passages and visually
inspected printed page 1920 of the JEMS paper for the adjoint minus sign.

The root read the complete `LiteratureResults/Thorne.lean`,
`AutomorphicForms/BlochKatoSelmerVanishes.lean`, `IsTanZero.lean`,
`TheoremsMuLinked/OrdZero.lean`, `AutomorphicPointGalois.lean`, and
`IsAutCsdA.lean`; the definitions of `AutCsd0` and `IsForm`; the level/frame
construction in `ContinuousResP.lean` lines 65--164; and the crystalline
cocycle definition in `FiniteCohomology.lean` lines 75--177.
These support the exact implication claimed in the manuscript. The more
extensive source-reading scope of the drafting reviewer is recorded in the
separate source manifest; this record does not attribute all of it to root.

## Limits

Thorne's published vanishing theorem is an explicitly cited mathematical
input. This review does not reproduce or independently audit its full proof.
It does not construct automorphic deformations, prove quantitative integral
congruence bounds, or certify the separate CM-field/twist construction.
Rational vanishing alone gives no uniform bound on torsion length.
No complete local Lean kernel replay or claim of a proof of GRH follows.
