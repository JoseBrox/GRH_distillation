# Adjoint vanishing at the actual automorphic points

The reconstruction is `selmer_adjoint_vanishing.tex`. It proves the actual source implication `AdjointLiftingTheorem` using a cited classical theorem, with full coefficient descent, quotient transport, polarization uniqueness, and local-condition comparison. The rational symplectic projection is also proved. This closes one genuine dependency; it does not prove the automorphy or integral counting steps of cases I, II, III, V.

## Primary sources actually checked

1. Jack A. Thorne, *On the vanishing of adjoint Bloch–Kato Selmer groups of irreducible automorphic Galois representations*, arXiv:2207.04925v1, 11 July 2022, https://arxiv.org/pdf/2207.04925. Local file: `sources/primary/thorne_adjoint_2207_04925v1.pdf`.
   - Read the introduction on PDF pages1–4, including Theorem A, and the exact Theorem6.1 and proof-reduction paragraph on PDF/printed page24.
   - Read the accompanying setup through the initial paragraph on page25, including the polarized extension and the multiplier delta^n epsilon^(1−n).
   - Theorem6.1 assumes a CM field, n≥2, a regular algebraic cuspidal polarized automorphic representation, an abstract isomorphism Qbar_p≃C, and irreducibility on G_{F(mu_{p∞})}. It applies to every prime p and does not require residual irreducibility or residual adequacy. The unramified/split/Iwahori hypotheses in the following proof reduction are not theorem hypotheses.
   - The full32-page proof has not been independently audited. The theorem is an explicitly cited classical input.
2. James Newton and Jack A. Thorne, *Adjoint Selmer groups of automorphic Galois representations of unitary type*, JEMS25(2023),1919–1967, DOI10.4171/JEMS/1228, https://ems.press/content/serial-article-files/32858. Local file: `sources/primary/newton_thorne_jems_2023.pdf`.
   - Read printed1919–1923 (PDFpages1–5) for the conjugate-self-dual convention, symmetric pairing, adjoint action, local Selmer kernels and Tate normalization. Parts of the exposition on printed1921–1922 were read in the retrieved text; no claim of full-paper review.
   - Visually checked printed1920 (PDFpage2), especially the minus sign in c·X=−X*. Local image: `sources/primary/newton_thorne_jems_1920.png`; root independently visually checked it.
   - The older theorem's enormous-image hypothesis is not used: Thorne2022 replaces it with the exact cyclotomic-kernel irreducibility above.

## Exact source definitions

All source files below were read in full. Paths are relative to `sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/`, except where explicitly marked otherwise.

- `WeilGroupCharacters/UniversalOrdinaryDeterminantRing.lean`: GFrame10–42; the subgroup G'73 is exactly ker(epsilon|ker eta); IsForm101–103 is r(g)^t P r(cgc^{-1})=epsilon(g)^(1−n)P. Read all307lines.
- `WeilGroupCharacters/ContinuousResP.lean`: HidaSetting70–94 supplies a genuine complex conjugation; Lev106–117 supplies the finite-ramification quotient, quadratic character, and exact cyclotomic compatibility. The map pr129–130 is the quotient restricted to G_L. The frame is constructed142–162. Read all164lines.
- `WeakShimuraTheory/UnipotentIdempotents/PrFacts.lean`: surjectivity of pr and conjugation/cyclotomic compatibilities are proved explicitly. The ordinary reconstruction supplies its own short proof of the required exact image of the cyclotomic kernel.
- `WeakShimuraTheory/EigenbasisLifts/IsTanZero.lean`: IsAdExt31–35 has the ordinary adjoint action on ker eta and c·X=−P^{-1}X^tP. Read all38lines.
- `TheoremsMuLinked/OrdZero.lean`: TypeI14, the exact AdZero conclusion66–70, and the older AdL interface. Read all102lines.
- `ModularityArgument/ThresholdArguments/DenseThresholdCases/AutomorphicPointGalois.lean`: the active AutomorphicPointGalois includes continuity and IsAutCsdA; its locally generic extension includes TypeI; the active AdjointLiftingTheorem34–39 asks for the above AdZero conclusion. Read all42lines.
- `ModularityArgument/AutomorphyLifting/IsAutCsdA.lean`: AutCsd0 is the first conjunct; the extra witness is unnecessary for this classical route.
- `../Foundations/GaloisRepresentations/AdmissibleResidues/IsAutomorphicOverImagQuad.lean`: AutCsd035–36 explicitly gives a regular algebraic conjugate-self-dual cuspidal representation and AttC.
- `AutomorphicForms/BlochKatoSelmerVanishes.lean`: FrobEig69–72 uses the inverse of arithmetic Frobenius; algSat74–75 multiplies Satake roots by q^((n−1)/2). AttachedSys77–79 includes semisimplicity. IsBK135–140 is the usual unramified-away-p/crystalline-at-p cocycle condition. Read all148lines.
- `PadicHodgeTheory/FiniteCohomology.lean`: finiteCocycles is the existence of a single vector in the algebraic tensor product with Bcris trivializing the cocycle. Read all177lines. This is the condition for which the explicit coefficient projection in AV applies.
- Outside the main prefix: `sources/lean/src/Development/AbelianVarietyTheory/Definitions/GaloisGeometry/DualIsConjByOne.lean`, all59lines. PolarizedPair53–55 imposes chi_v(−1)=(−1)^n. For a conjugate-self-dual pi the source convention therefore uses chi=delta_{F/F+}^n, rather than chi=1 in odd rank. Norm pullback is trivial, so the multiplier on G_F remains epsilon^(1−n). This is a matched convention, not a flaw.
- `LiteratureResults/Thorne.lean`: ThorneLit33–52 states the finite coefficient field, symmetric pairing, exact multiplier, both adjoint actions, and H1_f vanishing. Read all54lines. This existing interface confirms the intended classical theorem, but is not treated as an independently proved Lean theorem.
- `ModularityArgument/ThresholdArguments/DenseThresholdCases/AdLOf.lean`: the source's existing route goes through ordinary vanishing and local p-adic Hodge theory. Read all151lines; the new proof replaces that route for the actual conclusion.
- `ModularityArgument/ThresholdArguments/DenseThresholdCases/RigSp4.lean`: read all195lines, including its idempotent projection, character twist on the complementary subspace, exact polarized action and transport of Bloch–Kato cocycles. AV proves the matrix content directly. It does not replace the separate CM-field/twist existence theorem.

## Independently supplied arguments and limitations

- Every compact matrix group over Qbar_p has a finite coefficient field: use countability of finite p-adic fields, Baire, and finitely many coset representatives. The countability assertion is justified by Hensel approximation and the elementary conjugate-distance proof of Krasner's lemma. Applying this to the block representation (R,z;0,1) treats cocycles as well as representations.
- Local coboundary equations descend by an E-linear coefficient projection. No continuity of that projection is asserted or required.
- Semisimple Frobenius matching uses Chebotarev and the explicit finite-dimensional-algebra proof of Brauer–Nesbitt supplied in the text.
- Pairing uniqueness is an eigenspace proof of Schur's lemma. It also shows that the source's arbitrary P is automatically a scalar multiple of the symmetric classical pairing.
- Exact quotient compatibility proves the image equality q(G_{F(mu_{p∞})})=ker(epsilon|ker eta). There is no substitution of ordinary irreducibility for cyclotomic-kernel irreducibility.
- The theorem uses rational cohomology. No uniform torsion-length estimate is claimed from rational vanishing; the concluding example explains why such an inference would be invalid.
- No complete Lean replay, no audit of every imported classical theorem, and no claim that the remaining complementary-parity estimates are finished.
