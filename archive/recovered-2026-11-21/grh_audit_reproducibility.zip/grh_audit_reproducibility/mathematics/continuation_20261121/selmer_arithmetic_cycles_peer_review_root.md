# Review of the arithmetic homology cycles

Reviewer: root. Date: 21 November 2026.

The complete conventional proof in `selmer_arithmetic_cycles.tex` was read, including the five-step construction and all preceding prism identities. The final reviewed snapshot has SHA256 `8b659ef048f0db6db7ec5b991ab0d217246f6ae3da5f27b6d5451563c7f9d67d`.

No mathematical defect was found. The character interpolation is performed over the prime-power ring with a unit coefficient in the cyclic relation; it does not divide by an arbitrary nonzero residue. The fractional ideal exponents give the required lattice isomorphisms on each character block. The twisted cyclic isomorphism, its determinant, and the weighted norm retain the stated direction of the Galois action. The one- and two-prism homotopies give the asserted boundary identities with the same orientation as the finite-field functional. The resulting class is a cycle over the original ring of integers after clearing a finite common set of denominators.

The size, cycle, and excluded integral element are selected before the finite residue field and its functional. This order is essential for their later use at all degree-one primes. The primitive scalar representation is written explicitly as rho_x(j)=zeta^(xj), so the value x^E v(det g) also applies when x is not a unit. The prime-power coefficient ring and the bound on the number of characters are retained.

This review concerns the mathematical proof and its use of previously proved interpolation and homology lemmas. It is not a new full compilation or kernel replay of the submitted Lean development.
