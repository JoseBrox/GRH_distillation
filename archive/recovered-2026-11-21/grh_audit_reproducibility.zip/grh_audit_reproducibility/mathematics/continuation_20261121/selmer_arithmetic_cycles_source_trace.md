# Source trace: integral arithmetic cycles

Date: 21 November 2026. Fragment: `selmer_arithmetic_cycles.tex`.

## Completed mathematical assertion

The fragment proves the actual SClass assertion, with E=e+1, M=2E+1, modulus q=ell^nu, kappa=1+ell^c, and the exact factor product over j<M, j≠E, of (kappa^E−kappa^j). It constructs a cycle in some GL_N(O_L), a nonzero base integer b in O_L, and the specified residue evaluation for every admissible residue map and every additive functional having the actual determinant normalization. Its N and b may depend on the input, exactly as allowed in SClass.

The proof uses the already proved SZc/SRel, SEta, SStein and finite-field normalization, but does not use BOdd, SUpper, SFew or the alternative K-theory coarse theorem. The ordinary proof of projectivity and the good-reduction splitting are included. It does not import a class-number provider or assume that the coordinate ideals are principal.

## Source read scope

All 23 files in

`sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/ModularityArgument/ClassCounting/LatticeBlockClasses/`

were read in full, totaling 2447 lines. Their names, lengths and hashes are recorded in the manifest. This includes all local providers passed by SClassOf to CJoin. The small `SClassOf.lean` assembly was also read in full, as were the complete definitions in `HasVal.lean` and `LemmaKOfSteps.lean`.

The fundamental source files implementing SChain, SPrism and SPrismMul were not all independently read in this pass. The manuscript instead supplies explicit general one- and two-prism homotopies, with full face-cancellation proofs. No claim of a complete transitive Mathlib or Lean-kernel audit follows from this read scope.

## Precise comparison

| Source input | Conventional proof and exact convention |
|---|---|
| `CChain.lean` | The stabilizer-cycle lemma uses k_t=g_t0^(-1)g_t and rho_1=g_t0^(-1)rho g_t0. Its cycle is rho_1(b)−rho_0(b)+sum n_t P_k_t rho_1 d_t(z). |
| `RedApplyMap.lean`, `ExistsOfInLat.lean` | A finite torsion-free O_L-module is proved projective, then embedded as a summand of a finite free module. The complement remains in the representation with trivial action; it is not discarded integrally. |
| `CSplit.lean`, `CMu.lean` | Good residue splitting is proved by an integral primitive element, removal of the order index and discriminant, and Chinese remainders. This is an alternative to the source's trace-dual construction. Both give the same map x→(r(tau x))_tau and the same tensor kernel. |
| `CRes.lean`, `CLatLoc.lean`, `CSupp.lean`, `CUnit.lean`, `ExistsRes.lean` | The proof explicitly enlarges a nonzero element b of O_L to clear all needed denominators and inverses. This is allowed because SClass places no quantitative bound on b. All Galois conjugates remain units because b belongs to the base ring. |
| `CGtNe.lean` | The sums of eta on the nondistinguished character blocks vanish, so SStein gives determinant-one maps of the exact ideal lattices. |
| `GtEqZeta.lean`, `CBlock.lean` | For chi(j)=kappa^i, the coordinate Galois change is gamma^(−i), and the new character is one. The order of kappa modulo q equals the order of gamma, so repeated weights give the same automorphism. The final map is L-linear, not generally F-linear. |
| `CBetaDiv.lean` | beta=Q(gamma^(−1))alpha, with Q(T)=P(T)/(T−kappa^E). Its divisor is sum p_i d(gamma^i P), with the sign of the inverse action explicit. |
| `CBlockVal.lean`, `BlkEquiv.lean` | Reduction of the coordinate Galois changes permutes the embedding index by tau→tau sigma_j. The transformed blocks have weight kappa(tau) times the new character. Only the distinguished determinant beta contributes. |
| `CBetaVal.lean` | The residue functional F(x)=sum a^j f(gamma^j x) satisfies F(gamma^(−1)x)=aF(x), using a^d=1 modulo q. Therefore F(beta)=Q(a)F(alpha), exactly the required Vandermonde factor times the weighted norm logarithm. |
| `CJoin.lean` | The cyclic relation has a unit coefficient n_t0; dividing by it occurs in Z/q, and exactly removes that coefficient from the final evaluation. All other terms have determinant one and vanish. |

## Boundary and adversarial checks

- The order statement uses c≥2 at ell=2; no principal-unit order formula is applied at c=1 in residue characteristic two.
- The distinguished block is nonempty because the coordinate (1,0) has character one. The empty-block determinant qualification from SStein is retained elsewhere.
- The ideal powers and divisor coefficients may be negative. They remain fractional-ideal lattices, and all matrix changes have the exact required determinant.
- A coordinatewise Galois change is only L-linear. It is not treated as an F-linear matrix before the block reduction.
- Positive-degree cycles are used when eliminating the trivial complementary representation.
- The residue map is required to be surjective on O_L. The split tensor product is established only after the specified nonzero b is inverted.
- The case nu=c has trivial Galois group and kappa=1 modulo q; all formulas still make sense, and no division by a zero Vandermonde scalar is used.
- The cycle relation and the polynomial value use different normalizations: only n_t0 is inverted, whereas the integer product c_E is retained.

`check_selmer_prisms.py` checks the displayed one- and two-prism identities with exact integer coefficients for S_3 in chain degrees 0–3: 1554 one-prism identities and 9324 two-prism identities passed. These are finite sign checks only; the general proofs are in the manuscript. No number-theoretic claim is inferred from those computations.

No counterexample satisfying the actual hypotheses was found. The remaining source-specific portion of SFew is the stable rational homology bound BOdd, its conversion into SUpper, and the final separation/counting assembly. The alternative exponent-14 K-theory proof does not certify these remaining source dependencies.

## Later status update (21 November 2026)

The mathematical finite-set comparison SFew is now proved in `selmer_finite_set_bound.tex`, Theorem sw-few, using the independently proved arithmetic cycles and the explicitly classical rational homology inputs in `selmer_homology_count.tex`. It has the improved scalar exponent and implies the original source statement. The earlier modular conditional exponent propositions are retained, with their hypothesis now supplied. This does not retrospectively enlarge this trace's source read scope or certify the original differential-form proof of BOdd.
