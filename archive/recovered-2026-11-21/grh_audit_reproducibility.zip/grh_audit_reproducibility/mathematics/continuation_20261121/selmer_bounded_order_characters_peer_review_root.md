# Independent root review: bounded-order characters at exponent one

Reviewed manuscript: `selmer_bounded_order_characters.tex`, 243 lines before the final one-character multiplication correction.
Final reviewed SHA256: `6ece5780b95fdb06b479d8c93c576a1d1e8cc1202b453742d3ee14c26610fda5`.
Outcome: PASS for the stated case Vs estimate and its uniform summation corollary. No counterexample or substantive gap found in this fragment.

The root read the complete fragment. The displayed threshold in SV1 originally contained a comma where multiplication was intended; the author corrected it to the product in the actual source. This was a transcription error in the reconstruction, not a defect in the submitted proof.

Independently inspected source scopes:

- `HeightAndVanishing/DirichletPrimeToLPartMulLPowerPart.lean` 75–225: local components, prime-to-p factor, multiplicative order, exact threshold, Host and case definitions.
- `HeightAndVanishing/CmDatumCharTwoAdicOrderBounds.lean` 45–88: exact threshold bound.
- `HeightAndVanishing/Counts.lean` 45–80: the required exponent-one alternative and fixed-power conclusion.

These paths are relative to `sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/`. The contributing agent separately verified the prime-pair and Host component hypotheses; its source manifest records that inspection.

Mathematical checks:

1. Every odd local inertia image has exponent dividing 2o. Distinct local components act on distinct CRT factors, so their product also has order dividing 2o. Its prime-to-p part has order u dividing 2o.
2. lcm(4,u) divides 4o and is prime to p. The order f is bounded by phi(4o), and 2^nu <= p^f-1 < p^phi(4o). This bounds the threshold by a constant H_p depending only on the fixed data.
3. The small-conductor alternative bounds the full character order by 2oH_p. The character-killing field with mu_p therefore has degree at most 2opH_p before q,d,h vary.
4. The discriminant estimate follows from the tower formula and the derivative norm of the cyclotomic polynomial. It does not require assuming that the cyclotomic order is the full ring of integers.
5. The invariant subgroup over the killing field has length ba, where (p-1)p^(a-1)<=n implies a<=n. The finite cocycle bound loses at most n^2 after ramification normalization. No prime-to-degree assumption is inserted.
6. Applying the already proved coarse strict Selmer estimate at e=1 and bounded degree gives a fixed power of pN_h. It would not give such a power if the degree grew; the manuscript keeps this distinction explicit.
7. There are at most H_p possible local 2-components, M possible components at the odd primes of M, and two at each of q,d. The resulting 4MH_p character count and maximum over the fixed finite prime set give a uniform exponent independent of h,q,d. The empty prime set is explicitly covered.

Limits: this is the bounded-order part of case V, not the high-conductor automorphic case. The uniform sum is a separately proved strengthening of the per-character source statement. This review does not assert a full Lean replay. No numerical experiment is needed for these exact arguments.
