# Bounded-order complementary Selmer characters: source trace

The proof is `selmer_bounded_order_characters.tex`. It proves the exact small-2-power-conductor subcase `HV.CountVs`, with coefficient fields allowed to ramify, and a fixed polynomial bound for the sum of all such characters over a fixed finite prime set. It does not use an automorphy assumption.

All Lean source paths below are relative to `sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/`. Each listed file was read in full.

- `HeightAndVanishing/DirichletPrimeToLPartMulLPowerPart.lean`: the exact definitions th0, th1, c2, f0, n0, R1, the Host character condition, and cases V and Vs.
- `HeightAndVanishing/Counts.lean`: CountVs is the alternative 2^(c2 psi) < R1 for e=1 and p in the fixed finite set.
- `HeightAndVanishing/LayerLe.lean`: specifies the fixed set and the shape of the final counting estimates.
- `HeightAndVanishing/HostComp.lean`: order of each odd local component divides 2o; the q,d components are at most quadratic.
- `HeightAndVanishing/CmDatumCharTwoAdicOrderBounds.lean`: f0 is the order of p modulo lcm(4,order(th1)), n0 is v2(p^f0-1), and R1 is bounded by 16o(pM)^2 p^(2phi(4o)).
- `HeightAndVanishing/PowTotientConductor.lean`: the order of a character under the Vs threshold is bounded by 2o times that fixed threshold bound.
- `HeightAndVanishing/VsField.lean`: the source character-killing field contains mu_p, has degree at most p times order(psi), and lies in Q(mu_(pN)).
- `HeightAndVanishing/CountVs.lean`: uses the coarse K-theory estimate only at exponent one and only after the degree has been bounded in terms of the original character and the fixed bad-prime set.
- `CharacterLevelBounds/ShaFamMono.lean`: coefficient action, normalized length, and level-local-condition monotonicity.

## Ordinary mathematical input and comparison

The note uses the already proved strict Selmer coarse estimate `sw-coarse-consequence` from `selmer_finite_set_bound.tex`, at exponent one. It retains the explicit exponent86, because its value is harmless once degree is bounded. The discriminant inequality D_F <= (pN)^n is proved using the discriminant tower and the derivative norm of a cyclotomic polynomial. The restriction comparison uses the explicit finite invariant module and the finite group cocycle bound proved in the preceding fixed-conductor note; it never divides by the field degree. Coefficient ramification cancels after the prescribed normalization.

The maximum over the fixed finite prime set is taken before growing h, q, d. The final summation also bounds the number of characters by 4M H_p, so neither the exponent nor a hidden character-count factor grows. This is not a general use of the coarse estimate for an unbounded-degree field.

No new unverified literature hypothesis is introduced. The submitted archive is cited in the note; the source-specific route is an arithmetic comparison, not a claim of complete Lean replay. Cases I, II, III and the other half of V remain separate.

## Exact threshold and character-count hypotheses

The fixed modulus called `h.q` in this source is denoted by `M` in the note; the varying first auxiliary prime `h.q1` is denoted by `q`. This distinction is essential in the threshold.

- `HeightAndVanishing/DirichletPrimeToLPartMulLPowerPart.lean`, lines 80--102: the prime-to-p factor, its quotient by the local 2-part, the local conductor exponent, the multiplicative order, and the 2-adic valuation used in SV1.
- The same file, lines 148--164: `Host`, the `PrimePair` condition, `h.q = h.chi.N`, and `N = lcm(2^(h.ex+2),h.q) * (h.q1*h.d)`; lines 179--190 give `IsChar`, `Big`, and the parity-restricted character set; line 206 is exactly `R1 = 16 * h.o * (l*h.q)^2 * 4^(n0 l psi)`.
- `PrimeSetBoundDataOfPrimitiveChar.lean`, line 26: `PrimePair M q d` means that q,d are primes, q is 3 modulo 8, d is 7 modulo 16, and gcd(qd,M)=1. The residue conditions make q,d odd and distinct. Only distinctness, oddness, and coprimality with M are used in SV9.
- `HeightAndVanishing/CmDatumCharTwoAdicOrderBounds.lean`, lines 61--85: the source threshold and the uniform bound by `16*o*(p*M)^2*p^(2*phi(4*o))`, under `Host.IsChar`, primality, and p odd.
- `HeightAndVanishing/Counts.lean`, lines 60--71: the `CountShape` quantifiers and the exact `CountVs` alternative. `Host.CaseV`, defined at line 219 of the first file, restricts p to the fixed set `Bchi` and e to one.
- `HeightAndVanishing/HostComp.lean`, lines 21--24, with proof through line 81: odd local character orders divide 2o, and at primes outside M the components are quadratic or trivial.

SV9 is a separately proved strengthening of the source's individual-character CountVs bound. It sums even over all characters of Gal(E_h/Q), and hence bounds the source's parity-restricted subset. The count `4*M*H_p` follows directly from the Chinese remainder decomposition under the above PrimePair assumptions: at most H_p choices at 2, at most M at the odd part of M, and at most two at each of q,d. Its proof introduces no growing-field-degree factor. The inspected scope for `PrimeSetBoundDataOfPrimitiveChar.lean` is lines 1--155 only; the other files listed above were read in full.
