# Independent review: finite character comparison

Verdict: PASS for the whole-field comparison and its uniform polynomial
error, conditional only on the explicitly retained character-group bounds.

Root read all 435 lines of `selmer_character_comparison.tex`, SHA-256
`7acc18081b77f965aa9a5228c9f79a171ef89ea1248d60e52338c3396184e289`.

## Mathematical checks

- For e >= 1, arithmetic Frobenius acts on the divisible negative Tate
  module by a scalar different from one at every place away from p.
  Multiplication by its difference from one is surjective. Unramified
  local H1 is therefore zero; the strict condition becomes zero on every
  finite decomposition group. The analogous character statement retains
  all extra local conditions at primes dividing pN.
- The explicit coinduction formulas are consistent with the action
  (g f)(delta)=epsilon(g)^(-e) f(gbar^(-1)delta). Root checked the cocycle
  identity and the coboundary in FC6 directly. Local orbit decomposition
  gives the required local Shapiro identifications.
- The Fourier maps have the inverse character in exactly the specified
  coefficient action. Both compositions are multiplication by d. The
  complex-conjugation calculation in FC9 includes the coefficient sign
  (-1)^e; the selected characters have theta(j)=(-1)^e.
- Finite free coefficient extension commutes with continuous cochains,
  kernels, the parity projectors and p-power torsion. Its O-length is
  multiplied by the ramification index, so the normalized length has no
  residual coefficient-field factor.
- The integral Fourier kernel is killed by p^v_p(d); it need not vanish.
  The displayed cyclic-group vector is a nonzero element of that kernel.
  The example does not assert that the same vector is a global Selmer
  class, and is used only to rule out an invalid coefficient isomorphism.
- A p^nu-torsion Selmer class lifts to finite coefficients. Divisibility
  of the inertia invariants away from p makes every lift unramified there.
  Restriction to L(mu_(p^nu)), the elementary inflation kernel bound, and
  ray class reciprocity give FC13. The local unit group has Z_p-rank equal
  to the local degree and at most one cyclic torsion summand, proving the
  stated finite character bound.
- Only the fixed odd primes dividing the original character order cause
  an error in the growing family. The bound uses log h_F, not h_F. Root
  checked each term in FC20 and the constants C_p against d>=1 and
  log N>=log 2. The final error is additive and retains coefficient one
  on every character length and hence on every common-interval bound.

## Source and primary-reference checks

Root checked `LengthEqAddEigen.lean` lines 60--85 for the exact eigenspace;
`CharacterLevelBounds/ShaFamMono.lean` lines 1--95 and 132--163 for the
inverse twist, level and length normalization, and parity character set;
and `Formalism/GaloisCohomology/Statement.lean` lines 1--105 for the strict
negative Tate module. The drafting review's broader 14-file read scope
is recorded separately.

Root independently opened Milne's Class Field Theory v4.03 and read
Chapter V Theorem 1.7 and proof (printed 150--151) and Theorems 3.5--3.6
with the conductor description (printed 158). These give exactly the ray
class sequence and ramification-supported modulus used in FC14. No claim
of independent review of the whole book is made.

## Limits

The remaining automorphic character-length estimates are still hypotheses
of FC18. This comparison does not derive them from rational adjoint
vanishing and does not certify the complete GRH proof or a local kernel
replay. No counterexample to the stated comparison was found.
