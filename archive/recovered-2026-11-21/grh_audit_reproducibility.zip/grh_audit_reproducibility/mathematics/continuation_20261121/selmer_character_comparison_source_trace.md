# Finite character comparison: precise source trace

The proof is selmer_character_comparison.tex, equations FC1--FC20. It gives a conventional mathematical replacement for the whole-field-to-character comparison in the complementary-parity estimate. It does not assert the remaining automorphic character bounds.

## Exact definitions and target

Except where explicitly stated otherwise, paths below are relative to sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/.

- LengthEqAddEigen.lean, full 193 lines, especially lines 66--78: ShaPlus is the eigenspace of the actual Galois conjugation action with eigenvalue (-1)^e. The negative summand has eigenvalue (-1)^(e+1). FC1 retains this convention.
- PartsConj.lean, full 279 lines: the Galois action conjugates the cohomology argument and acts on coefficients; the coefficient scalar at line 141 is the inverse e-th cyclotomic power. FC9 checks this action explicitly for the chosen coinduction convention.
- CharacterLevelBounds/ShaFamMono.lean, full 162 lines: rho is psi^-1 * chiO^(-e) (line 18); V' is the local-kernel length at level p*N (line 35); nrm divides by the coefficient ramification index (line 75); evenSet is the set of characters factoring through the chosen field and taking value (-1)^e at -1 (line 145). These are exactly FC2 and FC10.
- GaloisLibrary/SelmerTransport/ConjStableShaFam.lean, lines 65--130 only: the underlying local family is formed from decomposition groups above the level and inertia at every finite prime. The local scalar argument in FC proves that the strict group over L is already zero on every finite decomposition group for e>=1.
- sources/lean/src/Formalism/GaloisCohomology/Statement.lean, lines 1--90 only: the original strict local conditions and negative Tate twist. This path is relative to the workspace, not to the preceding directory.
- GaloisLibrary/GaloisCohomologyLength/LevelInertiaLeLevelDec.lean, read in full: the source's passage between inertia and decomposition local conditions. The new proof uses the direct local vanishing calculation and does not need its numerical loss.
- CharacterLevelBounds/ReductionToDirichletCharAnyLevelOfLe.lean, full 106 lines, and HeightAndVanishing/RedAll.lean, full 21 lines: the actual whole-field comparison uses V', the exact parity-restricted character set, and a summation of normalized error terms. FC supplies a separate sufficient comparison with one global torsion error, rather than claiming to reproduce that error formula.

## Family, quantifiers, and error

The following source files were read in full:

- HeightAndVanishing/LayerLe.lean (48 lines);
- HeightAndVanishing/LossLe.lean (54 lines);
- HeightAndVanishing/HostIndex.lean (164 lines);
- HeightAndVanishing/DirichletPrimeToLPartMulLPowerPart.lean (237 lines);
- HeightAndVanishing/FinalLe.lean (263 lines).

The last file was inspected through a requested window ending at line 310; the actual file ends at line 263, so this was a full read. PrimeSetBoundDataOfPrimitiveChar.lean was inspected only through line 155 in the preceding review. The exact family and fixed data are already written in selmer_fixed_conductor_restriction.tex and selmer_bounded_order_characters.tex: the original character has fixed conductor M and order o; the growing fields are K_chi R_h(sqrt(-q),sqrt(-d_0)); their degrees divide 2^(h+2)o and they lie in Q(mu_(N_h)).

The integral Fourier maps satisfy GF=FG=[L:Q]. They are inverse isomorphisms when p does not divide [L:Q]. At other odd primes the kernel is contained in the p^v_p([L:Q])-torsion of the strict Selmer group. In this family only the fixed odd primes dividing o occur, and v_p([L:Q])<=v_p(o). The Fourier counterexample with the vector (1/(zeta_p-1),-1/(zeta_p-1),0,...) shows why this torsion error cannot simply be discarded.

The finite-coefficient bound is proved by inflation--restriction followed by global reciprocity and local principal-unit structure. Its logarithm is bounded using the existing class-number estimate in selmer_layer.tex and the discriminant argument in selmer_bounded_order_characters.tex. It uses log(h_F), not h_F, in the final length estimate. After summing, the error is C_o N_h^2(t-1)log N_h, with C_o fixed before h,q,d_0,t or any coefficient extension. Normalization by the ramification index cancels coefficient extension exactly. Thus an additive C B character bound remains C B.

## Primary input checked directly

J. S. Milne, *Class Field Theory*, version 4.03 (6 August 2020):
https://www.jmilne.org/math/CourseNotes/CFT.pdf.

- Chapter V, Theorem 1.7 and its proof: printed pages 150--151, PDF pages 159--160 (one-based). The exact ray class sequence has kernel a quotient of local units, with the real sign factors displayed separately.
- Chapter V, Theorems 3.5--3.6 and following ray class field description: printed page 158, PDF page 167 (one-based). Reciprocity gives a defining modulus supported exactly on ramified primes.

These passages were opened directly in the web reader on 21 November 2026, including the extracted intervals 8653--8745 and 9190--9240. Only these passages, not the complete book, are claimed as inspected. The odd p-primary characters are trivial on real inertia. The local unit bound itself is proved in the note by the logarithm and exponential on a deep principal-unit subgroup, plus the structure theorem for finitely generated Z_p-modules.

## Scope

This is an ordinary mathematical proof of the character comparison and its required uniform error. It is not a complete Lean replay. The source inventory is conservative: partial reads are recorded as partial reads. Finiteness and quantitative bounds for the remaining automorphic character groups remain explicit hypotheses of FC18. The source's rational adjoint vanishing has been reconstructed separately in selmer_adjoint_vanishing.tex; rational vanishing alone does not supply those integral length bounds.
