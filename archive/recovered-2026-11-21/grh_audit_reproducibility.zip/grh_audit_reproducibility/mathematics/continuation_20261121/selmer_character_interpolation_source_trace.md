# Source trace: integral interpolation of cyclic characters

Date: 21 November 2026. Fragment: `selmer_character_interpolation.tex` (172 lines).

## Exact input and output

For q=ell^nu, c≤nu, M<ell^c, and a distinguished t0 in {0,...,M}, the source requires an integer-valued function eta on (Z/q)^2. Its pushforward under (x,y)↦x+ty is zero at all t≠t0 and is the prescribed sum of point masses at (1+ell^c)^i at t0. Their coefficients are those of the degree-M polynomial product over j<M of T−(1+ell^c)^j. Integer coefficients are essential because eta supplies powers of fractional ideals later.

The fragment proves this statement exactly. It first proves divisibility of the corresponding polynomial in Z[X] by (X^(ell^c)−1)^M using the substitution operator X↦X^(1+ell^c). It then maps to the integral group ring and writes an explicit product whose unwanted pushforwards vanish. It never inverts a slope difference in Z/q and never cancels a zero divisor in the group ring.

## Source text actually read

Paths relative to `sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/ModularityArgument/ClassCounting/`:

- `ExpStep.lean`: all 182 lines. The source's `exp_step` and `exp_dvd` are the polynomial divisibility; `nat_dvd` and `diff_dvd` are the prime-power slope divisibility; `alg_dvd` and `sEta` give the group-ring construction.
- `LemmaKOfSteps.lean`: all 178 lines read previously and the relevant definitions reread. SEta is defined at lines 71–76.
- `LatticeBlockClasses/CJoin.lean`: all 187 lines, including the use at M=2e+3=2E+1 and the subsequent use of eta as ideal exponents.
- `LatticeBlockClasses/GtEqZeta.lean`: complete file, for the character-block regrouping to which eta is supplied.

## Boundary checks and limits

The proof includes M=0 and c=nu. In the latter case the group-ring element [ell^c]−1 is zero, and for M>0 the polynomial image is also zero by proved divisibility. The construction is therefore valid without a nonzero-divisor assumption. Negative differences of slopes are treated by factoring their ell-adic valuation and inverting their prime-to-ell part modulo q. No counterexample satisfying the actual hypotheses was found.

This closes SEta only. It does not by itself produce the arithmetic cycle or the finite-field homology functional.
