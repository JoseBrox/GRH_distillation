# Independent root review of the comparison reduction and SSha

The root reviewed all of selmer_comparison_reduction.tex and
selmer_comparison_proofs.tex on 21 November 2026.
No mathematical defect was found.

## Reduction

The exact valuation 2Ec+2v_p(E!) follows from distances 1,...,E
occurring twice. The p=2,c=1 counterexample is correct and excluded.
The improved scalar exponent does not by itself prove stronger SFew.
The numerical propagation C -> 5(max(C,9)+2)+11 was checked through
every estimate, including the degree and discriminant enlargement.
C=13 gives 86 and the source's C=24 gives 141.
At the time the fragment was written all four comparisons were
isolated. The later sections now prove SCount, SSha, SLayer and the
class-number estimate; SFew remains the substantive source input.

## SSha

- The restriction to the infinite cyclotomic kernel is injective
  because (1+p^c)^(-E)-1 is nonzero and surjective on Q_p/Z_p.
- A continuous cocycle on compact G_L has finite image.
- The local coboundaries at p can be bounded uniformly over all
  conjugate decomposition groups, using the finite image of the
  cocycle and the explicit conjugation formula.
- At a sufficiently high level, cocycles become homomorphisms with
  values in A[p^nu] and vanish on every finite inertia group.
- Hilbert class field reciprocity is correctly stated as a classical
  input; total imaginaryness avoids narrow-class-group distinctions.
- The Frobenius conjugation formula gives phi(gamma P)=kappa^(-E)phi(P),
  exactly equivalent to the source's inverse-gamma relation.
- Distinct classes remain distinct on G_infinity and hence give
  distinct class-group characters at the chosen finite level.
- The uniform bound applies to every finite subset, which proves
  finiteness before taking the Z_p-length.

The argument does not use generic injectivity of restriction in an
arbitrary finite p-extension, and it retains the nonzero twist.
The review is an ordinary mathematical review, not a kernel replay.
