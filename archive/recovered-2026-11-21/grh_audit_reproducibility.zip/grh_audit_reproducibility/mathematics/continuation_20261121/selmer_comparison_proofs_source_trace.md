# Source trace for the strict Selmer character comparison

Date: 2026-11-21 UTC. Conventional fragment: `selmer_comparison_proofs.tex` (310 lines; three pages in the isolated typesetting check).

## Exact statement and completed mathematics

The fragment proves the source interface SSha, stated as assertion sc-sha in `selmer_comparison_reduction.tex`. The coefficient module is `Q_l/Z_l(-E)` with `E >= 1`. The strict local condition is zero on decomposition groups at primes over `l`, and unramifiedness at all other finite primes. The root exponent `c` is the largest one in the base field, with `c >= 1` and `c >= 2` at `l=2`. A uniform bound on all the equivariant class-group character sets in the specified cyclic layers bounds the order, and therefore the `Z_l`-length, of the strict Selmer group.

The new ordinary proof gives the following steps in full:

- injectivity of restriction to the infinite cyclotomic kernel for the nonzero negative twist, by division by the nonzero scalar `kappa^(-E)-1`;
- finite images of continuous cocycles and a common exponent for a finite family of classes and all chosen local coboundaries;
- passage to every sufficiently deep finite cyclotomic layer;
- zero decomposition restrictions above `l`, uniformly over all conjugate decomposition groups, using the exact cocycle conjugation identity;
- unramifiedness at the other primes, including the cyclotomic inertia explanation;
- the inverse-gamma equivariance required by EqHom, namely `phi(gamma^(-1) P)=kappa^E phi(P)`;
- injectivity on each prescribed finite set, rather than an unsupported generic injectivity of finite-extension restriction;
- the finite-subset argument and the equality of finite `l`-primary order with `l` to the module length.

The only large classical theorem imported in this fragment is Hilbert class field reciprocity. The exact form is stated as SP1. The cyclotomic image calculation is supplied by the separately reconstructed `selmer_layer.tex`.

## Lean source read scope

The primary file is

`sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/ModularityArgument/ClassCounting/RingEquivalences/OrderOfOneAddPrimePowZmodPrimePow.lean`.

All 490 lines were read, over the successive bounded reads recorded during this task. Transitive imports were not all independently read.

| Source lines | Declaration or role | Conventional counterpart |
| --- | --- | --- |
| 26–40 | LayEx, ClInj, ShaAsm interfaces | Parameters SC3, character injection, and SSha |
| 79–106 | Order of `1+l^c` modulo `l^nu` | Earlier exact valuation and cyclotomic-layer lemmas |
| 108–206 | LayEx_holds | The layers and generators used before SP4 |
| 213–259 | Class-group and prime-divisor auxiliary maps | Prime classes generate the class group and principal-divisor relations |
| 265–332 | ClInj_holds | SP9, prime characters and exact inverse-gamma equation |
| 348–410 | tors_fun, pow_smul_of_le, procyc_of_top, Good, up, good_of | Replaced by the bounded-image continuous-cocycle construction in sp-finite-level |
| 412–450 | card_le | Injection of each finite set into one sufficiently deep EqHom set |
| 454–486 | ShaAsm_holds | sp-restriction and sp-sha |
| 490 | sSha | The completed provider |

The source interface in `ClassCounting/LemmaKOfSteps.lean` was fully read in the earlier reduction task and is listed in that task's manifest. The fragment uses that exact interface, without inferring global class-group bounds from the mere existence of the source provider.

## Primary external reference

J. S. Milne, *Class Field Theory*, version 4.03, 6 August 2020, Chapter V, section 3, Theorems 3.5–3.6 and Example 3.9, printed pages 158–159. Official source: https://www.jmilne.org/math/CourseNotes/CFT.pdf . The theorem and the Hilbert class field example were opened and checked in the official PDF during this task. They are cited in the TeX under `milne-cft`. The TeX explicitly does not claim a proof of global class field theory.

## Adversarial checks and remaining scope

The zero-twist case gives nonzero homomorphisms from `Z_l` to `Q_l/Z_l` and would invalidate the restriction argument; it is explicitly excluded by `E >= 1`. A degree divisible by `l` does not in general make cohomological restriction injective; this proof does not use that assertion. The conjugation calculation retains both the negative Tate twist and the inverse on gamma. Local coboundary exponents are bounded uniformly over all conjugate decomposition groups, rather than only the finitely many representatives initially selected.

No counterexample satisfying the actual hypotheses was found. The root agent independently reviewed the complete fragment and reported no defect, specifically confirming the negative-twist convention and all conjugate local coboundaries. A new global class-count bound is not supplied by SSha alone: SFew remains a separate substantive comparison. SCount and SLayer are proved in their own later fragments.

The added corollary sp-conditional-coarse assembles the now-proved SCount, SSha and SLayer with the proved homology exponent 13: under the remaining SFew assertion it gives strict Selmer exponent 86 and, using the explicitly stated classical duality inputs, H² exponent 88. It does not claim a proof of SFew.

The recorded XeLaTeX check is a typesetting check only. There was no new large proof-export scan or kernel run.

## Later status update (21 November 2026)

The mathematical finite-set comparison SFew is now proved in `selmer_finite_set_bound.tex`, Theorem sw-few, using the independently proved arithmetic cycles and the explicitly classical rational homology inputs in `selmer_homology_count.tex`. It has the improved scalar exponent and implies the original source statement. The earlier modular conditional exponent propositions are retained, with their hypothesis now supplied. This does not retrospectively enlarge this trace's source read scope or certify the original differential-form proof of BOdd.
