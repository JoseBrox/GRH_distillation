# Strict Selmer comparison: exact remaining route

Date: 21 November 2026 (UTC).

## Stable result

selmer_comparison_reduction.tex is a four-page conventional fragment. It proves:

1. the exact valuation v_l(P_E)=2E c+2v_l(E!) for the scalar in the actual class construction;
2. the resulting scalar cancellation power 2E(c+1)+2v_l(E!);
3. the complete conditional exponent propagation C -> 5(max(C,9)+2)+11, and hence 13 -> 86.

It does not claim to prove SFew, SCount, SSha or SLayer. The bound for the class number remains explicitly imported in this fragment. In particular, the sharper cancellation scalar alone does not prove the stronger SFew statement.

## Shortest dependency chain

All paths below are relative to sources/lean/src/.

The direct route from the now-proved homology estimate to the strict Selmer length is:

- Development/AutomorphicArithmetic/AutomorphicVarieties/ModularityArgument/ClassCounting/ExponentLe.lean: sTors supplies STors.
- ClassCounting/LemmaKOfSteps.lean: SNum, lines 165–165, takes SFew, SCount, SSha, SLayer and STors as inputs.
- ClassCounting/NumThree.lean: sNum, lines 211–378, supplies that numerical implication.
- ShaK, LemmaKOfSteps.lean lines 161–164, is the uniform finite strict Selmer length bound.
- The later SFinal comparison is separate; it passes from the strict Selmer length to H^2 using global and local duality.

There is no direct implication STors -> ShaK in the submitted source.

## Definitions and exact hypotheses

ClassCounting/HasVal.lean, lines 113–141, defines the arithmetic objects translated in SC3–SC7:

- Lay: K/L is Galois, gamma generates its cyclic Galois group, zeta is a primitive l^nu-th root, gamma(zeta)=zeta^(1+l^c), order(gamma)=l^(nu-c), 1<=c<=nu, and c>=2 if l=2.
- DivDel: v_P(alpha)=d_(gamma P)-a d_P. The direction of gamma is preserved.
- nrm: product over j from 0 to order(gamma)-1 of gamma^j(alpha)^(a^j). This weighted product is not the ordinary field norm.
- EqHom: functions on finite primes annihilating every principal divisor, with phi(gamma^(-1)P)=a phi(P). The inverse is preserved.
- pe: product of kappa^E-kappa^j over j in [0,M) except E. At e=E-1 in the actual SFew route, M=2E+1, so this is exactly the P_E of SC16.

The direction of actP was additionally checked against Mathlib/RingTheory/DedekindDomain/Ideal/Lemmas.lean lines 579–604: equivOfRingEquiv maps a prime via comap of the inverse, hence the ordinary image prime. CountOrdP.lean was read in full to check that ordP is the usual principal-divisor exponent.

The actual coefficient representation is the negative twist. Formalism/GaloisCohomology/Statement.lean lines 67–78 defines qzTw using chi^(-e), and the strict local kernel Sha. GaloisLibrary/GaloisCohomologyLength/LevelInertiaLeLevelDec.lean defines shaInv as the Z_l-length of absolute classes trivial on decomposition groups above l and inertia groups away from l.

GeneratorCountTuples/LemmaK.lean line 9 defines HasMuQ as mu_l for odd l and mu_4 for l=2. Replacing the latter by mu_2 would weaken an essential hypothesis.

## The four remaining providers

### SFew

Definition: ClassCounting/LemmaKOfSteps.lean lines 131–137.

For a totally imaginary base field, Lay data and E>=1, with 2E+1<l^c and 2E+1<r_2(L), it bounds sets of distinct classes of weighted products after the power l^b, with

    b = 2E + (2E+1)(c+2E+1),
    B = (l^nu)^(r_2(L)) * t_L(4E+6,2E+1) * t_L(4E+6,2E).

Actual assembly:

    FinSFewOf.lean
      -> Development/EtaleCohomology/CyclotomicDiscriminants/SFewOfCut.lean
      -> sFewOf(STheta, SPhi, SClass, SUpper, SDetect).

SFewOfCut was read in full. It constructs a product of residue-field functionals outside a finite bad-prime set, proves injectivity using SDetect, and applies SUpper to a finite image set. The key cancellation uses pe_dvd, lines 68–83 of that file, and the equality of l^(2e+2)-scaled evaluations. The valuation lemma in the new TeX fragment replaces only that cancellation estimate.

SUpper is supplied by ClassCounting/SUpperOf.lean from Bockstein, stability, rank and finite-fiber inputs. Its BOdd input is an odd-degree rational rank bound for a sequence formed from repeated block-diagonal maps. ClassCounting/BOdd.lean only forwards LiteratureResults/KTheoryStability/ReductionBoundsTorsion/TorsionIntegers/Bridge.bOdd_zk. That deeper result was not reconstructed in this task.

SClass contains the actual integral homology class construction, not merely a torsion bound. The relevant full construction and the finite-field STheta/SPhi providers remain outside this task.

### SCount

Definition: ClassCounting/LemmaKOfSteps.lean lines 123–129.
Actual provider: ClassCounting/SelmerOrderCounts.lean, sCount, all 111 lines.

For totally imaginary L, Lay data, E>=1, and any b,B satisfying the finite-set assertion Few, it gives

    |EqHom| (l^nu)^(r_2(L))
       <= B * l^((b+v_l(E))*g_L+c+v_l(E)),

where g_L=2[L:Q]+floor(log_2 h_L)+2.

The proof assembles the separate modules DatEx, CardEQ, EqHomLe, SelLCard, SelInvLe, KerFDelNm and PCount. It uses the exact valuation

    v_l((1+l^c)^E-1) = c+v_l(E),
    v_l((1+l^c)^(E*l^(nu-c))-1) = nu+v_l(E).

The provider TorsionExponentBound.lean was read in full and has the correct c>=2 condition at l=2. Most of the remaining divisor/unit module providers were not read here, and their conclusions are not treated as proved in the conventional fragment.

### SSha

Definition: ClassCounting/LemmaKOfSteps.lean lines 143–147.

The base L is totally imaginary and contains mu_(l^c) but not mu_(l^(c+1)), with c>=1 and c>=2 at 2. A uniform bound B on EqHom over every cyclic datum in the tower implies finite strict Selmer length s and l^s<=B.

The actual provider is PositivityTheory.QuaternionShaBounds.sSha at the end of

    ClassCounting/RingEquivalences/OrderOfOneAddPrimePowZmodPrimePow.lean.

It assembles LayEx and ClInj through ShaAsm. Only lines 1–100 were read for this initial trace: they state the exact intermediate interfaces and begin the root-order calculation. The larger Kummer, class-field and length comparison proof is not represented as already reconstructed. It is the next chosen target of the formal-verification lane.

### SLayer

Definition: ClassCounting/LemmaKOfSteps.lean lines 149–155.
Actual assembly:

    Development/EtaleCohomology/CyclotomicDiscriminants/FinSLayer.lean
      -> SLayerCut.lean, goal_of.

SLayerCut was read in full. It chooses m=ceil(log_l(4E+4)), a cyclotomic layer of degree l^m, and the maximal root exponent c in that layer. The resulting inequalities are exactly SC13. The underlying abstract SLayer interface only asks for the fields and numerical invariants, while its actual provider constructs the cyclotomic extension stated in SC13.

The discriminant bound is proved in disc_cyc using the different and the derivative of X^q-1. The strict Selmer length comparison sha_le uses NumberFieldTowers/ExistsDescends.exists_descends and compares the images of g^(l^m)-1 and g-1. It is not justified by generic injectivity of restriction in an l-power extension. The parent is separately reconstructing this provider in selmer_layer.tex.

## Class-number input and numerical propagation

NumThree.gens_le, lines 186–208, calls GeneratorCountTuples/NumGens.lean.
That theorem calls

    Development/AutomorphicArithmetic/CyclotomicBounds/
    ClassNumberBounds/IdealCounting/ClassC.lean,
    log_classNumber_le.

ClassC was read in full. It obtains

    log h_L <= (1/2) log D_L + n_L log(1+(1/2) log D_L)

from the small-ideal representative theorem and ideal-counting providers ClassA and ClassB. Those latter providers were not read in this task. The manuscript therefore isolates SC14 as imported, with the exact weaker consequence SC15 used in the numerical proof.

NumThree.sNum fixes E=k+1 and cancels the factor (l^nu)^(r_2(L')) between SFew and SCount. Its two torsion factors are at degrees 2E+1 and 2E and rank 4E+6, exactly the now-proved homology range. It obtains a field-level exponent max(C,9)+2; descent of degree and discriminant then multiplies this by five and adds eleven. SC21 proves this calculation independently in ordinary inequalities.

Thus:

- submitted C=24 gives conditional exponent 141;
- reconstructed homology C=13 gives conditional exponent 86.

No stronger global conclusion is asserted before the comparison providers are proved.

## Focused adversarial checks

1. The valuation condition at 2 is real: with c=1, v_2(3^2-1)=3 differs from 1+v_2(2)=2. The actual Lay and LTE providers exclude this by c>=2.
2. The case nu=c is permitted. The extension is then trivial; q remains positive, the displayed equivariance and scalar bounds make sense, and the valuations reduce correctly.
3. The cyclic group order is l^(nu-c), not l^nu.
4. SFew distinguishes weighted-product classes only after the specified l-power. The assertion is not a bound on all admissible alpha; the finite set and injectivity hypotheses are necessary.
5. A smaller power in SFew is a stronger result and is not implied merely by a larger-power Few statement. The new exact valuation is only the scalar part of the strengthened proof.
6. The factor q^(r_2(L)) is positive and can be cancelled in the cardinality comparison. No logarithm of zero is taken in the ordinary proof; each torsion group is finite and contains its zero element.
7. The fields in the odd-degree rank input satisfy 2E+1<r_2(L') after the enlargement. Small base fields need that enlargement; the rank hypothesis is not omitted.
8. The detection provider SDetectCut was read fully. It uses degree-one primes over Q, whose prime residue fields receive a surjective map from O_L automatically. The unrestricted number-field extension in SDetect is therefore not silently assumed Galois.
9. The converse direction in residue-key orbit counting and an O_F-basis for common minimal columns are nowhere assumed.
10. No counterexample satisfying all actual hypotheses was found in these focused checks.

## Read scope and compile status

selmer_comparison_source_manifest.json records exact full and partial read intervals, source hashes and artifact hashes. The initial 1–100 line read of the 490-line SSha assembly file is explicitly partial. Subsequent work on SSha has its own scope record.

selmer_comparison_check.tex compiles with XeLaTeX to four pages, with no overfull boxes. The isolated wrapper has the expected external ac-section and shared bibliography references. This check verifies typesetting only.


## Later completion status

The initial scope above is historical and applies to the comparison-reduction fragment itself. The subsequent selmer_layer.tex and selmer_unit_count.tex now prove SLayer and SCount, including the required class-number and unit results. selmer_comparison_proofs.tex proves SSha from explicitly stated Hilbert class field reciprocity. selmer_detection.tex and selmer_homology_cycles.tex prove the detection, cyclic-cycle and cyclic-relation inputs to SFew. Its remaining finite-field cohomology/class-construction step is still separate. k_theory_coarse.tex gives an independent proof of the coarse H2/Selmer bound with exponent14 from named classical K-theory and duality results; it does not certify the source-specific SFew construction.

## Later status update (21 November 2026)

The mathematical finite-set comparison SFew is now proved in `selmer_finite_set_bound.tex`, Theorem sw-few, using the independently proved arithmetic cycles and the explicitly classical rational homology inputs in `selmer_homology_count.tex`. It has the improved scalar exponent and implies the original source statement. The earlier modular conditional exponent propositions are retained, with their hypothesis now supplied. This does not retrospectively enlarge this trace's source read scope or certify the original differential-form proof of BOdd.
