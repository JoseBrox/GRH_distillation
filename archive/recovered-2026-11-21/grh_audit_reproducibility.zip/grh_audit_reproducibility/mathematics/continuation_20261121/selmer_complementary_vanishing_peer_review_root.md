# Independent review of the exceptional complementary Selmer case

Root review, 2026-11-21. All 264 lines of
selmer_complementary_vanishing.tex were read at SHA-256
94f64e5905e55e5937c9e8407a24f2b09b1b5554d36ef5dcf018d40426d99e9b.
The proof passes independent review.

Continuity into the discrete torsion module gives finite cocycle
image, hence primary torsion of every class. The local cyclotomic
image at p is the full Z_p^*, by the Eisenstein cyclotomic polynomial
at every p-power level. Thus the global and p-local invariant
subgroups of A_e agree, including for ramified coefficient rings.
The long exact sequence for multiplication by the coefficient
uniformizer allows a residual lift to be adjusted by a global
connecting class to vanish at p. Local injectivity of the connecting
map proves that this adjusted cohomology class is unique. Inertia
away from p has trivial action on the divisible module, so the
residual lift is unramified there as well.

Restriction to the field cut out by the residual character is
injective by prime-to-p inflation--restriction. The restricted
cocycle is a homomorphism with zero finite inertia, and its odd-order
image also kills real inertia. It therefore factors through the
ordinary ideal class group. This proves the stated residual injection
and its k-dimension bound. It does not give an estimate for the full
length when the residual group is nonzero.

If p-1 divides e the residual field is Q and the group vanishes.
If e is even and p-1 divides 2e but not e, then p is 1 modulo 4 and
the residual field is Q(sqrt(p)). The already proved small-ideal
count gives h <= sqrt(p)(1+log sqrt(p)) < p, so its p-part is zero.
The torsion observation then gives vanishing of the full strict
Selmer group, not only of its uniformizer-torsion subgroup.

Root source comparison (all paths below the AutomorphicVarieties
directory): CharacterLevelBounds/ShaFamMono.lean1--110;
HeightAndVanishing/Counts.lean1--90;
HeightAndVanishing/DirichletPrimeToLPartMulLPowerPart.lean1--48,
96--122; GaloisLibrary/SelmerTransport/ConjStableShaFam.lean65--105;
GaloisLibrary/SelmerTransport/RestrictionMemInvariantH1.lean1--44,
65--80; HeightAndVanishing/CountZ.lean in full. The signs, parity,
additional level conditions and PropZ quantifiers agree. A finite
discrete valuation subalgebra of Q_p^alg over Z_p is the ring of
integers of its finite fraction field, so the stated coefficient
range covers the actual Coef structure.

The root directly opened Milne, Class Field Theory version 4.03,
Chapter V section 3, Theorems 3.5--3.6 and Example 3.9, including
the distinction between ordinary and narrow class groups:
https://www.jmilne.org/math/CourseNotes/CFT.pdf . Only the explicit
class-field reciprocity input is imported here.

No counterexample to the assertion with its actual local conditions
was found. The proof does not treat nontrivial Dirichlet characters,
nor establish the remaining complementary-parity counting estimates.
No full Lean kernel replay is claimed.


## Integration correction

Only the section label was changed from sz-section to sz-selmer-section, avoiding a collision with the previously included quadratic determinant argument. No mathematical text changed. Updated artifact SHA256: `9dd9e2015ee4be050164761bec5bf765ccfd9274eb0999c601bfca5d2573e231`.
