# Trivial-character complementary Selmer vanishing: source trace

The conventional proof is `selmer_complementary_vanishing.tex`. It proves the source's full `HV.PropZ` and hence `HV.CountZ`, for arbitrary finite ramified coefficient extensions. It also proves the stronger residual-class-group injection for every exponent e. It does not prove the other complementary-parity counting assertions.

## Exact source interface

All paths in this paragraph are under `sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/`.

- `CharacterLevelBounds/ShaFamMono.lean`, fully read: `Chr.Psi`, `Chr.rho`, `Chr.V`, and `Chr.V'` at lines 15–34 use the inverse character times the negative cyclotomic twist. The theorem `V'_le_V` follows from imposing additional zero local conditions.
- `GaloisLibrary/SelmerTransport/ConjStableShaFam.lean`, lines 65–125 inspected; `shaFam` is defined at lines 94–96 as decomposition groups above divisors of the integer level together with inertia groups everywhere.
- `GaloisLibrary/SelmerTransport/RestrictionMemInvariantH1.lean`, lines 1–125 inspected; `LocSel` at lines 73–74 is the intersection of restriction kernels.
- `HeightAndVanishing/DirichletPrimeToLPartMulLPowerPart.lean`, fully read: `PsiEven` is the condition psi(-1)=(-1)^e at line104, and `Vlen` is the level-N group at line117.
- `HeightAndVanishing/Counts.lean`, fully read: `PropZ` at lines49–51 is precisely vanishing for p>=5, even e>=2 and p-1 dividing 2e; `CountZ` is defined at line73.
- `LevelCohomology/TorsClass.lean`, all205lines read: `zOne` at line97 handles p-1 dividing e by a longer control-theoretic route. The conventional proof instead adjusts the residual lift directly using equality of global and p-local cyclotomic invariant subgroups.
- `LevelCohomology/ZqField.lean`, all233lines read: `zQuad` at line228 handles the quadratic residual character. The conventional proof makes the restriction to Q(sqrt(p)), its local conditions, the class-group bound, and the injectivity of restriction explicit.
- `LevelCohomology/HQuad.lean`, all35lines read: the class-number bound agrees exactly with the small-ideal and ideal-count proof already in the ordinary manuscript.
- `LevelCohomology/PropZ.lean`, all16lines read: combines the two divisibility cases.
- `HeightAndVanishing/Cases.lean`, all48lines read; and `HeightAndVanishing/CountZ.lean`, all32lines read: outside the fixed bad-prime set, the trivial character has even exponent; the prime is >=5 and V'<=V transfers vanishing.

## Primary mathematical input

J. S. Milne, *Class Field Theory*, version4.03 (6August2020), ChapterV section3, Theorems3.5–3.6 and Example3.9. Author PDF: https://www.jmilne.org/math/CourseNotes/CFT.pdf. The relevant statements were opened directly in the web reader on21November2026, PDFpages166–167 (printedpages158–159), especially lines9190–9289 in the extracted reader. The source asserts the ordinary class-group description of the everywhere unramified abelian extension, including real places. The odd residual characteristic makes homomorphisms vanish on real inertia automatically. No class-field theorem is used without checking this distinction.

## Scope and checks

The argument is independent of the source's K-theory and automorphy providers. It uses continuous cohomology of discrete torsion modules, the long exact sequence, prime-to-p inflation–restriction, the elementary local cyclotomic extension calculation, Hilbert class-field reciprocity, and the previously proved ideal-count estimate. It gives an injection of the residual torsion into a finite class-group character group, not a general bound on the full length. No full Lean replay or unconditional bound for nontrivial Dirichlet characters is claimed.
