# Independent root review of power detection and cyclic homology

Date: 21 November 2026. Reviewer: root.

Read selmer_detection.tex and selmer_homology_cycles.tex completely. The lift to a normal closure over Q, choice of actual Frobenius at a prime, and fixed-residue argument correctly give absolute residue degree 1. The roots-of-unity reduction and Kummer argument are sound; Milne ANT 8.31 was directly checked. The 16/eighth-power counterexample is correct at every odd prime. For the cycles, checked all bar-face cancellations, exactness and A-splitting of the periodic cyclic resolution, the two-factor total complex, the rank m+1 calculation, primitive integer kernel relation, and the mod 6 counterexample. The finite-field cohomology functional and arithmetic class construction remain outside these two fragments.

Snapshot SHA256: 64f5a078fbc8d16d5f55eadcd9f9aa62022a2681ce64d8ad5ac9be14bb80a8d7
