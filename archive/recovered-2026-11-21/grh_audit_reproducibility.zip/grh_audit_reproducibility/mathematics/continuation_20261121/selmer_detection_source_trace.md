# Source trace: detection of global powers

Date: 21 November 2026. Fragment: `selmer_detection.tex` (192 lines at recording).

## Actual assertion

The source's SDetect assertion requires a number field F containing all q-th roots of unity, an element beta of F*, and a nonzero element b of O_F. At every prime P not dividing b for which O_L→O_F/P is surjective, beta must have a nonzero residue which is a q-th power. It concludes that beta is a global q-th power. The source has q=ell^nu; the conventional proof permits every q≥1.

The manuscript proves the exact assertion by a slightly stronger statement using only primes of absolute residue degree one. Such primes automatically have the required surjectivity from O_L. Neither F/L normality nor a quantitative Chebotarev bound is used.

## Source files read

- `Development/EtaleCohomology/CyclotomicDiscriminants/SDetectCut.lean`: complete 144 lines.
- `Development/AbelianVarietyTheory/Proofs/InertiaEigenvalues/ChebotarevDegreeOne.lean`: complete 71 lines.
- `Development/EtaleCohomology/CyclotomicDiscriminants/SFewOfCut.lean`: complete 215 lines, for the actual use of SDetect after the finite-field functional and Vandermonde argument.

All these paths are relative to `sources/lean/src/`. The manifest records hashes and exact file lengths independently of this prose.

## Classical input

Milne, *Algebraic Number Theory*, Theorem 8.31 (Chebotarev):
https://www.jmilne.org/math/CourseNotes/ANT.pdf

The official PDF's theorem statement was read through the web tool; the parent independently checked it. Only the qualitative statement over Q is imported. The degree-one consequence over a possibly nonnormal field is proved in full by passing to a normal closure, lifting the desired Frobenius, choosing the exact conjugate at a prime, and observing that it fixes O_F while acting by the rational Frobenius on the residue field.

## Counterexample search and limitations

The full power-detection claim is proved, including q=1, fractional beta, excluded bad primes, and residue roots of unity. The counterexample beta=16, q=8 over Q shows precisely why the roots-of-unity hypothesis cannot be deleted. It violates the actual hypothesis and is not a flaw in the source. No counterexample satisfying the actual hypotheses was found.

This closes SDetect only. It does not establish the finite-field homology functional, its stable extension, or the integral arithmetic class construction used earlier in SFew. Parent `/root` independently reviewed the whole conventional proof and found no defect.
