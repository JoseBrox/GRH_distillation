# Independent review of two elementary arithmetic-cycle inputs

Reviewer: root. Date: 21 November 2026.

Both fragments were read in full. No mathematical defect was found.

## Prescribed determinant for ideal lattices

The CRT choice of q has the required nonzero residue in D/PD, including nonprincipal fractional ideals. The construction gives ps-qr=1. All four forward and all four inverse ideal containments in the two-coordinate move are correct. The induction retains the product of the coordinate ideals and determinant1. Multiplication of the first coordinate by beta then gives precisely the required determinant and ideal product. The dimension-zero condition beta=1 is necessary and is explicitly retained. The converse follows from the top exterior power.

## Integral character interpolation

The substitution operator raises the power of D=X^w-1 after subtraction of the appropriate scalar. The w=0 and M=0 cases are covered by the same identities. Modular divisibility uses the exact prime-power condition and remains valid when c=nu. Divisibility identities are multiplied without cancellation in the group ring. Each undesired pushforward has a zero factor; the distinguished pushforward has exactly the phase factor canceled by the displayed unit. The target coefficients remain integers. The rank-one cyclic group at nu=0 and the empty product give the correct result.

These are complete independent proofs of the displayed mathematical assertions. Source-identification records are supplied separately by the author; no new proof-kernel certification or completion of SFew is claimed.

## Reviewed snapshots

* selmer_lattice_isomorphisms.tex: 197 lines; SHA256 `2ba42330059011416b8249c3570e3b2bf7998578c8730cf3448c04ebb60270a3`.

* selmer_character_interpolation.tex: 172 lines; SHA256 `809112f009d19fe7b4af9cdf0b885a3e1b04dbdf397417bf153922e542b399ea`.
