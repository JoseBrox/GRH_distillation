# Independent review of the finite-field homology functional

Reviewer: qrh_mathematics. Date: 2026-11-21.

The entire current fragment was read and its decisive algebra checked independently. No mathematical defect was found.

## Checks

1. The cyclic generator can indeed be chosen with g^(N/q)=zeta, even when q is composite or shares prime factors with N/q: the stated congruences ensure a unit exponent modulo N and the correct exponent modulo q. The carry sum telescopes for every x, including nonprimitive zeta^x, and gives exactly x modulo q.
2. The carry function is symmetric and is an integer-valued two-cocycle. Its cup power with the additive homomorphism v is a cocycle with the given bar convention. Adjacent insertions cancel in pairs by symmetry, leaving the last insertion with positive sign. This checks the exact x^E v(g) value, including E=0.
3. For the right projective action by rho(g)^(-1), the scalar ratio satisfies c(gh,x)=c(g,x)c(h,xg). Changing homogeneous sections produces precisely b(x)^(-1)c(g,x)b(xg).
4. The explicit transfer homotopy has the correct orientation: c_i b_i=b_(i-1)c_i'. Its first and last unpaired faces are T_c' and minus T_c. I checked the degree-one expansion directly; the same adjacent-face pairing gives the displayed general sign. First-face summations are correctly reindexed by the group action.
5. Direct-sum transfer has Q^(dim W) copies over each projective line in V and one copy over each line in W. The scalar cocycle is constant on each such fiber for the chosen homogeneous function. Hence additivity uses exactly Q=1 in the coefficient ring, and choice independence is needed only on cycles.
6. The product of projective multipliers is a homomorphism. The diagonal exponent Q^(n-i) gives exactly the determinant in k*. The transvection commutator proof works for Q>2; Q=2 has trivial multiplicative target, so no false perfectness assertion for GL_2(F_2) is used. Dimension zero has empty product one.
7. Scalars fix projective lines; after insertion of g the remaining scalar cocycle values are unchanged. Thus the scalar-prism transfer identity is exact on chains, with no multiplicity or inverse missing. Applying v to the product gives v(det g).
8. The positive-degree trivial-representation term is zero on cycles even for unnormalized bar chains: the trivial group differential is identity in positive even degrees and zero in odd degrees. Stabilization and d-fold direct-sum formulas follow. The q=1 and zero-dimensional endpoints are correctly separated.

## Scope

This verifies the explicit finite-field cochains, transfer, determinant normalization, and additive family. It does not audit the construction of the subsequent arithmetic cycles or the global homology bound, and it is not a fresh Lean kernel certification. The fragment states these remaining tasks correctly.

Reviewed line count: 435.

Reviewed SHA256: `5ef336e0c57e4c8d995d88dc88866ae735a257853444029a891fc073fe7654b7`.
