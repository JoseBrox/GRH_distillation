# Independent review of the finite-field homology functionals

Reviewer: root. Date: 21 November 2026.

The full mathematical fragment was read. No mathematical defect was found.

The normalized carry cocycle uses a generator whose (Q-1)/q power is the specified root zeta; surjectivity of unit reduction is correctly proved by CRT. The carry sum is the residue of x, even when zeta^x is not primitive. The cup differential and the pairwise cancellation in the even insertion chain give exactly x^E v(g), including E=0.

For the right action on projective lines, c(gh,x)=c(g,x)c(h,xg) has the stated orientation. The first boundary face is accounted for by permuting x. With c'_i=b_(i-1)^(-1)c_i b_i, the equality c_i b_i=b_(i-1)c'_i has exactly the sign convention needed in the homotopy; its two endpoint faces are T_c' minus T_c. The direct-sum fibers have Q^(dim W) and1 elements respectively, so the assumption Q=1 in the coefficient ring is essential and sufficient.

The product of the projective-line multipliers is a homomorphism, equals determinant on diagonal matrices, and kills every transvection when Q>2 by the displayed commutator. Q=2 has trivial multiplicative target. The elementary generation argument and dimension-zero case are valid. In the scalar prism, the projective line only changes at the inserted g; all other multiplier entries are scalar and line-independent. This proves the direct prism-transfer identity with no conjugation or missing permutation factor.

The positive-degree homology of the trivial group is zero in the unnormalized complex by the explicitly computed alternating boundary. Thus stabilization and repeated diagonal sum have the stated effects on cycles, including zero copies.

The source comparison and finite controls are recorded separately. This review proves neither the later arithmetic cycle construction nor the rational homology rank estimate. It is not a new kernel replay.

Reviewed snapshot: 433 lines; SHA256 `40ecee7e7a1bc1f7b5b096589ee59966bd2de58cfe88b563ef1adccee5390301`.
