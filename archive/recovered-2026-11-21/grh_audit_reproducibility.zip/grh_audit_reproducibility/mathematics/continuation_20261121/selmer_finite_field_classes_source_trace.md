# Source trace: explicit finite-field homology functionals

Date: 21 November 2026. Fragment: `selmer_finite_field_classes.tex`.

## Completed statements

The fragment proves the exact source assertions SCoc, STrans, STheta, and SPhi by ordinary mathematics. SCoc is the normalized cyclic carry cocycle. STrans is the transfer over projective lines for any coefficient ring in which the field cardinality equals one. STheta combines the two and gives the required value x^(e+1) times the residue logarithm of the determinant. SPhi follows from additivity and vanishing of positive-degree homology for a trivial group.

The determinant-value argument is deliberately simpler than the source wrapper: transfer of the central scalar prism is computed directly, and the product of the scalar multipliers over all projective lines is proved to be the determinant. Thus no theorem concerning finite-field K-groups, general linear group abelianization at F_2, or an unproved normalization is imported.

## Source files read in full

Paths relative to `sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/ModularityArgument/ClassCounting/`:

- `HasVal.lean`, 147 lines: bar degree, scalar character, prism convention, additive family, exact HasVal statement.
- `LemmaKOfSteps.lean`, 178 lines: actual SCoc/STrans/STheta/SPhi interfaces. The full file had been read previously; lines 1–130 were reread for this reconstruction.
- `FProd.lean`, 152 lines: symmetric integral carry cocycle, cup product, insertion cancellation, and exact cyclic sum.
- `STrans.lean`, 415 lines: full file read in ranges 175–425 and 1–177. The source uses the same inverse linear action on projective lines, the same scalar ratio, the same change-of-section coboundary, and the same direct-sum fibers. Its coboundary argument is replaced in the manuscript by an explicit chain homotopy.
- `SThetaOf.lean`, 277 lines: complete file read. The source's use of an element different from 0 and 1 in the field is confined to the nontrivial coefficient case. The manuscript's determinant proof also treats F_2 separately through its trivial multiplicative group.
- `PiRepApply.lean`, 154 lines: complete file read, for stabilization and repeated direct sum after reduction.

## Exact comparison of conventions

- A degree-m chain is an m-tuple. The source's e corresponds to E=e+1, so its functional degree is 2E+1 and its cyclic cycle degree is 2E.
- The projective right action is line times g = rho(g)^(-1) line. The scalar cocycle is lambda(v)/lambda(rho(g)^(-1)v).
- Under lambda→lambda', the coboundary is c'=b(x)^(-1)c(g,x)b(xg), with b=lambda/lambda'. The homotopy in the manuscript satisfies dK+Kd=T_c'−T_c, including the displayed endpoint sign.
- The cyclic cocycle uses a generator whose N/q-th power is exactly the given primitive root. Its cyclic sum is x modulo q even when x is not coprime to q.
- The finite-field transfer value is exactly x^E v(det g), without a factorial, a field-cardinality scalar, or a missing determinant power.
- The coefficient condition Q=1 is used in the direct-sum fiber of cardinality Q^(dim W), not as an equality of integers.
- q=1, the zero vector space, and d=0 in repeated direct sums are treated explicitly.

## Independent review and exact checks

The parent independently read the whole conventional proof and checked the carry normalization, cup/prism cancellation, right-action transfer, homotopy signs, fiber count, determinant identity, and boundary cases; no defect was found.

`check_selmer_transfer.py` independently implements the displayed bar formulas with exact integer coefficients. It checks 2478 transfer chain-map identities and 2478 homotopy identities over GL_2(F_3), 2550 determinant products over the fields of orders 2, 3, 5, and 7, and 576 each of the central-prism transfer and normalized functional identities. The results are in `selmer_transfer_exact_checks.json`. These finite checks confirm signs and normalization; they are not substitutes for the general proofs and do not test the later arithmetic cycle construction.

No counterexample satisfying the actual hypotheses was found. The remaining arithmetic construction SClass and the stable rational homology input BOdd are separate dependencies.
