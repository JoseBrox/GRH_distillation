# Independent review of selmer_finite_set_bound

Reviewer: qrh_mathematics. Date: 2026-11-21.
Read the complete 239-line fragment, SHA256 `a226394d21a9e53fdfcff67be8f99ed20eda8e8e8bc2b25f038cb0d5c0f95eab`.

## Conclusion

No mathematical defect was found in the ordinary proofs under their explicitly stated classical inputs.

## Detailed checks

The arithmetic cycles and their bad divisors are chosen before all residue fields and finite-field functionals. The product b0=ell times the product of those finitely many nonzero divisors is a common nonzero element of O_L. All chosen weighted norms are units away from it.

Reduction of the primitive qth root at primes away from ell makes q divide the finite residue multiplicative order. The discrete logarithm modulo q is well-defined and has kernel precisely the qth powers. Its generator choice is independent of the earlier cycle construction; the functional theorem permits that arbitrary logarithm. The product over every allowed prime is a legitimate A-module, even when infinite, and the homology finite-image bound applies to its finite image set.

The cancellation uses v_ell(c_E)=2Ec+2v_ell(E!), so the total exponent after multiplication by ell^(2E) is exactly b_*. Only the prime-to-ell factor is canceled. If b_*>=nu the displayed vanishing is automatic and the argument remains valid; it does not divide by an element of positive valuation. Raising further to ell^b with b>=b_* is valid in every residue group.

The same common bad divisor b0 is used in the global power-detection corollary. Its relative residue-degree-one primes are exactly the ones used to build the product target, and all hypotheses F/L cyclic, roots of unity, and unit residues are retained. Thus equality of product values implies the stated global qth-power relation and the separating assumption gives injectivity.

The original scalar exponent dominates b_* with the displayed elementary factorial-valuation bound. Empty finite sets and the endpoints E>=1, nu>=c>=1 pose no issue. The final coarse consequence is an application of the earlier conditional theorem once SFew is supplied; I did not reread every earlier Selmer/cohomology fragment in this review. The stronger independent K-theory exponent14 is clearly distinguished.
