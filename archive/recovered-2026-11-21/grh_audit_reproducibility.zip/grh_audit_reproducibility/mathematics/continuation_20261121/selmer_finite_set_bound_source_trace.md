# Source trace: the finite-set comparison SFew

Date: 21 November 2026. Fragment: `selmer_finite_set_bound.tex`.

## Completed result

The fragment proves SFew for the actual source data, after the index change E=e+1. In fact it proves the same cardinal bound for every exponent b≥2E(c+1)+2v_ell(E!), and it removes the additional hypothesis 2E+1<r2(L). The original exponent 2E+(2E+1)(c+2E+1) is larger and follows as a corollary. This proves the stronger statement directly; it is not inferred incorrectly from the source statement with a larger exponent.

The needed components have ordinary proofs in the following stable fragments: `selmer_homology_cycles.tex`, `selmer_character_interpolation.tex`, `selmer_lattice_isomorphisms.tex`, `selmer_finite_field_classes.tex`, `selmer_arithmetic_cycles.tex`, `selmer_homology_count.tex`, and `selmer_detection.tex`. The classical H-space, stability, Borel and degree-one K-theory inputs are explicit in the homology-count fragment. The detection argument uses qualitative Chebotarev. No effective bound on the excluded primes or their product is needed or asserted.

## Exact source read scope

The complete source file

`sources/lean/src/Development/EtaleCohomology/CyclotomicDiscriminants/SFewOfCut.lean`

was read in full (215 lines). Its complete final theorem `sFewOf` and each of its elementary preceding lemmas were checked. The full files `ClassCounting/HasVal.lean` and `ClassCounting/LemmaKOfSteps.lean` were also read, including the actual Lay, DivDel, nrm, Few, SClass, SUpper and SDetect definitions. Hashes and exact lengths are recorded in the manifest.

| Source declaration or step | Conventional counterpart |
|---|---|
| `one_add_pow_eq`, `not_dvd_pow_sub_one`, `not_dvd_sub`, `pe_dvd` | Replaced by the exact valuation lemma sc-vandermonde, with c≥2 at ell=2. No division by an ell-divisible scalar is performed. |
| `exists_index` | For a generator g of the finite-field multiplicative group, v(g^j)=j mod q has kernel exactly the q-th powers, since q divides the group order. |
| `prim_map` | Roots of unity remain distinct at primes not dividing ell, proved in sd-roots-reduce. |
| `res_one`, `res_mul`, `res_inv`, `res_pow` | Arithmetic cycles make every weighted norm an actual localized unit; ordinary reduction is therefore multiplicative and compatible with inverse and powers at every chosen prime. |
| `isPrimFam_pi` | The product of all residue functionals satisfies the required three linear identities coordinate by coordinate. The product is not assumed finite. |
| `sFewOf`, first construction | A cycle and excluded element are chosen for each member of the finite set before any residue map or functional is chosen. The nonzero product ell times all excluded elements handles every pair simultaneously. |
| `sFewOf`, injectivity | Equality in the product implies a q-th power residue of the quotient of weighted norms raised to ell^b at every allowed prime; SDetect proves a global q-th power; the exact Few separation hypothesis then forces equality. |
| `sFewOf`, final count | SUpper is applied in degree 2E+1 with size 4E+6, multiplier ell^(2E), and the two torsion orders in degrees 2E+1 and 2E. |

The source's excluded elements belong to O_F. Our already proved SClass construction chooses them in O_L, which is a permissible stronger conclusion and makes their finite product an element of both rings. The source hypotheses only require each divisor witness to exist; no common divisor witness or common matrix size is assumed. Different sizes are handled by the stable finite-image theorem.

## Exact hypotheses and endpoint checks

- A primitive q-th root is integral and invertible in O_F. Excluding primes above ell preserves its exact order and ensures that the finite-field construction applies.
- The residue map is required to be surjective on O_L, exactly as in SClass and SDetect. The detection theorem independently proves this suffices because absolute degree-one primes satisfy that condition.
- The exact cyclic degree is ell^(nu−c), with the generator acting on zeta by 1+ell^c. This is the Lay datum used in SClass, not an arbitrary cyclic extension.
- The finite set is separated only by its powered weighted norms modulo global q-th powers. It is not identified with all admissible elements, and no roots-of-unity quotient is silently inserted.
- c_E can vanish modulo q. The exact valuation lemma still implies the necessary annihilation after the larger ell-power, including valuation≥nu. Only its prime-to-ell part is inverted.
- The target product over good primes may be infinite; the homology estimate was explicitly proved for arbitrary target modules.
- The empty finite set causes no problem: the excluded product is ell and the cardinal inequality is immediate. The case nu=c is already included in the SClass construction.

## Consequences and limits

The fragment completes the sole source-specific comparison previously left conditional in `selmer_comparison_proofs.tex`: together with the already proved SCount, SSha and SLayer, it gives the strict Selmer exponent 86 and coarse H² exponent 88 with the stated classical reciprocity and duality inputs. The alternative K-theory proof still gives the stronger coarse exponent 14.

This completion concerns the finite-set comparison and its downstream coarse arithmetic estimates. It does not establish the full theta or period-map construction, and it is not a proof of GRH. No counterexample satisfying the actual SFew hypotheses was found. No new kernel or whole-export certification is claimed by these mathematical source reads.
