# Independent root review: fixed-conductor Selmer restriction

Reviewed manuscript: `selmer_fixed_conductor_restriction.tex`.
Final reviewed SHA256: `d55162d5b8bccd4124718c494f1e47326ce9bb505f0d8cdfbe7a368f49528dde`.
Outcome: PASS for the stated case IV comparison. No counterexample or substantive gap found in this fragment.

The root read the complete original 272-line argument and checked the final label changes and the added principal-unit invariance sentence. The final labels are `iv-*`, avoiding the earlier collision with an unrelated section. The source statements `LayerLe` and `HostOdd` were read, and the character definitions in `DirichletPrimeToLPartMulLPowerPart.lean` 75–225 were independently checked. The contributing agent's manifest records its broader full-file reads; this review does not expand the root's own source-read scope.

Checks of the mathematics:

1. Local components at 2, q and d have 2-power or quadratic order. Since p is odd and distinct from q,d, removing its p-power character and its local p-component does not change those components. The odd-order hypothesis forces them to be trivial, so the character conductor divides fixed M.
2. F=Q(mu_(p^(j+1)M)) kills the character. Its cyclotomic image is exactly 1+p^a Z_p, with a=j+1+v_p(M). The added sentence establishes divisibility for every principal unit, not only the one used to attain equality. Thus the invariant module is exactly A[p^(a+v_p(e))].
3. The inflation–restriction kernel is bounded by all functions on the finite group. No division by its degree occurs, so p dividing [F:Q] is permitted.
4. Finite free coefficient extension commutes with the cochain complexes and restriction kernels. A Z_p summand Z_p/p^r contributes O/p^r O of O-length br, so the normalization cancels arbitrary coefficient ramification.
5. The image obeys the actual strict local conditions after restriction. The bound remains additive in the fixed common-interval B. Summing v_p(e) gives at most (t-1)/(p-1).
6. There are at most phi(M) fixed-conductor characters. The resulting fixed multiple of B does not grow with q,d,h.

Limits: this proves the fixed-conductor comparison with the stated fixed-layer B. It does not prove the whole-field character decomposition or the separate automorphic cases, and is not a local full Lean kernel replay. No computation is needed for these exact cohomological and elementary valuation arguments.
