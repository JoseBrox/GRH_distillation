# Fixed-conductor complementary Selmer case: source trace

The ordinary mathematical proof is `selmer_fixed_conductor_restriction.tex`. It proves the source's `HV.CountIV`, with the stronger additive error n(a+1/(p-1))(t-1) instead of a polynomial in Nt. The coefficient of B is one for each character, independently of the coefficient extension. The total over this fixed family is explicitly bounded by phi(M) times the fixed sum of log(p) times B. This does not purport to handle the distinct character-decomposition comparison for the full growing field.

All source paths below are relative to `sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/`.

## Source statements inspected in full

- `CharacterLevelBounds/ShaFamMono.lean`: inverse Dirichlet character and negative cyclotomic twist, the normalized O-length dividing by the ramification index, and monotonicity when local conditions are added.
- `HeightAndVanishing/DirichletPrimeToLPartMulLPowerPart.lean`: the Host field's fixed subgroup, exact character family, p-power and prime-to-p order factors, deletion of the local p-component in `chiP`, and the odd-order condition of case IV.
- `HeightAndVanishing/LayerLe.lean`: the exact CountIV statement and fixed-layer bound `LayerLe`. The input B is a normalized sum for the fixed cyclotomic layer; it is not replaced by a bound depending on q,d.
- `HeightAndVanishing/HostComp.lean`: local odd-prime components have order dividing 2o and at q,d have square one.
- `HeightAndVanishing/HostOdd.lean`: the source conductor reduction under odd order of `chiP`. The new ordinary proof gives the same reduction directly from inertia at 2,q,d.
- `HeightAndVanishing/IvField.lean`: constructs the fixed field over Q(mu_(pM)), of degree at most p M p^j, that kills all characters of conductor dividing M. The ordinary proof uses the explicit model Q(mu_(p^(j+1)M)).
- `HeightAndVanishing/CountIV.lean`: the source restriction-and-invariant bound with an integer C fixed before the growing level and auxiliary primes. The ordinary proof replaces the source's general invariant estimate by the exact cyclotomic invariant length b(a+v_p(e)).

## Actual mathematical inputs

Only the continuous inflation--restriction sequence, finite free change of coefficients, cyclotomic Galois groups, and the binomial valuation formula are used in the new comparison. The manuscript proves the needed invariant calculation, cocycle-length bound, and summation explicitly. The common-interval estimate for the specified fixed fields is an already established input in the reconstruction and is retained with its exact B. The original source archive is cited in the TeX. No new literature theorem is introduced without proof.

## Scope

The degree n and exponent a depend only on the fixed p, M, j. There is no assumption that p does not divide n. Coefficient fields may ramify arbitrarily; their ramification index cancels. The number of contributing fixed-conductor characters is at most phi(M), even if the ambient field grows. No complete Lean replay and no estimate for cases I, II, III or the high-conductor part of V is claimed here.
