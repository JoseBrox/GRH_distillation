# Independent review of selmer_homology_count

Reviewer: qrh_mathematics. Date: 2026-11-21.
Read the complete 349-line fragment, SHA256 `fb536993be27acc8ce66f3ef0d5dc80fa72005b3f567ef8c2453b1901aca5978`.

## Conclusion

No mathematical defect was found in the ordinary proofs under their explicitly stated classical inputs.

## Detailed checks

The repeated direct-sum homomorphism is the iterated direct-sum H-space power after stabilization. The Hopf-algebra proof computes its action as d on primitives and d^s on products of s primitives. The polynomial kills all product lengths 2 through m without dividing by eigenvalue differences; d=1 and m=1 are handled correctly. The integral stable range is comfortably satisfied by N>=2m+4. Exactness of rational tensoring controls only the rank of the integral image, and no integral torsion-free decomposition of the entire group is assumed.

The finite-rank counting lemma works without finite generation of H: each finite set lies in the image of a finitely generated subgroup W' of rank at most r whose torsion is a subgroup of H_tors. The universal coefficient sequence is proved directly from the free bar complex, including the m=1 endpoint. Its failure-of-integral-lifting term is retained.

For SUpper, the finitely many representatives are moved to a common size before applying stability. The multiplier product is ell^(m-1) times a unit modulo ell^nu. Its inverse is applied to an integral cycle, so no illicit cancellation by ell occurs. The integral-image cardinal bound is then multiplied by the order of the preceding-degree torsion subgroup, exactly as required by the coefficient sequence. The target B can be arbitrary; the proof never counts all its elements. nu=0 is correctly separated.

The example L=Q(zeta_13) has r2=6 and five degree-one primitives; degree three has six primitives and ten triple products. It refutes the unfiltered rank assertion but not the actual statement.

The classical homological-stability, K-theory, and rational H-space theorems are retained explicit inputs. I checked their use and hypotheses, not their original published proofs or references afresh. Root reports those references independently verified.
