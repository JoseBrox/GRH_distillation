# Review of the odd-degree and finite-set bounds

Reviewer: root. Date: 21 November 2026.

Both complete fragments were read: `selmer_homology_count.tex` (SHA256 `fb536993be27acc8ce66f3ef0d5dc80fa72005b3f567ef8c2453b1901aca5978`) and `selmer_finite_set_bound.tex` (SHA256 `a226394d21a9e53fdfcff67be8f99ed20eda8e8e8bc2b25f038cb0d5c0f95eab`). No mathematical defect was found.

The primitive-generation and stability theorems are explicitly identified classical inputs. The repeated direct-sum map acts as d on primitives and as d^s on a product of s positive-degree primitives. Therefore the displayed product of differences kills every product of length at least two in degree m. This argument needs neither a diagonalizability assertion beyond those products nor a division by an eigenvalue difference. The degree-one endpoint uses the correct K_1 result for rings of integers of number fields. The chosen matrix sizes lie in the quoted integral stable range.

The image-counting lemma does not assume finite generation: any finite collection of image elements is lifted to a finitely generated subgroup, whose torsion lies in the ambient finite torsion. The exact coefficient sequence accounts for non-liftable cycles modulo q and gives the indispensable factor from degree m-1. The product of (1-ell^(j-1)) is a unit modulo q; this is the only cancellation used. The target may be an arbitrary module, including an infinite product. The case nu=0 and the empty difference product for m=1 are valid.

In the finite-set argument, all arithmetic cycles and one common bad divisor are fixed before selecting residue fields and finite-field functionals. Each selected residue has a primitive q-th root and a cyclic multiplicative group; the chosen logarithm has kernel exactly the q-th powers. Equality of the product-valued images forces the required power residue at every allowed prime. The exact valuation of c_E, followed by the already proved global-power detection theorem, gives injectivity. The improved exponent 2E(c+1)+2v_ell(E!) is sufficient, and the original exponent is larger. The extra condition m<r_2(L) is unnecessary for these two estimates.

The concluding exponents 86 and 88 follow from the earlier modular comparison once this finite-set assertion is supplied. The independent K-theory exponent 14 remains the stronger coarse bound. None of these results by itself completes the theta or final period-map argument.
