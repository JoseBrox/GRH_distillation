# Source trace: odd-degree rank and finite-image counting

Date: 21 November 2026. Fragment: `selmer_homology_count.tex`.

## Mathematical status and route

The fragment proves the mathematical statements called BOdd and SUpper. It uses classical integral homological stability, the rational homology theorem for connected H-spaces, Borel's rank theorem, and the Bass–Milnor–Serre identity K1(O_L)=O_L^× for the degree-one endpoint. These inputs are stated explicitly, with verified theorem locators. The rest of the argument is proved in ordinary mathematics.

This is an alternative to the submitted differential-form proof of BOdd. It is not a claim that all its Hecke, invariant-form, or differential-form dependencies have been independently read. There is no new Lean-kernel replay, no inferred certification from a source scan, and no integral Hurewicz comparison hidden in this route.

The primitive-generation argument actually proves the two stated conclusions without the source's extra condition m<r2(L). Only the rank of the primitive part in odd degree is used. It is unnecessary to assume that the full odd homology has that rank, or to diagonalize an arbitrary endomorphism.

## Exact source read scope

Write CC for `sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/ModularityArgument/ClassCounting/` and KB for `sources/lean/src/Development/AutomorphicArithmetic/AutomorphicVarieties/LiteratureResults/KTheoryStability/ReductionBoundsTorsion/`.

The following files were read in full. Lengths and SHA256 hashes are in the manifest.

| File | What was checked |
|---|---|
| CC/HasVal.lean | psi is repeated block diagonal; lev is d^t N; zSeq subtracts d^(t+2) times stabilization at step t. |
| CC/LemmaKOfSteps.lean | Exact BOdd and SUpper statements, parity, size 2m+4, modulus, arbitrary target module, two torsion factors. |
| CC/BOdd.lean | Final bridge to bOdd_zk. |
| KB/TorsionIntegers/Bridge.lean | Definitional agreement of lev, psi, zSeq and their target homology groups; no weakening in the final rank transfer. |
| KB/FinalOdd.lean | Actual differential-form dependency assembly. |
| KB/SBStar.lean | Weight-system, SSurj, and repeated-difference definitions. |
| KB/SBStarOdd.lean | Odd weight decomposition and exact BStarOdd statement. |
| KB/OddSpanRank/SBStarOddOf.lean | Rational rank proof from invariant-form surjectivity and weight-one functionals. |
| KB/OddSpanRank/RankSpanLe.lean | Passage from real linear functionals to the integer rank of the actual span. |
| KB/SInv.lean | Immediate invariant-form provider only. |
| KB/SurjectivityCase/SSurjOf.lean | Immediate assembly into SSurj, not the transitive IteratedHeckeBounds proof. |
| KB/OddWeightCycles/SWtOddOf.lean | Immediate assembly into SWtOdd, not every imported invariant-theory construction. |
| CC/SUpperOf.lean | Complete final finite-image assembly. |
| CC/TorsionRankCounts/RankCount.lean | All seven abstract interfaces, including actual torsion finiteness and Bockstein kernel statement. |
| CC/TorsionRankCounts/TorsStab.lean | Integral stability, not a rational substitute, and the exact two finite torsion orders. |
| CC/TorsionRankCounts/Descend.lean | Descent of the chain functional through integral homology. |
| CC/TorsionRankCounts/PhiZSeq.lean | Scalar equals ell^t times a unit modulo ell^nu; no cancellation of ell. |
| CC/TorsionRankCounts/RankCountAlt.lean | Finite subset lifts to a finitely generated subgroup; full group finite generation is not assumed. |
| CC/TorsionRankCounts/BockAbs.lean | Lifting a mod-q cycle; chain-group torsion freeness; adjustment of the lift by q times a chain. |
| CC/TorsionRankCounts/FibCount.lean | Each fiber is controlled by translation of the kernel image. |

The seven TorsionRankCounts files total 405 lines. Complete transitive-source coverage is not claimed. In particular the local bridge to Mathlib group homology and the complete source proof of differential-form surjectivity are not newly certified by this fragment.

## Classical sources actually checked

- Charles Weibel, *The K-book*, Chapter IV, Corollary 1.14.1: stable homology for N≥max(2m+1,m+sr(R)); Chapter IV, the paragraph before Theorem 1.17 and Theorems 1.17–1.18: rational primitives and Borel's ranks. Local extracted text lines 519–601 were read. URL: https://sites.math.rutgers.edu/~weibel/Kbook/Kbook.IV.pdf . The earlier K-theory fragment proves sr(O_L)≤2 by the Chinese remainder theorem.
- Weibel, Chapter III, Example 1.3.6, printed p. 5: Bass–Milnor–Serre gives K1(O_L)=O_L^×. Local extracted text lines 199–205 were read. URL: https://sites.math.rutgers.edu/~weibel/Kbook/Kbook.III.pdf . This is used only for m=1; no analogous assertion for arbitrary Dedekind domains is made.
- John Milnor and John Moore, *On the Structure of Hopf Algebras*, Annals of Mathematics 81 (1965), 211–264: Corollary 4.18 (printed p. 234), Theorem 5.18 (p. 244), and Appendix (pp. 262–263). These exact theorem statements and the entire Appendix were read. Local extracted text intervals 1242–1249, 1789–1798, and 2717–2780. URL: https://www.sas.rochester.edu/mth/sites/doug-ravenel/otherpapers/Milnor-Moore.pdf . No full-paper reading is claimed.

Root independently checked all three classical source locators, including the degree-one endpoint. The connected K-theory component is a homotopy commutative infinite loop space, so the H-space assumptions hold. The repeated direct-sum map is its integer power map under this multiplication.

## Adversarial checks and limitations

- The rational calculation is applied only after all finite matrix sizes lie in the integral stable range; d≥1 ensures levels cannot decrease.
- Products of s positive-degree primitives have repeated-sum eigenvalue d^s. Their length is at most the homological degree m. The factors j=2,...,m therefore remove every decomposable term in degree m without dividing by any eigenvalue difference. d=1 and m=1 are both covered.
- The source's rank assertion concerns the image of the repeated difference, not all of H_m. The example L=Q(zeta_13), m=3 gives total rational rank 16 versus r2=6 and explicitly refutes that tempting weakening.
- Integral torsion is retained at every stage. The subgroup of rank at most r may itself have torsion, bounded by the torsion of its ambient integral homology group.
- The coefficient exact sequence contributes the second torsion factor in degree m−1. Its cycle-lifting proof is included, with the m=1 endpoint treated in the ordinary bar complex.
- The target B can be an infinite product. The finite-image estimate uses only its exponent q and finite-subset counting; it does not assume B is finite or finitely generated.
- The case nu=0 gives the zero coefficient ring and zero unital module. The unit factor in the scalar identity is inverted modulo ell^nu only when nu≥1.

No counterexample satisfying the actual hypotheses was found. The conventional conclusions are proved subject only to the explicitly cited established classical theorems, not to the source-specific BOdd or SUpper providers.
