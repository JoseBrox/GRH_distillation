# Source trace: cyclic bar cycles and a primitive relation

Date: 21 November 2026. Fragment: `selmer_homology_cycles.tex` (210 lines at recording).

## Scope

The fragment proves the precise elementary homology inputs SZc and the used instance of SRel by an ordinary periodic-resolution argument. It does not claim to reconstruct every auxiliary generalization in the source SRel proof. The arithmetic class construction, transfer-compatible finite-field functional, and upper bound for its values remain separate statements.

## Source reads

All source paths below are relative to `sources/lean/src/Development/EtaleCohomology/CyclotomicDiscriminants/` unless specified.

- `SZcTPf.lean`: complete 124 lines, read in ranges 1–100 and 101–130.
- `SRelTPf.lean`: only lines 1–90 and 237–317 of 317 were read. The intervening source proof was not independently reconstructed. The manuscript supplies a different complete proof for the actual instance needed by the class construction.
- `FinSRel.lean`: complete 7 lines.
- `SFewOfCut.lean`: complete 215 lines.
- `Development/AutomorphicArithmetic/AutomorphicVarieties/ModularityArgument/ClassCounting/HasVal.lean`: complete 147 lines, to fix the source convention that an m-tuple represents bar degree m.
- The `LatticeBlockClasses/CJoin.lean` assembly, under the same ClassCounting directory: complete 187 lines, to check the exact use of SRel with E=e+1 and 2E+2 diagonal maps.

## Mathematical matching

- The cycle has degree 2E and is the sum over E independent cyclic entries of the alternating tuple [j1|1|...|jE|1]. Its boundary cancellation is proved directly, including the first face's q multiple.
- The coefficient ring is Z/q with q=ell^nu, nu≥1. A complete split periodic cyclic resolution gives H_m(C_q×C_q,Z/q) free of rank m+1 over Z/q.
- For the 2E+2 maps x↦(x,tx), their images lie in a module of rank 2E+1. A primitive integer relation in a lifted integer matrix reduces to a relation having a unit coefficient over Z/ell^nu. This exactly supplies a boundary and a coefficient that can be divided by in CJoin.
- The case nu=0 is the zero coefficient ring, treated separately rather than being mistaken for the positive prime-power argument.

The composite-modulus example over Z/6 correctly shows that arbitrary nonzero relations do not necessarily have a unit coefficient. It violates the prime-power hypothesis. No counterexample satisfying the actual hypotheses was found.

Parent `/root` independently read the entire conventional fragment and checked the cyclic faces, split exact resolution, total-complex rank, primitive integer relation, and counterexample; no defect was found.
