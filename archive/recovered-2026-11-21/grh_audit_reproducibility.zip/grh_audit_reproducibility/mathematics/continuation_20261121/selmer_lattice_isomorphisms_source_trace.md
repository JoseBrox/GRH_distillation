# Source trace: determinant-prescribed ideal-lattice isomorphisms

Date: 21 November 2026. Fragment: `selmer_lattice_isomorphisms.tex` (197 lines).

## Statement and completed proof

This fragment proves the exact source assertion SStein. For coordinate fractional ideals I_i and J_i and beta in F*, it constructs an F-linear map with determinant exactly beta carrying their direct sums onto each other, under the exact equality of determinant ideals. It retains the necessary condition beta=1 when the coordinate set is empty. The conventional proof uses Chinese remainders and explicit determinant-one two-coordinate operations; it does not assume that individual fractional ideals are principal or that the lattices are globally free as modules over the ring of integers.

## Source text actually read

All paths are relative to `sources/lean/src/`.

- `Development/EtaleCohomology/CyclotomicDiscriminants/SSteinTPf.lean`: all 230 lines. The source's `exists_sl2_with_valuation_bounds`, `rel_move`, `rel_of_sum_eq`, `rel_scale`, and `SStein_of` correspond respectively to the two-element lemma, two-coordinate move, equal-product reduction, determinant scaling, and final theorem in the conventional proof.
- `Development/EtaleCohomology/CyclotomicDiscriminants/FinSStein.lean`: all 7 lines; confirms the provider passed to the class-counting assembly.
- `Development/AutomorphicArithmetic/AutomorphicVarieties/ModularityArgument/ClassCounting/LemmaKOfSteps.lean`: all 178 lines read previously and the relevant definitions reread in this continuation. SStein is defined at lines 78–82, with the empty-index qualification explicit.
- `Development/AutomorphicArithmetic/AutomorphicVarieties/ModularityArgument/ClassCounting/LatticeBlockClasses/GtEqZeta.lean`: complete file read, to check where the prescribed determinant and the nonempty distinguished block are used.
- `Development/AutomorphicArithmetic/AutomorphicVarieties/ModularityArgument/ClassCounting/LatticeBlockClasses/CBlockValAlt.lean`: complete file read, including CGtEq and CGtNe's exact interfaces.

## Audit observations

The fractional ideals may have negative prime exponents. Chinese remainders are applied to the invertible module D, not to a fictitious global generator. Both the forward and inverse matrices preserve the required ideal inclusions. Their determinant is exactly one, so the final scalar beta is preserved rather than being determined only up to a unit. The empty-index example beta=-1 over Q demonstrates why the extra qualification is essential; it is excluded by the actual source statement. No counterexample satisfying the actual hypotheses was found.

The parent reviewer independently read the entire fragment and checked the CRT choice, all forward and inverse inclusions, the determinant scaling, and the empty-index case; no defect was found. This proves SStein, not the full arithmetic homology class construction.
