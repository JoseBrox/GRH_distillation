# Independent review of the cyclotomic layer and class-number section

Reviewer: the formal-verification/conventional-reconstruction agent, independent of the root author. Completed 2026-11-21 UTC.

## Scope and conclusion

I read the complete 318-line `selmer_layer.tex` and checked its arguments as ordinary mathematics. No mathematical defect or counterexample satisfying its hypotheses was found. This is a review of the displayed proofs, not a fresh kernel verification of the corresponding Lean providers.

## Decisive checks

- The Minkowski body has volume `2^r1 (pi/2)^r2 T^n/n!`, while the embedded ideal has covolume `2^(-r2) sqrt(D) N(I)`. The resulting ideal-class representative bound is in the correct direction, and the passage to the limiting radius uses finiteness of lattice points in a bounded set.
- The count of ideals of norm at most `X` uses unique prime-ideal factorization and assigns at most `n` integer coordinates to the prime ideals above each rational prime. The product of those coordinates does not exceed the ideal norm. The ordered-integer-tuple bound therefore applies even without unique factorization of elements or a principal-ideal hypothesis. The displayed class-number estimate with `n-1` is valid, including degree one.
- The principal cyclotomic image is exactly `1+p^c Z_p` when `c` is the largest root-of-unity exponent and the stated `p=2` restriction holds. The proof uses the full closed-subgroup classification of that procyclic group; it does not infer the image merely from one congruence. The finite-layer generator, extension degree, and maximal exponent after enlargement agree.
- In the discriminant proof, `A=O_L[zeta]` is free over `O_L` with the displayed monogenic basis although `O_K` need not be free over `O_L`. The anti-triangular trace matrix has unit determinant. Thus `A^#=f'(zeta)^(-1)A`, and `O_K^#` is contained in `A^#`. It follows that `f'(zeta)` lies in the different. Since the derivative of `X^N-1` is `N zeta^(N-1)`, the ideal `(N)` is contained in the different. Taking norms consequently yields the asserted upper, not lower, discriminant bound.
- The monotonicity of the strict Selmer length uses the previously proved quotient description of the dual and the factorization of `U^(p^m)-1`. It does not assert injectivity of arbitrary cohomological restriction in a degree divisible by `p`.
- The least-power enlargement has `d < p(4E+4) <= (n+1)(4E+4)`. The root degree gives the required `p^c <= 2n'`, while the lower bounds on `d` give the two strict inequalities needed by SFew. The convention that `c` is the largest exponent remains valid in the enlarged field.

No correction was required. Global class field theory in the separate SSha section and SFew are not claimed to follow from this review.
