# Class number and cyclotomic enlargement

## Completed ordinary mathematics

selmer_layer.tex proves the class-number estimate and all of SLayer.
It supplies its own lattice-volume argument through the already-proved
arithmetic-complex lemma, the archimedean body-volume calculation,
the injection of ideals into integer tuples, the elementary cyclotomic
degree calculation, the trace-dual/different bound and the length
comparison through the previously proved strict Selmer descent.

The class-number estimate is slightly stronger than the source:

    log h_F <= (1/2) log D_F
               + (n_F-1) log(1+(1/2)log D_F).

The degree/different estimate is proved for the actual extension
L'=L(mu_(p^(c0+m))), with p^m the first power at least 4E+4.
The p=2 hypothesis is mu_4, not merely mu_2.
The maximal root exponent is c0+m, not an arbitrary selected root.
Restriction/duality is proved for this cyclotomic nonzero-twist setting;
there is no generic prime-power-extension injectivity assertion.

## Exact submitted providers

Full read coverage and hashes are in selmer_layer_source_manifest.json.

- IdealCounting/ClassA.lean bounds integer tuples by harmonic sums.
- ClassB.lean encodes ideal prime factors into distinct slots above each
  rational prime, with no principal-ideal assumption.
- ClassC.lean combines this with the small-ideal representative theorem.
  Our fragment additionally proves that representative theorem explicitly.
- GeneratorCountTuples/LemmaK.lean gives HasMuQ and the coarse H^2 input.
- CyclotomicDiscriminants/FinSLayer.lean forwards SLayerCut.goal_of.
- SLayerCut.lean gives disc_cyc, sha_le and goal_of. The manuscript proves
  the same different-divisibility bound directly from the trace dual,
  and uses the previously reconstructed infinite-tower descent for sha_le.

The Dirichlet unit theorem is subsequently proved in selmer_unit_count.tex;
it is not needed for the class-number or cyclotomic enlargement proof.
No counterexample satisfying these actual hypotheses was found.

These records do not assert full review of imported algebraic-number-theory
libraries and do not supply a new proof-kernel run.
