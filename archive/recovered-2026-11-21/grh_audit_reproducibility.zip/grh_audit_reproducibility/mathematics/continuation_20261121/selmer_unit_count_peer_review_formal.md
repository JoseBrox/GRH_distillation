# Independent review of the unit and class-group comparison

Reviewer: the formal-verification/conventional-reconstruction agent, independent of the root author. Completed 2026-11-21 UTC.

## Scope and conclusion

I read the original complete SCount fragment and then read the inserted unit-theorem proof and the explicit cyclotomic-field identification in the current 510-line `selmer_unit_count.tex`. The union of these reads covers the complete current argument. No mathematical defect or counterexample satisfying the stated hypotheses was found. No new Lean compilation or full exported-proof verification was performed for this review.

## Unit theorem added in the final version

The proof of `su-unit-theorem` is complete. The Minkowski boxes have volume independent of the chosen point of the product-formula hyperplane. The integral nonzero norm provides a lower bound for each logarithmic coordinate after all the other coordinates are bounded above. There are only finitely many principal ideals of the resulting bounded norm. Choosing one generator for each of them expresses every point of the hyperplane within a fixed distance of a logarithm of a unit. This forces real span. Discreteness, a real basis from the subgroup, and reduction into a bounded parallelepiped give finite index in a full lattice. The argument covers rank zero. The finite kernel is exactly the roots of unity and is cyclic.

## Divisor and unit comparisons

- From SC3, the action of the cyclic generator on the primitive `p^nu`-th root has the full order of `Gal(K/L)`. Its kernel is therefore trivial, so `K=L(mu_(p^nu))`. This justifies the use of unramifiedness away from `p` later; it was an initially missing explanation, and the author has now inserted it.
- With `g=gamma^(-1)`, the divisor-coordinate relation is exactly `(gD)_P=D_(gamma P)`. The operator `delta=g-a` is injective on the torsion-free divisor group because `g^d=1` and `a>1`.
- The exact sequence for `W` has the stated kernel: if a unit is `delta z` modulo roots of unity, divisor injectivity forces `z` to be a unit. The equality of the orders of the kernel and cokernel of `delta` on the finite ideal class group is legitimate.
- On complex places, `Gal(K/L)` acts freely over every place of the totally imaginary base. The unit logarithm space is the permutation representation with the constant line removed. This gives the factor `(a^d-1)^r/(a-1)` with no missing factor at complex places. Its valuation is `r(nu+v_p(E))-c-v_p(E)`.

## Kummer, descent and cardinality comparisons

- The base Kummer bound accounts separately for units, the `p`-torsion of the class group, and the primes above `p`; the coarse `g_L` bound has sufficient room for the stated counts.
- The displayed cyclic Hilbert 90 proof has the correct coefficients and automorphism direction. Independence of distinct field automorphisms supplies a nonzero vector.
- The invariant Kummer count only needs at most `p^2` pairs of the auxiliary choices, not uniqueness of those choices. Equal pairs give a ratio from the base field modulo a `p`-th power. The previously established cyclotomic-field identity ensures that valuations away from `p` descend with ramification index one.
- The map from `W[p]` into invariant Kummer classes is well-defined. The fact that `delta x` is torsion implies that `x` is torsion follows by multiplying by the geometric-series polynomial and using torsion saturation of `K^times`. The same observation proves injectivity.
- The weighted norm polynomial is `sum_(j=0)^(d-1) a^j g^(d-j)`, so it corresponds to the intended product involving `gamma^j`, not the ordinary field norm. Its product with `delta` is `(1-a^d)g`. The quotient `(a^d-1)/p^nu` has valuation `v_p(E)`.
- Roots of unity are added to the quotient only when bounding the image. This weakens the distinctness condition used for the image representatives and does not strengthen the original finite-set hypothesis A(b,B).
- On the `p`-primary part, the kernel is killed by `p^(b+v_p(E))`. Combining `|W[p]| <= p^g_L` with the elementary successive-filtration count yields exactly the claimed SCount exponent. No factor of the whole integer `a^d-1` is incorrectly replaced by a `p`-power before restriction to the `p`-primary part.
- The boundary case `d=1`, including an imaginary quadratic base with unit rank zero, satisfies the same exact sequences and valuation formulas.

The proof is conditional only on the stated finite-set bound A(b,B) when it is used to derive SCount. It does not prove the separate homological construction SFew.
