# The unit and ideal-class comparison

## Completed result

selmer_unit_count.tex proves the actual SCount statement, including
all local conditions and the boundary nu=c. It also supplies an elementary
proof of Dirichlet's unit theorem from the lattice-volume argument and
finite ideal count already proved in the manuscript.

The notation is ordinary: fractional divisors I, Y=K^* written additively,
g=gamma^(-1), delta=g-a, principal-divisor map partial, admissible group
V=partial^(-1)(delta I), and W=V/(delta Y+mu(K)).

## Exact source matching

The hash manifest lists thirteen files fully read, not their entire
transitive dependency closures.

- TwoLe.lean defines Dat, U, W, EQ, ClQ, SelInv and SelL. These are the
  groups in SU1 and SU6; the notation in the manuscript is conventional.
- DatEx.lean fixes g=gamma^(-1) on K^*, and (gD)_P=D_(gamma P)
  on divisors. The inverse is preserved.
- CardKerEqCoker.lean proves |W|=|EQ||ClQ|. We instead write the
  short exact sequence explicitly and use equality of kernel and
  cokernel orders on a finite class group.
- CardEQ.lean and UnitLat.lean give
  |EQ|(a-1)=(a^d-1)^(r_2(L)). The ordinary proof derives it from
  the free permutation action on complex places and its sum-zero
  hyperplane, using the full logarithmic unit-lattice proof.
- SelInj.lean injects W[p] into SelInv; the manuscript proves
  independence of all choices as well as injectivity.
- SelLCard.lean bounds the base Kummer group by units, class-group
  p-torsion and valuations at primes above p.
- SelInvLe.lean gives the additional factor p^2. We prove its
  root-of-unity exponent/norm classification and supply a complete
  cyclic Hilbert 90 proof instead of leaving that as an extra lemma.
- EqHomLe.lean identifies the equivariant functions with a subgroup
  of Hom(ClQ,Z/p^nu). In fact the displayed definitions give equality;
  the manuscript proves it and bounds its order by |ClQ|_p.
- KerFDelNm.lean uses the same polynomial identity
  N_a delta=delta N_a=(1-a^d)g. We prove that the kernel of
  [y] -> [p^b N_a y] modulo qY+mu is killed by p^b(a^d-1)/q.
- ActUPow.lean identifies N_a with the source's weighted product
  and transfers Few to the image bound. We retain the logical
  direction: distinct images modulo qY+mu give distinct classes
  modulo qY. No stronger Few hypothesis is silently introduced.
- PCount.lean bounds the p-primary kernel using W[p].
  The manuscript gives the same finite-group argument through the
  multiplication-by-p filtration.
- SelmerOrderCounts.lean assembles these statements. The last
  cancellation and the two LTE valuations are written explicitly.

The p^nu roots and degree hypotheses in Lay force
K=L(mu_(p^nu)); this is proved from the exact order of 1+p^c modulo
p^nu. It justifies unramifiedness outside p in the Kummer descent.

## Boundary and classical references

There is no remaining assertion imported specifically for SCount:
the unit theorem, cyclic Hilbert90 and finite-group comparisons are
all proved in the fragment. The foundational ideal factorization,
trace/different identities and elementary field theory have their
usual meanings. The separate SSha section explicitly invokes
Hilbert class field reciprocity, and does not claim to prove it.

Milne, Algebraic Number Theory v3.08, Chapter5, Theorems5.1 and5.9,
was checked as an authoritative statement of the classical unit
theorem, not as a new hypothesis of the reconstruction.
URL: https://www.jmilne.org/math/CourseNotes/ANT.pdf
Checked 21 November 2026.

No counterexample satisfying the actual SCount hypotheses was found.
The essential source-specific unresolved comparison in this route
is SFew, which constructs and detects the finite-field homology
classes. This section does not establish SFew.
