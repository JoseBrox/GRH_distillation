# Independent review of the archimedean size estimates

Reviewer: qrh_mathematics. Date: 2026-11-21.

The entire current fragment was read, including the final power-scale and final-smallness corollaries. No mathematical defect was found.

## Mathematical checks

* The coefficient of each binary perturbation in the logarithmic Vandermonde sum is exactly `(H_(i-1)-H_(J-i))/4`. The sum of positive coefficients gives the stated even and odd formulas, including J=1. The quadratic logarithmic remainder is bounded by pi^2 J/144.
* Both spectral cases keep every tuple strictly decreasing. In the second case the positive interior entries and the missing `(4 Delta)^(k-2)(k-2)!` factors are accounted for. The factorial inequality holds at its first endpoint k=4.
* The formal-degree lower bound gives exactly the factor `exp(-1/4)/2` after taking the kth root. The remaining power loss is at most exp(mu), with the specified uniform upper bound on the product of b_j.
* In the boundary factorization, the signs of the factors on each side of the differing binary index are correct; the numerator and denominator do not vanish on the prescribed compact interval. The differing factor is sqrt((tau+1)/(Delta-tau)); the product before that index is bounded by (5/3)sqrt(k). The exceptional last entry gives the factor 8/a0. The final rational bound 122716/1539 is less than 80.
* The finite-level exponent in the exact mass ratio is `km+m(m-1)/2` when m=2r+2. The factorials cancel exactly, the residual denominator is `(1-T^(-k))^f`, and the four contributions to the logarithmic error total at most 8 f 2^(-k).
* The maximum defining Theta covers every block. Its product estimates correctly retain `C_t^(1/f)`. The exponent identity `nu+1=m-1-d` gives the ordinary widths. Directly squaring the terminal formula gives `C B_v kappa/sqrt(TT')` times `h^(2b-2)`, so the square-root and powers of g and rho are correct. The lift endpoint retains the factor two.
* The growth corollary is uniform in the varying m,f,B,Delta,T,T' under its hypotheses: m<=f<=k controls the first two terms and m>=2 gives the stated third exponent. The final smallness corollary only uses its displayed assumptions and does not need an unstated upper bound on f.

## Scope

This is an independent review of the conventional mathematical arguments, not a new Lean kernel certification. The actual mass recurrence, automorphic dimension identity, formal-degree lower bound, and representation-theoretic coefficient identities remain explicit inputs. The size estimates do not discharge them, and the fragment does not claim otherwise.

Reviewed line count: 709.

Reviewed SHA256: `61bd48c8a8121bf24a99e9794925136772074041fda639d3b24024744c594911`.
