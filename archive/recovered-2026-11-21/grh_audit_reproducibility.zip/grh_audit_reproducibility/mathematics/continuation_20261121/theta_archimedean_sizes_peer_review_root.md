# Independent mathematical review of the archimedean size estimates

Reviewer: root. Date: 21 November 2026.

The complete conventional fragment was independently read and all substantive inequalities were checked. No mathematical defect was found.

The review checked the exact harmonic coefficient in the binary Vandermonde sum and its positive-part bound; both last-entry cases and the factorial inequality; the critical-scale normalization; nonvanishing of the actual boundary polynomials; every factor in the boundary estimate and the rational constant 122716/1539 below80; the finite-level mass exponent and factorial cancellation; the remaining product error8 f 2^(-k); the geometric mean of the critical scales; every ordinary and terminal width, including the square root and factor2; and the uniformity of the final power estimates in all growing parameters.

The last base spectral entry is nonnegative, not necessarily strictly positive. This wording was corrected. The proof itself already allowed zero.

The mass recurrence, automorphic dimension identity, formal-degree lower bound, and the identities for actual representation-theoretic coefficients remain explicit inputs. The fragment proves the size deductions from those inputs; this review does not certify those inputs or all global orbital bounds. This is a mathematical review, not a Lean kernel check.

Reviewed lines: 709

Reviewed SHA256: `61bd48c8a8121bf24a99e9794925136772074041fda639d3b24024744c594911`.
