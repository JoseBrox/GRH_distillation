# Archimedean polynomial and size estimates: exact source trace

## Mathematical status

The fragment **theta_archimedean_sizes.tex** gives full conventional proofs of the actual spectral polynomial and normalized width estimates, with several stronger constants. It does not assume the desired width inequalities. It does explicitly assume the actual automorphic mass recurrence, source-space dimension formula, and formal-degree lower bound when those are used. It also does not prove the representation-theoretic differential identities that convert small polynomial widths into Fourier-coefficient or off-diagonal decay.

The main new conclusions are:

* An exact binary Vandermonde linear term with absolute value at most J log2/4, and a quadratic logarithmic error at most pi² J/144.
* Direct comparisons for both final-entry spectral cases, and the critical-scale lower bound with the source's factor (19/50)e^(−mu)/(1+eta_*).
* The actual boundary polynomial estimate with **constant80**, improving the source's160. Its key finite product is bounded by (5/3)sqrt(p), improving the source's3.3sqrt(p).
* The exact mass-ratio identity, conditional on the three displayed automorphic inputs, with logarithmic error at most8 f 2^(−k).
* Every actual interior and terminal width normalization, including the different exponent and terminal factor2.
* A stronger uniform power of Theta and the sharper sufficient smallness condition c C_f>7.

No counterexample to the exact source statements treated here was found. These improvements do not by themselves prove any of the four complete global orbital energy bounds.

## Source definitions and actual hypotheses

All612 lines of StatementSz.lean were read across this pass and the preceding global pass. Cfg fixes the actual arithmetic progression v_i, the negative parameters −b_j, the two possible final entries, and the binary words with last entry0. Cfg.Ok gives k≥4, m≥2, Delta≥1, v_*≥0, v_1≤4kDelta, b_1≥1, b_(j+1)−b_j≥1, a−v_1≥4kDelta, and b_1/2≤b_*≤b_1−3 in the second case. Cfg.Small gives exactly eta≤1/10, b_j≤B² and mu≤1/10. The new manuscript preserves every one of these hypotheses.

The formal-degree premise used here is FormalDegreeLower c (1/2) VV, namely VV≥(1/2)Vand(lambda). VV is not silently identified with Vand(lambda): in SizeData it is dsig multiplied by sfac(n). Thus the Haar normalization matters.

The definitions TcritPow, SizeData.MassRatios, LBound, ColumnCount, Dstar, and Ea match the displayed formulas in the manuscript. The mass recurrence contributes rho^(−f/2) at each rank step, because the source's dF=rho^f. The factor (T^k−1)^f belongs to the column dimension and produces (1−T^(−k))^(−f) in E_T. Omitting it changes the exact identity.

The new logarithmic error permits g_1,g_2≥2 and T≥2. The source's stated corollary uses g_1,g_2≥4, so the replacement is valid in its actual range. The separate critical-scale estimate retains g=g_1g_2≥2pi and rho≥1; the width section retains rho≥2. The actual selected level primes and source size assumptions imply these restrictions. No argument has silently used q=2 as an actual selected level prime.

## Independent proof and source provider comparison

VandermondeRatioHarmonic.lean was read in full. The source estimates the harmonic binary sum with a coarser expression. The independent proof sums its positive coefficients exactly: for J=2p the sum is2p(H_(2p)−H_p), and for J=2p+1 it is(2p+1)(H_(2p)−H_p). This gives the bound without an additive constant.

Only the initial210 lines of the1038-line CriticalThresholdLowerBound.lean provider were directly read in this pass. They include the actual Vandermonde splitting and lambda lower bound. The manuscript does not claim to have read that entire provider: it replaces the remaining u-comparison and critical-scale reasoning by a short direct proof, including both final-entry cases and the exact factorial inequality.

BetaBoundOnBoundary.lean was read in full. Its source assembly uses an imported factorization, a product bounded by3.3sqrt(k), and an edge factor8/a_0, producing the constant160. The manuscript directly factors the actual P(Y)P(Y+1)/Q(Y), proves nonvanishing on the actual interval, proves the finite-product bound (5/3)sqrt(p) by a one-line rational induction, and obtains the certified rational upper constant122716/1539<80. This is a strengthening, not a correction of a false source result.

MassRatioFormula.lean was read in full. Its algebra agrees with the independent proof: the finite-level index exponent is km+m(m−1)/2, the rank sum is (m−1)k+m(m−1)/2, and the factorials cancel exactly. The provider assumes the mass and column identities. The manuscript preserves this distinction.

The final size assembly SixteenMulLeTwoPow.lean was read in full. The relevant final407 lines of CmRingIdempotentUnitRatioIdentity.lean were also read, including normalised_forms, threshold_products, theta_lower_bound, theta_power_bound, and final_smallness. The manuscript retains the exact finite maximum defining Theta but uses C_t^(1/f) instead of the coarser C_t, tracks N=10m≤10f, and avoids unnecessary losses of powers of k.

Consequently, under the actual hypotheses, every fixed

0<c<min((C_Delta−1)/2, (2c_T C_b−1)/4)

is allowed for Theta≥k^c once k exceeds a threshold depending only on the fixed constants. The uniformity includes varying m,f,B,Delta,T,T' and all individual place parameters. This improves the source's chosen smaller positive exponent; it does not change any formal theorem in the archive.

## Width normalization and its scope

The exact actual widths are supplied by SupremumAIsMajorant.lean (read through310, including the complete instance_sizes argument) and JointInstanceTheoremA.lean (read through105). Their block exponent is the same nu(r,b,s)=2r+3−2b−s already proved in global_theta_estimates.tex.

The interior polynomial majorant uses the short interval only for (b,s)=(1,1). All terminal square-root widths use the full-interval majorant B_v. The new text states this distinction explicitly. Multiplication by g rho^(nu+1) gives the normalized interior width, while multiplication by g rho^(r+1−b) gives the normalized terminal width. The adjacent-exponent identity identifies the interior lift width with the next dual ideal. At the terminal step the width is doubled, exactly as in the source.

The manuscript's mass/product assumptions are sufficient to prove all these width products. The step from polynomial width to actual Fourier coefficients still needs the analytic identities below; it is not a consequence of normalization alone.

## Exact remaining coefficient route

The current source trace reaches the following actual interfaces:

* StatementC.lean defines the normalized Gram sum and psiInf, whose phase is positive. Relative to the manuscript's standard Fourier transform with negative phase, Nhat(l) is evaluated at the negative of the frequency2/g times the conjugated embedding. Because the ideal and its absolute-value profile are invariant under l→−l, this sign does not change the stated sum bounds. It must nevertheless be retained in any exact coefficient identity.
* StatementJC.lean defines WaveByPlaces, LiftBelowTop, and LiftTopDiag, with bounds for every subset of archimedean places and probability measures on extended words.
* TheoremPIntegralOfPlaces.lean, lines366–559, proves the aggregation from these subset bounds to the product of minima. The terminal argument uses Gram positivity and a three-way partition of places according to which of |t_v| and |t'_v| is smaller.
* LevelZeroEstimateProduct.lean passes this to EstWave and the corresponding lift/block interfaces.
* RealInputsBuiltClosedForm.lean takes the actual polynomial/differential and positivity identities as inputs. Its assembly is not a proof of those inputs.
* The next concrete providers located by name and exact conclusions are WaveLocalBuiltPlaces.lean, WaveLocalPositiveCompactSupport.lean, BuiltBoundsCompactOfParts.lean, and the local predicates in StatementKB.lean. Their proof bodies are not included in this manifest until they have actually been read.

These obligations remain separate from the automorphic mass/formal-degree identities and the global diagonal and dimension comparisons.

## Exact controls, review and compilation

The script check_theta_archimedean.py performs10124 finite controls using exact integer, rational and symbolic arithmetic. They check all binary linear-term identities through length12, the sharper finite product through p500, the rational constant below80, both actual polynomial factorization cases for k4,5,6, finite-level mass exponents and factorial cancellation, and the actual interior and terminal width normalizations for r0 through4. The small polynomial examples test identities; they are not claimed to satisfy the additional asymptotic smallness hypotheses. Results are in theta_archimedean_checks.json.

The general theorems rest on the displayed proofs. Root and the QRH reviewer have independently read the entire manuscript and checked all substantive inequalities, normalizations and uniformity claims without finding a mathematical defect. Their independent records give exact review scope. The standalone wrapper theta_archimedean_check.tex includes the completed global lattice section and compiles with XeLaTeX to18 pages.

The file theta_archimedean_source_manifest.json, regenerated by build_theta_archimedean_manifest.py, gives exact SHA256 hashes, line counts, and conservative read intervals. This is a mathematical reconstruction/read record, not a claim of complete formal dependency closure.
