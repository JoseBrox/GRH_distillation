# Independent review of exact arithmetic theta equivariance

Reviewed manuscript: theta_arithmetic_equivariance.tex, all 584 lines.
SHA256: d837d57608874b5f83b6491784b7bd91258329dd2d38bcf8921b6def41d54f3f.
Result: the argument passes review under the stated arithmetic hypotheses.

The reviewer checked the trace dual and inverse different, the same norm
semicharacter on each lattice, and the simultaneous hyperbolic decomposition
of two self-dual lattices over an unramified quadratic local extension.
The correction of a primitive vector uses a unit trace and Hensel lifting;
it does not divide by two and remains valid at dyadic places. The two
orthogonal complements are self-dual in the same space. Chinese remaindering
in the intersection of the two endomorphism lattices gives all six required
error inclusions, including the images in the common intersection.

On the actual finite group P/T the approximate projector is an idempotent.
The quadratic function is trivial on each of the two summands, so its sum
is nonnegative by finite character orthogonality. Thus the normalized
triple scalar is exactly one, not merely an eighth root of unity.
The norm-minus-one congruence is available at every finite place because
the CM quadratic extension is unramified. It makes both the general triple
sum and the Cayley sum real, with the displayed moduli sufficient for all
integrality claims. The even complex dimension then gives c(g)^2=det(g).
The factorization for a unitary map with fixed vectors retains its triple
scalar, whose square is one. Row and column tensor powers cancel the
remaining signs, and the character factors have exactly the stated
opposite exponents. The zero dimensional case is also included.

Independent source reads by this reviewer:

- Formalism/LocalToGlobal/KernelLattices/LateralTheory.lean, lines 146–179
  and 210–225: actual product theta, two successive moves, character factor,
  eNat and EqP.
- Formalism/SharpRestriction/GlobalSchurBounds/TaylorLogMetric.lean,
  lines 1–60: all three actual EqP equalities.
- Formalism/SharpRestriction/GlobalSchurBounds/GeneralLinearActions/IsDiscriminantTwelfthRootOfIdealLattice.lean,
  lines 101–111 and 314–326: positive normalization of averaging, pullback,
  relative determinant and character on principal norm-one ideals.
- Formalism/LocalToGlobal/KernelLattices/ColumnData.lean, lines 258–263:
  the same generalized character convention.

The other inspected source ranges in the manifest are attributed to the
contributing agent. No complete import-closure audit or kernel replay is
claimed. The explicit quadratic Gauss sum with imaginary value is a
counterexample to dropping the arithmetic hypotheses, not to the actual
equivariance theorem. Measure support and incidence remain separate tasks.
