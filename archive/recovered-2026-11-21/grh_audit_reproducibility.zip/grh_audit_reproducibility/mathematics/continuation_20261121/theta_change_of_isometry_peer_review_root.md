# Independent root review: exact theta normalization

Reviewed manuscript SHA-256:
2d6c435c13af30980c02bc6f818a4090366cea2322ef654c07ebd059a7348901.

The root read all 802 lines. The self-dual covolume, Fourier dimension
argument, unitary finite averaging, and triple-composition phase were
checked. The elementary quaternion proof of the finite quadratic Gauss
eighth-power formula works also at even orders; the radical reduction
does not presume that a degenerate Gauss sum is nonzero.

The Cayley calculation retains alpha(delta x)=alpha(x). Its quotient
Lambda / (1-delta^{-1})(Lambda intersect delta Lambda) has the claimed
index and nondegenerate polar form. The root checked the Gaussian
kernel, diagonal torus-character integral, absolute convergence, unfolding,
complex Gaussian determinant and c^8=det(delta)^4. No inference from
complex absolute value alone to a finite-place unit is made.

The norm semicharacter and the nonprincipal ideal's half-period parity
were checked, including odd a, D=7 mod8 and even c. The fourth tensor
construction and scalar ratio follow with the correct direction of the
isometry and determinant. The determinant/valuation corollary uses the
previously reviewed LM normalization.

Independently inspected the source:
- QuadraticSemicharacters/UnitaryConstant.lean: all103 lines.
- QuadraticSemicharacters/ProductThetaMem.lean: all100 lines.
- QuadraticSemicharacters/IsSemiChar.lean: lines1--140.
These lie under Formalism/LocalToGlobal/TorsionIntegrality and match
the actual translation operators, sign semicharacters, lattice averages,
unitary eighth power and fourth tensor normalization.

Result: PASS for the analytic change-of-isometry theorem, including
the source's general ideal base. The nonprincipal base's p-integrality,
local standardization and actual arithmetic support/incidence are
separate obligations, not consequences of this analytic review.
