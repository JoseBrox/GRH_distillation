# Independent review of the local coefficient algebra

Reviewer: qrh_mathematics. Date: 2026-11-21.
Reviewed the complete fragment `theta_coefficient_algebra.tex` (684 lines), SHA256 `8deb5648ceb252c1b2f4a5c077adc4d1e1f69205d027f220ee642b6f88f308eb`.

## Conclusion

No mathematical defect was found in the stated ordinary-mathematical results. The actual representation-theoretic and separated-grid inputs remain explicit hypotheses; this review does not certify those inputs or the source transitively.

## Decisive checks

1. The real Lie-algebra decomposition and the complexified matrix-unit differentiation have the correct involution signs. The two ordered column determinants have the stated leading terms. In particular the second-order leading determinant is the complex conjugate of the first: the relation `g^-1=H g^* H` yields the required entry without an extra transposition or reversed determinant sign. Operator order is fixed throughout; no noncommutative factors are interchanged.
2. The normalized differential operators have leading term `y^j Id` on their common open domain. The lower component has strictly smaller degree, including the explicit `j=0` convention. Checking membership of their coefficient vectors in a complex subspace by distinct real evaluations is valid by Vandermonde interpolation.
3. With the form linear in its first argument, the mixed polynomial has degree at most `2j` and leading coefficient `s B(Ux,x')`. The conjugation in the second factor causes no problem because the parameter is real. The two-component shear produces exactly this mixed expression. Its pointwise phase having modulus one is correctly distinguished from preservation of the differential Hermitian form.
4. Iterated leading-coefficient extraction requires only polynomial dependence in the last variable at each stage, not simultaneous multivariate degree bounds. The exact tensor-product probability weights sum to one, so the triangle and Cauchy--Schwarz estimates have no extra number-of-nodes factor. Empty products cover `K=0`.
5. The Chebyshev extremal coefficient sum is exact, including `d=1`. Descending nodes give sign `(-1)^i` to the interpolation coefficients. Applying the same scaled Chebyshev polynomial at arbitrary alternative nodes gives the asserted optimality. The statement correctly excludes `d=0` from this formula and does not claim the nodes satisfy the source's additional separation conditions.
6. Each rational correction factor is `1+u` with `|u|<=1/D`. The logarithmic bound `L/(D-1)` has the correct direction for negative factors as well. At `N=20`, `8N/(N^2-8)=20/49`; hence the reciprocal square-root loss is exactly `exp(10/49)`. Positivity is retained and none of the denominators can vanish under the stated hypotheses.
7. The positive block estimate uses its mixed inequality for every pair of vectors. Division by the exact `Gamma S` and the two different products of polynomial values gives the stated ratio. Weighted Cauchy--Schwarz gives the averaged diagonal forms and the exact constant. The zero-diagonal and `K=0` cases are valid.
8. The Fourier phase and frequency are correct: `s=2*pi*i*l/(g*lambda)` gives `exp(s*z-conj(s)*conj(z))=exp(4*pi*i*Re(l*c)/g)` and `T^K s^K=i^K l^K`. Under the stated Fourier convention the frequency is `-2*conj(l)/g`.
9. The final minimum estimate explicitly requires a common majorant for the original diagonal product and the averaged differentiated diagonal product. This is necessary and has not been smuggled into the algebraic conclusions.
10. Both counterexamples are exact: entrywise bounds fail block positivity for the all-ones mixed block, and complex interpolation parameters give `|y|^2` instead of `y^2`.

## Scope still open

The fragment deliberately does not prove the actual radial Fourier identity, positivity and mixed inequality of the specified radial forms, their invariance under the phase/shear operator, or the simultaneous separated grids. It also does not replace the mass and formal-degree assumptions in the archimedean-size fragment. No conclusion about a flaw in the actual source follows from the two counterexamples to weakened statements.
