# Independent review of the coefficient algebra and separated grids

Date: 21 November 2026. Reviewer: root agent.

The complete mathematical contents of `theta_coefficient_algebra.tex` and `theta_coefficient_grids.tex` were read and checked. The subsequent status-only edits connecting the two sections were also checked. No mathematical defect was found. This record concerns their explicit mathematical statements, not a certification of the remaining radial analytic inputs.

Checks included the complexified right derivative convention; the two distinct orders in the noncommutative column minors; the conjugate leading coefficient from g inverse = H g star H; the level-zero convention; the requirement that interpolation parameters be real; iterated extraction without commuting preceding operators; the exact Chebyshev coefficient sum, including degree one; positivity of the rational correction factors; the uniform constants20/49 and10/49; cancellation of Gamma and the two different polynomial normalizers; positivity for all linear combinations, including degenerate forms; and the factor2 and sign in the complex Fourier character. The complete actual `BlockKWaveC.lean` was additionally read and agrees with the stated finite-dimensional reduction and its explicit hypotheses.

For the grids, I checked every endpoint and shift, the short interval bound, the long and short separations, the decreasing block indices under concatenation, the zero-degree/zero-extension cases, the availability of unused short nodes, and the coefficient bound24 using the exact factor1/2. The construction preserves the full simultaneous avoidance conditions. The eventual interval-length hypothesis follows from the stated large-parameter range; it is not claimed for arbitrary small parameters.

The fragments explicitly retain radial form positivity, the mixed inequality, wave isometry, the Fourier identity, the function-domain and limiting assertions, and the separate mass/dimension/formal-degree inputs. In particular, a unit-modulus function is not assumed to preserve a differential Hermitian form, entrywise bounds are not substituted for block positivity, and two estimates are combined into a minimum only after requiring a common diagonal majorant.

The exact finite computations are supplementary controls; the general proofs are written in the TeX fragments. Neither the controls nor this review proves the remaining analytic identities or GRH.
