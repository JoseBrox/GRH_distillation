# Independent review of the finite coefficient field

Root review, 2026-11-21. All270 lines were read at SHA-256
5f61450f1f92debd7c1a7504f0bbb4024b0a7675ce7490d8f9b1a3190641b038.

The quotient of norm-one fractional ideals by principal ideals with
a norm-one generator is finite. The proof correctly keeps the unit
obstruction after passage to the ordinary class group; norms of units
contain the squares of ground-field units. This proves that the
determinant character has all its values in a single number field,
without adjoining roots for infinitely many principal ideals.

The semilocal Hom quotient is finite for every positive support and
period denominator, including the empty set of primes. Its dependence
on the residue class of the lift uses the already checked phase-exact
indicator identity. There are finitely many positive definite
self-dual lattice classes and finitely many bounded derivative
multi-indices. Their actual algebraic coefficients consequently
generate a finite extension.

Rational unitary covariance introduces only the normal closure of E
and principal-ideal character values. The chain rule does not increase
derivative order. Thus arbitrary rational isometries do not require
new field generators. The finite bad-prime set consists of primes of
E, and all its subsets and the prescribed bounded local moduli are
included before the coefficient field is enlarged. There is no
circular reselection of primes or derivative bounds. Ramification in
the coefficient field is permitted; its normalized p-adic absolute
values are the ones already used in the measure estimates.

The root read FinAlgJetSet.lean and ExistsColInJetsIn.lean in full,
ExistsHypJetsAll.lean in full, and DegreeEqTotDeg.lean90--124,
233--318. In particular, the latter uses the actual modulus
T_u*(product N(P))^(2m) and a finite list of subsets of badP.
The construction can enlarge this to the stated m+1 list without
affecting finiteness. The source finite field extension is thus
matched, rather than assuming that all algebraic numbers already
belong to a preassigned field.

The proof passes review and supplies the coefficient-field descent
needed for the complex column identities in the fixed construction.
It does not give one field for unbounded orders or infinitely many
independently varying levels. No full kernel replay is claimed.

The final fragment at SHA-256
55142598c646f2161a9f97ebe9ead8df45a53d01be97664b1509dfb37cfe9ebb
adds only the submitted-source citation to the reviewed mathematics.
That final change was inspected. The root also read
Definitions/Foundations/ExistsBaseTwoWords.lean171--239, checking that
the finite field extension preserves toPre exactly and does not
change the primes, moduli, or derivative bounds fixed in advance.
