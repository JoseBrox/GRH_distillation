# Finite coefficient field for the required theta jets

## Mathematical scope

`theta_coefficient_field.tex` proves the finite coefficient-field extension for a fixed finite column construction. It uses the proved algebraicity of normalized jets (GM), exact unitary covariance (TE), the finite indicator and its phase (CS), and the proved finiteness of self-dual lattice classes (AL). It does not assert a single field for unbounded derivative order or unbounded independent levels.

The finite inputs are: the underlying CM field and Hermitian spaces, the finite rank and weight list, the selected and auxiliary primes, the finite character-twist family, its finite ramification set, the two local exponents m and m+1, and the direction/frame coefficients. All subsets of the resulting finite set of primes of E are included before choosing coefficient fields. The local modulus is T_u times the product of the selected local norms raised to 2m (or 2m+2 for the prescribed enlargement). An arbitrary K-valued locally constant test function is expanded in the finite characteristic-function basis and causes no further adjunction.

## Actual source interface

- `Proofs/IwasawaDecomposition/FinAlgOfFinite.lean`1–67 defines finite algebraic generation, the jet set, and the exact algebraicity and vacuum covariance interfaces.
- `Proofs/IwasawaDecomposition/ExistsFinsetSdLatReps.lean`1–18 gives the finite self-dual lattice representatives.
- `Proofs/IwasawaDecomposition/FinAlgJetSet.lean`1–108 proves finiteness of the indicator-function image of the semilocal quotient and finite field generation of all bounded jets under rational unitary transport.
- `Proofs/IwasawaDecomposition/DerivAt0CompMem.lean`1–89 is the multilinear chain-rule calculation; the ordinary proof is (JF5).
- `Proofs/IwasawaDecomposition/DegreeEqTotDeg.lean`1–318 sets the coefficient-independent host fields, bad-prime set, fixed derivative order, allSet and generator set. Lines233–240 use the exact modulus T*q_R^(2m); 283–316 give JetsIn after adjoining the generators.
- `Proofs/IwasawaDecomposition/ExistsColInJetsIn.lean`1–43 packages the finite generator set independently of the enlarged coefficient field.
- `Proofs/GlobalInterpolation/ExistsHypJetsAll.lean`81–125 chooses the algebraic generators before BaseExt.exists_base, then obtains JetsIn.
- `Definitions/Foundations/ExistsBaseTwoWords.lean`140–239: BaseField.exists_base preserves toPre exactly, adjoins prescribed finite algebraic sets, and does not impose unramifiedness at the selected primes.
- `Proofs/IwasawaDecomposition/ExistsGaloisGe.lean`1–80 supplies normal closures and the algebraic finite-idele character values; the reconstruction separately proves the field-of-values fact for the exact norm-one ideal character.
- `Proofs/IwasawaDecomposition/GensJAlgebraic.lean`1–end supplies the corresponding m+1 enlargement while retaining the original prime selection and analytic data.
- `Definitions/AutomorphicMembership/JetsInIffStepField.lean`1–end spells out the exact rational-index condition.
- `Proofs/GlobalInterpolation/StepBoxIffStepSuppDeg.lean`111–143 converts fixed-degree membership into JetsAll. `BlockTheory/GlobalSignature/JetSumTable.lean`80–88 is the actual RatIdx definition.

## Read and verification scope

The manifest records exact hashes and conservative line intervals. This is an ordinary mathematical reconstruction and source comparison, not a complete Lean replay. The root independently read the entire original 270-line fragment and the decisive finite-generation providers before its submitted-source citation was appended. Compilation is two-pass XeLaTeX in a dependency wrapper; the check wrapper uses a snapshot of two external references to AL and ACL/CV rather than reading a concurrently rewritten manuscript auxiliary file.
