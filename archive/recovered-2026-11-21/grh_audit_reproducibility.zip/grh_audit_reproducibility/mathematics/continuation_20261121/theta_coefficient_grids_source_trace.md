# Actual separated interpolation sets

## Completed mathematical proof

theta_coefficient_grids.tex closes the finite interpolation-set and separation input left conditional at the first coefficient-algebra checkpoint. It uses the actual chosen sets, not a replacement family requiring a new comparison theorem.

At a differing binary spectral position l, the source interval is alpha=5/2-v_l, beta=Delta/2-v_l. Its length I is independent of the place. The exact actual size is N=20(r+1), and the needed degrees are at most R=2r. Under I>=6N^3+6N, put q=I/(6N). The long blocks start at alpha+(2N+2a-2)q and have length q-1. CarrierGrids defines the union of Chebyshev sets of degrees1 through max(1,R) on each block; this is exactly the union in the new fragment.

CarrierSizes chooses each short node inside [alpha+jN^2,alpha+jN^2+1/2], avoiding the finitely many zeros of P(Y)P(Y+1). The new proof works for every choice in those intervals. For the actual spectral parameters, it also proves P has no zero on the full working interval, so it does not silently depend on an extra root-avoidance hypothesis.

The proof verifies the exact source shifts by0 or1, the long--long and long--short separation N^2+1, and the short--short separation at least N^2/8. It verifies the source's margin of2 between the differing spectral entries and proves Q>0 directly by its paired factors. No positivity of a differential form is inferred from this scalar sign.

For every degree d>=1, the exact Lagrange coefficient sum is one half times (4/(q-1))^d. Since d<=2r<N/10 and q>=N^2+1, the factor1/2 absorbs the endpoint loss. This proves the improved actual bound (24N/I)^d, compared with the source's (28N/I)^d. The degree-zero coefficient sum is exactly1.

Admissible sequences are defined in ordinary language with all index and signed-shift conditions. New long grids have block indices h+K+1-a, so old indices are unchanged after prepending. All choices from the product grids are admissible. In degree zero, removing at most h used underlying nodes leaves at least K of the N short nodes. The proof includes K=0 and r=0. Product absolute Lagrange weights and their pushforwards are genuine probability measures, without a multiplicity factor.

The final corollary supplies the exact denominator conditions in the rational correction bound and hence the conditional improved Fourier barrier with constants24 and exp(10/49). The preceding numerical range implies the interval-length requirement for all sufficiently large k with a uniform threshold.

## Exact source route and read coverage

- CarrierSizes: actual interval length, N, short-node selection, and avoidance. Read lines1--245; later bodies are not claimed as read.
- CarrierGrids: fully read; actual finite Chebyshev sets, sharp coefficient estimate, shifted separation, and all set interfaces.
- GridsRichITc: fully read; exact identification of these sets with the theta input.
- AdmissibleAtOfAdmissibleList: fully read; local/global signed-sequence extension and probability pushforward.
- RoomOffGridSymmetric: fully read as an adjacent avoidance provider, although the direct disjoint-block route suffices here.
- PBCutInside and StatementI: fully read; exact margin and spectral polynomial conventions.
- Remaining definition excerpts are enumerated exactly in theta_coefficient_grids_source_manifest.json.

build_theta_coefficient_grids_manifest.py reproduces the source hashes and conservative read scopes. This is a source-reading record, not a formal proof-graph or re-elaboration claim.

## Checks and status

check_theta_coefficient_grids.py records1145 passing exact rational controls in theta_coefficient_grids_checks.json, including interval endpoints, every neighboring-block separation for selected actual ranks, the improved coefficient bound, both last spectral-entry cases, and the excluded reuse of an old short node. The general proofs are in the TeX fragment.

QRH independently read every line and found no mathematical defect; its record is theta_coefficient_grids_peer_review_qrh.md. The combined global-lattice, archimedean-size, coefficient-algebra and grid check compiles cleanly to30pages.

No counterexample to the actual finite-grid hypotheses was found. The radial Fourier identity, differential-form nonnegativity/mixed inequality, wave isometry, and function-domain/limiting assertions remain unproved here. The actual mass recurrence, source-space dimension formula and formal-degree estimate remain separate as before.
