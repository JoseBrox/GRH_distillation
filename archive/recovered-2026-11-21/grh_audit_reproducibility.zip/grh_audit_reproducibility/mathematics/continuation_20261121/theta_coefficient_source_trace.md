# Coefficient algebra: source trace and status

## Scope and result

The mathematical fragment theta_coefficient_algebra.tex reconstructs genuine algebraic steps of the actual archimedean Fourier coefficient proof. It does not certify the complete estimate EstWave or EstLift. It proves the two ordered differential-minor leading identities, the normalized two-component polynomial identity, its real-variable mixed leading coefficient, iterated Lagrange extraction without assuming commutation of the old operators, exact probability averaging, the rational correction bound, and the positive-block conversion with every normalization factor retained. The positive-block theorem states the mixed-form inequality as a hypothesis.

The exact source versions and conservative read ranges are in theta_coefficient_source_manifest.json, reproducible by build_theta_coefficient_manifest.py. A file recorded as fully read has had its complete body inspected in this pass or the immediately preceding coefficient pass; fragmented read ranges are retained wherever the full body was not inspected. This record does not assert formal dependency closure or successful Lean re-elaboration.

## Actual source route

1. StatementG, StatementIO and OperatorsCommuteTranslations define the Hermitian matrix, right-invariant complexified derivatives, ordered shifted column minors, and the two coefficient matrices. The basis is e0,...,e(r-1),w0,...,wk,f(r-1),...,f0, with the nontrivial second order beginning f0,...,f(r-1). PBGLet and LeadingTermIdentity provide the actual leading coefficients. The manuscript gives a shorter direct expansion which uses no commutation relations.
2. RealInputsClosedAdmissibleSettings defines the normalized positive/negative operators, the two-component transformations and the shifted negative parameter. PBGWaveMain, PBGDegW and PBGWave apply these to actual sliced functions and repeatedly extract the highest coefficient. The manuscript proves the algebraic identities on a common smooth-function domain. It explicitly retains the actual slice-domain/compactness requirements when these functions are inserted into a radial form.
3. LagrangeExtraction gives the finite extraction and weights. SizeAtMinusW supplies the precise actual grid interface used in the local Fourier argument. Its imported construction of separated admissible grids has not been reconstructed here. The sharp Chebyshev coefficient sum in the manuscript is a separate exact minimization result, not an assertion that those nodes meet the actual simultaneous avoidance requirements.
4. StatementWd and LevelOneWordEstimate identify the exact plus/minus rational factors. CutIntervalLong identifies the base function with the spectral polynomial Q, proves its positive sign on the selected differing-position interval, and supplies the denominator separation. At the actual N=20(r+1), the manuscript improves the source's square-root loss e to exp(10/49). It does not change the spectral intervals or discard any denominator condition.
5. BlockKWaveC and RatioBound give the exact finite positive-block estimate. The manuscript retains Gamma, the previous product of polynomial values, the different factors P(y) and P(y+1), and the Lagrange probability weights. The inequality is required for all linear combinations, not merely entrywise.
6. WaveLocalBuiltPlaces, WaveLocalPositiveCompactSupport and StatementKB assemble the local coefficient bound and the barrier X. The phase is exp(4 pi i Re(lc)/g). After z=lambda c, the parameter is s=2 pi i l/(g lambda) and T=g lambda/(2 pi), so T^K s^K=i^K l^K. The usual negative-phase Fourier frequency is -2 conjugate(l)/g. The no-power and power bounds may involve different diagonal forms; the manuscript explicitly requires a common majorant before writing a minimum of the two scalar bounds.

## Analytic inputs inspected but not independently reconstructed

SizeStandardCompact was read in full. It compares the actual compactly supported coefficient forms with radial module forms, obtains the required positive representation from ThmPActualCpt, and invokes a weighted determinant/form-pairing inequality. It is not merely a pointwise positive integral.

ModuleFormPosCompactSupport was read in full. Its positivity proof uses the same radial representation theorem and the radial module comparison, with a positive proportionality factor.

VectorIsomorphismCompactSupport was read in full. Its isometry proof treats both positive residual rank and residual rank zero, comparing to radial wave identities. The unit absolute value of the scalar exponential is insufficient on its own, because the actual Hermitian form also contains differential and component operators.

StandardPairingOfHeads was read in full. Its exact compact-support statement asserts a continuous integrable scalar function, an explicit equality away from zero with the next-level kernel, and an integral identity for every complex phase parameter. It still imports the radial and terminal integration identities and their normalizations.

None of these wrappers is being counted as an ordinary proof of its imported representation or integration theorem. The separate mass recurrence, source-space dimension formula, and formal-degree lower bound from theta_archimedean_sizes.tex remain unchanged.

## Counterexample search

No counterexample satisfying the actual hypotheses was found in this pass. Two false weakenings are exhibited in full in the fragment:

- Entrywise mixed bounds do not imply the positive block matrix estimate. The block matrix with both diagonal blocks I2 and off-diagonal blocks all ones has value -4 at (1,1,-1,-1).
- The real interpolation variable cannot be replaced by an arbitrary complex variable in a sesquilinear pairing: the simplest example gives |y|^2 rather than y^2.

The actual source uses real nodes and tests the mixed form on all linear combinations, so neither example contradicts the source.

## Exact controls and compilation

check_theta_coefficient.py, using SymPy and exact rational arithmetic, records 993 passing assertions in theta_coefficient_checks.json. They include deliberately noncommuting column-minor endomorphisms, exact unitary matrices in the two index orders, mixed leading coefficients, Lagrange monomial identities, exact Chebyshev sums, rational correction inequalities, positive-block normalization, the two counterexamples, and the Fourier phase. These are reproducible controls, not substitutes for the displayed general proofs or certificates of the remaining analytic assertions.

theta_coefficient_check.tex includes the already reviewed global-lattice and archimedean-size fragments and the new coefficient fragment. Two XeLaTeX passes produced a clean 26-page PDF without remaining warnings or overfull boxes.

## Subsequent completion of the finite grids

After that first checkpoint, theta_coefficient_grids.tex supplied the complete actual finite-set, shifted-separation, signed-sequence extension and probability construction. It improves the interpolation constant28 to24 at every needed degree. The coefficient fragment now points forward to that proof and retains only the analytic function-domain assertions among these obligations. The original read scopes above remain unchanged; the additional sources and proof are documented in theta_coefficient_grids_source_trace.md and its manifest. The combined check now has30pages.
