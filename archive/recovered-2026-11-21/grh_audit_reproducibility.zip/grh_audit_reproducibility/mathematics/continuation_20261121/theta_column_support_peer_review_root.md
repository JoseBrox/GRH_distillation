# Independent review of the arithmetic theta column supports

Reviewed by the root agent on 2026-11-21. The full 586-line proof was
read. The final change only renamed labels to avoid a collision with
the existing slope section. Reviewed SHA-256:
a2cb7aec6889649ca63de93a7081fb2c25de8d2b9c127bffd53b144b71e983b2.

The selected-prime assumptions imply complete splitting with multiplicity
one. The eigen-direction unit argument uses integral separating
operators and the coordinate ideal's actual generator. The moment
coordinate retains the ideal norm, discriminant ratio, ordinary period,
and Hermitian adjoint, without factorial division.

The operative indicator is Amb.thInd. Its outside inverse square-root
volume cancels the volume in the finite Fourier coefficient. The
resulting denominator is the finite index n. The general lift is
allowed to have an unrelated auxiliary denominator; the common half
lattice and the difference in the opposite half lattice prove lift
independence with its phase. This does not require either a p-adic unit
volume or an unprovided comparison of auxiliary exponents.

The Fourier transform of the affine matrix equation is supported on
the annihilator of its kernel and equals p^(-fa) times the corresponding
character. Nonzero residue functionals are used essentially. In the
conjugate ordinary type, exact Fourier inversion restricts the original
norm-one measure. In the selected type, the annihilator is the quotient
of the actual companion lattice. The exact theta move supplies both
the positive index square root and the determinant character. Their
p-adic norms cancel, leaving the claimed norm p^(fa).

Prime-to-p auxiliary factors are handled through the primary
decomposition of finite quotients and representatives with prescribed
p-divisibility. The proof retains the torsion phase, and finite sums
preserve the bounds by the ultrametric inequality. Rational points
with the required congruences are dense in both ordinary supports,
so finite simultaneous approximation applies to all the needed
polynomials. Descent to the stated coefficient field is required only
at the source's RatIdx indices and is not inferred from algebraicity
alone.

The root directly read JetSumTable.lean lines 25--125, ThDistC.lean
lines 58--107 and 465--478, as well as the previously reviewed exact
theta-move statement and the CV9--CV10 target. The author-agent's wider
source scopes are in the manifest and are not misreported as a second
complete root reading. The root reran the exact checker: 11,506
cyclotomic character sums in 18 cases and 12 scalar valuations passed.
The general assertions are proved in the text, not inferred from these
finite checks.

No flaw was found under the actual hypotheses. Adjacent-column
incidence, global Hecke commutation, the remaining analytic bounds and
the final arithmetic assembly are separate tasks. No full Lean replay
or complete GRH proof is asserted.
