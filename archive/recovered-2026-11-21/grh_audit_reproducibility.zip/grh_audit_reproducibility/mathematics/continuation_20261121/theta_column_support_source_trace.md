# Arithmetic column support: exact source comparison

The CS manuscript proves the two ordinary moment-support inputs
CV9–CV10 for the actual finite theta column. It retains p>=5,
the selected completely split prime, the prime-to-p elliptic
ideal norm and auxiliary levels, and the actual nonzero residue
functionals. It does not claim the adjacent-column incidence law.

## The actual indicator, not a different normalization

The operative definition is Amb.thInd in ThDistC.lean90–98,
not merely thIndC in XiIndCClass.lean. It has a factor
volC^(-1/2) outside xiInd, whose own finite Fourier coefficient
is volC^(-1/2)*(volC/n). The two factors cancel exactly.
CS12a is consequently n^(-1) W_{-s_x} sum_y W_y F, with
positive finite index n. No p-adic unit assertion about volC
is assumed.

Amb.liftW uses a lift belonging to some halfAO(c'), rather
than only halfAO(c). This matters when the auxiliary support
denominator is larger than its periodicity denominator.
CS12a permits exactly this general lift. The proof of its
independence uses two lifts in a common integral half lattice
and their difference in halfBO(c). Thus the Weyl phase is
controlled exactly. ThetaMovedCosetIndicatorVacuumShape.lean
was read in full; its thInd_shape at284–399 is the same
formula, and its two_lifts at242–281 verifies the same issue.

The basic finite Fourier definitions hatS, xiS and xiInd are
in XiIndCClass.lean18–38. The concrete half lattices, local
exponents, lift and scaling are at170–252. The source uses
the quadratic norm semicharacter alV, consistent with TE/GM.

## Test function, supports and moment table

FiniteSumNonzeroLargeDepth.lean646–650 defines phiT as
the indicator that x maps the selected source lattice into
the selected target and intertwines the two residue
functionals. StdLatUnimodular.lean81–97 requires the functionals
to be additive, linear over the residue field and nonzero.
Since each selected residue field is F_p, CS4 is exactly
this condition. Nonzero is used in the codimension a and
index p^a calculation; the exact check file includes the
excluded zero-functional control where this calculation fails.

JetSumTable.lean30–35 gives the supports suppBar and suppP;
its ptTab at64–66 is the product of u_tau times the entries
of the Hermitian adjoint. Its jetSum, RatIdx and OffDatum
are at74–88, and MomAt at95–120 explicitly requires the
factor p^(-f*a) in the selected type. CS7, CS15, CS23 and
CS26 match these definitions, including the adjoint.

CS proves the selected Fourier calculation directly:
the transform of 1_{ell' X=ell} is p^(-fa) times a
character on the annihilator of the kernel. The annihilator
is the companion Hom-lattice quotient. TE then supplies
its exact normalized move, including the determinant
character. The index square root has norm p^(-fa/2),
and the character has norm p^(fa/2); the surviving norm
is exactly p^(fa). In the conjugate ordinary type the
same Fourier sum restricts the norm-one measure directly,
so no p-denominator survives. This is a shorter independent
ordinary proof of the conclusions of MemSuppBarOfNe.lean,
RelIndexNeZeroOfSmul.lean and MomentsCosetSum.lean, all of
which were read in full.

The actual companion is the one in MomentCompanion.lean
and RelDetCompanion.lean, both read in full. It is the
kernel of ell' at selected primes and its dual at the
conjugate primes; its relative determinant is (pi/bar pi).
JetMomentsOfUnitPeriod.lean108–144 applies precisely that
move and the same character convention.

The selected hypotheses pi*bar(pi)=p, coprimality, selected
norm p, and selected cardinal f are invoked at
JetMomentsOfUnitPeriod.lean32–35,51–58,101–123. They force
complete splitting, as CS explains. The inverse half
different is a unit there; NotDvdDifferent.lean, read in
full, gives the source's localization verification.

## The ordinary period and eigen-direction units

ThDistC.lean60–62 defines jetC as the mixed derivative
multiplied by the powers of cD, with no factorial division.
Its IsDgen at473–475 says cD generates the corresponding
coordinate line of mmM. These lattices are defined in
IsDiscriminantTwelfthRootOfIdealLattice.lean148–155.
CS5 is this exact lattice, built from the inverse half
different, without an extra elliptic ideal factor.

NormPadicEmbeddingLeOneOfMemInverseHalfDifferent.lean was
read in full. Its coordinate integrality and integral
separating operators imply norm_generator_eq_one at203–221.
CS8 proves the same assertion directly at the completely
split selected prime. JetMomentsOfUnitPeriod.lean44–48
sets u_tau=lam(cD_tau)/Omega and invokes precisely this
unit theorem.

The source pairing conversion in
PairingScaledDirectionsEqPeriodPairing.lean was read in
full. It replaces the principal discriminant-normalized
period Omega_0 by A*Omega_0*lam(delta_I/delta_0).
CS6 and the direct Hermitian calculation CS9 retain
exactly those factors. The elliptic ideal norm and the
discriminant ratio are both units at the selected prime.

## Other primes, checks and limits

The away-prime test function is bounded and periodic in
the exact sense OffDatum specifies. Its quotient is of
order prime to p, since cA and g are prime to p. CS25
factors the full indicator formula through the elementary
primary decomposition of its finite lattice quotients.
All away-prime coefficients are values of that test function,
roots of unity, and inverse indices prime to p. It does not
assume an inequality between the two auxiliary exponents
A,B: LocCst.Ok only bounds both below by M.

check_theta_column_support.py uses exact integer character
counts modulo the cyclotomic polynomial Phi_p. It checks
11,506 Fourier sums in18 finite matrix examples, separately
checks Y^t ker(ell')=0 for the annihilator, and checks12
normalization valuation identities. These computations
support the general proofs; they do not replace them.

The full arithmetic table may descend only the indices
specified by RatIdx. CS asserts equality at precisely such
descended indices and proves algebraicity of all the jets
used to construct the measure. It does not assume that an
arbitrary algebraic coefficient already belongs to the
specified coefficient field. The general kernel covariance
and adjacent-rank incidence are separate steps. No complete
Lean replay, complete import-closure audit, or completed
proof of GRH is claimed.

