# Focused independent review: actual theta kernel and selected-prime column estimate

Reviewer: /root/formal_degree_review.
Result: PASS within the following precise scope.
Final fragment: theta_column_valuation_completion.tex.
SHA-256: 6209d0a574509b0e2a99de6ee1cecb5c824bcf6d7ac4680bfb3486c3206d2ac2.

## Read scope

The reviewer read the entire fragment and independently compared its kernel identification with:

- ThDistC.lean, lines 1–62 and 138–151 (also inspected 63–137 for thInd, jetK, and the character definitions).
- JetSumTable.lean, lines 1–145.
- ValuationLeOneOfMemZmu.lean, lines 176–228, especially jetOp_sum and kerOf_thDistC.
- arithmetic_column_valuations.tex, lines 1–190 and 575–805, for the precise existing polynomial, integral-lattice, one-step, and column statements. This was a focused comparison, not a new full review of that already reviewed fragment.

The previously reviewed coefficient-field, moment, support, arithmetic-equivariance, Hecke-commutation, hook, and lowering results are inputs. Their entire transitive source dependencies were not reread. No Lean compilation or full kernel replay was performed by this reviewer for this record.

## Normalization checks

1. The source uses derivative indices (tau,beta,alpha); TC1 uses Z_(tau,alpha,beta). The transposition is explicit and correct. subD inserts the first a target columns, exactly as the polynomial Q_m construction requires.
2. jetLin sends each mixed monomial to J_m times its remaining target monomial. It introduces neither a multinomial coefficient nor a factorial denominator. derivAt0 is the ordinary iterated Frechet derivative; the mixed partial identity in TC2 is correct for the holomorphic functions under consideration.
3. Coefficient comparison in the independent Z variables shows each Q_m(F) belongs to the target polynomial representation. Therefore the arbitrary linear projection retrVV is the identity on the actual image, without any integrality assumption on that projection.
4. jetK contains the inverse chiF normalization. Defining G_x with that normalization and keeping the separate muInvDet ratio eta gives exactly TC4–TC5; no character is counted twice.
5. kerOf_thDistC uses the finite quotient c_A^{-1}H/c_BH and the ambient allowed denominator D=c_A c_B. The implication c_A x in H implies c_A c_B x in H is exactly the source check. The theta indicator is still evaluated at c_B. No additional quotient-cardinality factor occurs in kerOf.
6. The positive square-root/Fourier normalization stays inside the previously constructed indicator. This identification does not re-normalize the indicator.

## Quantifiers and column estimate

The statement retains the actual selected-prime hypotheses, the source/target weight compatibility, integral test data away from p, the unit direction constants, and the target hook condition. The common finite coefficient field is the one constructed for the fixed finite data; the argument does not assert uniform algebraicity for an infinite family of arbitrary derivatives.

JetSumTable.InIntClosure provides one finite integral sum for all moments in any fixed finite set, exactly the simultaneous approximation used in CV. The selected support carries scalar p^(-f N_i), whereas the conjugate support carries scalar one. The factor p^(s_0 r) in the upper-neighbor commutation law has the same direction as the reviewed HC identity. Induction therefore adds s_0 r(i+1) at step i, giving b_m=m e+s_0 r m(m+1)/2.

The final editorial correction explicitly requires nonnegative integers W_tau. Thus e and b_m are integers. The valuation statement uses v_w(p), so extending the coefficient field introduces no missing ramification factor. Multiplication by p^A with A nonnegative preserves the resulting inclusion. The statement concerns the modified initial lattice p^A U_0^m S_0, not all of S_0.

At conjugate-type places the single-step maps already preserve the original lattice, so composition does too. Stabilizer denominators are units under p>2f N_m+1. The cited lowering and row-pairing assertions then add no denominator at that place.

No counterexample or unresolved mathematical defect was found in this fragment. The stated conclusion remains the selected-prime column divisibility under its displayed construction hypotheses. It does not establish nonvanishing, estimates at the auxiliary level primes, or the global archimedean period comparison.

## Final editorial amendment

The final version 6209d0a574509b0e2a99de6ee1cecb5c824bcf6d7ac4680bfb3486c3206d2ac2 was checked against the fully reviewed mathematical version e46b623280d4d59e6d8df182a8b52557db0db9086a17d7e95d531c13a08dbdc6. Equation TC1 now correctly closes its split environment and writes the substitution as F^sharp((Z_tau Y_tau,[1,a])_tau), with Y_tau,[1,a] explicitly defined as the first a columns. This is the same matrix substitution used in CV; its indices and dimensions remain correct. The theorem and proof logic are unchanged. PASS is retained.
