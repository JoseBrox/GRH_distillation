# Actual theta kernel and selected-prime column estimate

The conventional fragment is `theta_column_valuation_completion.tex`. It closes the identification of the actual finite theta kernel with CV2 and combines the reviewed moment, support, finite-field, hook, stabilizer and incidence results to prove the selected-prime column estimate on the prescribed modified initial lattice.

## Exact definitions inspected by the root

- `Formalism/LocalToGlobal/KernelLattices/ThDistC.lean`, 1–220: `DVar`, `subD`, `jetLin`, `jetMap`, `retrVV`, `jetOp`; ordinary `iteratedFDeriv` in `derivAt0`; scaled derivative in `jetC`; `jetK` and the exact determinant ratio in `thDistC`. The generic projection is harmless because the universal polynomial's coefficients already lie in the target representation. The finite coefficient-field result supplies every used index, so the fallback zero in algebraic descent is never used on a nonzero contributing term.
- `Formalism/LocalToGlobal/Columns/FiniteSumNonzeroLargeDepth.lean`, 580–647: actual semilocal Hom module, finite quotient sum and kernel.
- `Development/AbelianVarietyTheory/BlockTheory/GlobalSignature/JetSumTable.lean`, full: actual finite jet sum, normalized adjoint matrix coordinates, both supports and the scalar p^(-fa).
- `Development/AbelianVarietyTheory/Proofs/SatakeParameters/ValuationLeOneOfMemZmu.lean`, 176–262: finite linearity in the jet table and exact `kerOf_thDistC` identity. The c_A c_B admissibility test is discharged from c_A x integral.
- `Development/AbelianVarietyTheory/Proofs/SatakeParameters/JetOpIntegral.lean`, 1–155: actual coefficient compatibility and distinct auxiliary-level-prime obligations. The latter are not claimed as proved by this fragment.

All paths are relative to `sources/lean/src/`. The separate manifests for CV, GM, CS, JCF, HC and FH record their broader source provenance and reviews.

## Mathematical normalization

The source derivative variable has indices (tau,beta,alpha). The universal polynomial uses Z_(tau,alpha,beta), so its substitution is exactly the matrix product ZY. The derivative is an ordinary mixed derivative, not a Taylor coefficient; no factorial is inserted. The normalized theta indicator already includes the volume and finite Fourier factors. The only remaining scalar outside the summed jet table is the determinant/frame character ratio, which is a selected-prime unit under the retained prime-to-level hypotheses.

The class sum uses inverse stabilizer orders and the actual upper-neighbor operators. The selected-prime moment loss p^(-fa), determinant factor, target hook bound and residue removal give p^e U_(i+1) K_i integral, with e=2 sum W_tau+fN_m. HC gives U_(i+1)K_i=p^(s0 r)K_iU_i. The iteration has exponent b_m=m e+s0 r m(m+1)/2. It applies to the actual initial lattice p^A U_0^m S_0 with A>=0; it is not asserted on an arbitrary unmodified initial vector.

## Limits

The displayed construction hypotheses are retained. This fragment does not prove seed nonvanishing, bounds at the two auxiliary level primes, the integrated archimedean norm estimate, or the final arithmetic inequality. It is an ordinary mathematical proof and focused source audit, not a full kernel replay. No numerical test is needed for the finite linearity identification; the previously recorded moment, Fourier and incidence controls remain independent corroboration.
