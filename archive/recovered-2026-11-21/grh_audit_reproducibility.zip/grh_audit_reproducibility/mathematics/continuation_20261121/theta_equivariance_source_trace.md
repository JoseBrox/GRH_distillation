# Exact arithmetic theta equivariance

The TE fragment proves the exact predicate EqP for the normalized family,
not just its eighth powers or absolute values. The definition audited is
TaylorLogMetric.lean37–52: the first identity is pullback covariance under
the two unitary groups, followed by the right and left finite averaging
identities. In LateralTheory.lean157–179 the actual eNat is the product
base vector followed by a horizontal and a vertical normalized average,
multiplied by the determinant characters with exponents n'/2 and -n/2.
LateralTheory.lean219 calls precisely that predicate EqP.

## Arithmetic hypotheses retained

The CM extension E/F is unramified at all finite places. Even dimensions
are retained. The source invokes this unramifiedness at
SplitPairOfGen.lean13 via D.sp.cm.cmUnram. The underlying HostDer.unramEF
at ConjEMemHostFIff.lean135 excludes inertia of complex conjugation.
DataHost.lean65 gives the factorization of the relative different as
b times its conjugate, and153–154 defines the fractional ideal AA0 as
b inverse. Thus the trace lattice in TE2 is exactly the elliptic ideal
times AA0 times the integral Hom module. The complex scaling and the
elliptic ideal norm in its Hermitian form are retained.

## Exact phases, not only eighth powers

The source path FinalEq -> Outright -> EqPAll -> SplitPairOfGen ->
SquareSplitPairs/EqPOfPair -> PolFamInhabited -> EqPOfSplit reduces the
identities to square and triangle phases and unitary determinant
constants. MuOneOfSplit.lean was read in full: it proves nonnegativity of
the finite triple sum by splitting representatives and summing characters.
TE instead works directly on the same finite quadratic group P/T already
identified in TC, yielding a shorter proof of that exact positive sign.

The local Cartan provider was traced through the actual statement in
SqPair.lean and the wrappers in OrbitalBoundsConclusion. The lengthy
transitive local proof closure has not been represented as inspected.
TE gives a separate complete proof: primitive-vector correction with a
unit trace derivative gives a common hyperbolic plane for both lattices;
induction and CRT give the projector required by the source's split-pair
statement. This works also in residue characteristic2.

For determinant constants, TE uses the already checked Gaussian trace
formula TC31. Local norm surjectivity from the independently reviewed ACL
lemma gives an element whose norm is -1 modulo any prescribed integer.
It conjugates the actual finite Cayley quadratic function and makes its
sum real. This strengthens the eighth-power identity to the square
identity in even complex dimension. Taking an even number of rows or
columns removes the residual sign before the determinant characters are
inserted. The final covariance and both moves follow exactly, with the
same positive index square roots as the source.

The alternative normal-family provider
Development/AbelianVarietyTheory/Proofs/IwasawaDecomposition/NormalisedFamilySatisfiesEquivarianceLaws.lean
was also read in full. Its comparison of two character choices agrees
with the principal-ideal cancellation used in TE.

## Verification and scope

The fragment was self-checked against the exact source definitions and
compiled with its OT/CM/LM/TC/CI/TS dependencies and the exact two local
Hermitian lemmas excerpted from reviewed arithmetic_classes.tex. The
two-pass wrapper has40 pages, no undefined references or citations, and
no overfull boxes. The TE fragment itself occupies about6 pages.
The manifest records full versus partial source reads and exact hashes.
It does not assert a full Lean replay, a full import-closure audit,
or a completed GRH proof. No counterexample under the actual retained
hypotheses was found. The remaining column support and incidence
identities are not supplied merely by equivariance.
