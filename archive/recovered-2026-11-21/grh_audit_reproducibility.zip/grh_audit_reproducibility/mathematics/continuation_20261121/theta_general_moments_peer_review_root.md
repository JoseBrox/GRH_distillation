# Independent review of the general theta moment laws

Reviewed by the root agent on 2026-11-21. The complete mathematical
argument was read, including the final clarification concerning sums of
torsion lifts at a fixed level. The reviewed manuscript has SHA-256
44d83c4bd33999abd5f566c97322a2cee2a49c7029e0605a7aeed11d23501cb9.

## Checks of the argument

The rational orthogonal frame has positive integral norms prime to p.
The integral frame lattice has prime-to-p index, and the finite Heisenberg
average is nonzero by the perfect pairing of the two finite quotients.
This gives an actual finite sum of products of translated elliptic theta
functions, rather than an unsupported identification of theta spaces.
The argument does not require the arbitrary complex coefficients of this
finite sum to be integral.

The coordinate change from the elliptic measure to the lattice measure
uses A_i=a_i z_i. Since each a_i is a p-adic unit, it preserves the
integral lattice and the norm. The Hermitian convention, the Weyl phase,
and the factor a_i in each character were checked together. The choice of
one integer S prime to p clears the finitely many denominators and is
independent of the torsion level. At each fixed level n, the integral
numerator and conjugate divisibility by p^(2n) survive sums and negatives.
No assertion of this form for arbitrary mixtures of levels is needed or
made. CRT supplies all characters of the level-n lattice quotient.

The norm-one assertion for the actual normalized theta function uses the
previously proved CM period and finite averaging results, as well as
exact change-of-isometry covariance. It does not assume that an
unspecified complex rescaling is a p-adic unit. Determinant characters
are units by the stated ideal-power relation.

The algebraicity argument fixes an embedding of the algebraic numbers,
allows its extension to C, and uses the bounds for every such extension.
A transcendental coefficient can be moved to transcendental p-adic
values of arbitrarily large norm by extending transcendence bases. This
contradicts the uniform bound. The prime-avoidance argument and the
clearing of rational directions were also checked.

## Source comparison and limits

The root agent read the exact definitions in TranslateMomentsAll.lean,
lines 1--95, including goodLifts, MomentsAt, and the fixed-level additive
closure. The author-agent's additional exact source scopes are recorded
separately in the source manifest; they are not represented as a second
complete root reading of those helper files.

The conventional proof passes review under its stated hypotheses. The
remaining finite support and Hecke commutation arguments are separate
tasks. This review is neither a full Lean kernel replay nor a conclusion
that the entire submitted proof is correct.
