# Finite-target reduction for the remaining orbital germ formula

Companion fragment: `theta_germ_uniformity.tex`.
Date: 21 November 2026.

## Result and exact scope

The fragment proves that, on the fixed compact parameter range c*t^m in Q,
only finitely many marked cokernel types can occur in either configuration
of the orbital germ identity. Consequently a scalar orbital germ formula
proved separately for each of finitely many fixed integral matrices implies
the full kernel germ formula uniformly against every comparison
configuration, of arbitrary total size.

The scalar orbital germ formula itself is not proved here. Its hypothesis
still requires uniformity as c*t^m varies over the fixed compact set Q.
Only the comparison-target uniformity is removed as a separate obstacle.
The pointwise neighborhoods are intersected over a list fixed before the
later parameters t,c are chosen.

## Mathematical proof

1. If the determinant of an integral n by n matrix belongs to a compact
   subset D of K^times, compactness of D^(-1) gives one N with
   p^N/det(Z) in R. The adjugate formula then gives
   p^N R^n subset ZR^n subset R^n. This does not require a maximal order,
   a principal ideal theorem, or a determinant-volume formula.
2. Every such cokernel is a quotient of finite (R/p^N R)^n. A specified
   vector has finitely many choices, and its functional has image in
   p^(-N)R/R because p^N annihilates the module. If a=#(R/p^N R) and
   B=a^n, the displayed elementary upper bound for marked types is
   2^B * B * a^B.
3. For s=m+1 and z^s=(-t)^m c, the determinants of h[m,t][1,c] and
   h[s,z] are exactly equal. The two signs differ by exponent 2m, so
   equality holds before taking an absolute value.
4. Only types actually realized by an integral orbital matrix are kept.
   Each therefore has a fixed realizing integral invertible n by n matrix.
   This avoids assuming an arbitrary marked finite module has the special
   last-vector/last-inverse-coordinate realization used in the source.
5. The kernel is a finite sum of its first argument's orbital coefficients,
   evaluated against the second argument's marked cokernels. Types outside
   the finite list contribute zero on both sides. Intersecting the finitely
   many pointwise neighborhoods and summing their identities proves the
   unrestricted comparison-configuration formula.

## Source connection

Paths below are relative to `sources/lean/src/` and pinned by
`theta_germ_uniformity_source_manifest.json`.

- `Formalism/DoubleCosetMeasures/Statement.lean`, lines 55--110:
  reversing block matrices, marked last vector, and last inverse-coordinate
  functional. These give the exact determinant and marked-cokernel
  conventions used in the new proof.
- `Formalism/HermitianCurvature/BlockKernelPropertiesOfSteps.lean`,
  lines 1--125: the local assumptions and actual finite orbital kernel.
- `Formalism/HermitianCurvature/ThetaExistenceInductiveFromPieces.lean`,
  lines 1--160 and 410--472: the configurations, germ coefficient,
  HeadReduction, Germ, KpFromBB and GermKernel. The source GermKernel
  chooses its neighborhood before the comparison configuration. The new
  proposition shows how that quantifier order follows from finitely many
  scalar versions of Germ that may choose a neighborhood separately for
  each fixed target matrix.

These are exact definition/statement comparisons. This pass did not read
or certify the full source proof of HeadReduction, OscReduction or Germ.
The original source already asserts the stronger uniform statement; the
new lemma is a conventional simplification of what remains to be proved,
not a claim that the source theorem is false.

## Independent review and compilation

The Siegel agent independently read the complete fragment and checked the
adjugate bound, finite count, exact determinant signs, realized-target
selection, arbitrary-size comparison sum, and zero/empty cases. No
correction was needed. It specifically confirmed that compact-parameter
uniformity in c*t^m is still retained as a hypothesis.

The fragment was compiled twice with XeLaTeX together with
`theta_estimates.tex` and `theta_orbital_identity.tex`. The internal
`theta_germ_uniformity_check.pdf` has 27 pages and no warnings, undefined
references, overfull lines or compilation errors. No computational check
is needed for the finite-module and adjugate arguments.

## Subsequent completion of the scalar germ

The scalar germ that was still conditional at the date of the original review is now proved by theta_head_reduction.tex and theta_scalar_germ.tex and assembled in theta_germ_assembly.tex. The complete conventional arguments and the assembly quantifiers were independently checked; see theta_scalar_peer_review_qrh.md. This updates the status of that input without asserting a complete source or kernel certification. The later local majorant induction is independently reviewed in theta_parseval_peer_review_qrh.md.
