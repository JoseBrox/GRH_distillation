# Fixed initial blocks in the scalar orbital germ

Companion fragment: `theta_head_reduction.tex`, 21 November 2026.

## Result

The fragment proves the actual reduction of a scalar marked-cokernel
orbital coefficient to the same function Phi of the remaining matrix,
for both the two-block and one-block configurations. It proves every
required property of Phi: integral unipotent invariance, bounded matrix
support, and uniform local constancy on the compact determinant range.
The support and constancy lattices are independent of the finite target
module, so they supply the stronger uniformity in the source as well.

Together with the independently reviewed scalar Hessenberg reduction and
stationary phase, this now proves the actual local orbital germ. The
finite-type reduction is an alternative way to handle target uniformity.
These local results do not prove the remaining global theta estimates.

## Exact source connection

All paths below are relative to `sources/lean/src/`.

The main file is
`Formalism/HermitianCurvature/HermitianCurvatureProofs/TwoBlockPoint.lean`.

- Lines 185--218 define the two boundary corner entries, the block matrix
  bigZ=[[A,AY],[XA,XAY+G]], and PhiH. These are exactly the quantities in
  the new fragment. The finite version first discards nonintegral A and
  sums over the finite rectangular quotients with XA and AY integral.
  These restrictions change no nonzero term.
- Lines 595--942 prove the lower and upper group/coset parametrizations.
  The lower matrix has blocks [[v_h,0],[X v_h,v_g]], while the upper
  matrix has [[u_h,u_h Y],[0,u_g]]. Once representatives of the diagonal
  cosets are fixed, the residual quotient is exactly X,Y modulo R.
  There is no determinant Jacobian in this discrete bijection.
- Lines 1030--1234 establish corner invariance, the two block-matrix
  transformation identities, PhiH_inv and PhiH_supp. The latter is
  precisely Phi(G) nonzero implies det(H)*G integral. The new proof uses
  the explicit adjugate identity
  det(A)G=det(A)(XAY+G)-(XA)adj(A)(AY).
- Lines 1330--1415 prove Fz_perturb under the squared-determinant
  smallness condition. The new proof takes the scalar small element to
  be p and uses the geometric series for I+pM. It preserves the image
  lattice and all inverse-coordinate functionals, not merely the
  abstract cokernel.
- Lines 1436--1473 give the phase factorization and full combined coset
  bijection. Lines 1579--1627 prove sum_identity. The remaining orbital
  sum runs over every coset for the last blocks, including ones whose
  matrix is nonintegral. Its effective support is finite by the full
  combined integral-orbit finiteness result.
- Lines 1631--1700 give the determinant factorization and PhiH_const.
  The new constancy lattice p^(k+1)R can be chosen with
  p^k det(H)^(-2)q^(-2) in R for every q in Q. This is a shorter
  sufficient choice than the source's named scalar parameters, with the
  same quantifier order and all the same marked data.
- Lines 1703--1751 assemble HeadReduction. The controlling lattices
  precede the arbitrary target matrix. The new construction meets this
  order and supplies the same matrix function in both block identities.

`Formalism/HermitianCurvature/ThetaExistenceInductiveFromPieces.lean`,
lines 97--105 and 399--472, defines PhiHyp, OscReduction, GermPhi,
HeadReduction and GermKernel. The support and local-constancy conditions
include determinant in Q OR -Q; this sign allowance is retained.

## Read scope

I directly read TwoBlockPoint lines 1--250, 595--942, 1030--1240,
1330--1477 and 1570--1751. This includes the substantive providers and
final assembly. I also inspected the theorem outline of the whole file.
The unrecorded portions consist largely of indexing/block identities and
auxiliary bookkeeping; they were not certified line by line in this pass.
The conventional proof is complete and was checked independently, rather
than inferred from the presence of a provider theorem name.

## Counterexamples to false simplifications

1. Over Q_3, the two blocks 3 and -1/3 have scalar orbital coefficient
   -1 against the zero marked module. A sum restricted to integral
   last-block matrices would give zero. The actual source sum does not
   make this restriction.
2. Over Z_p, B=p^2 and B+P=p^2(1+p) have the same image ideal, but their
   inverse entries differ by -1/(p(1+p)). The generator-marked modules
   with their inverse-coordinate functionals are not isomorphic. The
   source squared-determinant hypothesis prevents this error.

Neither example is a counterexample to an actual submitted statement.
No such counterexample was found in this part.

## Independent review

The Siegel agent read the complete fragment and independently checked
the group parametrizations, both representative changes, the phase,
support identity, marked perturbation, finite full-coset rearrangement,
nonmaximal-order/small-prime cases, and both explicit counterexamples.
No substantive correction was needed. Its optional request to explain
why a finite module vanishes after extension to K was incorporated using
its annihilation by its cardinality.

## Final combined compile

The head reduction, scalar germ, germ assembly, finite-type uniformity, orbital identity, local stationary phase, and local Parseval/majorant induction were compiled together with their bibliography in theta_head_reduction_check.tex. Two XeLaTeX passes succeeded, producing 42 pages. The final pass reported no undefined citations, undefined references, or overfull boxes. This is a document check, not a formal-kernel certification.
