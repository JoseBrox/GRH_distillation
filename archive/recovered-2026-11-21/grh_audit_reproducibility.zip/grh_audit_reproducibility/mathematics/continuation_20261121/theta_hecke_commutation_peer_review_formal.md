# Independent review: incidence and Hecke commutation

Reviewer: /root/formal_degree_review, 21 November 2026.

Reviewed fragment: theta_hecke_commutation.tex, all 419 lines.
Final reviewed SHA-256:
d6dbb1c54a8a6f04097a5377b35100e4cb18a3afe4bf1bc573ef977958ff3758.

**Finding: PASS within the explicitly stated mathematical scope.**
No counterexample to the actual hypotheses or substantive unresolved
gap was found in HC1--HC16. The result is an exact complex theta
identity followed by descent using the separately reviewed finite-field
construction. This review is not a full Lean replay or verification of
all transitive dependencies.

## Scope of the independent reading

The entire mathematical fragment was read, including the local
neighbor definitions and bijection HC1--HC4, the common-reference
theta calculation HC5--HC7, the scalar HC8--HC11, the point identity
HC12--HC13, and the stabilizer-weighted class sum HC14--HC16.

The following companion passages were independently read for this
review:

* theta_column_support.tex, lines 130--252, including the actual
  indicator formula CS12a, its denominator, lift independence,
  semicharacter phases, and the finite Fourier conversion.
* theta_arithmetic_equivariance.tex, lines 145--330 and 440--565,
  especially the positive Gauss-sum argument, exact path identities,
  determinant character TE15, and the three covariance laws TE17.
  These previously peer-reviewed results are inputs to the present
  review; their complete earlier dependency tree was not reread.

The following source passages were independently read, with paths
relative to sources/lean/src:

* Development/AbelianVarietyTheory/BlockTheory/GlobalSignature/
  IndexExponentDegree.lean, all 97 lines: idxExp, InBox, JetsIn,
  locScal, MoveLaw, and even-rank scalar specialization.
* Development/AbelianVarietyTheory/Proofs/GlobalInterpolation/
  MemMulLatIff.lean, all 476 lines: arbitrary-period reduction,
  exact indicator normalization, common reference, and kerOf_eq.
* Development/AbelianVarietyTheory/Proofs/GlobalInterpolation/
  MoveStepOfFamily.lean, all 136 lines: application to the actual
  family, period-ideal unit hypotheses, finite-field jet descent,
  and the separate character factor.
* Development/AbelianVarietyTheory/Proofs/GlobalInterpolation/
  LevelNotMemRowSG.lean, lines 95--167: local selected-prime cases,
  conjugate determinant exponents, and the finite product.
* Formalism/LocalToGlobal/KernelLattices/ThDistC.lean, lines 58--169:
  actual indicator and jet definitions, muOff, muInvDet, and thDistC.
* Formalism/LocalToGlobal/Columns/AbelianHostFieldConditions.lean,
  lines 210--241: the actual selected-prime norms and disjointness.
* Formalism/LocalToGlobal/Columns/CyclotomicIsCyclotomicExtension.lean,
  lines 236--266: the displayed provider of the norm/splitting fields.

The finite-field theorem jcf-common-field is used as a separately
reviewed theorem. Its proof was not independently repeated in this
particular review. The file check_theta_hecke_commutation.py was read;
the parent independently reruns its exact controls. Its finite output
is supplementary, not the basis of this mathematical verdict.

## Decisive normalization checks

1. If C is the common selected sublattice and n_i=[L_i:C], the
   finite Fourier projector has coefficient 1/n_i. The positively
   normalized lattice-change operator has coefficient 1/sqrt(n_i).
   Thus P_C v_(L_i)=n_i^(-1/2) v_C. There is no surviving determinant
   character at this stage because it was explicitly removed.

2. The common-representative formula has coefficient n_i^(-1/2)
   multiplying the SAME sum of W_(-x) v_C. Since
   vol(L_i)=n_i vol(C), the quotient is sqrt(vol(L_2)/vol(L_1)),
   in the direction asserted by HC5. Reversing this ratio would
   reverse the final Hecke exponent.

3. For source determinant increment e and target increment e',
   the Haar volume of Hom(N,M)=M tensor N^* changes by
   p^(b e-a e'). Both ranks are even, so its positive square root
   is p^((b e-a e')/2). The actual selected primes have norm p.

4. The character quotient changes by w^(-e)/w^(-e')=w^(e'-e).
   At the conjugate prime both its determinant increment and its
   unramified character invert; the factor remains the same.
   Auxiliary frame factors are unchanged.
   This matches locScal in IndexExponentDegree.lean, not merely
   its valuation or absolute value.

5. In the two simultaneous lower lattice moves, e=e'=1.
   The character cancels and the scalar is p^((b-a)/2).
   The common affine test function is integral on N^0 to M and is
   periodic under p Hom(N^0,M); its original support and
   periodicity conditions also hold. Therefore the exact scalar
   applies before summing the local incidence identity.

6. The lower lattice is uniquely ker(ell); its possible residue
   functionals are exactly q^(a-1). For a fixed X, both incidence
   sides have at most one admissible neighbor, and the constructions
   in HC4 are mutually inverse. This includes noninjective X.

7. An orbit of related pairs contributes
   1/|Gamma_x intersect Gamma_y| from either side of HC14.
   In the coefficient-valued application the source representation
   factors cancel in k(x,d')f(y), so the required simultaneous
   invariance holds with d' fixed. The S_3 negative control correctly
   demonstrates failure if stabilizer weights are discarded.

## Clarifications incorporated during review

The initial draft was mathematically correct under the intended
source conventions, but several conditions needed to be explicit.
They are all present in the final hash:

* Positive even source and target ranks are fixed before the common
  theta calculation.
* The intermediate period is C subset D subset L_i.
* The common C lies in the CHOSEN periods of both functions;
  it is not required to lie in every possible smaller period.
* The selected rational p splits completely, so NP=p and p is
  a uniformizer. Without this condition the local formula must use
  NP, and merely splitting in E/F would not justify p.
* Representatives in the common integral lattice A are chosen by
  CRT with additional conjugate divisibility, making them admissible
  for both original indicator systems. Membership in an arbitrary
  Hom lattice A alone would not imply membership in a scalar
  half lattice for either original system.
* Two stray commas in exponents were removed.

The last CRT clarification matters for applying the ACTUAL indicator:
for each original lattice first clear all selected denominators of A,
then impose the required conjugate divisibility and A membership.
These are disjoint-prime constraints. This supplies simultaneous
admissible lifts, after which CS12a and its proved phase independence
apply without an additional assumption.

No new classical theorem is imported by this finite calculation.
The final conclusion remains the Hecke commutation law for the
specified theta columns; it does not settle unrelated global
orbital-energy estimates or the entire GRH argument.

Root finalization note: the only subsequent TeX change replaces the
two occurrences of "real prime" by "prime of F", as recommended by
the reviewer. Final SHA-256:
63d121e5a8c5a6cea55e3fee7dfbc425cad9a27a72ef36e0ac9ead2b0b1d8e60.
The exact matrix, Fourier and scalar checks were rerun against this
final hash and passed. No mathematical formula changed.

Reviewer acknowledgement: the final terminology-only amendment and final
fragment SHA above have been checked. The PASS applies to final63d121 as
well as to the mathematically identical fully reviewed d6dbb1 version.
