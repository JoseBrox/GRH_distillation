# Theta incidence and Hecke commutation: source trace

This is a conventional reconstruction, initially over C, of the actual
theta-column incidence identity. It does not replace a test function by
an abstract kernel with an assumed commutation law.

## Local identity

UkTermOfMoveStep.lean160--537 was read. Rel at169 is exactly the
intertwining residue equation. The upper and lower uniqueness arguments,
the two existence directions, and sum_phiT give the identity reconstructed
in HC1--HC4. The proof in ordinary mathematics uses a basis of a DVR
lattice to make the neighbor count and the two inverse constructions
explicit. The source's global lower lattice has the dual change at the
conjugate prime; local patching retains that change.

The same file verifies the support and periodicity of the common test
function under both lattice changes, linearity of the finite kernel sum,
and the exact scalar for two lower moves. These checks appear explicitly
in HC12--HC13. Both exponents are one, so the auxiliary character cancels
and the scalar is p^((b-a)/2), not its square or inverse.

## Actual normalization

MemMulLatIff.lean was read in full (476 lines), together with all136
lines of MoveStepOfFamily.lean and all97 lines of
IndexExponentDegree.lean. The latter defines idxExp, InBox, JetsIn,
locScal, and MoveLaw. Its local scalar is
w^(e'-e) p^((b/2)e-(a/2)e').

HC5--HC7 are a shorter proof of the common-reference calculation:
finite Fourier projection contributes 1/[L:C], the exact normalized
theta move contributes sqrt([L:C]), and the test-function sum in the
common reference is independent of the original lattice. Thus the
remaining scalar is the square root of the ratio of selected Haar
volumes. The Hom determinant gives HC9. The determinant character
was removed before this calculation, precisely as the source divides
by chiF. All signs of the theta moves are supplied by the independently
reviewed exact TE argument, not by an eighth-power identity.

ThDistC.lean118--137 was read for muOff and muInvDet.
LevelNotMemRowSG.lean95--167 was read for its local and global change
formula. The selected real prime may be lifted to P or its conjugate:
the determinant exponent and unramified character both invert, so the
factor is unchanged. The identity w_barP=w_P^(-1) uses unramifiedness
and trivial restriction to the ground field. Auxiliary frame factors
are unchanged. These observations give HC10 and the actual locScal.

The selected rational prime splits completely in E. In particular,
each selected prime above it has residue norm p and p is its local
uniformizer. The root checked
Formalism/LocalToGlobal/Columns/AbelianHostFieldConditions.lean210--241
and CyclotomicIsCyclotomicExtension.lean236--266 for the exact norm
condition and its cyclotomic splitting provider. This hypothesis is
explicit in the reconstruction; splitting over the real subfield
alone would require the factor Norm(P) in place of p.

## Point model and weighted class sum

HeckeLawPointKernelOfCoefficientKernel.lean was read in full (276
lines), including the exact local field correspondence, both neighbor
bijections, and transfer of the coefficient-kernel identity to points.
LevelChainUOperatorCommutationOfPointPairLaw.lean was read in full
(96 lines). Its count_incidence is proved directly here by decomposing
the relation into group orbits and computing each contribution as
1/|Gamma_x intersect Gamma_y|. The actual inverse-stabilizer weights
are retained. The scalar for an iterated Hecke operator is obtained
by induction from the one-step identity.

BelowFiniteNonempty.lean1--145 was read for the precise definitions of
the kernel, term, MoveStep, UKTerm, and both finite neighbor sets.
FivePointLawsTrueChains.lean was read in full (64 lines) for assembly.

## Descent and limits

The complex theta identity and its mixed derivatives are proved.
Descent to the source's specified number field requires JetsIn.
Algebraicity alone does not identify a coefficient with an element of
that field. ExistsHypJetsAll.lean was read in full: its finite
coefficient-field enlargement is the precise additional source provider.
Its finite-generation and parameter-order step is reconstructed
separately. That reconstruction is complete and independently
reviewed in theta_coefficient_field.tex (JCF). It fixes the entire
finite prime/level/order list before adjoining the required algebraic
generators. Thus field descent is supplied by that separate proved
result, rather than by algebraicity alone.

The exact checker enumerates137,974 matrices against all actual local
upper and lower neighbors, checks81 finite Fourier identities and1600
volume/character scalars, and includes a negative control for omitted
stabilizer weights. These finite checks are supplementary. An
independent peer review of the entire fragment passed, including the
common-reference calculation, simultaneous admissible lifts, local
incidence, support and periods, and the weighted global class sum.
No complete Lean kernel replay or final proof of GRH is claimed.
