# Exact theta normalization: source trace and scope

The files lattice_theta_measures.tex (LM) and
theta_change_of_isometry.tex (TC) give an ordinary mathematical
reconstruction. TC supplies an actual proof of the analytic
change-of-isometry identity; it does not leave that identity as a new
conditional premise. LM's finite moment criterion remains useful as an
explicit interface. Subsequent CI and TS drafts address the nonprincipal
ordinary chart and local isometry existence separately.

## Definitions that fix the theorem actually being proved

All paths in the following table are relative to
sources/lean/src/Formalism/LocalToGlobal/TorsionIntegrality/QuadraticSemicharacters/.

| Source | Exact inspected definition or provider | Mathematical counterpart |
|---|---|---|
| IsSemiChar.lean, lines 15–82 | Hermitian form, E, U, self-duality, sign semicharacter, finite averaging, pullback | TC1–TC4 and TC10 |
| IsSemiChar.lean, lines 107–130 | standard form/lattice, tensor in four independent blocks | TC43–TC46 and tensor normalization |
| UnitaryConstant.lean, lines 13–35 | Cayley phase, bilinear phase, A-lattice, UnitaryData | TC26–TC30 |
| UnitaryConstant.lean, lines 23–33 | UnitaryData includes positive H, self-dual lattice, sign semicharacter on both lattices, alpha(delta x)=alpha(x), commensurability, A=1-delta inverse | These hypotheses are all retained in TC |
| UnitaryConstant.lean, lines 89–101 | exact normalized Gaussian constant and eighth-power target | TC31–TC32 |
| ProductThetaMem.lean, lines 52–78 | StdData, kernel4, ThetaVector | K_g is precisely the normalized finite average evaluated at g z; TC45–TC47 |
| QuadraticSemicharactersFactAltForm.lean, lines 34–42 | KernelRatio with g1-g0 injective and c^8=det(g1 g0 inverse)^4 | TC46 |
| CayleyGaussianIntegrals/FinitelyGeneratedModPow.lean, lines 103–208 | KernelRatio_of: invariant semicharacter, Cayley constant, triple-composition phase | TC kernel-ratio proof |
| CayleyGaussianIntegrals/FinitelyGeneratedModPow.lean, lines 88–99 | norm_mul_eq_one | LM scalar corollary and TC47 |
| CayleyGaussianIntegrals/StdDataCmProof.lean, lines 93–132 | norm semicharacter for the general scaled CM ideal base | TC41–TC44 |

The full inspected source files and their exact SHA256 values are in
theta_normalization_source_manifest.json. That manifest distinguishes
partial reads from full-file reads. It does not claim all imports were
read or a full Lean kernel replay was performed.

## Proof dependencies examined

The finite phase chain was read through GaussDegenerate.lean,
GaussSumEighthPower.lean, GapStatement.lean,
DifferentialRepresentation.lean, TripleSumEighthOf.lean, and
TripleEighthProof.lean. TC replaces the lengthy triple-conjugacy
calculation by orthogonal finite averaging, but retains exactly the
finite quadratic phase. Homogeneity of the quadratic function and
sign values of the semicharacter are essential and have not been weakened.

The Gaussian trace definitions were read in KerPNonzero.lean.
The inspected analytic providers are CayleyGaussianIntegral.lean,
DiagIntegrable.lean, UnfoldingIntegral.lean,
SelfDualCovolumeProof.lean, and UnitaryEighthOf.lean.
TC independently proves the needed normal convergence, character
integral, Gaussian integral, unfolding, theta-space dimension, and
covolume identity. In particular the calculation uses the exact
positive square root of the lattice index. It does not replace the
constant by an unspecified complex number of absolute value one.

## Arithmetic normalization and application

The actual source normalization is defined in
Formalism/LocalToGlobal/KernelLattices/LateralTheory.lean:
IsThM at lines 23–26 says theta tensor four equals kappa times kernel4;
the trace isometries and local lattice conditions are at lines 80–94;
KapChoice, yP and the finite product kappa are at lines 96–110.
LM9–LM13 reproduce its determinant-valuation correction.

The inspected application is
Development/AbelianVarietyTheory/Proofs/GlobalInterpolation/ExistsStandardIsometryFourthPowerSplitPrime.lean.
Its isomStdCm and isomStd explicitly assume that the split prime
does not divide the norm of the curve ideal. The proof invokes
KernelRatio and the exact kappa norm comparison, and then obtains a
scalar of p-adic absolute value one multiplying the locally standard
kernel. The corresponding scalar comparison was inspected in
NormKappaSqMulDetSplitPrime.lean, NormKappaSqMulDetIsometryEqOne.lean,
ComplexPadicNormKappaSplitPrime.lean, and
UnitaryStandardAtQFromIsometryOverField.lean.

For the measure interface, the inspected providers include the
fourth-tensor descent, pullback, finite integral combinations, and
normalization of the self-dual lattice vector. Finite support and
incidence for the complete arithmetic column remain distinct steps:
partial reads of MemSuppBarOfNe.lean and MomentsCosetSum.lean
are recorded conservatively and are not represented as complete
audits of those files.

## Verification and exclusions

The combined OT, CM, LM and TC wrapper was compiled twice with
XeLaTeX to 27 pages. The final pass had no undefined references or
citations and no overfull boxes. The surviving underfull paragraph
and math-in-heading PDF-string warnings are inherited from the
earlier CM section.

No counterexample to the exact analytic hypotheses has been found.
The reconstruction proves the analytic identity under those
hypotheses. This does not prove the claimed GRH theorem, certify
the complete source corpus, or resolve the separate arithmetic
column support/incidence dependencies.
