# Independent review of the local orbital identities and support

Reviewer: `/root/qrh_mathematics`. Reviewed 21 November 2026.
Target: `theta_orbital_identity.tex`, all 857 lines of the reviewed draft,
including the newly added uniform local constancy proposition. The author
was correcting literal `quad` typography and preparing an additional
counterexample; those changes do not alter the reviewed core arguments.

Follow-up review: checked the resulting 911-line version's explicit Q_3
counterexample and final scope paragraph. The counterexample's binomial
error has valuation at least N-3, its contributing root remains in the
specified coset, and the changed phase is the asserted nontrivial
psi(-2/3). The final scope paragraph correctly leaves the uniformly valid
orbital germ formula, averaged diagonal estimate and global energy
estimates unproved.

## Conclusion and remaining requirement

No mathematical defect was found in the displayed elementary proofs.
The change-of-variables identity, mixed-term cancellation, finite orbit
sums, uniform local constancy, finite-module duality and triangular
averaging argument are all proved under the stated local hypotheses.
The support corollary uses the actual marked-cokernel kernel, rather than
an arbitrary positive or Hermitian kernel.

The orbital germ expansion remains an explicit assumption. Its
neighborhood must be chosen before the arbitrary comparison configuration
w. The fragment retains this quantifier and therefore can legitimately
apply the expansion twice. This review does not establish the missing
head reduction or its uniform oscillatory-integral realization.

## Local analytic checks

1. The binomial series converges after a data-dependent shrink, including
   primes dividing s or 2. The auxiliary b_s takes values in the actual
   open subring R by continuity; it is not assumed that R is maximal.
2. Compactness of Omega and its inverse set makes the root shifts and
   representative changes uniform. The cuts are R-stable for sufficiently
   small t, and all roots of a selected fiber belong to Omega by its
   root-of-unity invariance.
3. A Lambda-invariant function on compact Omega is locally constant and
   has only finitely many relevant cosets. The Jacobian of z^s/(-t)^m
   has absolute value |s||z|^m/|t|^m. Partitioning into sufficiently small
   product balls justifies the formula without any differentiability
   hypothesis on the amplitude. Multiple roots are counted once each.
4. For mixed terms, periodicity under changing c to c+r is the decisive
   step. The phase increment is a product of r, b_s(r/c), and
   (-1)^m t_1^(m-1)(1-zeta*rho)/z^m. For m>=2 the last factor is uniformly
   small. For m=1, zeta^2=1 makes the leading term exactly the inverse
   difference required by the support assumption. No claim that zeta lies
   in a nonmaximal order is made or needed.
5. In a product of fields, zeta may equal 1 in some components. One
   component with zeta_j != 1 is enough to make the phase frequency leave
   the compact annihilator of a fixed small additive lattice. Arbitrary
   compact open additive lattices contain sufficiently small product
   lattices, so the argument does not silently assume a product lattice.
6. The amplitude after the two germ expansions has the correct factor
   |t|^m |s|^(-1) |z|^(-m). The two exponent identities in the text account
   for every normalization. Square invariance of the Gaussian phase makes
   its local constancy uniform in t_1. The near-one kappa expansion gives
   the phase sigma-sigma' with the stated sign.

## Algebraic checks

7. **Finite integral cosets.** Block Gaussian elimination recovers all
   lower and upper entries from integral Z with fixed nonzero diagonal
   block determinants. The inverses of those determinants remain bounded
   when the last scalar varies over a compact set of units. The resulting
   compact set maps to a finite subset of the discrete coset space.
8. **Representative independence.** Replacing Z by aZb uses a lower
   integral matrix on the left and an upper integral matrix on the right.
   The cokernel map v -> av preserves the last marked vector; the last
   row of b^(-1) preserves the marked inverse-coordinate functional. The
   adjacent-entry phase changes by an element of R.
9. **Uniform local constancy.** A common finite list of possible integral
   cosets suffices over a compact parameter set. If all inverse entries
   lie in p^(-b)R, a perturbation in p^(2b+1)M_n(R) preserves both the
   lattice image and all inverse-coordinate functionals modulo R. The
   geometric-series inverse converges in the compact subring. This
   identifies the marked modules themselves, hence is uniform against
   every comparison configuration, regardless of its size or parameters.
10. **Finite-module duality.** Self-duality of R gives the perfect pairing
    R/p^N R with p^(-N)R/R. Extending an additive character of the finite
    image of the lambda_i and then applying the identity to every rc
    promotes an additive-character equality to an R-linear functional
    equality. This works for the nonmaximal split order; no assertion that
    it is a discrete valuation ring is used.
11. **Unique partial lift.** The tail map from L_B/S_0 to R^l is an
    isomorphism. It removes the tail error in a lift of phi uniquely.
    It proves independence of representatives, R-linearity, injectivity,
    surjectivity and preservation of the marked vector. The class of the
    upper-unipotent tail matrix D is determined modulo its action on
    Lambda(P) in R^l; fixing representatives makes the construction
    unambiguous. A resulting lift determines D itself because Lambda(P)
    spans K^l.
12. **Failure of the next relation.** The common-kernel criterion gives a
    pair whose higher inverse coordinates can be made exactly zero by
    subtracting elements of the old lattice. The actual inverse-coordinate
    functionals modulo R are unchanged. On this subspace p_B^(-1) has no
    effect on coordinate k, so the nonintegral difference is independent
    of B,B' and belongs to the fixed lift data.
13. **Shear permutation.** The chosen shear has its column vector in the
    first a coordinates and its row vector in the last l coordinates,
    so it is upper unipotent and its square term vanishes. The target row
    beta'=beta D^(-1) is integral and has first entry one. Integral
    perturbations preserve the admissible orbit pairs. In the membership
    test, the explicit condition b(x) in R is essential for applying Psi
    R-linearly; it is correctly retained. The inverse shear gives the
    inverse permutation of the finite family with fixed Psi.
14. **Phase cancellation.** There is exactly one adjacent entry in the
    shear rectangle. Its source-target change is -r_0*d, so every term is
    multiplied by the same nontrivial character value. This cancels the
    whole finite sum for that lift, including the isomorphism
    multiplicities, since each admissible pair has a unique descended
    isomorphism for a fixed lift.
15. **Strong inverse support.** Iteration leaves T_r. Evaluating on the
    marked last vector gives t^(-1) and t'^(-1) in coordinate r and zero
    higher coordinates. Their difference is integral. When s=1 the same
    assertion follows immediately from the already preserved last
    functional, without an averaging step.

## Counterexample check for a stronger false statement

If the support condition is omitted for m=1, mixed-term vanishing for
every representative choice is false. Independently checked example:
K=Q_5, R=Z_5, Omega=(5+125R) union (-5+125R), Lambda=125R,
g=1_(5+125R), zeta=-1, t_1=t_2=t=5^N with N>=4, kappa=1.
For the coset represented by c_0=-25/t, the unique root contributing to
g is z=5. Replacing c_0 by c_0+1 replaces it by
z'=5 sqrt(1-5^(N-2)), still in 5+125R. The binomial expansion gives
4(z'-5)/t = -2/5 modulo R. Thus its summand changes by the nontrivial
factor psi(-2/5), while all other representatives can be left unchanged.
Both complete sums cannot vanish. This is a counterexample only to the
stronger statement without the actual support hypothesis; that
hypothesis fails here because 2/z is nonintegral.

## Exact source comparison and read scope

Independently read the following source definitions and ranges in this
pass, in addition to the entire conventional fragment:

- `Formalism/DoubleCosetMeasures/Statement.lean`: lines 55--110,
  205--248, and the displayed finite-sum definitions later in the file.
  The source lower group is the block lower-unipotent group: conjugation
  by each reversing block would turn a lower diagonal block upper, so
  membership in both forces that diagonal block to be the identity.
- `Formalism/HermitianCurvature/BlockKernelPropertiesOfSteps.lean`:
  lines 1--125, including LocalDatum, the actual phase and pairTerm,
  marked module maps, and the triangular relations.
- `Formalism/HermitianCurvature/ThetaExistenceInductiveFromPieces.lean`:
  lines 1--205 and 410--595, including IsLat, LatInv, IsOmega, IsCr,
  cutSet, GermPhi, HeadReduction, Germ, GermKernel, LocConst,
  ChangeVar, CrossVanish and GermIdentity.
- `Formalism/HermitianCurvature/HermitianCurvatureProofs/HenselRootsBounded.lean`:
  lines 575--675 only, which include the beginning of the actual
  CrossVanish proof and its explicit parameter ordering. The rest of that
  Lean proof was not certified by this pass.

The exact GermKernel source has the order: fix m, gamma, h, Q; choose
V; then for all t,c satisfying the compactness condition and all w'
assert the identity. HeadReduction similarly chooses its controlling
lattices before the comparison matrix. The conventional conditional
theorem preserves these orders; it does not replace them by separate
pointwise neighborhoods depending on w'.

## Subsequent completion of the scalar germ

The scalar germ that was still conditional at the date of the original review is now proved by theta_head_reduction.tex and theta_scalar_germ.tex and assembled in theta_germ_assembly.tex. The complete conventional arguments and the assembly quantifiers were independently checked; see theta_scalar_peer_review_qrh.md. This updates the status of that input without asserting a complete source or kernel certification. The later local majorant induction is independently reviewed in theta_parseval_peer_review_qrh.md.
