# Local theta orbital identity: source trace and audit limits

## Subsequent closure of the actual local germ

The original checkpoint below deliberately retained the orbital germ as an assumption. The later sections `theta_head_reduction.tex`, `theta_scalar_germ.tex`, and `theta_germ_assembly.tex` now prove that input for the actual kernel, with full compact-parameter uniformity and arbitrary comparison size. The parent agent's `theta_parseval.tex` also proves the separate finite character identity, averaged diagonal estimate and local positive-majorant induction. The read scopes in this record and its 16-file manifest remain the exact earlier scopes; the new scalar and initial-block source records document the additional work. Historical statements below about an unproved local germ are therefore superseded. No global theta energy estimate is inferred from this completion.

## Outcome of this checkpoint

The companion `theta_orbital_identity.tex` now gives conventional proofs of:

1. The exact root-fiber change of variables, with Haar factor `|m+1|/|t|^m` and root multiplicities intact.
2. Vanishing of the mixed stationary-point terms, including the indispensable support hypothesis when `m=1`.
3. The truncated orbital identity from the actual, precisely stated orbital germ formula.
4. Finiteness and representative independence of the actual integral orbital coset sums.
5. Local constancy of that kernel in the final block parameter, uniform against **all** comparison configurations.
6. Strong inverse-parameter support for the actual marked-cokernel kernel, by finite-module duality, an explicit partial-module lift, and a rank-one shear permutation.

The germ formula is the sole unproved hypothesis of the new truncated orbital identity for this actual kernel. The averaged diagonal estimate for the positive-majorant induction and the quantitative global theta energy estimates remain further, separate obligations. This is a substantial local reconstruction; it is not a proof of the global theta estimates or GRH.

An additional independently reviewed fragment, `theta_germ_uniformity.tex`, reduces the germ formula's comparison-configuration uniformity to finitely many fixed marked-module targets. This uses only compact determinant bounds and adjugates, not the unproved orbital germ providers. It is included after the principal fragment in the local compilation. The scalar germ for each fixed target remains an explicit obligation.

No counterexample satisfying the complete hypotheses of these local statements was found. The document proves a counterexample to **removing** the inverse-parameter hypothesis from mixed cancellation at `m=1`. That example is expressly not a flaw in the source, which includes the hypothesis.

## Exact source statements and their mathematical counterparts

All relative paths below are under `sources/lean/src/`.

| Source declaration | Exact mathematical role | Reconstruction |
|---|---|---|
| `Formalism/HermitianCurvature/BlockKernelPropertiesOfSteps.lean`: `LocalDatum`, `Kp`, `Ns`, `InTT`, `intTT` | Self-dual compact open order, finite marked cokernels, weighted orbital kernel, upper-triangular agreement of inverse-coordinate functionals | Explicit definitions before `orb-actual-kernel` and before `orb-triangular-average` |
| `Formalism/DoubleCosetMeasures/Statement.lean`: `lowW`, block reversal matrix and cokernel markings | The lower group is block lower unipotent with identity diagonal blocks; the marked vector is the last basis vector and the marked functional is the last inverse row | Short block-conjugation argument; complete representative-invariance proof |
| `ThetaExistenceInductiveFromPieces.lean`: `ChangeVar` | Root-fiber summation over representatives of `K/R`; finite-lattice integral normalization | `orb-change-variable` |
| Same file: `CrossVanish` | Mixed-root cancellation, with `z^{-1}-(ζz)^{-1}∈R` on the support | `orb-cross-vanish` |
| Same file: `LocConst` | A single parameter lattice works for every comparison configuration | `orb-local-constancy-proved` |
| `BlockKernelPropertiesOfSteps.lean`: `AvgClaim` | Descending from the condition `T_{k+1}` to `T_k` does not change the weighted sum | `orb-triangular-average` |
| Same file: `TTEnd`, `BlockKernelSupport` | Evaluate the final inverse coordinate on the marked vector to obtain `t^{-1}-t'^{-1}∈R` | `orb-support-proved` |
| `ThetaExistenceInductiveFromPieces.lean`: `GermKernel`, `GermIdentity` | Actual germ expansion, followed by exact truncated orbital identity | Germ is retained explicitly as `orb-germ-input`; the complete implication is `orb-cut-identity` |

### Root-fiber measure and mixed cancellation

The exact `ChangeVar`, `CrossVanish`, `GermIdentity` statements were read at lines 522–565 of `ThetaExistenceInductiveFromPieces.lean`, with their preceding definitions. `PadicChangeOfVariables.lean` provides `PhaseDiff` and `ChangeVar`; its final proofs were read, not merely the signatures. The full `crossVanish` proof in `HenselRootsBounded.lean` was read.

The conventional proof replaces a substantial amount of finite lattice bookkeeping with Haar integration of a root sum. It first proves that the root sum is invariant under changing a representative by an element of `R`; only then is the finite quotient sum replaced by an integral. This order is necessary. Simply applying stationary phase to an arbitrary choice of representatives would be invalid.

The mixed-root phase is `a z`, where `a=(m+1)(1-ζρ)/t_1` and `ρ=κt_1/t_2`. Under a representative change, its leading coefficient is

`(-1)^m t_1^(m-1) (1-ζρ)/z^m`.

For `m≥2` this tends uniformly to zero. For `m=1`, the non-small term is `-(1-ζ)/z`. Since `ζ^2=1`, that term lies in `R` precisely by the stated inverse-parameter support condition. No assertion that `ζ` itself belongs to a nonmaximal order is used. In a product of fields, a single component with `ζ_j≠1` suffices for character orthogonality on a fixed sufficiently small product sublattice.

The reconstructed cancellation does not need the additional equation `κ^(m+1)=(t_2/t_1)^m`; the source's actual proof also discards that assumption after introduction. The equation is required later to pair the roots in the double germ expansion. This separation is a genuine simplification, not a weakening of what is needed in that later expansion.

All neighborhoods are chosen after fixing `K,R,ψ,m,Ω,Λ,Σ,ζ`. Residue characteristics dividing `2(m+1)` are retained. The binomial-series neighborhoods shrink when needed. No uniform stationary-phase radius across growing block sizes, changing conductors, or varying residue characteristics is claimed.

### Finiteness and local constancy

The integral orbit-coset sum is proved finite by block Gaussian elimination. On the compact set of integral product matrices, all diagonal-block determinants are fixed nonzero scalars. Adjugate formulas bound every coordinate of the lower and upper factors. Compactness and the openness of the integral unipotent subgroups then imply finiteness in the double quotient.

This proof remains uniform when the last block scalar ranges over a compact subset of `K^×`. One fixed finite list of cosets consequently suffices. On this finite list, inverse matrices have a common bound in `p^{-b}R`. A perturbation in `p^{2b+1}M_n(R)` preserves the image lattice and changes the inverse by an integral matrix. It therefore preserves **every** inverse-coordinate functional modulo `R`, the marked vector, and the phase. The resulting kernel equality is uniform against arbitrary comparison modules, not only a finite comparison family.

`KernelScalingBack.lean:phase_locally_constant` was located but its proof was not read. The conventional proof above is independent of that provider. The new manifest marks this file as declaration-index coverage only.

### Strong inverse-parameter support

The exact `AvgClaim`, `TTEnd`, and `BlockKernelSupport` statements were read. Their assembly was checked in `FirstKernelPropertiesOfHypotheses.lean`, `SecondVanishingOffRing.lean`, and the final `lattice_average_identity` theorem. The detailed matrix definitions, the initial lift construction, and the complete shear construction were read in `LatticeAverageIdentity.lean`. That 1,864-line provider was **not** read in its entirety; the manifest lists the precise ranges.

The conventional proof covers the full mathematical averaging step. Its main reductions are:

* Self-duality converts a functional's vanishing on a common kernel into membership in the `R`-span of the other functionals. The proof uses extension of characters of finite abelian groups and the exact duality between `R/p^N R` and `p^{-N}R/R`.
* An upper triangular block quotient is represented by a single arbitrary upper rectangle. Keeping the other factors fixed, all candidate lattices have the same first columns.
* Each marked isomorphism satisfying the higher-coordinate conditions has a **unique** lift to the quotient by those first columns, after choosing one representative of its higher-coordinate transformation. The higher-coordinate map is an isomorphism on the remaining lattice quotient, which proves uniqueness.
* Failure of the next coordinate condition is an intrinsic pair of vectors for this lift, with vanishing higher coordinates and a nonintegral next-coordinate difference.
* A rank-one upper triangular shear preserves the finite family of pairs of lattices inducing the lift and multiplies every weight by one fixed nontrivial character value. Their sum is therefore zero.
* Iteration leaves only isomorphisms satisfying the first coordinate of the last block. Evaluation on the marked last basis vector yields the inverse-parameter congruence.

The membership test for the shear retains the condition that its scalar coefficient belongs to `R`; omitting that condition would incorrectly apply `R`-linearity with a nonintegral scalar. The proof also handles `s=1` directly, and carries the zero-dimensional marked-module convention in the kernel definition. Nonmaximal compact open orders are allowed throughout.

### Double germ expansion and normalization

The exact local germ hypothesis is uniform in the comparison configuration: the neighborhood is chosen **before** that configuration. This is required because the second configuration in the truncated sum also depends on the small parameter. The new theorem retains this quantifier order.

After expanding both variables, pairing roots by `y=ζκz`, and normalizing, the prefactor is `|t|^m/|m+1|` and the amplitude contains `|z|^{-m}`. Mixed roots cancel by the proved theorem. The diagonal phase reduces to `ψ(z(σ-σ'))`. The root-fiber change of variables contributes the exact reciprocal prefactor and `|z|^m`, leaving the asserted integral of the normalized larger-block kernel.

`GermSumLattices.lean` was read through the double expansion, root reindexing, local amplitude invariance, and the complete final assembly. The central interval of its proof was not all read; the separate conventional argument supplies the calculation. The manifest records this limited coverage rather than calling the entire file audited.

## The remaining germ formula

Two genuinely larger imported steps remain:

1. `OrbitalIntegralReduction.lean` (3,271 lines) converts the two-block orbital integral to a multidimensional oscillatory integral with phase `x_1+...+x_m+D/(x_1...x_m)` and identifies its critical-point amplitude. Initial coordinates, a local change estimate, and the final reduction assembly were read. The full matrix elimination and critical-amplitude proof were not reconstructed.
2. `TwoBlockPoint.lean` (1,751 lines) incorporates the previous block configuration and a comparison marked cokernel into a matrix test function with support and local-constancy bounds independent of that comparison. The final provider was read. Its test-function construction and all its preceding estimates were not reconstructed.

The previous `theta_estimates.tex` proves the stationary-phase evaluation once such an amplitude and its required uniform bounds have been obtained. It does not prove either algebraic reduction above. No assertion about actual global energy estimates follows merely from the local work in this checkpoint.

The additional finite-type reduction simplifies the second obligation: the exact determinants on both sides of the germ are equal, with the reversal-matrix signs differing by an even exponent `2m`. Since those determinants stay in a fixed compact subset of `K^×`, adjugates give a common annihilating power `p^N`. The marked cokernels lie among quotients of the finite module `(R/p^N R)^n`, with finitely many markings and functionals. Choose one actually occurring integral matrix for each type. Exact scalar germ identities against these finitely many targets imply the formula against every comparison configuration, by intersecting finitely many neighborhoods and summing over its finite orbital expansion. This argument retains uniformity in `ct^m∈Q`; it removes only the need to establish a separate uniform bound across infinitely many target modules.

Tactic scripts containing alternative `try`/`first` branches were not treated as evidence of an exploit. An unused branch need not elaborate and is not a dependency of a successful proof. This lane concerns the conventional mathematical statements; it makes no independent claim about which exported kernel proof term a wrapper selects.

## Reproducibility and coverage

`check_theta_orbital.py` enumerates actual finite marked-module isomorphisms for the six cases `p=3,5`, `t=p`, `t'=vp`, `v=1,2,p+1`, with a single block of size two. It works in `(Z/p^2 Z)^2`, directly enumerates images of generators, tests the defining relations, the two markings, bijectivity and the additional triangular condition, and reduces the phase polynomial modulo the prime cyclotomic polynomial. For `v=2`, the unrestricted coefficients are all `p`, whereas the restricted coefficients are all zero. For `v=1,p+1`, both kernel values are `p^2`. It also verifies the representative-change congruence in the omitted-support example for `N=4,5,6,7`. All ten controls passed exactly; results are in `theta_orbital_checks.json`. These finite examples do not replace the general proofs.

`build_theta_orbital_manifest.py` records SHA-256 hashes, total line counts, and conservative read ranges for all listed source files. `theta_orbital_source_manifest.json` is generated from that script. Ranges describe source text inspected; they do not certify dependency closure, Lean elaboration, axiom inventories, or an independent kernel check.

The mathematical fragment has been independently reviewed by the parent agent and the QRH mathematics agent. Those reviews found no defect in the local arguments. Their agreement is not a substitute for the displayed proofs and does not extend to the unproved germ providers or to the global argument.
