# Independent review of the nonprincipal ordinary theta extension

The reviewer read all of cm_ideal_theta_moments.tex and
theta_local_standardization.tex and checked the final scope amendments.
Reviewed hashes:

- CI: 48f221a1d632553ea35b406c0ed76d9f460fdbadfddce3c639cee73b9250a99b.
- TS: 6e85449ac6ee52cbd116453f001878571e33213542df6cf4b25c7c89fe66a0f4.

Result: the mathematical arguments pass this review under their stated
hypotheses. In particular p is split, p is at least five, and the ideal
norm is prime to p. The underlying source allows p=3 in some general
interfaces; these fragments prove the range required at the large
selected primes and do not claim the extra case.

CI constructs the prime-to-p isogeny between the principal and ideal CM
models, retains the unit ratio of invariant differentials, and thereby
uses one ordinary period. The quotient by the finite etale subgroup
satisfies the projectivity and free-action hypotheses of Stacks Tag 07S7,
Lemma 66.14.2, which the reviewer checked independently in the primary
reference. The elliptic schemes and ordinary reduced theta input are
explicit classical inputs. They are not reproved from scheme theory.
The finite-combination norm, nonzero half-period, torsion translation,
quadratic sign, and arbitrary simultaneous complex scaling were checked.
No p-adic unit assumption on the arbitrary complex scale is inserted.

TS proves the rational four-square construction and the fourfold Hermitian
isometry, then split local standardization and simultaneous rational
approximation by skew-adjoint Cayley transforms. Invertibility of both
the relevant differences and the Cayley denominators is retained. The
ideal twist changes the Hermitian form by its ideal norm and preserves
self-duality. The untwisted lattice defines the same determinant
correction used in LM. Combining TC's exact eighth power with that
correction gives a p-adic unit. The prime-to-p finite intertwiner and the
fourth-tensor moment criterion give the stated normalized lattice vector.

The reviewer independently read lines 1–180 and 195–275 of
Development/AbelianVarietyTheory/Proofs/GlobalInterpolation/ExistsStandardIsometryFourthPowerSplitPrime.lean,
including the actual isomStdCm and isomStd statements and proofs.
The exact IsCurveIdeal definitions were read in
Formalism/SharpRestriction/GlobalSchurBounds/GeneralLinearActions/IsDiscriminantTwelfthRootOfIdealLattice.lean
(lines 45–63) and Formalism/LocalToGlobal/KernelLattices/ColumnData.lean
(lines 62–80). They require the norm to be coprime to 2D.
Other source reads in the manifest are the contributing agent's reads,
not additional independent reads by this reviewer.

The ordinary moments of the normalized lattice vector do not alone prove
the full arithmetic column's covariance, support or incidence formulas.
Those remain separate tasks. This review is not a full transitive source
audit or a Lean kernel replay.
