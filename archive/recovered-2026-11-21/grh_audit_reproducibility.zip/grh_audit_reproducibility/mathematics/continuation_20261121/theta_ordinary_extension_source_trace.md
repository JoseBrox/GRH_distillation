# Nonprincipal ordinary theta bases and local standardization

The CI and TS fragments extend the already reviewed OT, CM, LM, and TC arguments.
They supply ordinary mathematical proofs, with explicit p>=5 scope, rather than
assuming the desired local standardization or the analytic constant identity.

## Exact source assumptions

The curve ideal definition in
Formalism/SharpRestriction/GlobalSchurBounds/GeneralLinearActions/IsDiscriminantTwelfthRootOfIdealLattice.lean
lines56–57 requires a nonzero ideal of norm coprime to 2D. The generalized
definition in Formalism/LocalToGlobal/KernelLattices/ColumnData.lean lines73–74
is identical. In particular the content reduction in CI concerns odd-norm
ideals. It does not claim that every ideal, including a prime above2, has an
odd primitive norm.

Development/AbelianVarietyTheory/Proofs/GlobalInterpolation/ExistsStandardIsometryFourthPowerSplitPrime.lean
contains odd_norm at106–110, isomStdCm at196–253 and isomStd at255–272.
The local theorem explicitly requires the rational split prime not to divide
the curve ideal norm. CmThetaBaseVectorTranslatesIntegral.lean51ff retains
that same hypothesis. The generic source theorem allows all odd primes;
the present use of Bannai–Kobayashi retains p>=5. This is enough for all
sufficiently large selected split primes, but is not a proof of the p=3 case.

## The period and the normalization

CI constructs the good ordinary model for the ideal lattice by a prime-to-p
isogeny from the principal lattice. Pullback of the same multiplicative
formal coordinate gives equality of the unscaled periods, not merely equality
of their norms. The isogeny extends on good models with an integral formal
inverse. Algebraicity and the unit property of the discriminant ratio follow
from the algebraic good differentials and their unit isogeny multiplier.

The corresponding source theorem is delta_ratio in
DiscOneScaleRatioIdealRingAlgebraicUnit.lean101–142. The entire144-line file
has been inspected. CI uses the direct isogeny argument and the ordinary
theta integrality theorem rather than that file's all-embeddings argument.
The exact algebraic quotient result used for the good model was checked in
Stacks Project Tag07S7, Lemma66.14.2. The primary Bannai–Kobayashi reference
is arXiv math/0610163v4, Proposition2.15 and Corollary2.16(i), with the formal
parameter normalization in section3.1. The already recorded primary-source
inspection did not cover the full55-page paper.

CI repeats the exact p-power torsion phase for the basis a,tau_b, and handles
an arbitrary common complex scaling by transporting both the function and its
directions. No assertion that the complex scale has p-adic absolute value1 is
used. Likewise no binomial substitution with an arbitrary element of O_Cp is
used. The common coordinate is an actual formal-group coordinate, and the
allowed lattice direction changes have Zp coefficients.

## Rational isometry and local correction

TS proves rational four-square decomposition by descent, diagonalizes the
positive Hermitian form over the imaginary quadratic field, and gives the
fourfold isometry through quaternion matrices. At each split prime it chooses
dual integral bases for the two local factors. Cayley parametrization and
Chinese remaindering produce a global rational isometry which is locally
standard and differs invertibly from the reference isometry.

The ideal twist preserves self-duality after dividing the Hermitian form by
the ideal norm, and agrees with the untwisted lattice at the allowed primes.
Thus the determinant correction is exactly the one already checked in LM.
The analytic eighth-power identity is supplied by TC, not reintroduced as an
assumption. CI supplies the elliptic ordinary moments; prime-to-p averaging
and the fourth-tensor root criterion yield the normalized trace-lattice theta
moments. The whole arithmetic column, support identities and incidence maps
are distinct subsequent steps.

## Verification

The combined OT/CM/LM/TC/CI/TS wrapper was compiled twice with XeLaTeX to33
pages after the final prime-scope clarifications. Source and artifact SHA256
values, conservative read intervals and the exact compile logs are recorded
in theta_ordinary_extension_source_manifest.json. No new full Lean replay is
claimed. No counterexample under the retained hypotheses was found.
