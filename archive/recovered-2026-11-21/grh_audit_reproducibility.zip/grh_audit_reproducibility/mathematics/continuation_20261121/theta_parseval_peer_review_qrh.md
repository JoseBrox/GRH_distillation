# Independent review of single-block Parseval and the majorant induction

Reviewer: `/root/qrh_mathematics`, 21 November 2026.
Read all 464 lines of `theta_parseval.tex` and inspected all of
`check_theta_parseval.py`. No mathematical defect or modelling error was
found. The finite controls are supplementary; the general arguments were
reviewed independently of them.

## Algebra and normalization

1. The dual module is the row quotient R^n Z^(-1)/R^n. Self-duality
   of R gives both orthogonality identities, including the step that an
   R-linear functional nonzero in K/R is detected after multiplying an
   argument by a suitable r in R. No principal-ideal hypothesis enters.
2. The bordered-module model E_alpha={(x,k):[k]=-alpha(x)} has precisely
   the stated first-column quotient. Its last-column relation is
   g=(beta,c), its marked vector is e=(0,1), and the last inverse-coordinate
   functional is [k/c]. The signs match the actual block inverse.
3. Preservation of [k/c] gives a unique lift of a quotient isomorphism
   preserving k exactly: subtract its unique required multiple of g'.
   This proves linearity, invertibility, preservation of e and g, and
   the exact bijection with unqualified base isomorphisms theta satisfying
   alpha' theta=alpha and theta beta=beta'. The argument includes zero-size
   heads and nonmaximal orders.
4. The lower-left and upper-right coset coordinates are independently
   rows/columns modulo R once the diagonal representatives have been fixed.
   Their added phase is alpha(e)+lambda(beta). Conjugating the second
   phase gives the exact finite-inner expression in the manuscript.
5. Summation over c mod R removes exactly one constraint for each
   (alpha,beta). The two independent orthogonality sums give (#C)^2,
   hence c(h)c(h') after summing base orbital classes. Both factors are
   necessary; the Q_2 example with values 3 and 1 is correct.

## Support and induction

6. The selected minor uses the first r+1 rows and columns 1,...,r,n.
   Lower triangular multiplication restricts to those initial rows and
   preserves its determinant; the first row of the last reversing block
   contributes exactly t in the last column. Thus the minor is
   det(Z(h))*t, with no missing sign or extra factor.
7. Integral invertible heads have one integral orbital class by successive
   block elimination, giving the zero marked cokernel and N_0=1.
8. Applying Parseval to h[m,t],h'[m,t'] cancels the powers exactly and
   gives U_m=c(h)c(h')N_m. The already constructed positive majorant
   therefore bounds every unrestricted diagonal, and their averages.
9. The full and truncated sums are positive Gram matrices, finite on
   their effective supports. The inverse-parameter support makes distinct
   L_2/R blocks orthogonal, since their shift differences are not in R.
10. For an inner product conjugate linear in its first entry, the positive
    coefficient psi(z sigma) combines with the truncated kernel's phase
    to give psi((w-z)(sigma-sigma')). The factor is
    a/(ab)^2 times the squared character sum. Orthogonality makes it a
    on z+L_2^perp, whose volume is 1/a. Thus the exact larger-block
    kernel, not a rescaled one, is recovered.
11. The finite Fourier lemma is applied with chi(v)=psi(-zv), agreeing
    with the displayed vector coefficients. Its mass is exactly the
    averaged unrestricted diagonal. The majorant is R-periodic because
    its inner v variables lie in R; phases involving the outer
    representatives cancel in the majorant.
12. Restricting to the fixed compact R-module L_c decreases positive
    mass and preserves domination, because the kernel vanishes outside
    it. The finite quotient L_c/R permits an ordinary finite-dimensional
    subsequence argument. Zero entries and the positive inequalities
    survive the limit. The result for unit heads follows from its single
    possible support coset.

## Inspection of the exact controls

The code constructs actual integral bordered matrices for rank-one heads
Z=p*u, choosing xi=r/p, eta=b/(p*u), c=1 or k/p. Its columns and determinant
are correct. Their cokernels are killed by p (determinant valuation zero
or one), so reduction modulo p captures the complete modules. The code
enumerates the possible image of the first generator while fixing the
second marked generator, checks every source column relation, checks the
inverse-coordinate functional on both generators, and checks bijectivity.
Thus its isomorphism count is independent of the separate finite-duality
formula used for comparison. The cyclotomic reduction subtracts the final
coefficient using Phi_p=1+X+...+X^(p-1), giving an exact equality test.
The scope is eight head pairs, hence 28 kernel comparisons and eight
Parseval totals over Q_2,Q_3,Q_5. I inspected the code but did not rerun it;
the root records the successful run. It supplies no computational claim
for higher rank or nonmaximal orders.
