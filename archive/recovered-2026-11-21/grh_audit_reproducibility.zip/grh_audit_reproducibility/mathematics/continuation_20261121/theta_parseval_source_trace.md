# Single-block Parseval and the local majorant induction

Date: 21 November 2026.
Mathematical text: `theta_parseval.tex`.

## Result

The fragment proves the actual single-block orbital formula and its exact
Parseval identity in conventional mathematics. The compact open self-dual
order need not be maximal. It also proves the determinant-minor support,
the unrestricted diagonal identity and bound, and the whole local
positive-majorant induction, using the now-proved orbital germ in the
adjacent scalar and fixed-initial-block reconstruction.

The core proof replaces a long coordinate implementation by the pullback
module E_alpha={(x,k):[k]=-alpha(x)}. For an integral bordered matrix,
its cokernel is E_alpha/R(beta,c), its mark is [(0,1)], and its functional
is [k/c]. A marked isomorphism lifts uniquely preserving k; quotienting
instead by R(0,1) recovers the original finite module. This proves the
exact isomorphism-count identity, with no choice of invariant factors.
Finite character orthogonality then gives precisely c(h)c(h')N_0.

The finite Fourier step keeps all factors 1/a, 1/b, and a. Its contraction
norm equals the desired next kernel because the selected root-fiber
identity integrates over one coset of L_2-perp, of volume 1/a. The
unrestricted diagonal is bounded by the previous majorant's total mass.
There is no additional analytic estimate or dimensional loss here.

## Source correspondence and read scope

Paths are relative to `sources/lean/src` and are pinned in the companion
manifest. Ranges denote text actually consulted, not imported proof closure.

- `Formalism/HermitianCurvature/BlockKernelPropertiesOfSteps.lean`,
  lines 315--445: SingleBlockFormula, SingleBlockParseval, NsSupport,
  ThetaProps, the base case and induction statement. Its local kernel
  definitions were already read in the preceding orbital audit.
- `Formalism/HermitianCurvature/ThetaExistenceInductiveFromPieces.lean`,
  lines 1--95 and 450--743: exact truncated and unrestricted Gram sums,
  germ identity, UGramEq, UNormBound, CutNormEval, ThxSum and induction.
- `HermitianCurvatureProofs/FirstKernelExplicitFormula.lean`,
  lines 1--230, 400--444, 900--1082, 1295--1457 and 1570--1945:
  bordered matrix and phase, marked lift, integral-pair parametrization,
  finite combinatorics and final single-block formula. Declarations in
  the other ranges were indexed; their proof bodies were not all read.
  The ordinary coset and pullback-module arguments supply independent
  proofs of the statements actually needed.
- `HermitianCurvatureProofs/FirstKernelPropertiesOfHypotheses.lean`,
  lines 1--260 and 300--480: base majorant and finite character-sum
  Parseval proof, including both cokernel cardinality factors.
- `HermitianCurvatureProofs/FirstKernelProperties.lean`: entire short
  assembly file read. Its import closure was not thereby audited.
- `HermitianCurvatureProofs/AveragedVectorChoices.lean`, lines 1--260:
  the positive-semidefinite truncation and unrestricted norm deduction.
  The ordinary proof makes all later Fourier normalizations explicit.
- `HermitianCurvatureProofs/AddedBlockKernelSupport.lean`, lines 1--200:
  the exact determinant minor giving det(Z(h))*t in R. The conventional
  proof uses the same minor directly, including an empty initial block.

## Adversarial checks

The example K=Q_2, h=[1,2] gives single-block masses 3 and 1 on the
classes 0 and 1/2. Their total is 4, while N_0=1. It disproves omission
of the two cokernel-order factors. The source retains those factors.
The requirement alpha(beta)=-[c] is kept throughout: deleting it would
destroy finite support as c varies. The pullback construction retains
the last inverse-coordinate functional, not only the cokernel module.

The companion exact program checks bordered marked-isomorphism counts
by enumerating maps on actual finite quotient modules, independently
of the pullback formula. These finite controls do not replace the proofs.

## Scope

No new kernel replay or full source rebuild was performed for this
mathematical component. The local induction uses the displayed
orbital germ; its completed reconstruction is in the adjacent scalar
and fixed-initial-block sections. The global orbital-sum estimates,
global energy argument, and arithmetic divisibility are not consequences
of this finite local argument alone.
