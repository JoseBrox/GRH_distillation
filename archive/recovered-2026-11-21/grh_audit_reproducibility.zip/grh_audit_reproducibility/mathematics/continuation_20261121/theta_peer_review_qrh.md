# Independent mathematical review of the theta reconstruction

Reviewer: QRH and selected-character reviewer, 21 November 2026.
Companion: `theta_estimates.tex` in this directory.

## Conclusion

The reconstructed mathematical lemmas reviewed below are correct with their
stated hypotheses. No counterexample satisfying those hypotheses was found.
This is a mathematical peer review of the written section, not a kernel
verification or an exhaustive audit of the source's global theta estimates.
The exact source orbital identity and the uniform global sums remain
explicit conditional inputs. Local stationary phase and positivity do not
supply them by themselves.

## Analytic and algebraic checks

- The self-dual measure for the nonmaximal split order is q times product
  measure, and the order has volume one. The finite-cokernel cardinality
  argument uses compactness and change of variables, not a principal-ideal
  assumption on that order.
- Gaussian admissibility implies B^{-1}L^perp is contained in L by
  polarization and double annihilation. The squared integral and the
  lattice-independent Gaussian factor include the correct determinant.
  Residue characteristics dividing 2 or m+1 require a smaller neighborhood;
  no uniform radius in those parameters is inferred.
- The analytic square-root construction in the Morse lemma is valid in
  characteristic zero, including at p=2. Its uniform version requires a
  common weighted coefficient norm on a fixed polydisc; this requirement
  was made explicit after review. The product-field formula and the factor
  |m+1|^{-1/2} are retained.
- The marked-module isomorphism-count identity has the correct automorphism
  denominator. With conjugate-first inner products, its quadratic form is
  sum_alpha |sum_w conjugate(b_w) B_w(alpha)|^2 / |Aut(C_alpha)|.
  The corrected coefficient conjugation is present. Determinant support
  follows from cokernel cardinality; inverse-parameter support is a
  separate, explicitly stated source obligation.
- The contraction realizing 0 <= G_c <= G descends through the null space
  and follows from the positive square root of an operator between 0 and I.
  It remains valid for a zero-dimensional quotient.
- Finite Fourier averaging has exactly the factors 1/a, 1/b, and a in its
  definitions. Orthogonality of different outer cosets gives domination;
  character orthogonality gives the total mass, with no missing factor.
- The local limiting argument takes a subsequence in a fixed finite product
  of bounded matrix spaces indexed by L_c/R. The annuli increase to K^x,
  so a single subsequence gives domination for every fixed parameter.
  No diagonal extraction over an uncountable parameter set is needed.
  The support module R + sum_h det(Z(h))^{-1}R is compact open and sufficient.
- The convolution convention and p(g)=d_pi conjugate(<w,pi(g)w>) are
  consistent. Schur orthogonality gives p*p=p. The L^1 assumption is
  explicitly retained; square integrability alone would not justify
  applying the bounded convolution operator to an arbitrary unitary
  representation. Its nonzero eigenvalue is therefore exactly one.
- The Poincare unfolding formula has the correct double coset orientation
  Gamma_{u'} backslash Gamma / Gamma_u and subgroup
  Gamma_u intersect eta^{-1} Gamma_{u'} eta. Absolute integrability is an
  explicit hypothesis, sufficient for both rearrangements.
- With conjugate-first inner products, the row expression
  sum_{i,j} Gamma_ij <v_i,v_j> is bounded by P gamma sum_i ||v_i||^2 when
  P gamma I - Gamma is positive semidefinite. The equal-row partition and
  the generic/nongeneric triangle inequality give the stated multiplier.

## Uniform numerical bounds and source normalization

The inequalities yielding 1+14 b^{-7} <= 1+b^{-6} are valid for b>=16.
All uses of k,f,r,C_n,c_5 and C_Gamma retain the displayed quantifiers.
In particular, the density factor and nongeneric error are exponentially
small only after the stated inequalities relating k to r,f,log b.
The diagonal estimate follows directly from the two Hilbert--Schmidt
bounds and d_u Gamma^2/D_* <= C_0.

The actual row prefactor in the source is

    P = product_{v|g1 g2}(1+3/q_v)
      = ((1+3/g1)(1+3/g2))^f
      <= exp(6 f/(k b)^8) <= exp(6 b^{-7}).

It is now explicitly distinguished from the optional estimate for
product_j (1-q^{-j})^{-1}. Complete splitting is required for the equality.
The local density product bound is uniform in the number of places because
there are at most f places above each rational prime.

The exact source definition is

    D_* = (product of archimedean formal degrees)
          * volume(G(F) backslash G(A_F)) * Re(e_fin(1)).

It agrees with `GlobAut.lean` and `AutTie.Dstar_eq`. The written section does
not identify this main term with the actual dimension without the separate
ambient-dimension estimate. The rank/signature parameters agree with
`Ranks.r = k+m-1`, `Ranks.rS = m/2-1`, `sigY0=(k+rS,rS+1)`.

## Additional source read scope for this peer review

Paths here are relative to `sources/lean/src/`.

| Source | Scope actually read |
|---|---|
| `Formalism/SharpRestriction/CuspSpanNormBounds/GlobAut.lean` | Definitions through the start of `RowsAut`, including the quotient measure, right convolution, Dcount, vol, Dstar and admissible idempotent. Not the entire remainder. |
| `Formalism/SharpRestriction/CuspSpanNormBounds/DstarEq.lean` | Entire file, including the exact formal-degree and main-term tie. |
| `Formalism/SharpRestriction/CuspSpanNormBounds/PlaceDegreeData.lean` | First 105 lines: local coefficient, global product of formal degrees, and associated hypotheses. Not the later representation-theoretic proofs. |
| `Formalism/SharpRestriction/CuspSpanNormBounds/StandingNumericalData.lean` | Entire 170-line file, including f3G, its complete-splitting identity, the row inequality and dimension comparisons. |
| `Formalism/SharpRestriction/CuspSpanNormBounds/UniformConstantsAndStatements.lean` | Initial 150 lines, defining the analytic/arithmetic assertions. Their full proofs were not reviewed here. |
| `Formalism/SharpRestriction/CuspSpanNormBounds/FrobeniusProjectedBounds.lean` | Selected initial definitions of the diagonal, nongeneric, ambient-dimension and projection bounds; not the full file. |
| `Formalism/SharpRestriction/CuspSpanNormBounds/AdmissibleBoundsFromSource.lean` | Initial definitions through the first conclusion, especially the scales and prerequisites; not the full later proof. |
| `Formalism/SharpRestriction/CuspSpanNormBounds/BridgeCountE.lean` | Initial interfaces through line 110, including the dimension asymptotic; not the counting theorem's proof. |
| `Formalism/LocalRingCardinality/Params.lean` | Entire 125-line file, including ranks and signatures. |
| `Formalism/LocalRingCardinality/DataParams₂.lean` | The parameter fields around lines 145--183, including log Gamma=C_Gamma m^5 f L. |

The separate theta source trace records the author's broader source reading.
Neither trace claims to reprove all the discrete-series, local-orbit,
Poisson-recursion, or lattice-counting inputs.
