# The two polynomial lifts involving terminal off-diagonal entries

## Mathematical result

The fragment theta_radial_coupled_lifts.tex proves both remaining
polynomial differential lifts in the source's four-operator construction.
It specifies the terminal entries t21, t12 and t22 with the source's
spectral shifts and signs. A general bordered quantum-minor identity,
proved by column expansion and reverse row expansion, applies also when
the row and column omission sets differ. The right and left unipotent
characters give the bulk recurrence and the terminal t22 boundary term.
All scalar coefficients stay outside the differential operators.

The two full-group coefficient determinants have degree r+1 and the
operators have order at most r+k. Their exact radial restrictions are
the expressions in CutJDHatJDCapR.lean. The unspecified constant epsilon
in the source's existence statements is made explicit: -(-1)^(r(k+1))
for rhatOp, and -1 for rvhatOp. The scalar signs follow directly from the
displayed source ordering of isotropic and dual isotropic indices.

The proof gives full left and right covariance. In particular the
nontrivial determinant character of the compact stabilizer is retained
and cancelled against the complementary exterior coefficient. Omitting
that factor in either intermediate identity would give a false formula.
Polynomial growth and ordinary Haar formal adjoints follow from the
already proved derivative argument in theta_radial_differential_lifts.tex.

## Source identification and read scope

The manifest records exact source hashes and conservative read ranges.
CutJDHatJDCapRGrpP.lean and CutJDHatJDCapRGrpM.lean were read in full:
they supply the actual coefficient determinants and the existence targets
for radial action and invariance. CutJDHatJDCapR.lean lines 1--120 give
the exact target radial expressions and their immediate interfaces.
StatementQ.lean was read at the ranges recorded: the column/row and
border identities, the actual terminal entries, and the root/torus rules.
The ordinary proof supplies these rules directly from the character.
The submitted transitive proof of every wrapper is not claimed to have
been read or independently kernel checked here.

## Independent exact controls

check_theta_radial_coupled_lifts.py runs 986 exact checks. Eighty-eight
evaluate the bordered identities using actual right vector fields on
GL_n and independent Gauss-decomposition Taylor jets for n=2,3, including
unequal and differently ordered row/column lists. The boundary signs
are checked coefficient by coefficient in independent omitted-pair
symbols. The full-group coefficient determinants and both exterior
covariance identities are checked with exact rational Gaussian unitary
matrices, including nontrivial compact determinants and unipotent factors.
These are finite controls of the conventions, not a replacement for the
general determinant and equivariance proofs.

## Scope still remaining

All four polynomial lifts and the regular spectral inverse now have
ordinary mathematical proofs and exact radial identifications. The
terminal quantum relation, the adjoint rule for the Jacquet pairing,
and locally uniform integrability/weighted Fourier decay for the actual
generated class remain separate obligations. Ordinary Haar integration
by parts is not silently substituted for the Jacquet-pairing assertion.
