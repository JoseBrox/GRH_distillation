# Independent review: theta_radial_decomposition

Date: 2026-11-21. Reviewer: qrh_mathematics.

Read all 430 lines of `theta_radial_decomposition.tex`, SHA256 `19077cd3cc531a737f6125f53e1746aa78d8cd4af070d2526ec5a0a48462167b`.

I independently read the entire fragment. No mathematical defect was found, using the compact branching proof which I also independently reviewed in full.

* With the linear-first Hermitian convention, v_g=y+h(y,x)x/T' is perpendicular to x and has norm G/T'. The varying orthogonal projection is smooth on G>0. Positive Gram--Schmidt gives local smooth frames, and full Capelli covariance removes frame choices. For g'=agb, E_(g')=b^(-1)E_g and C_(g')=pi'(b)^(-1) C_g pi'(b), which is exactly the transformation required by the right equivariance.
* The constants lambda_i-i+1 and the source u_i are strictly decreasing, so equality of the full Capelli polynomials identifies the weights without an ordering ambiguity. The shifts rho_i=mu_i-i+1+(k-2)/2 give exactly the simultaneous interlacing intervals and integer step used in the earlier positivity section. The k=1 empty tuple is correct.
* The intersection subgroup H_g fixes x and y and is U(k-1). The equality Phi(g)pi'(h)=pi(ghg^(-1))Phi(g) kills noncommon right constituents by irreducibility. This remains true when a noncommon constituent happens to have the same eigenvalue as a common one at a chosen spectral value.
* Iterating X(Y0) is legitimate because the preceding lemma first shows that it preserves the whole smooth equivariant function space. Thus its polynomial action is pointwise right matrix multiplication. q0(X)=0 follows on the evaluated image; no annihilation of the unused spectrum on all of W is assumed. Interpolation gives a unique unital algebra homomorphism, orthogonal idempotents, and the exact normal-form identity for every complex Y.
* The matrix formula preserves support. Pointwise orthogonality gives constant-one L2 contractions for arbitrary positive measures and scalar weights, with no dependence on the interpolation denominators. Scalar multiplication and c-derivatives commute whenever the resulting functions remain in the stated domain. Compact support inside G>0, not merely bounded support touching the boundary, justifies the final conditional density integrability assertion.

The fragment closes the finite spectral decomposition premise of terminal positivity. It correctly retains the noncompact integrated differential identities, generated function classes, boundary terms, and successive radial integrations as separate obligations. This review does not assert those later analytic steps.
