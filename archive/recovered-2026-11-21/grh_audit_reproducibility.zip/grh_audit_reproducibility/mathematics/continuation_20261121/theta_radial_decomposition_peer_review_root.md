# Review of the finite radial decomposition

Reviewer: root. Date: 21 November 2026.

The entire fragment was read. No mathematical defect was found.

The positive complement has a smooth local orthonormal frame because its Gram denominators stay positive. Full Capelli covariance gives independence from the chosen frame. Under left and right stabilizer actions its matrix field transforms with the displayed inverse on the right representation, so pointwise multiplication preserves the exact radial function space and its zero extension. This also justifies iterating the nominal differential operator as a pointwise matrix operator.

The relation between the compact highest weights and the source spectral parameters retains every half-integer and index shift. Strictly ordered real roots identify those weights uniquely. The compact branching law gives precisely the common interlacing set on the left and right. Equivariance makes evaluation an intertwiner for the common positive-complement stabilizer, hence kills all noncommon types.

A real separating parameter exists for the distinct finite polynomials. The polynomial q_0 annihilates the actual endomorphism on the radial function space, even though it need not annihilate every vector of the right coefficient representation. Lagrange interpolation then constructs the unital algebra map, proves uniqueness, and gives its exact terminal entry. Self-adjointness of the finite matrices gives orthogonal evaluations and the norm identity with constant one. Thus there is no quantitative loss from interpolation denominators.

The arbitrary-positive-measure L2 statement follows from the pointwise orthogonal decomposition and finite sums. Support and smoothness are preserved. Compact-support density integrability follows from a positive minimum of G on that support. The identification with the original integrated differential forms and the noncompact radial induction are explicitly not proved by these arguments.
