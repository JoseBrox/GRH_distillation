# Direct radial decomposition: source and proof scope

## Actual result reconstructed

The fragment theta_radial_decomposition.tex proves the exact finite algebra action needed for the terminal positive density. It starts with the actual radial function space, actual terminal differential operator, and actual Capelli spectral equations from StatementQ.lean. It does not posit the larger normal form or its raising and lowering relations.

The compact branching theorem is proved independently in compact_branching.tex, rather than imported as an unverified classical theorem. The terminal operator, its exact shift, complementary-minor sign and compact interpretation are proved in theta_radial_positivity.tex.

Smooth local orthonormal frames of the common positive complement exist by projection and Gram--Schmidt. Full Capelli covariance makes the matrix field independent of those frames. Its conjugation under the two compact groups proves that multiplication by that field preserves the actual function space.

The source spectral parameter u_i corresponds to the integral highest weight lambda_i=u_i+i-1-(k-1)/2. Compact branching gives the common constituent parameter rho_i=mu_i-i+1+(k-2)/2, with exactly the source's finite interval and integral-coset conditions. Bi-equivariance annihilates every right constituent absent on the left.

A real separating parameter and elementary Lagrange polynomials then construct the finite algebra action on the function space. Polynomial identities are imposed only on the evaluated image: unused right constituents are killed by the equivariant function. This yields the exact terminal operator for every complex parameter. Orthogonal projections give norm bound one and arbitrary weighted L2 contractions, with no interpolation-denominator estimate.

## Source comparison

QuadraticFormTwoTwo/RadialDecompositionOfParts.lean, SpecAbstract.lean and Vanish.lean contain the corresponding source route through common compact types, finite interpolation and the annihilation of noncommon types. The ordinary proof reconstructs these steps directly.

StatementQ.lean supplies the radial domain, smoothness convention, compact types, actual operators and the larger normal-form interface. StatementWR.lean fixes the nonzero-coordinate parameter domain. QNFAsm.lean identifies where the source assembles the larger normal form; its additional imports are not asserted as reviewed or needed here.

## Status

The finite algebra action and terminal pointwise positivity are proved. The radial integrated-form equality, actual function-class stability and integrability, one-variable derivative corrections, Fourier decay and wave identities remain separate analytic work. Compact support is used only in the explicitly stated elementary integrability corollary, not as a claim about the actual generated class.

No counterexample to the actual hypotheses was found. The proof explicitly treats rank k=1 and the zero radial function space.

Root and QRH agents independently read the complete mathematical fragment and the compact branching theorem. Their reviews found no defect. The associated manifest records exact versions and conservative source read scopes; it does not claim archive-wide review.
