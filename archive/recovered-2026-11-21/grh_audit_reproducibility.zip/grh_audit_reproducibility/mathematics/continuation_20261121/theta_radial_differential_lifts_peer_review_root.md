# Independent review of the two differential lifts

Reviewed artifact: theta_radial_differential_lifts.tex

SHA256: 849f5a794bdd42d04aad8cbf1255abfd5d424fc0f56bc42c30f32109c26b205c

The root reviewer read the entire 596-line mathematical fragment, including the full-group definitions, polynomial coefficient estimates, Haar adjoints, both translation covariance arguments, six root and torus rules, the enveloping-algebra cofactor reduction, the last-column induction, and both radial identities with their precise scalar conjugation. No mathematical correction was required.

The review checked in particular that arbitrary right derivatives preserve the left character law, whereas the induction retains only the specific right character laws that it actually needs. The conjugate identity uses the reversed dual ordering and the negative conjugate Euler derivative; the expansion over disjoint adjacent edges justifies reversal without commuting a derivative past a coefficient involving its own variable.

Independent source comparison in this review covered OperatorsCommuteTranslations.lean lines 1--135; the entire CutJDHatJDCapAGrp.lean; StatementIO.lean lines 1--120; and StatementQ.lean lines 145--160, 210--240 and 380--410. These confirm the ordered quantum minors, right complexification, the two full-group scalar coefficients and spectral parameters, the actual two character laws and the radial scalar factor. The author's source manifest records additional source reading; this review does not claim to have repeated all of it.

The reviewer reran check_theta_radial_differential_lifts.py. All 305 exact controls passed, including the independent Taylor-jet evaluations of actual right vector fields. The general proofs, rather than the finite controls, establish the identities.

Status: passed for the stated smooth equivariant class. This does not prove the distinct Jacquet-pairing adjoint formula, local uniform square-integrability, or the weighted Fourier estimate for the actual generated class, and is not an independent Lean kernel replay.
