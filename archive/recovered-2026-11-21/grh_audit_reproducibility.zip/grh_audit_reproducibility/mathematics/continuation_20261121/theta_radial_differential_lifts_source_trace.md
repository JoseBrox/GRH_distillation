# Polynomial Capelli operators and actual Toda radial identities

## Completed mathematical assertions

The fragment theta_radial_differential_lifts.tex proves the actual
full-group operators underlying the two weighted isotropic Capelli
operators. Their scalar coefficients have degree r; their order is at
most r. No intermediate-minor denominator is introduced. The source
records order exactly r by adding a formally zero term, which has no
mathematical effect on the order bound proved here.

The proof includes commutation with the full relevant left and right
unipotent and compact translations, obtained from the all-minor
covariance proved earlier and Cauchy–Binet. Polynomial coefficient
bounds and class preservation are proved for the operators and their
ordinary Haar formal adjoints. This does not identify their adjoints
for the separate Jacquet pairing.

The exact radial identity is proved by a short enveloping-algebra
argument. Last-column expansion leaves two terms by the right
Whittaker character. In the non-diagonal cofactor, moving its unique
last-row generator to the left gives one adjacent-root term and terms
annihilated by the left Whittaker character. This proves the actual
three-term Toda recurrence. The source's scalar radial factor cancels
each diagonal shift exactly. For the conjugate operator, reversing the
dual order and expanding over disjoint adjacent edges proves the
required reversal identity. The signs of the character, negative
conjugate Euler derivative, and both spectral shifts are all explicit.

## Source map

The JSON manifest gives exact hashes and conservative read ranges.
The key definitions are in OperatorsCommuteTranslations.lean,
CutJDHatJDCapAGrp.lean, and StatementIO.lean. The exact first radial
target is CutJDHatJDACapToda.lean. MinorCellOfParts.lean states the
three derivative rules, reconstructed directly in the manuscript from
the actual character in StatementG.lean.

For the mirror calculation, CutJDHatJDACapTodaVCut.lean gives the
dual ordering and parameter. CutJDHatJDACapTodaVGrpCut.lean and
CutJDHatJDACapTodaVChain.lean contain the exact mirror determinant
recurrence. CutJDHatJDACapTodaVCrd.lean supplies the original
coordinate/gauge assembly, replaced here by the direct expansion over
disjoint adjacent edges. CutJDHatJDCapARep.lean confirms the finite
polynomial Lie-word representation.

The complete analytic assertions imported to put an actual Jacquet
function into the smooth equivariant class are not claimed from
reading the application wrappers. The manuscript explicitly states
smoothness and the character laws for its radial theorem.

## Exact controls

The script check_theta_radial_differential_lifts.py performs 305
exact rational checks. Its substantive controls compute the ordered
Capelli operator using actual right vector fields on GL_n for n≤3.
The test functions are defined by their exact Gauss decomposition and
have the two Whittaker laws. Truncated Taylor jets evaluate the
differential operator independently of the three-term recurrence.
The resulting values are compared to the predicted Toda expressions.
Additional checks verify every gauge and mirror shift in small
dimensions, matching reversal, and the empty-rank case.

These are controls of formulas and conventions. The general proof is
the displayed determinant and equivariance argument, not a numerical
extrapolation.

## Remaining dependencies

The coupled operators involving the off-diagonal terminal entries,
their quantum relations, the Jacquet-pairing adjoint formula, local
uniform square-integrability of the generated class, and the resulting
weighted Fourier decay remain separate. This fragment closes the two
actual polynomial differential lifts and their radial identities.
