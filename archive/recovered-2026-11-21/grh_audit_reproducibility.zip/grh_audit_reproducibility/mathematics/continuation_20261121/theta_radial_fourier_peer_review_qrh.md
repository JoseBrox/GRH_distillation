# Independent review: noncompact radial integration

Reviewer: qrh_mathematics. Date: 2026-11-21.
Reviewed all 638 lines of theta_radial_fourier.tex.
SHA256: `391c359350042bd428c4cccf290f7d59b8b48f88ff21ea592e9067b64092c4a6`.

## Result

No mathematical defect found in the conventional fragment. The actual generated Jacquet-family bounds and radial operator recursion are correctly retained as separate obligations. This is not a claim to have audited every original provider.

## Checks

- Fourier phase st-conj(s)conj(t)=2i(bx+ay), Gaussian transform exp(-a|s|²), and inverse constant pi^(-2) all agree with planar Lebesgue measure. Gaussian regularization gives the asserted pointwise and almost-everywhere inverse without an assumed inversion theorem.
- The polar moment integral is 2pi (j+1)!(m-j)!/(m+2)! for j<=m. Differentiation contributes 2^j, yielding exactly M_(m,j). The weight's derivative polynomial has degree<=j and coefficient norm increased by at most 5j+4. The factors16 and2^(j/2) correctly pass to a (1+|t|)^(-4) multilinear derivative estimate.
- The cutoff integration-by-parts proof uses integrability of each derivative and its predecessor, removes both endpoint concerns, and gives zero for every positive-order derivative. No boundary term or unjustified absolute convergence is hidden.
- The Gaussian-mixture counterexample has L1 norm1, Fourier transform (1-exp(-|s|²))/|s|², and logarithmic divergence at zero. It is a valid obstruction to the m=0 critical exponent -2.
- Both one-letter identities were expanded directly under the linear-first Hermitian convention. The conjugated coefficient in the second argument gives exactly the plus shift+1 and minus shift-1, and the indicated Wirtinger derivatives.
- The subset induction requires only E_a commuting with all other-coordinate component matrices and the scalar differential operators. Pairwise distinct indices supply that condition. The repeated-index example gives the stated factor1 versus2 and is a genuine counterexample to omitting this assumption.
- Formal adjoints for the |t|^(-2) measure are p*=-bar(p), t*=bar(t). Both 2x2 inverse identities hold with the displayed shifts; I_w V_w* cancels in the written order. No unproved noncompact Hilbert-space adjoint-domain equality is claimed.
- The added L2-smoothness lemma is valid under the single common exceptional null set and joint measurability. Segment FTC, Tonelli and the locally uniform next-derivative L2 bound prove norm continuity and differentiation with a quadratic remainder. A pointwise L2 majorant is indeed unnecessary.

The finite-subset expansion reduces the analytic requirement to the weighted transforms of D(Rx,E_Jy). Constants and allowed dependencies remain explicit. No correction requested.
