# Independent mathematical review: noncompact radial integration

Reviewer: root agent, 21 November 2026.
Scope: all lines of theta_radial_fourier.tex, including the stated limits.

The Fourier inverse has factor 1/pi^2 for exp(st-conj(s)conj(t)); the
Gaussian approximate-identity proof establishes equality without an
assumed pointwise inversion theorem. The beta-integral moment constants
and the recursive derivative bound for (1+|t|^2)^(-2) are correct.
Their product gives decay of every derivative through the required order.
A smooth cutoff proves that all positive-order derivatives have integral
zero, so neither zero nor infinity has been silently dropped.

Both one-letter identities were checked by direct expansion with the
inner product linear in the first argument. In the admissible-word
induction the constant elementary operator commutes with all operators
at the other, distinct tensor indices. This gives exactly the subset
expansion, not an unwarranted commutation of the variable differential
operators themselves. The repeated-index example and the borderline
Fourier-decay example are valid counterexamples to weakened hypotheses.

The formal adjoint matrices, their inverse identities, and the ordered
word cancellation have the correct shifts. The local uniform L2 bounds
suffice for smooth Hilbert-space dependence by the Taylor remainder
estimate; no missing pointwise dominator is needed.

Conclusion: the stated mathematical results pass. Their application
still requires the weighted Fourier bounds for the actual generated
Jacquet functions and the source frame identity. The fragment explicitly
retains both dependencies. No fatal source flaw is asserted.

Reviewed fragment SHA-256: 391c359350042bd428c4cccf290f7d59b8b48f88ff21ea592e9067b64092c4a6
