# Noncompact radial integration: exact source trace

## Proven scope

theta_radial_fourier.tex proves the actual scalar analytic and differential steps used in the source one-coordinate integration. Its Fourier convention is exp(st-conj(s)conj(t)), with Lebesgue measure on C and inverse constant pi^(-2). The Gaussian argument proves inversion, including equality at continuity points, before differentiation is used.

For E=(1+|t|^2)^2 D, decay of its transform by (1+|s|)^(-m-3) supplies a C^m extension across zero with every derivative through order m bounded by an explicit constant times (1+|t|)^(-4). Every positive-order derivative has integral zero on the whole plane. The proof controls both zero and infinity; it makes no compact-support assumption in t.

The source ContinuousExtensionOfFourierDecay.lean assumes transform decay for both D and E. The reconstruction proves the same conclusion using only the E estimate; integrability of D follows from that of E. The unweighted transform assumption is therefore unnecessary for this particular implication.

The source's exact plus/minus two-component operators are preserved, including the real spectral parameter, shifts by 1, conjugations, Euler derivatives and measure |t|^(-2)dt. Direct multiplication gives the two one-letter density identities. The distinct component indices in an admissible word yield a closed subset expansion with at most 2^h terms, coefficients of absolute value one, and derivative order |J|. This replaces the source's recursive unspecified finite expansion by an explicit expression. The derivative-integral theorem then proves the noncompact one-coordinate identity under exactly stated weighted Fourier hypotheses.

Both orders of the elementary inverse formal-adjoint identity are also proved, with the word order fixed. These are algebraic differential-operator identities, not an assertion about noncompact adjoint domains.

A further lemma proves that local uniform L2 bounds for all pointwise derivatives already imply smoothness as an L2-valued map. The proof uses the fundamental theorem of calculus, Cauchy--Schwarz and Tonelli, without requiring a pointwise dominating L2 function. In the actual coordinate algebra, real derivatives are finite sums of words in p, conjugate-p and multiplication by t^(-1), conjugate-t^(-1). Thus the source's local uniform word bounds would suffice for this smoothness conclusion.

## Exact source mapping

- ContinuousExtensionOfFourierDecay.lean: smooth extension, weighted spatial decay, and zero integrals of derivatives. Its two Fourier assumptions are reduced to one.
- ThmPActualCptOfStepParts2.lean: actual DecayData and finite derivative-combination interfaces.
- TheoremPCompactOfStepDensity.lean, initial scalar part: conversion of derivative combinations to a continuous integrable density with the prescribed integral.
- CutSEOneLetterDens.lean: actual plus/minus operators, Hilbert--Schmidt conjugation, |t|^(-2) weight and one-letter identity.
- ExpansionSiteZeroInduction.lean: distinct-index word expansion and commutation of elementary matrices with other component factors.
- CutSE2.lean: actual generated class, weighted Fourier conditions, density expansion, inverse-adjoint word and separate smoothness/Leibniz hypotheses.
- CutSELeibnizCls.lean and CutSEJSRadLoc.lean, recorded partial ranges only: local square-integrability and the local uniform word-norm provider. The current reconstruction does not claim the imported Jacquet estimates in those providers.
- CutSERD.lean, CutSERDAsm.lean, CutSERDBdd.lean and CutSERDBeta.lean: exact next-step four-operator identity, boundedness, iteration and Jacquet pairing normalization. These identify remaining dependencies; reading their assembly does not establish the full imported analytic assertions.

## Remaining work

The actual Jacquet-generated densities still require the local uniform L2 word bounds and the weighted Fourier estimates. The source obtains these from regular full-group differential operators, their adjoints, invariance of the coefficient class, and exact Jacquet pairing and measure identities. The actual recursive frame relation also remains separate. The present section makes those hypotheses explicit and does not replace them with a compact-support claim.

## Adversarial checks and controls

No counterexample to the actual hypotheses was found. The manuscript gives exact counterexamples to two invalid weakenings: the borderline Fourier power -2 need not give continuity in dimension two; a repeated component index invalidates the closed subset formula. The actual source uses the stronger decay and distinct indices.

check_theta_radial_fourier.py performs 532 exact rational/Gaussian-rational controls. These include 58 full subset density identities for all orders and signs through three distinct component indices, 420 word inverse-adjoint component checks, both elementary inverse orders, the repeated-index counterexample, and exact derivative-polynomial coefficient bounds. The general proofs do not rely on these finite checks.

The combined local wrapper compiles to 58 pages including earlier mathematical dependencies; its only unresolved reference is to the divisor section outside this wrapper. A long inline formula in the earlier positivity section was moved to display form after the first compilation. The root agent independently reviewed the complete new mathematical section and found no defect. QRH review is recorded separately when complete.

## Read coverage

The associated JSON manifest records exact hashes, source lengths and conservative read scopes. It distinguishes source assertions used in this proof from providers read to identify the next analytic obligations. No complete-archive review is claimed.
