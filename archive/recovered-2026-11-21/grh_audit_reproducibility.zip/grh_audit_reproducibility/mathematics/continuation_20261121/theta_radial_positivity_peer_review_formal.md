# Independent review of terminal radial positivity

Reviewer: formal-verification lane. Date: 21 November 2026.

## Outcome and scope

I independently read all 744 lines of `theta_radial_positivity.tex`. I found no mathematical defect in its statements or proofs under the explicitly retained normal-form hypothesis. The original operator conventions were checked in the source ranges below. This is not a new transitive-source or Lean-kernel certification, and it does not supply the outstanding analytic integration, boundary-term, or normal-form-existence proofs.

## Detailed checks

- **RTT sign.** For input auxiliary indices j,l and output i,k, the two permutation terms have coefficients L_kj(u)L_il(v) and L_kj(v)L_il(u). Their difference is exactly (u−v)(delta_kj E_il−delta_il E_kj). Thus the required relation has `(u−v)I−P`, with the displayed gl commutator sign.
- **Fusion.** For adjacent spectral parameters the difference is one. The antisymmetrizer kills the symmetric part on either side after RTT reverses those adjacent factors. The pair permutation commutes with every other auxiliary factor. This proves A_n L=A_n L A_n. The normalized exterior basis gives the determinant entries with no missing n!.
- **Covariance.** The underlying matrix-basis change is E'_ab=sum P_ca(P^(-1))_bd E_cd, or P^t E P^(-t) in the auxiliary matrix. Its exterior entries are exactly the two displayed minors of P and its inverse.
- **Adjoint reversal.** A reversal can be obtained by exchanging pairs initially ordered a<b. The RTT factor then has positive integer scalar b−a+1 on the exterior space. It commutes with all other labeled factors, so cancellation is legitimate. No zero scalar or integrality assertion is involved. The adjoint statement is for finite-dimensional Hilbert-space operators, not an assumed integrated adjoint of unbounded differential operators.
- **Centrality and highest weight.** Differentiating the basis covariance gives the exact inner derivation by sum X_cd E_cd. The largest nonfixed column of a nonidentity permutation has a strictly smaller row index; its raising factor kills the highest vector after the diagonal factors on its right act by scalars. The resulting product has the correct u−a shifts. The negative convention follows by extracting one minus sign per factor.
- **Complementary contraction.** The complementary-minor identity has sign (-1)^(sum A+sum I). Applying it twice gives C(E')=(wedge^2 P^(-1)) C(E) (wedge^2 P). Simultaneous vector and covector changes cancel these matrices. The surviving {0,1} term has positive sign, including N=2.
- **Terminal geometric factor.** With h linear in its first argument, the covectors are h(-,y), h(-,x); their determinant is TT'−|zeta|^2=−G. The operator definition contributes a second minus sign. The complementary space has positive dimension k−1 and its fixed orthonormal frame makes the transformed generators b_a h(-,b_b). The final shift is Y+k/2−1=Y+(k−2)/2. k=1 is the empty determinant case.
- **Frozen coefficients and differential order.** The source places the coordinates outside the differential minor on the left, exactly as in the fragment. The adapted basis is chosen at the evaluation point and kept fixed during differentiation. Every associated rank-one matrix annihilates z', as does its adjoint. Right equivariance along g exp(tX) therefore transfers E_A E_B F to F D_A D_B in the same order. There is no differentiation of a point-dependent frame or reversal of the representation product.
- **Compact representation.** The convolution argument proves smoothness of a continuous finite-dimensional unitary representation. The complexification of its skew-adjoint derivative gives D_ab^*=D_ba on the positive frame. This is the exact adjoint needed for the terminal determinant.
- **Pointwise positivity.** Real interpolation at one parameter separating all p_rho gives evaluation of each algebraic idempotent as right multiplication by a self-adjoint matrix polynomial. Orthogonality then follows from the idempotent relations on the function space. The proof does not require those matrix polynomials to be global spectral projections on the whole representation space.
- **Scalar parameters.** Interlacing forces strictly decreasing rho_i, so the polynomials are distinct. The cut margin gives at least 5/2 in absolute value before shifts by at most one. Exactly k−l factors are negative. The exceptional pair in q has opposite signs while all other pairs have equal signs, hence q(Y),q(Y−1)>0. Pairwise parameter distance greater than two makes every recursively used denominator nonzero and every ratio positive.
- **Remaining conditions.** The unital normal-form homomorphism with the specified terminal entry remains explicitly assumed. The final density identity is used only under that hypothesis. Extension by zero off the stated function domain is pointwise; no distributional derivative or boundary-term claim is inferred from it.

## Exact source ranges read

All paths below are under `sources/lean/src/`.

- `Formalism/RealPlaceAnalysis/StatementE.lean`, 1–24: ordered minor, product order, and exact RTT component equation.
- `Formalism/FormalDegreeBessel/StatementG.lean`, 1–25: h(v,w)=conj(w)^t H v and the signature matrix.
- `Formalism/FormalDegreeBessel/StatementIO.lean`, 10–29 and 85–103: foldr operator order and the two real Lie-algebra components defining EabH.
- `Formalism/RealPlaceAnalysis/SmoothOnGVIff.lean`, 156–165: derivative at g exp(tX).
- `Formalism/HermitianCurvature/StatementQ.lean`, 80–100, 151–215 and 595–670: Econj/chat2A, full and complementary shifts, frozen coefficient operators, compact-frame representation, and actual CapelliIdentityEntry/RightTypeAction assertions.
- `Formalism/HermitianCurvature/HermitianCurvatureProofs/CapelliTwoByTwo.lean`, 1–135 and 300–379: frozen evaluation, adapted-frame covariance, Gram determinant −G, and final shift. Its intermediate frame lemmas were not all independently reread.
- `Formalism/HermitianCurvature/HermitianCurvatureProofs/FrameEntries.lean`, 173–182: terminal uC value.
- `Formalism/HermitianCurvature/HermitianCurvatureProofs/DiagonalTransferAction.lean`, 24–110 and 252–275: compact derivative adjoint, determinant symmetry, and the zero-extension branch.
- `Formalism/HermitianCurvature/StatementFr.lean`, 218–240, and `StatementWd.lean`, 94–107: exact scalar recursions.
- `Formalism/HermitianCurvature/CompositeFormulaLevelZero.lean`, 85–101: actual terminal density definition.
- `Formalism/HermitianCurvature/HermitianCurvatureProofs/TopDensNonnegOfKappa.lean`, 115 through the end: diagonal coefficients and the exact |zeta|²/G scalar factor.

No counterexample satisfying the actual hypotheses was found. No correction to the mathematical fragment is requested.

Reviewed SHA256: `a02e34cd3d3f345051e5dae9765d88b2d78a805ad833b83dbea8d452e44d29fd`.
Recorded UTC: 2026-11-21T01:13:42.215184+00:00.
