# Independent review of terminal radial positivity

Date: 2026-11-21. Reviewer: qrh_mathematics.

I read all 749 lines of `theta_radial_positivity.tex`, SHA256 `a02e34cd3d3f345051e5dae9765d88b2d78a805ad833b83dbea8d452e44d29fd`. No mathematical defect was found. This is a review of the conventional proofs, not a transitive import audit or fresh kernel check.

## Checks

* The RTT sign matches [E_ij,E_kl] = delta_jk E_il - delta_li E_kj. The adjacent spectral difference is exactly one. Moving its antisymmetric projector proves left fusion without assuming that arbitrary L factors commute. For reversal, each exchanged pair has labels a<b, so the scalar b-a+1 on the exterior power is nonzero. The normalized exterior basis gives the ordered minors with no missing factorial, including n=0.
* Covariance uses E'=P^t E P^(-t), not P E P^(-1). Taking complementary minors gives C(E')=(Lambda^2 P^(-1)) C(E) (Lambda^2 P), with the displayed covector/vector transformations. The sign of the wedge pairing is consistent for zero-based indices. The centrality differentiation and largest nonfixed-column proof of the highest-weight eigenvalue are valid.
* With the source's Hermitian convention linear in the first argument, beta(v)=h(v,y), beta'(v)=h(v,x). Their determinant is -G. The external minus sign in t22 makes the terminal operator +G times the compact Capelli determinant. The full shift is Y+k/2 and the contraction shift is Y+(k-2)/2. The last rows of P^(-1) are the stated h-dual covectors. The rank-k-1 positive complement and the k=1 empty determinant are handled.
* The adapted basis is fixed at the point during differentiation. Right-equivariance gives E_A E_B F = F D_A D_B in the displayed order. The complexified unitary differential has D_ab^*=D_ba. The elementary smoothing argument is valid in finite dimension.
* The real interpolation polynomials yield self-adjoint evaluated idempotents without asserting any spectrum away from the evaluated image. Cyclicity of trace moves the right matrix factor with the correct linear-first Hilbert--Schmidt convention. Pairwise orthogonality, the exact sum of squares, and its minimum/maximum bounds follow.
* Interlacing makes the rho tuples strictly decreasing, hence their characteristic polynomials distinct. The cut margin gives the claimed signs for p(Y+delta), q(Y), and q(Y-1). Strict separation greater than two controls every recursive denominator. Empty tuples and the terminal rank-one case are valid. Both weakened-hypothesis counterexamples are correct.

## Exact source-definition comparison

Independently read `Formalism/HermitianCurvature/StatementQ.lean:80--220`, including chat2A/chat2L, uC, yv/ybv/xv/xbv and tL. At the terminal index mdim=k+1, and its (1,1) entry is exactly minus chat2L at uC-1. Read `Formalism/FormalDegreeBessel/StatementG.lean:1--30`, which defines h(v,w)=star(w) dot H v; `Formalism/FormalDegreeBessel/StatementIO.lean:84--103`, which defines the two real parts and EabH; and `Formalism/RealPlaceAnalysis/SmoothOnGVIff.lean:155--170`, which defines the right derivative g exp(tX). These definitions match the conventional operators, signs and order. The full providers of their imported identities were not re-audited in this review.

## Retained hypotheses

The displayed algebra-homomorphism normal-form identity remains an explicit hypothesis in this version. The source of the required compact branching and that normal form is being reconstructed separately. This fragment does not establish integrated adjoints, convergence after differentiation, boundary-term identities, or wave identities. Its scope paragraph states those limits accurately.
