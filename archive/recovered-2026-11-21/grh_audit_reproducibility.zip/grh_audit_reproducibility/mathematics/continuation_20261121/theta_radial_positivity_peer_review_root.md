# Review of the terminal radial operator and pointwise positivity

Reviewer: root. Date: 21 November 2026.

The complete mathematical fragment `theta_radial_positivity.tex` was read. No mathematical defect was found in the stated results.

The RTT relation has the correct sign for [E_ab,E_cd]=delta_bc E_ad-delta_da E_cb. Its adjacent-parameter specialization gives the stated antisymmetrizer identity and exactly the ordered minors, without an extra factorial. In reversing the ordered product between antisymmetrizers, the exchanged labels a<b give the nonzero scalar b-a+1, so its cancellation is valid. The resulting minor adjoint relation is compatible with off-diagonal minors as well as the full determinant. Full covariance implies centrality with the displayed transpose convention; the largest nonfixed column proves the highest-weight scalar formula. The alternative negative convention differs by precisely (-1)^N and u -> -u.

Complementary-minor covariance and the two-vector contraction have the correct index orientation. The adapted Hermitian basis yields Gram determinant -G and hence the terminal factor +G after the definition's minus sign. The basis is fixed during differentiation; no derivative of a chosen varying basis is suppressed. Right equivariance transfers ordered derivatives in the same order to the finite-dimensional representation. Its adjoint relation follows from compact unitarity.

The interpolation argument proves an orthogonal decomposition on the evaluated functions without assuming a spectral assertion on all of the coefficient space. Pairwise distinct polynomials suffice to choose one real separating parameter. The cut margins and strict parameter separation give every scalar sign and nonvanishing denominator used in the recurrence. Empty determinants and k=1 are included.

The existence of the algebraic normal-form homomorphism and its stated terminal entry remains an explicit hypothesis of the final density result. The fragment does not claim the integration, boundary terms, or differential-domain estimates needed for an integrated positive radial form. Those limitations are material and are correctly retained. This review is of the mathematics, not a new complete source or kernel audit.
