# Terminal radial positivity: exact source trace

## Proved mathematical scope

The new fragment theta_radial_positivity.tex proves the actual terminal differential-operator identity and the finite-dimensional positivity mechanism. It does not infer the integrated radial theorem from pointwise positivity.

The ordered column minors, shifts, operator composition, conjugation, and signs are fixed by RealPlaceAnalysis/StatementE.lean and FormalDegreeBessel/StatementIO.lean. The ordinary proof uses the antisymmetrizer on exterior tensor powers and the exact RTT identity. It supplies all-minor covariance, adjoints, centrality and the highest-weight scalar. The negative-operator convention needed by the integral branching section is explicitly converted.

The source StatementQ.lean defines the terminal (2,2) entry as minus the two-vector complementary contraction at uC-1. At the terminal group uC=Y+k/2. The vectors are y=g^(-1)z and x=z', the covectors are the Hermitian duals in the linear-first convention, and all coordinates multiply on the left of the differential operators. The source CapelliTwoByTwo.lean proves the adapted-frame contraction. The reconstruction proves that contraction directly using exterior covariance and complementary scalar minors. The two-vector Gram determinant is -G; hence the two minus signs cancel and the remaining compact determinant has shift Y+(k-2)/2.

Right equivariance is differentiated in the exact convention g exp(tX). The compact common-complement operators satisfy E_ab^*=E_ba. The finite representation is smooth by a direct compact convolution argument. These facts prove the actual terminal evaluation formula, with the basis fixed at the point.

DiagonalTransferAction.lean proves positivity using interpolation at the type values and the remaining eigenvalues of one self-adjoint matrix. The reconstruction instead constructs real Lagrange idempotents in the finite type algebra. Their evaluated functions are orthogonal. This gives an exact sum of squares and minimum/maximum bounds, and does not require an assertion about unused matrix eigenvalues.

The actual parameters are the finite products of intervals defined in StatementM.lean. Their strict ordering makes their monic polynomials distinct. The spectral margin proves the exact signs of the signed x-polynomials at shifts -1,0,1 and of q at shifts 0,-1. The source recursions for phiL, xs, cs and qw then preserve positivity because distinct parameter distances exceed two. This matches HermitianCurvatureProofs/TopDensNonnegOfKappa.lean, including its exact factor (|zeta|^2/G)^length and off-domain zero.

## Explicit remaining inputs at this checkpoint

The terminal-density corollary assumes the precise normal-form property kappa(p_rho(Y))=G^(-1)t22(Y). The source supplies it as the (2,2) entry of NFData.QQ after NormalFormActual. The larger raising/lowering construction has not been silently used as a proof. A subsequent fragment will construct the needed finite algebra directly from compact branching, avoiding the unused normal-form relations.

The integrated adjoint and density identity, preservation and integrability of the actual function classes, one-variable radial integral identities, decay and boundary terms, and wave identities remain separate analytic obligations. Reading the four CutSE top-level assembly files identifies those obligations; it does not constitute a review of all their imports.

The actual mass, dimension and formal-degree formulas from the earlier archimedean section are unaffected.

## Subsequent completion of the finite algebra

The separate fragment theta_radial_decomposition.tex now constructs precisely the required finite algebra action from the actual compact terminal operator and the elementary compact branching theorem. It proves smoothness, equivariance, the exact parameter shifts, vanishing of noncommon types, and the action on the evaluated function space. Thus normal-form existence is no longer a remaining input to this pointwise positivity result. This completion does not expand the historical source read scopes below and does not discharge the separate integrated analytic obligations.

## Counterexample search

No counterexample to the actual displayed hypotheses was found in this scope. Two exact examples expose essential hypotheses in weaker statements: a self-adjoint Capelli polynomial need not be positive at an arbitrary real parameter, and distinct spectral parameters need not avoid a pole in the frame recursion. The actual argument includes the sign margin and stronger separation, respectively.

## Verification

check_theta_radial_positivity.py uses exact rational and Gaussian-rational arithmetic in seven finite matrix representations. Its 3,660 checks cover the general-linear relations, generator and minor adjoints, centrality, highest-weight polynomials, the negative convention, all-minor covariance, the complementary contraction, the exact terminal sign and shift in rational Lorentz examples, evaluated interpolation projections with unused spectrum, and the actual interlacing signs.

These controls check conventions and edge cases. The general conclusions rest on the displayed proofs.

The combined standalone compilation wrapper includes the preceding global lattice, archimedean sizes, coefficient algebra and finite grids sections, followed by this fragment. The checkpoint has 37 pages. Root, QRH, and formal-verification agents have independently reviewed the mathematical fragment; their records specify their own source checks.

## Read coverage

theta_radial_positivity_source_manifest.json records the exact SHA256, length and conservative read scope of each of the 25 source files used in this targeted review. Partial reads are explicitly marked. No claim of complete archive coverage is made.
