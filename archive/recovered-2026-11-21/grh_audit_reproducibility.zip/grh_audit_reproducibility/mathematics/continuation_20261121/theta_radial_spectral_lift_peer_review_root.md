# Independent mathematical review by root

Snapshot SHA-256: 15217583cc4905aee96b462a3f4f17cb2d79c657d26251604e739fa56088cbd4

## Scope

The entire conventional fragment was displayed in three successive nontruncated portions and checked in the current context. The author confirmed the exact real Lie-direction convention in StatementB.lean.

## Result

PASS under the explicitly stated hypotheses. The adjugate vector identities hold even when intermediate minors vanish. Its polynomial covariance gives the correct compact Capelli contraction; the finite interpolation polynomial handles repeated spectral values. The homogeneous smooth coefficient on the nonzero vector space gives the stated mixed left/right derivative growth without differentiating orthonormal frames. Multiplication and its adjoint preserve the stated rapidly decreasing support class. The explicit U(2,2) example is an allowed point and refutes only a proposed inverse-intermediate-minor formula. Differential lifts, Jacquet intertwining and actual integrated decay remain separate inputs.

This is mathematical review and source-statement comparison, not a new Lean build or kernel replay. Typesetting checks are recorded separately.
