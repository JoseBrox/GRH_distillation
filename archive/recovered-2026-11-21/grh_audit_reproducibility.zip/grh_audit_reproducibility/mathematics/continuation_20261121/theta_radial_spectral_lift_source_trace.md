# Regular global spectral inverse: exact source trace

## Mathematical scope

The fragment theta_radial_spectral_lift.tex constructs the actual zero-order
coefficient needed in the four-operator argument on the full open set where
the final Gram polynomial is positive. It does not restrict to the radial
chart, whose intermediate minors need not be nonzero there.

The cofactor-vector norm and covariance are proved directly from the
adjugate identity and the Witt decomposition. The compact complementary-minor
operator uses the already proved exterior Capelli identity. The inverse is a
finite interpolation polynomial on the actual common compact types. The
coefficient is smooth and has only powers of the positive Gram polynomial in
its denominator. Its derivatives of length at most m grow at most as
(1+||g||)^((r+1)m) away from Gram zero. This improves the source's sufficient
exponent 3(r+1)m; constants depend on the fixed representation data,
spectral parameter, derivative order, and Gram cutoff.

The polynomial extension need not agree on compact types which never occur
in the actual evaluated radial space with an arbitrary alternative
interpolation polynomial chosen by the source. The theorem constructs a
valid lift satisfying the source's existential requirements and proves the
exact identity on every actual radial value. It does not assert an
unjustified identity on unused types.

## Exact source map

The companion JSON records hashes, line counts, and conservative read
scopes. The main defining and construction files are:

| Source | Role in the reconstruction |
|---|---|
| CutSERDSOpX.lean | Actual global inverse coefficient, derivative bound, covariance, Good0, and restriction to the radial chart |
| XFibreOfParts.lean | Normalized cofactor vector and compact Capelli operator representing G^-1 t22 |
| InvMulVecOfFixedVector.lean | Exact cofactor vector, norm, polynomial structure, covariance, and cell formula |
| CapelliVectorFrame.lean | Complementary-minor contraction with a unit vector |
| CutSERDSYReal.lean | Choice of real spectral parameter avoiding roots at three consecutive parameters |
| CutSERDSOpR.lean | Zero-order coefficient conditions and composition with remaining full-group differential operators |
| StatementTL.lean 195–325 | Exact normalized-vector and inverse-lift interfaces |
| StatementD.lean 75–115 | Cofactor and orthogonal projection conventions |
| StatementG.lean 1–115 | Hermitian form, unipotent groups, minors, and Gram polynomial |
| StatementB.lean 1–190, 215–280 | Fixed real-place data and derivative/coefficient conventions |
| StatementM.lean 150–192, 225 | Radial inverse data and sign |

This is a targeted read of the displayed source chain. It is not a claim
that every imported file or the complete source archive has been read.

## Independent proofs and exact controls

The general claims rest on the full displayed mathematical proofs.
The script check_theta_radial_spectral_lift.py separately checks 128 exact
identities over rational Gaussian numbers using SymPy. These include
unitary matrices in nine small (k,r) cases, the cofactor norm and covariance,
leading minors, compact Capelli covariance, the fundamental-representation
inverse, radial cell formulas, and a matrix with zero intermediate minor
but Gram polynomial one.

That final example shows why dividing by intermediate minors is invalid on
the full allowed locus. It is not a counterexample to the source, whose
actual coefficient avoids those denominators.

## Remaining obligations

This section proves the actual RDSOpX/zero-order part. It does not prove
the regular full-group differential lifts of the other radial operators,
their complete off-diagonal quantum relations, the Jacquet-pairing
adjoint formula, the generated-class local uniform square-integrability
bounds, or the four-operator weighted Fourier decay. These are separate
dependencies in the continuation.
