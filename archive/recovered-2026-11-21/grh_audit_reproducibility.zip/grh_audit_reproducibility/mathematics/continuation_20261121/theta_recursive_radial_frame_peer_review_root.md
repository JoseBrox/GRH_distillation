# Independent root review: the actual recursive radial frame

Final reviewed manuscript SHA256: `5172d5045817987a8f5f59a650b92ceb20d18661b97828700b7e074136a4859c`.
Outcome: PASS for the algebraic frame and its compactly supported positive-form identity. No counterexample or substantive gap found in this fragment.

The root read the complete frozen 901-line manuscript at SHA256 `d21d31dbae6a9b3a085a36b7ab2c300d2db43a6d09eae3593398956220f04627`, then independently read the final domain clarifications. The author’s source manifest records the exact source inspection; this review does not claim a complete read of all imported Lean helper files or a full kernel replay.

The review checked:

1. The actual leading two coefficients of the lower-left terminal entry give the first-order connection. The RTT coefficient calculation proves its coordinate commutators, and the formal Laurent coefficient proves commutation with the full spectral polynomial and its finite spectral projections.
2. The two shifted adjugate identities and Gauss decompositions preserve noncommutative multiplication order. The mixed identity needs inverses at u-1,u,v,v+1, not at u+1. The manuscript's cancellation proves this sharper domain claim.
3. The plus transformation's lower-left cancellation uses exactly the divided-difference commutator. The minus transformation uses the opposite Schur factorization. The lower-right identities on the entire regular set are proved without using inverses at a spectral root.
4. Conjugation by the coordinate diagonal matrices gives precisely TT'/bar(zeta), and the minus correction includes q(b-1), both specified inverse x factors, and the stated denominator. The signs of both divided differences agree with the connection commutators.
5. The weighted congruences retain an extra factor |zeta|^2/G at every step. In particular the claimed densities do not omit a Jacobian or confuse the ordinary adjoint with the weighted adjoint.
6. Product preservation of RTT and the determinant identities only uses the explicitly required fresh tensor factor. The Hermiticity argument expands the partial-transpose identity componentwise and does not assume a false general reversal rule for partial transpose.
7. Both signs remove the same shifted pair {y,y+1}; the later required y+2 value is covered by the spectral margin. The separation condition keeps all determinant and spectral factors away from their zeros and poles, with positive scalar weights.
8. The empty word, k=1 and r=0 cases are treated. Compact support inside G>0 makes all coefficient inverses smooth and makes integration by parts legitimate. The final quadratic form is then a sum of positive scalar multiples of orthogonal squared norms.

Two precision edits requested during review are now included. The determinant q is defined on the adjacent-point domain {Y:Y,Y+1 in Omega}, so the displayed q-plus formula is never evaluated at Y=a. The weighted upper Gauss coordinate m_Y is defined only when Y is real and Y-1 lies in I, and its identification with the actual coordinate additionally retains Y in I. These clarify the reconstruction's domains; they do not identify an error in the submitted source.

The exact noncommuting-matrix and Weyl-algebra controls are independent corroboration, not a proof of the general assertions. The root reran the supplied checker. Its recorded result is in `theta_recursive_radial_frame_checks.json`.

Remaining limitation: the actual generated noncompact Jacquet vectors require their own regularity, support, decay, operator-domain and commutation checks. The compactly supported congruence is not asserted to discharge those hypotheses. The next analytic fragment addresses that application separately.
