# Recursive radial frame: source trace

The conventional reconstruction is theta_recursive_radial_frame.tex.
Its source manifest records exact hashes and conservative read scopes.
The proof is independent of the source's large raising-operator normal
form. It proves the actual initial frame and both recursive changes.

## Initial data and actual operators

StatementQ defines the actual differential entries tL by full, single,
and double contracted quantum minors. Its ActualOps.QQ is a pair of
the forward operator and the proposed adjoint with conjugate parameter
and transposed indices. The manuscript verifies that this proposed
adjoint is the actual Haar formal adjoint: the off-diagonal equality
uses the covector shift, including its shift by one; the lower-right
entry uses the reviewed pointwise spectral decomposition.

The paired-operator device is therefore represented by genuine
differential operators and their formal adjoints on the radial space.
No assumption that a pair is an analytic adjoint is made merely
because the source assigns it a star operation.

The target LevelStartActual is existential in the connection and
correction. The manuscript constructs them from the leading two
coefficients of t21. Its connection has order at most one. The
leading terms and RTT relations alone force the coordinate
commutators. A formal Laurent coefficient proves commutation with
the spectral family and hence with each spectral projection.

The inverse domain is exactly the intersection of the nonzero sets
of all polynomials xC(P,rho,Y). The sign sgn has square one, so it
does not alter the determinant or the Gauss coordinate. In the
actual spectral cut, 1 <= l <= k and the usual integer exponent
(-1)^(k-l) is identical to the source's natural subtraction.
For the more general existential statement, either sign is allowed.

The source's structures store inverses and correction values even
outside their inverse domains, using Lean's totalized scalar
inversion. The ordinary proof never asserts an inverse at such a
point. One may define the scalar inverse to be zero on a zero
spectral summand, and set an initial correction to zero off the
domain; these choices satisfy the unused global commutation fields.
All asserted inverse and lower-entry equalities retain the exact
domain conditions. No division by a potentially zero operator occurs.

## Exact recursive identities

StatementFr.FrameData.plus and .minus, IsFrame, PlusHyp, MinusHyp,
IsLevelStart, and ofWord are matched entry by entry.

The change of variables is C_plus L_a F or C_minus M_b F.
The source writes the same products as diag(zeta^-1,bar(zeta)^-1)
times [[1,0],[G*l,G]], and its transposed counterpart. Multiplication
gives exactly the manuscript's factors, including the explicit inverse.

The lower-left correction in the minus step contains q(b-1),
x(b)^-1 x(b-1)^-1, and the denominator b-Y-1. The diagonal correction
contains the divided difference with its actual minus sign.
The plus correction contains TT'/bar(zeta), not TT'/zeta.

The form densities are w^N c, with w=|zeta|^2/G. The diagonal
congruence checks the additional factor w at every step. The
weighted Hermitian module equations, both quantum determinants,
and all required inverses and commutations are proved.

The lower-right identity is proved throughout the regular set,
including points where its spectral inverse does not exist.
The manuscript supplies an undivided RTT calculation for each sign.
This prevents an illicit use of a Gauss coordinate at a spectral root.

The Gauss mixed identity is slightly strengthened: it only needs
u-1,u,v,v+1 in the inverse set. The proof uses the opposite Schur
factorizations at u and v, so it never introduces an inverse at
u+1. The actual recursive minus step still assumes b+1 in the
inverse set, as the source does, because it is needed for the
divided-difference conjugation.

## Parameter domains and positivity

The original admitted predicate is matched by the sufficient
unshifted condition excluding integer differences from -2 to 2.
The exact recursive hypotheses are retained independently of that
sufficient condition.

The stronger application uses ypt=a for a plus step and ypt=b-1
for a minus step. Both signs remove the same pair {ypt,ypt+1}.
The manuscript proves AdmBase implies recursive admissibility,
and proves CPosBase directly from the positive scalar multipliers.
It also proves the CPosCutBase version in which either ypt or
ypt+1 is on the spectral cut. The sign proof in the reviewed
positivity fragment already has a margin of 5/2 per factor;
it therefore provides the extra nonzero evaluation at ypt+2.

The source processes a list from its tail toward its head.
The manuscript describes the resulting chronological sequence
of steps. This changes no multiplication order.

The empty word, r=0, and k=1 are explicit. The actual parameter
assumption k>=1 is retained; k=0 is not silently included.

## Checks and remaining scope

The exact controls use both one-site and two-site noncommuting
matrix models. They check every RTT component, both Schur
factorizations, the divided-difference commutators, and the plus
and minus last-row formulas. The additional mixed-identity
control places u+1 at a genuinely singular lower-right entry,
checking that its inverse is not needed.

A separate exact Weyl-algebra implementation uses two genuine
coordinate derivatives, variable rational coefficients, and
formal adjoints. It checks the original terminal matrix, both
recursive congruences, both inverse products and both transformed
last-row entries. Omitting the scalar TT'/bar(zeta) correction
fails the equality. These failures concern deliberately altered
formulas, not the actual submitted theorem.

Compact support makes the resulting positive-form identity
fully justified by ordinary integration by parts. No assertion
is made that the actual later noncompact vectors automatically
satisfy every regularity, support, decay and commutation hypothesis
of the Jacquet pairing theorems. That remaining application must
be checked separately. No complete Lean kernel replay or complete
read of every helper proof is claimed.
