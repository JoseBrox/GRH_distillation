# Independent review of the scalar germ and its assembly

Reviewer: `/root/qrh_mathematics`, 21 November 2026.
Read all 417 lines of `theta_scalar_germ.tex` and the complete
`theta_germ_assembly.tex`. No mathematical defect was found.

## Checked steps

- Reversing the rows of diag(t J_m,c) with the specified lower last row
  gives the displayed upper Hessenberg matrix. Its determinant is
  D=(-t)^m c, and its phase is (rho+sum x_i)/t.
- Scaling the d=m(m+1)/2 upper coordinates gives |t|^(-d). The affine
  map from the m lower coordinates to the remaining first-row entries
  has matrix C_t^t and modulus |product x_i|. It is a bijection on the
  entire first-row space once the trailing matrix is invertible.
- The first-order determinant term comes only from adjacent
  transpositions. Solving for rho gives x_0+t g_D+t^2 E with the signs
  and denominators in the manuscript.
- Compact support of either test-function integrand forces every x_i
  to be invertible with a uniform bound on its inverse. This is proved
  before the first-row change of variables; no branch or bad-coordinate
  region is silently omitted.
- The expansion is applied only after restricting the union of the
  supports of the original and limiting integrands. On this fixed compact
  set, the remainder is uniformly bounded. The t and rho perturbations
  fall in the actual test-function translation lattice, and t E falls in
  R, so removal of the remainder is exact rather than asymptotic.
- The amplitude support and translation lattice are uniform in D and
  in all permitted values of Phi. Reciprocal-coordinate differences
  control all denominators; no bound on the values of Phi is needed.
- At a critical point x_i=z, the substitution y=zv contributes |z|^d
  against |z|^(-m), giving exactly |z|^(m(m-1)/2) times the one-block
  orbital sum. The final stationary-phase exponents are -m^2/2 and
  m^2/2, and the |m+1|^(-1/2) factor is retained.
- The proof works for product fields, arbitrary compact open additive
  lattices and nonmaximal orders. Neighborhoods may depend on valuations
  of 2 and m+1. It makes no unsupported uniform claim over varying
  residue characteristics or block dimensions.

## Assembly and quantifiers

The initial-block construction gives Phi support in det(Z(h))^(-1)R
and one translation lattice for its compact determinant range, independent
of the finite target module. The scalar-germ neighborhood is chosen before
Phi, t and c. Thus one neighborhood actually works for every finite target
module. Summing their scalar identities against any comparison
configuration's finite orbital expansion proves the kernel germ uniformly
in that configuration, with no restriction on its size. Alternatively the
proved finite-target reduction supplies the same uniformity. Finite
intersections handle a finite family of h.

The assembly correctly includes nonintegral last-block matrices in the
initial-block reduction. The four requirements of the truncated orbital
identity are now supplied by proved statements. Global theta energy
estimates do not follow solely from this local assembly and remain separate.

## Exact source comparison and scope

I directly read `ThetaExistenceInductiveFromPieces.lean` lines 399--472
for OscReduction, GermPhi, HeadReduction and GermKernel. Their signs,
amplitude exponent, compact determinant range, and parameter order agree
with the conventional formulas. In `OrbitalIntegralReduction.lean` I read
the outline of named results and lines 2890--3018 and 3225--3271, covering
the final amplitude/critical-point provider and assembly. The independent
mathematical argument was checked in full; this review does not claim a
line-by-line certification of all 3271 lines of Lean indexing, finite-sum
bookkeeping or helper proofs. The original source hashes are recorded by
the scalar-germ author in its source manifest.
