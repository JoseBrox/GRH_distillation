# Scalar orbital germ: completed conventional proof and exact source trace

## Current mathematical status

`theta_scalar_germ.tex` proves the full scalar two-block orbital germ, including compact-parameter uniformity, from the exact three matrix test-function hypotheses used in the source. `theta_head_reduction.tex` supplies those hypotheses for the actual marked-cokernel coefficient with fixed initial blocks. `theta_germ_assembly.tex` combines them and proves the **actual kernel germ for every comparison configuration, of arbitrary size**, with its neighborhood chosen before that comparison. Thus the germ hypothesis retained at the previous local checkpoint has now been discharged.

Together with the previously proved strong inverse-parameter support, uniform local constancy, root-fiber change of variables and mixed cancellation, this also proves the actual truncated orbital identity. The separate `theta_parseval.tex` proves the finite character identity and averaged diagonal bound needed to complete the local positive-majorant induction. The quantitative global theta energy estimates, automorphic input bounds, and arithmetic-complex construction remain separate tasks.

No counterexample satisfying all the actual hypotheses of the scalar or initial-block reductions was found. The two explicit examples in the initial-block section refute shortcuts that the source does not take: dropping nonintegral last-block matrices, and preserving only the underlying cokernel while changing its marked functional.

## Exact target and normalizations

The relevant source is `Formalism/HermitianCurvature/ThetaExistenceInductiveFromPieces.lean`:

* `PhiHyp` requires invariance under integral lower and upper unipotent multiplication, entrywise support in a fixed compact open lattice, and a common additive translation lattice when the determinant belongs to `Q` or `-Q`.
* `OscReduction` asks for an amplitude with a common compact support away from zero and a common translation lattice, independent of the test-function values. It fixes `ct^m=D` in compact `Q`, and the oscillatory phase parameter is `D'=(-1)^m D`.
* `GermPhi` has one small neighborhood before the test function and the parameters `t,c`. The conventional proof retains this order.
* `GermKernel` fixes the initial configuration and compact parameter set, chooses a neighborhood, and then permits every `t,c` in that range and every comparison configuration. The assembled theorem retains exactly this unrestricted comparison quantifier.

For `s=m+1`, `d=m(m+1)/2`, the final scalar identity is

`O_Phi(t,c)=|t|^(-m^2/2)|s|^(-1/2) sum_(z^s=(-t)^m c) gamma_m(zt)|z|^(m^2/2) psi(sz/t) O_Phi(zJ_s)`.

Haar measure is normalized by `vol(R)=1`, and the upper-unipotent coordinate measure consequently gives `vol(U_s(R))=1`. The proof uses these normalizations throughout, including for a nonmaximal self-dual order. Residue characteristics dividing `2(m+1)` are retained; the allowed neighborhoods shrink with the fixed local data when necessary.

## The complete replacement for the large coordinate provider

The source provider `HermitianCurvatureProofs/OrbitalIntegralReduction.lean` has 3,271 lines. The conventional proof replaces its finite-lattice summation framework by Haar integration, while preserving every algebraic coordinate and normalization. The decisive steps are now proved explicitly:

1. **Orbital sum as an integral.** Entrywise support is compact. Block Gaussian elimination bounds the unipotent factors, giving finite support in the quotient by integral groups. The summand is constant on each such coset, which has volume one. Thus its sum equals its absolutely convergent Haar integral.
2. **Reversed-row matrix.** For the two blocks `diag(tJ_m,c)`, reverse the last-row lower-unipotent coordinates to `eta_0,...,eta_(m-1)`. After row reversal, the first row is `t sum_i eta_i U_(i,*)+c e_m^t`, and the remaining rows are `t U_(i,*)`. Subtraction and a cofactor expansion give the exact determinant `(-t)^m c`.
3. **First scaling.** Replacing every upper entry `u_ij` by `n_ij=t u_ij` contributes `|t|^(-d)`. The adjacent scaled entries become the last `m` diagonal entries `x_1,...,x_m`; the others give all upper entries below the first row.
4. **Degenerate coordinates excluded by the actual support.** If the test function is nonzero, the whole Hessenberg matrix has bounded entries and determinant in a fixed compact subset of `K^×`. Its determinant is `rho*prod(x_i)+tB`, with `B` bounded. For sufficiently small `t`, the product is invertible and every `x_i` has a uniformly bounded inverse. The support is therefore contained in a fixed compact open subset of `(K^×)^m`. This is proved before any inverse coordinates or Jacobians are used.
5. **Global affine change of variables.** Keeping the last `m` rows fixed, replace the lower variables by the first-row entries `tau_j`. Its coefficient matrix is the transpose of the trailing Hessenberg submatrix. On the support its determinant has modulus `|prod(x_i)|`, so the change is a bijection of all `K^m`, not only a local branch, and contributes `|prod(x_i)|^(-1)`.
6. **First-order determinant expansion.** The coefficient of `t` in the Hessenberg determinant is the sum of adjacent-transposition terms. Solving for the first diagonal entry gives

   `rho=D'/prod(x_i)+t*(y_01/x_1+(D'/prod x_i) sum_(i>=1) y_(i,i+1)/(x_i x_(i+1)))+t^2 E`.

   The remainder is uniformly bounded on the compact parameter support. This follows from a polynomial determinant and inversion of a denominator uniformly near one. No differentiability of the test function is assumed.
7. **Exactness.** The matrix change is inside its prescribed translation lattice for small `t`, and the discarded phase is `tE`, which belongs to `R`. The two test-function and character factors are therefore exactly unchanged. This produces the source amplitude `GG` and the phase `sum x_i+D'/prod x_i` with the correct sign.
8. **Uniform amplitude.** On the compact support, all rational denominators are bounded, and their changes under a small translation are uniformly small. The absolute-value factor, test-function factor, and character factor have a common translation lattice. Outside that stable compact support both values vanish. The construction is uniform in the test-function values, which need no magnitude bound.
9. **Critical amplitude.** At `x_i=z`, with `z^s=D'`, substitute `y_ij=z v_ij`. The resulting factor is `|z|^(d-m)=|z|^(m(m-1)/2)`, and the remaining integral is exactly the single-block orbital sum. Applying the already proved stationary-phase theorem gives the final germ exponents `-m^2/2` and `m^2/2`.

## Initial-block reduction and actual kernel assembly

The initial-block section has its own detailed source/read-coverage record. Its construction was independently checked in full in this lane. For an integral matrix `A` from the initial blocks, it sums over finite rectangular classes `X,Y` with `XA` and `AY` integral and tests the block matrix

`[[A,AY],[XA,XAY+G]]`.

It establishes the exact phase and quotient parametrization, entrywise support `G∈det(H)^(-1)M_s(R)`, and uniform local constancy by the marked perturbation identity. The latter uses an additive perturbation in `p*det(B)^2 M(R)` so that both the image lattice and **all** inverse-coordinate functionals modulo `R` are preserved. Its bounds do not depend on the fixed finite target.

The sum identity retains all last-block orbital cosets. An initially nonintegral last block can be made integral by the rectangular correction, so restricting this sum would be false. Finiteness follows from the bijection with the full integral orbital cosets.

The germ assembly first applies the scalar theorem to this test function. For arbitrary comparison configuration `w'`, its finite orbital expansion supplies finitely many target marked modules, which may have presentations of any size. Multiplying the scalar identities by the conjugate comparison phases and summing proves the actual kernel formula. The finite-type lemma `gu-uniform-germ` gives an alternative proof that target uniformity is a finite issue; the actual initial-block construction proves common target-independent bounds directly.

## Exact source read scope

The new manifest keeps read coverage distinct from the scope of the mathematical replacement:

* `ThetaExistenceInductiveFromPieces.lean`: exact definitions at 67–145 and target/assembly statements at 360–475 were directly reread.
* `OrbitalIntegralReduction.lean`: the initial coordinates; full two-block orbital formula; support estimates; the complete `pw_units`, `pw_main`, and `pw_det` proofs; affine matrix shape; complete pointwise formula; amplitude and critical-value identification; and complete final `fa_main`/`OscReduction` assembly were read. The precise intervals are in `theta_scalar_source_manifest.json`.
* The long early finite-lattice summation toolkit and several auxiliary polynomial proof bodies were **not** read in full. The conventional proof supplies the corresponding Haar and determinant arguments independently. No complete line-by-line audit of the entire 3,271-line provider is claimed.
* The earlier marked-kernel and block-group definition files retain their previous read scopes; they were not silently counted as newly fully reread.
* QRH mathematics handled the `TwoBlockPoint.lean` providers, with its own source manifest. This lane independently reviewed every line of its conventional reconstruction. The parent and QRH agents independently reviewed the whole scalar reconstruction and found no defect.

The reconstructed results are stated for the actual local models: finite products of finite extensions of `Q_p`, including the nonmaximal self-dual orders already identified in the global source. We do not claim here an independent proof for every abstract commutative topological ring that might satisfy a source-level interface.

## Exact controls

`check_theta_scalar_germ.py` performs four symbolic matrix controls, for `m=1,2,3,4`. It independently constructs the Hessenberg determinant, checks its linear coefficient, checks that the claimed approximation for `rho` leaves a numerator divisible by `t^2`, computes the affine coordinate Jacobian, and verifies the row operation yielding determinant `(-t)^m c`.

Five additional rational controls use `(p,m)=(2,1),(2,3),(3,2),(3,3),(5,4)` and `t=p^12`, with nonintegral bounded upper coordinates and varying diagonal valuations. They verify the exact determinant equation, unchanged modulus of the trailing determinant, integrality of the discarded phase, and smallness of the first diagonal change. These include residue characteristics dividing `2(m+1)`.

All nine controls passed using integer/rational arithmetic and symbolic polynomial identities. Results are in `theta_scalar_germ_checks.json`. The general proofs do not depend on these finite computations.

## Remaining limits

This completion is local. It supplies no explicit neighborhood uniform across changing fields, conductors or block sizes; the exact source germ needed here likewise fixes those data before choosing the neighborhood. Quantitative global estimates involving growing parameters must be proved separately. No new important flaw in the actual local germ was found.
