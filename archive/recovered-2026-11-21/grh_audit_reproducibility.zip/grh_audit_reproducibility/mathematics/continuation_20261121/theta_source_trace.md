# Theta estimates: mathematical reconstruction and exact source coverage

## Subsequent completion of the local identities

The coverage recorded below describes the earlier scoped pass and is retained unchanged as a read record. The later conventional reconstruction in `theta_orbital_identity.tex`, `theta_germ_uniformity.tex`, `theta_head_reduction.tex`, `theta_scalar_germ.tex`, and `theta_germ_assembly.tex` now proves the actual orbital germ, support, uniform local constancy, mixed cancellation and truncated orbital identity. `theta_parseval.tex` supplies the separate finite character identity, averaged diagonal bound and actual local positive-majorant induction. Their later source traces and manifests record the added coverage. Thus statements below describing these local providers as still unproved are historical status descriptions, not the current remaining obligations. The global theta energy and quantitative automorphic inputs remain unproved in the reconstruction.

This is a scoped continuation of the GRH audit. The conventional mathematical
text is `theta_estimates.tex`. It proves the stated local and abstract results
in full, but does **not** claim to have reconstructed the complete global theta
energy argument. No counterexample satisfying all the hypotheses of the results
proved in this section was found. The omitted hypotheses in the exact controls
below are present in the actual source, so those controls are not flaws in the
claimed GRH proof.

All paths in this record are relative to `sources/lean/src/`. The accompanying
`theta_source_manifest.json` records SHA-256 hashes, exact file lengths,
conservative ranges read, and files examined only through declaration searches.
The manifest has 38 files. A range of text read is not a claim that every
imported provider was mathematically audited or that the file was recompiled.

## 1. Exact target: actual Poincare maps and normalized Gram matrices

`Formalism/SharpRestriction/GlobalTheoremInputs.lean` defines `LinkS_at`.
Subject to the explicit two-sided proviso

`C0^-1 <= dim(Cu)*Gamma^2/Dstar <= C0`,

it asks for:

1. the off-diagonal Hilbert–Schmidt estimate for `L.hsSq`;
2. the diagonal defect for `KD - id`;
3. the upper bound for the actual ambient dimension `Dall` by
   `(1+eta1)Dstar`.

`LinkS` requires eta0, eta1, and sqrt(e0) to be at most
`exp(-x^(epsilon/8))` eventually. These conditions concern fixed maps with
their prescribed metric normalization, not arbitrary matrices that happen
to satisfy a similar inequality.

`Formalism/SizeWindowBrackets/FrameTraceRatioFinEquiv.lean`, `InputSG`,
contains exactly the corresponding pairwise, diagonal, and ambient-dimension
bounds for the normalized Gram matrices. In
`Formalism/SharpRestriction/GlobalSchurBounds/TopDensityNGeSixteen.lean`:

- `FrameReal_at` includes full source matrices, isometric inclusions of the
  ramified subspaces, the actual arithmetic pairing in the selected bases,
  positive normalizing factors, the deleted dimension, and `InputSG`.
- `PMat`, `gram_PMat`, and `kp_eq` identify the analytic matrices with the
  orthonormal matrices of the Poincare maps. A global conjugation appearing
  in one convention does not change the Hilbert–Schmidt norm.
- The ramification part obtains the deleted fraction from its actual local
  representation bounds; this is a separate quantitative assertion.

`Formalism/SharpRestriction/CuspSpanNormBounds/RelevantZeroGramTerms.lean`
defines `Kmat` and `KD` as `(c0(u)c0(v))^(-1/2) Pu.adjoint Pv`.
`c0` is `volN*volH/dimPi`, with finite-level volume already incorporated
into `volN`.

`Formalism/LocalToGlobal/SiegelLatticeTheory/HaarTransversals/PoincareInHH.lean`
was read in full. It defines the actual seeds, Poincare series, quotient
Hilbert spaces, and the membership/projector assertions needed for the
analytic map. Its normalization `c0X` includes the explicit finite-level
subgroup volume. `FlagStabilizerTensors/PoincareConstantEq.lean`, also read
in full, verifies that placement of the volume factor and specifies the
convergence, folding, and kernel-expansion assertions. Those assertions
are not replaced by merely writing the formal series.

**Conventional proof supplied:** absolute-convergence unfolding of the two
Poincare series into the actual double-coset Gram expansion, with the exact
intersection subgroup and quotient measures displayed. The assumptions
needed for Tonelli and the two unfoldings are explicit.

## 2. Reproducing kernels: what the shorter proof does and does not replace

`CompanionTheory/AutomorphicTheory/LocalBesselUniqueness/BesselModels/LocScalar.lean`
was read in full. It proves the final scalar-one assertion from formal-degree
orthogonality, coefficient integrability, and an induced quotient-Hilbert-space
calculation. The source's weighted coefficient bound is imported.

**Conventional proof supplied:** for

`p(g) = d_pi conjugate(<w,pi(g)w>)`,

Schur orthogonality gives `p*p=p`. Unitarity gives `p*=p`. If `p` is in
L1, its integrated operator in any strongly continuous unitary representation
is therefore an orthogonal projection. A nonzero scalar by which it fixes a
nonzero vector must be one. The proof treats the induced representation on
`L2(S\G,V_rho)` with its actual quotient measure. It does not infer L1 from
L2, and it does not infer nonvanishing of the Bessel vector.

`FlagStabilizerTensors/RootLatticeThresholds/WuDecayAll.lean` supplies the
weighted decay and final local scalar assembly. Only the initial definitions
and final assembly ranges, together with the relevant declaration locations,
were inspected here. The weighted decay and Bessel nonvanishing proofs remain
part of the uncompleted automorphic review.

## 3. The actual local algebras include a nonmaximal split order

`Formalism/SharpRestriction/CuspSpanNormBounds/FractionFieldToGenericStalkAlgebraMapEq.lean`
defines the actual local field/algebra model. The ordinary places use an
unramified quadratic étale algebra over a local field and its maximal order.
At the distinguished split places the order is instead

`R = {(x,y) in O_F^2 : x-y in varpi O_F}`,

with character `psi_F((x-y)/varpi)`. The source chooses additive Haar measure
with volume(R)=1. The file permits a product of fields; it does not require
the order to be a DVR. `LocalModelPeriodLattices.lean` provides the explicit
identification with the abstract `LocalDatum` and its self-duality hypotheses.

**Conventional proofs supplied:** direct computation of the annihilator of
this split order, and verification that its self-dual measure is q times
the product measure that gives O_F^2 volume one. This factor matters.
The general Gaussian proof works with arbitrary compact open additive
lattices and uses neither a maximal-order assumption nor a principal-ideal
assumption.

`Formalism/HermitianCurvature/BlockKernelPropertiesOfSteps.lean` defines
`LocalDatum`: compact open self-dual R in a reduced Artinian locally compact
ring, unit representatives for additive cosets, and the specified unitary
character. Its characteristic-zero application is to the actual finite
products of local fields above. The explicit field interpretation is used
in the ordinary proofs; no claim of a broader abstract-ring classification
is needed.

## 4. Gaussian, Morse, and stationary-phase steps

`Formalism/HermitianCurvature/ThetaExistenceInductiveFromPieces.lean`
defines the exact Hessian, Gaussian admissibility, phase, amplitude
conditions, and stationary-phase conclusion. The statement-level dependencies
were read through the finite averaging and limiting stage. Three large
provider files were located only by declaration searches:

- `HermitianCurvatureProofs/GaussSumModulusOfLattice.lean`;
- `HermitianCurvatureProofs/HenselRootsBounded.lean`;
- `HermitianCurvatureProofs/PadicChangeOfVariables.lean`.

The new proofs are independent conventional proofs of the displayed local
lemmas, rather than an assertion that those provider files have all been
checked line by line.

**Gaussian:** for symmetric invertible B, the condition that
`psi(1/2 xi^t B^-1 xi)=1` on the annihilator lattice implies
`|integral_L psi(1/2 x^t Bx)|=|det B|^-1/2`. Polarization first gives the
required inclusion of the annihilator image in L. Translation kills every
other lattice coset, proving independence of the admissible lattice.
For `H_m(a)=a^-1(I+J)`, the determinant is `(m+1)a^-m`, and the phase has
the expected invariance under multiplication of a by a square.

**Morse lemma:** on a sufficiently small ball,
`f(y)-f(0)=1/2 y^t(H+C(y))y`, with C(0)=0. The analytic matrix square root
of `I+H^-1 C(y)` gives an exact change of variables. After shrinking the
ball it is the identity plus a strictly contracting function, hence an
isometry of every sufficiently small coset partition and measure preserving.
The family version requires a common analytic radius, uniformly bounded
Gauss norms on that radius, and bounded inverse Hessians. Mere
coefficient-by-coefficient boundedness would be insufficient; the manuscript
does not use that weaker assumption.

**Stationary phase:** the critical points of

`f_D(x)=sum x_i + D/(product x_i)`

are `(z,...,z)` with `z^(m+1)=D`; the Hessian is `z^-1(I+J)`.
The proof includes the nonstationary complement and compact-parameter
uniformity. It works at residue characteristic 2 and at primes dividing
m+1, since the local fields have characteristic zero. It does not erase
the resulting dependence of the required small neighborhood on the
valuations of 2 and m+1, the conductor, or the dimension. For products of
fields, smallness is componentwise and the formula is a product of the
field formulas.

This matches the source's order of quantifiers: the neighborhood is selected
after fixing the local data, amplitude scale, and compact parameter set.
No conclusion with a radius uniform in every growing global parameter was
substituted for that statement.

## 5. Marked cokernels and finite Fourier averaging

`Formalism/DoubleCosetMeasures/Statement.lean` and
`Formalism/HermitianCurvature/BlockKernelPropertiesOfSteps.lean` define
the block reversal matrices, their unipotent orbits, and the marked finite
modules. The mark is the last coordinate class, and the functional is the
last row of the inverse matrix, taken modulo R.

**Conventional proofs supplied:**

- The cokernel has order `|det Z|^-1` by a Haar-volume calculation, valid
  for the nonmaximal order too.
- The weighted count of isomorphisms is a Gram kernel, by grouping marked
  modules into isomorphism classes and dividing by automorphism counts.
- Nonzero kernel entries force equality of determinant absolute values.

The actual integral orbit-coset finiteness and invariance must still be
proved before applying that finite Gram argument to the full source kernel.
The stronger support `t^-1 - t'^-1 in R` is a separate source assertion;
it is not obtained from equality of determinants.

The definitions `uGram`, `thx`, `GermIdentity`, `CutNormEval`, `ThxLower`,
`ThxSum`, `ThetaPropsOn`, and `ThetaExistenceInductive` in
`ThetaExistenceInductiveFromPieces.lean` make the last analytic part of the
local induction especially transparent.

**Additional conventional proofs supplied:**

1. If 0<=G_cut<=G are finite Gram matrices, both can be realized using
   the same vectors and a contraction.
2. A finite Fourier transform on R/L1, with orthogonality between the
   distinct L2/R classes, gives precisely the positive majorant and
   total-mass inequality. The factors 1/a, 1/b, and a are retained; no
   dimension-dependent constant is introduced.
3. Once majorants exist on increasing compact annuli, a common compact
   support lattice Lc makes Lc/R finite. A single subsequence of a fixed
   finite number of matrix entries gives a limiting majorant on every
   unit. There is no uncountable diagonal-selection argument and no need
   for a uniform stationary-phase radius. The upper bound when Lc=R
   follows from the one-coset mass inequality.

The actual cut orbital Gram identity, the stronger inverse-parameter
support, and the unrestricted diagonal bound are explicitly retained as
inputs when mapping those abstract lemmas to the source. In particular,
the cancellation between distinct stationary points has not been replaced
by positivity alone.

## 6. Global row estimates, constants, and dimension parameters

`Formalism/HermitianCurvature/StatementPB.lean` defines the exact expansion,
coarse row orthogonality, and four pair sums. `HermitianCurvatureProofs/GrowthOfBasic.lean`
provides the numerical and global assembly steps. Only the numerical section
and a portion of `MainRow` were read, so this record does not count the full
global energy recursion as audited.

`FlagStabilizerTensors/TheoremS.lean` was read in full. Its final theorem
explicitly uses local and global cores, lattice link, the local majorant
induction, and the four pair-sum estimates. It also exposes the order in
which constants are chosen. `FlagStabilizerTensors/RowsPos.lean`,
`PoincareConstantEq.lean`, and `LinkSPos.lean` were read in full; selected
parts of `ThmSOwn.lean` trace the actual operator and diagonal assembly.

`CokernelGLCounts/RowsConc.lean` fixes the actual scales:

- d_u is the actual compact-automorphic-space dimension;
- `Dstar = fdegAll * quotient_volume * Re(e(1))`;
- the large-corank and nonscalar error is `exp(-kf log k/3)`;
- the nongeneric error is `2^(-(k-2r-5))*exp(Cn(2r+2)^5 f log b)`;
- `Gamma=exp(CGamma(2r+2)^5 f log b)`.

`GlobAut.lean` gives the Dstar definition, and `PlaceDegreeData.lean`
defines fdegAll as the product of archimedean formal degrees. The manuscript
does not confuse this proposed main term with the actual ambient dimension.

`Formalism/LocalRingCardinality/Params.lean` is important for notation:
the manuscript's r is the source's rS, the isotropic-flag length; the
source's different symbol r denotes the total rank k+2rS+1. The ambient
signature is `(k+rS,rS+1)`, f is the totally real field degree, and the
number of lifts is 2rS+2. All global constants and their input domains
are now defined before the numerical estimates in the manuscript.

`StandingNumericalData.lean` defines the actual prefactor
`P=prod_v(1+3/q_v)` and its equality to
`((1+3/g1)(1+3/g2))^f`. Its bound by `exp(6b^-7)` is proved directly.
The separate elementary product of `(1-q^-j)^-1` in the manuscript is
not used to identify that prefactor.

**Conventional proofs supplied:** the four row estimates imply the exact
factor `P*(sqrt(A+2eps)+sqrt(eps+eps'))^2`. Under the displayed numerical
conditions this is at most `1+14b^-7`, improving the source's coarser
`1+b^-6`. The sum of local density errors is bounded with explicit
dependence on f and the exponent. The separate diagonal bounds imply

`||K_uu-I||_HS^2 <= d_u*(exp(-kf log k/2)+sqrt(C0/Gamma))^2`.

These are conditional consequences of the four actual orbital bounds.
They do not supply those global arithmetic bounds, the degenerate diagonal
estimate, or the ambient spectral-dimension estimate.

## 7. Exact controls and what they establish

`check_theta_local.py` uses exact integer counting and reduction modulo a
cyclotomic polynomial, not a floating-point approximation. Its output is
`theta_local_checks.json`.

- Six quadratic Gauss sums test the determinant factor, including p=2 and
  p dividing m+1.
- Four complete one-dimensional stationary-phase identities compare the
  finite sum of `exp(2 pi i (x+x^-1)/p^e)` over units with the sum of its
  two critical contributions. Cases include p=2.
- Omitting Gaussian admissibility gives a genuine elementary counterexample:
  for p=2, m=3, e=1, the quadratic sum has square absolute value 16,
  while the inapplicable determinant expression would predict 32.
- The split-order examples at p=3 and p=5 detect exactly the lost measure
  factor that would result from incorrectly using product Haar measure.

These computations verify selected exact controls. The general results
rest on their displayed proofs. The source retains both the admissibility
condition and the correct split-order measure, so neither control is
reported as an unfixable flaw.

## 8. Remaining proof obligations and source-reading priorities

The outstanding central assertions are specific:

1. weighted matrix-coefficient integrability and the needed Bessel
   nonvanishing for the actual varying representations;
2. finite orbital-coset support and invariance; the full cut orbital Gram
   identity; cancellation between distinct stationary points; the stronger
   inverse-parameter support; and the unrestricted diagonal bound used
   in the local induction;
3. the global Poisson/energy recursion, with the precise lattice indices
   and dual-lattice sums, yielding the scalar generic bound with
   delta<=b^-7;
4. the uniform large-corank, nonscalar, nongeneric, degenerate-diagonal,
   and ambient-dimension estimates for the actual family.

The limiting step and finite Fourier averaging need no further black box
once the preceding identities and bounds are available. The full
`GermExpansionMatrixFunction.lean` and `PadicChangeOfVariables.lean`
providers and the uninspected main body of `GrowthOfBasic.lean` are natural
next sources. The global and local core lists are recorded in
`HermitianCurvatureProofs/SecondDerivativeHolds.lean`.

Several source proofs use tactic alternatives containing names that may
not elaborate in the current branch. The formal-verification agent correctly
pointed out that only the successful elaborated term is exported. No
malformed statement, circular proof, or kernel exploit is inferred merely
from those unused alternatives or from the names of definitions. The
separate exported-proof/kernel audit belongs to that agent's record.

The QRH agent independently reviewed the Gaussian/Morse/stationary-phase
normalizations, finite cokernel Gram formula, convolution, unfolding,
four-row estimate, numerical constants, and the new finite Fourier and
compactness lemmas. The requested precision edits were incorporated.
