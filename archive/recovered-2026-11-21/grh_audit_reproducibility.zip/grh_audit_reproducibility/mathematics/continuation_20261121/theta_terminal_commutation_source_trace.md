# Full terminal commutation and shifted adjugate identities

## Reconstruction

The fragment theta_terminal_commutation.tex proves the complete terminal
RTT commutation relation for every smooth terminal function. It gives an
explicit smooth N times C* times U(W) times N factorization of the larger
group's open Bruhat cell, so the arbitrary-function extension used in the
descent is established rather than assumed. A first/last column and row
expansion gives the full bordered Capelli determinant, retaining the two
extra noncommutative correction terms. The character laws annihilate those
terms. The remaining four terms give the exact scalar-conjugated product
L(Y)t(Y)T(Y), with the source's shifts and order.

The full Capelli determinants commute. The two elementary Weyl matrices
satisfy RTT by their two nonzero commutators. Their tensor product identity
expresses the middle matrix's defect through the (1,1) commutator of the
full radial product. Applying it to |c|^(2 beta)c^n f(m) proves coefficient
independence using nine Laurent monomials and two independent pairs of
linear polynomials. Polynomial continuation includes the exceptional
parameter difference one. All16 terminal commutation relations follow.

The final corollary proves both shifted adjugate matrix identities directly
from those relations. On the actual compact types the determinant is the
scalar previously proved in theta_terminal_quantum_determinant.tex. The
two-sided inverse is asserted only away from its scalar roots.

## Source identification and scope

StatementQ.lean records BorderFull, the exact full-chain radial transfer,
RTTAt, RTTSandwich, RTTIndependence and QdetFromRTT. Their specified spectral
shifts, scalar radial conjugation, and parameter exception agree with the
ordinary proof. The source proves the terminal relation through a larger
level descent; this reconstruction only needs the explicit one-pair cell.
The beginning of RttUpperRelationsFromDescent.lean was read through line190,
including the full qdet_main proof and its four-entry adjugate equations.
The remaining parts of that859-line file are not claimed read. Relevant
read ranges and exact hashes are listed in the manifest.

## Exact controls

check_theta_terminal_commutation.py uses actual rational polynomial
differential operators E_ab=-y_b partial_y_a+eta_a partial_eta_b. Eighteen
tests check the complete bordered expansion, including the correction
terms, in total dimensions3,4,5. Another288 test every terminal RTT entry
in dimensions2 and3 with nonconstant inputs and variable coefficients,
including equal parameters and parameter difference one. No RTT identity
is used to compute either side. These are finite controls of the general
proof, not a substitute for it.

## Remaining work

The recursive frame identities and actual Jacquet-pairing estimates remain
separate. This fragment does not claim integration by parts for that pairing,
uniform bounds for the generated coefficient class, or a full kernel replay.
