# Independent review of the terminal quantum determinant

Reviewed artifact: theta_terminal_quantum_determinant.tex

SHA256: 89499dd44475b4c3015b706d03d90f52cf62cc84d4fa06daf7b0f297dd321aa2

The root reviewer read the complete mathematical fragment. The signed cofactor expansions, shifted quantum Jacobi identity, cancellation by a central polynomial variable, all four coefficient-commutation identities, and the contracted determinant calculation were checked term by term. The polynomial cancellation does not require the coefficient algebra to be a domain. The exterior-algebra shift proof retains the noncommuting order.

The application was checked with the actual complexified right derivatives and the two variable coefficient vectors. The passage to left derivatives reverses every word; this reversal agrees with the actual source convention and restores the correct highest-weight Capelli scalar. The displayed counterexample to deleting the spectral shift is valid and does not refute the shifted source identity. No mathematical correction was required.

The root independently read StatementQr.lean lines 1--155 and StatementQ.lean lines 580--690 and 791--840. These include the exact vector/covector commutators, signed Jacobi and contracted identities, reversed left product, type parameter and final DetHat/DetGeneric targets. Other source reading is recorded separately in the author's manifest, not silently attributed to this review.

Status: passed for the stated arbitrary algebra and smooth-function conclusions. The terminal commutation relations, the complete recursive frame identity, and the actual Jacquet pairing and decay remain separate. This is not a new kernel replay.
