# Terminal quantum determinant: exact differential identity

## Completed reconstruction

theta_terminal_quantum_determinant.tex proves the universal signed
quantum Jacobi identity by two complementary-minor expansions. A central
indeterminate makes cancellation valid over an arbitrary complex algebra,
so no nonexistent inverse or integral-domain hypothesis is used.

The draft then proves all variable-coefficient commutations needed for the
contracted determinant identity. The parameter-shift identities follow
from a short exterior-algebra calculation with the actual covector
commutator. The full contracted identity is proved by an explicit finite
sum calculation. Its application to y=m^{-1}z and eta=z*Hm yields the exact
terminal formula t11(Y+1)t22(Y)-t21(Y+1)t12(Y), with the minus sign and
all derivatives of variable coefficients retained.

The remaining conversion to left and right compact Capelli determinants
is also proved. At a fixed group point the transported perpendicular
frame is frozen; right differential words convert into reversed left
words. The draft proves this order reversal by differentiating the same
product of exponentials. The resulting identity is exactly the source's
DetHat statement for arbitrary smooth functions. On finite-dimensional
compact types it gives the source scalar
-TT' product_j(Y+1/2+u_j)(Y+1/2+u'_j).

## Source correspondence

StatementQr gives the actual general-linear relations with variable vector
and covector coefficients, QJacobi, DetVec, MinorCov, and AlgDet. The source
proofs QuantumMinorExpansion and QuantumMinorCommutation were read in
full. AlgebraicQuantumDeterminant was read through its initial 180 lines,
including the full finite-sum core proof; its remaining assembly was not
claimed read. FrameEntries lines 195--275 identify the actual terminal
composition and its conversion to frames; further source lines outside
this range were not claimed reviewed. The ordinary proof above supplies
the complete conversion directly. Precise conservative intervals and
hashes are recorded in the accompanying manifest.

## Exact controls and limits

check_theta_terminal_quantum_determinant.py performs 901 exact rational
checks in the actual polynomial differential representation
E_ab=-y_b partial/partial y_a+eta_a partial/partial eta_b. Thus the
coefficient commutators arise by differentiation. It tests the universal
Jacobi and contracted identities for dimensions two and three and several
nonconstant inputs, and checks the covector parameter shift. A negative
control deleting the spectral shift gives residual 1 already in dimension
two on the constant polynomial at u=1. The manuscript also gives this
counterexample in the trivial representation. This refutes only the
altered unshifted statement, not the submitted identity.

The remaining terminal commutation relations, recursive frame identity,
Jacquet-pairing adjoint formula, and uniform integrability estimates are
not claimed from this determinant calculation. No new Lean compilation
or kernel replay is asserted.
