# Independent review: formal degree in the compact-dual normalization

Reviewer: `/root/formal_degree_review`, 21 November 2026.

## Snapshot and conclusion

I read the complete `unitary_formal_degree.tex` fragment (all subsections,
including its final scope statement). The reviewed SHA-256 is
`06bc8570a32c9eaa24b70af808c2b8b7d14e4541845f6c14e1987c40fd6c49e1`.
This includes the compact-signature addition authorized by the root after
the initial review, whose previous snapshot had SHA-256
`638d7a812a8b49f1c101bcf4623c61e716520036b0ed2a03a1758fd52cfbb452`.

The mathematical argument passes this review, conditional on the explicitly
named classical representation-theoretic inputs. No substantive correction
or counterexample under its hypotheses was found. In particular, the formula
is for the specified Haar measure, not for an arbitrary normalization.
This review is not an independent Lean kernel replay or a reproof of the
classical discrete-series classification.

## Mathematical checks

- I derived both matrix-integral recurrences by the Schur complement,
  including the real Jacobian of the complex column change. The hypotheses
  ensure convergence at every induction step, including nonsquare matrices.
- The complex derivative of the fractional action has determinant
  `(det g)^q det(CZ+D)^(-p-q)`. Its absolute square gives the invariant
  ball measure. The compact Grassmannian integral gives
  `c_(p,q) = s_(p+q)/(pi^(pq) s_p s_q)`.
- In the defining complexification of each real unitary Lie algebra, an
  off-diagonal pair contributes absolute real determinant 4. Taking the
  square root for the product of the two equal densities gives the factor
  2 per pair. The compact and noncompact off-diagonal tangent coordinates
  therefore have the same factor `2^(pq)`, which cancels in the comparison.
- I checked the weighted Bergman representation law, unitarity, strong
  continuity, evaluation identity, cyclicity of the constant vector,
  one-dimensional compact character space, irreducibility and the explicit
  isometric embedding into the left regular representation. The resulting
  formal degree is `pi^(-pq) product_(i,j)(s-i-j+1)`.
- The highest-weight parameter is `(0,...,0,s,...,s)+rho` for the upper
  triangular positive roots in the chosen model. Its within-block
  Vandermonde is `s_p s_q`; reversing the first index gives exactly the
  cross-block factors used in the integral. This fixes the formal-degree
  constant with no additional gap assumption.
- The proof of the unique smallest compact type correctly applies the
  compact rearrangement inequality. Nonzero sums of positive noncompact
  roots pair positively with `lambda+rho`; the equality case forces the
  specified compact type. The integrality and dominance checks are valid
  even at the smallest permitted integral gaps and with arbitrarily
  interleaved signs.
- For the converse, every compact-dominant `mu_0-alpha` has strictly smaller
  squared shifted norm. This is exactly the exclusion needed in
  Parthasarathy's theorem. Restricting to `SU(p,q)` is legitimate: the
  compact central character is scalar, the restriction is irreducible,
  the compact types have the same fixed central weight, and `SL_n(C)` is
  simply connected. The finite central cover does not introduce a
  parameter-dependent measure factor.

## Source identification checked directly

I read the following submitted files in full, except where an interval is
specified. Paths below are relative to `sources/lean/src/`.

- `Formalism/LocalRingCardinality/DataCD.lean`: `IsOmegaLeb`, `ballU`,
  `OmegaDensity`, and every field of `CDHaar`. The source's balls use an
  entrywise norm, but the local density comparison is independent of the
  choice of norm, as the fragment explains.
- `Development/AbelianVarietyTheory/Definitions/Foundations/CdScaleTieIff.lean`:
  the measure transport, universal formal-degree proposition, and numerical
  definitions. The scalar measure used by the final argument is explicitly
  identified with `CDHaar`; it is not a freely chosen Haar measure.
- `Formalism/FormalDegreeBessel/StatementDS.lean`: the exact integral
  Harish-Chandra parameter convention, `lowK`, and `fdegHC`. The denominator
  in `fdegHC` is `product_(i<j)(j-i)=s_n`.
- `Formalism/SharpRestriction/CuspSpanNormBounds/RelevantZeroGramTerms.lean`,
  lines 1--130: representation, irreducibility, square integrability,
  coefficient, formal-degree, compact-type, `vNormSq` and `IsDS`
  definitions. The source's parameter is indeed specified by an occurring
  smallest compact type, which the reconstruction addresses.
- `Formalism/LocalRingCardinality/DataTies.lean`: the universal `dsigTie`
  and the exact `cdScaleTie`. The draft's nonvacuity argument is valid:
  the classical representation with the required type can be inserted in
  the universal identity.
- `Development/AbelianVarietyTheory/Proofs/FlagMeasures/NormalizedFormalDegreeEqVandermondeOfSizes.lean`:
  the large-gap source endpoint. The classical route proves its required
  numerical equality without retaining the source's extra gap bound.

This source check concerns the stated interfaces and normalization, not all
their transitive Lean proof dependencies.

## Primary references checked

- Harish--Chandra, *Discrete series for semisimple Lie groups II*, Acta
  Mathematica 116 (1966), Theorem 16 and section 41. I read the theorem and
  its formal-degree conclusion on printed pages 96 and 99--100 in the
  locally downloaded primary PDF/text, not the entire article's proof.
  The formula has a positive constant independent of the regular
  parameter and chamber. DOI: https://doi.org/10.1007/BF02392813 .
- Duflo--Heckman--Vergne, *Projection d'orbites, formule de Kirillov et
  formule de Blattner*, section III.1, theorem (2), printed page 111:
  https://www.numdam.org/article/MSMF_1984_2_15__65_0.pdf .
  I checked the primary theorem's statement and its character convention.
- Baldoni--Vergne, *Discrete series representations and K multiplicities
  for U(p,q)*, section 2.2, printed pages 12--14:
  https://webusers.imj-prg.fr/~michele.vergne/publications/discreteseries.pdf .
  I independently read the full parameter and Blattner-formula passage.
  Their compact Harish-Chandra parameter equals the draft's highest
  weight plus `rho_c`, giving exactly the displayed formula.
- Parthasarathy, *Classification of discrete series by minimal K-type*,
  Representation Theory 19 (2015), Theorem 1.1. I read the group
  hypotheses and both conditions of the theorem in the author's posted
  primary full text:
  https://www.researchgate.net/publication/282775275_Classification_of_discrete_series_by_minimal_-type .
  DOI: https://doi.org/10.1090/ert/467 . No omitted additional gap
  assumption is present in this theorem.

## Compact signatures and remaining limits

Following the initial review, the root authorized a compact-case addition.
It now treats `pq=0` separately: probability Haar measure makes the formal
degree the dimension, and Weyl's dimension formula gives the same
Vandermonde divided by `s_n`. The zero-dimensional group has formal degree
1. The compact-type proposition likewise handles the compact cases before
using Parthasarathy. I checked both additions. The initial `p,q >= 1`
assumption is needed only for the noncompact matrix-ball calibration.

I subsequently read the additional source normalization and calibration
files recorded in `unitary_formal_degree_source_manifest.json`; its 14
entries record the complete current read scope, including the entire
OmegaDensityUnique source and the asymptotic-calibration assembly.

The global multiplicity estimate, integrated Jacquet identities and theta
moment construction are outside this review and remain separately stated
tasks. A wrong normalization after doubling Haar measure is a
counterexample to a weakened assertion only; the source fixes the measure
and avoids it.

The regenerated standalone wrapper compiled twice with XeLaTeX to ten
pages after the compact-case addition. There are no overfull boxes; its
only unresolved references are the two external section/equation labels
supplied by the assembled manuscript. The root independently supplied
39619 passing exact controls at the final reviewed manuscript hash, as
recorded in unitary_formal_degree_checks.json.
