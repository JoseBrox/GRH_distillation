# The compact-dual formal degree: source trace

## What is proved

The conventional fragment computes the exact formal degree

    d(lambda) = product_(i<j) |lambda_i-lambda_j| / product_(j=0)^(n-1) j!

for the source's specified Haar measure on U(p,q). It proves directly the
complexification normalization of Lie algebra Lebesgue measure, its
compact-dual comparison, the scalar matrix-ball integrals, and the
calibration using a scalar holomorphic discrete series. Harish-Chandra's
formal-degree theorem supplies the parameter-independent proportionality
constant, which this calculation fixes.

The fragment also resolves a statement-identification issue: the source
does not define its parameter solely through an infinitesimal character.
Its IsDS includes an occurring compact type of weight
lambda+rho_n-rho_c minimizing ||mu+2rho_c||^2.
The reconstruction proves this exact minimum and uniqueness from
Blattner's formula, and the converse from Parthasarathy's minimal-type
characterization. The source's universal dsigTie can therefore be
evaluated on an existing classical representation.

The source imposes an additional large noncompact root gap. The classical
route proves the numerical formula for every regular integral parameter.
The compact cases pq=0, including the zero-dimensional trivial group,
are treated separately by compact Schur orthogonality and Weyl dimension.

## Source map

Paths are relative to sources/lean/src. The companion JSON records the
exact SHA-256, line count and read scope of each file.

| Source | Checked role |
|---|---|
| Formalism/LocalRingCardinality/DataCD.lean | Exact normalized Lie algebra measure, exponential density, compact probability and equal-density conditions |
| Formalism/LocalRingCardinality/DataTies.lean | Haar transport and universal numerical degree identification |
| Formalism/FormalDegreeBessel/StatementDS.lean | Harish-Chandra integrality, low compact type and Vandermonde denominator |
| Formalism/SharpRestriction/CuspSpanNormBounds/RelevantZeroGramTerms.lean, 1–130 | Representation, compact-type, minimum-norm and degree definitions |
| Development/AbelianVarietyTheory/Definitions/Foundations/CdScaleTieIff.lean | General measure and formal-degree interfaces |
| Development/AbelianVarietyTheory/Proofs/FlagMeasures/NormalizedFormalDegreeEqVandermondeOfSizes.lean | Required numerical endpoint for the size estimates |
| Development/AbelianVarietyTheory/Proofs/FlagMeasures/FormalDegreeEqHarishChandraOfGapStatement.lean | Endpoint statement wrapper |
| Development/AbelianVarietyTheory/Proofs/FlagMeasures/FormalDegreeEqHarishChandraOfGap.lean | Source existence and substitution into dsigTie |
| Development/AbelianVarietyTheory/Proofs/FlagMeasures/HarishChandraFormalDegreeCompactDualLargeGaps.lean | Source measure comparison and formal-degree application |
| ReciprocityTheory/ReductiveGroups/DiscreteSeries/FormalDegree/FdCons.lean | Source final calibration |
| ReciprocityTheory/ReductiveGroups/DiscreteSeries/FormalDegree/FdDefs.lean | Parameter deformation conventions |
| ReciprocityTheory/ReductiveGroups/DiscreteSeries/FormalDegree/PmatIsHermitian.lean | Source cPQ, polar measure, compact-dual measure and dimVlam |
| ReciprocityTheory/ReductiveGroups/DiscreteSeries/FormalDegree/ThmFD.lean | Source asymptotic calibration assembly |
| ReciprocityTheory/ReductiveGroups/DiscreteSeries/FormalDegree/HaarVolumes/OmegaDensityUnique.lean | Source uniqueness and transport of the specified measure |

Reading these interfaces and assembly files does not constitute verification
of every imported Lean proof. The conventional proof replaces the original
asymptotic calibration by a shorter classical argument; it does not claim to
reproduce that original calibration line by line.

## Classical inputs and verification scope

The bibliography contains the primary Harish-Chandra, Duflo–Heckman–Vergne,
Baldoni–Vergne and Parthasarathy references. Their exact read scopes are
recorded in the JSON. The full Harish-Chandra article was downloaded and
hashed, but only its relevant theorem and formal-degree passage are claimed
as read. The theorem statements used are standard results in representation
theory, explicitly imported in the mathematical fragment.

No hidden gap hypothesis is supplied by these references. In particular,
Parthasarathy's 2015 theorem allows all dominant integral parameters used
in the fragment; its group hypotheses hold on SU(p,q). The finite compact
central cover gives the stated U(p,q) consequence.

## Counterexample checks and outstanding work

The script check_unitary_formal_degree.py and its JSON result record 39619
exact integer and rational checks at the final reviewed manuscript hash.
These cover the Lie complexification Jacobian, scalar matrix-ball and
compact-dual constants, highest-weight shifts, and minimum-type inequalities
at small integral gaps. They are finite controls on conventions and
algebra, not a replacement for the general displayed proofs.

Doubling Haar measure halves the formal degree, so the same numerical
formula for arbitrary Haar measure would be false. The source's exact
normalization excludes this counterexample. Omitting the compact-type
condition would likewise invalidate identification of the representation
parameter. Neither omission occurs in the source.

The argument closes the formal-degree input to the reconstructed size
estimates, conditional on the stated classical theorems. It does not close
the separate ambient multiplicity, integrated Jacquet or arithmetic
theta-moment arguments, and it supplies no independent full kernel replay.
