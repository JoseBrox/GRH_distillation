# Independent review: local unitary densities and mass ratio

Reviewer: qrh_mathematics. Date: 2026-11-21.
Read all 420 lines of unitary_mass_densities.tex.
SHA256 of reviewed draft: `d4c47abbc709430f0d4eb1cee0404830e4d35cf62ab1d2b0c2f4de6ac9190626`.

## Result

No mathematical defect found. A typographical correction was requested for conjugate-transpose superscripts containing a literal comma. The global mass theorem is explicitly imported as a classical theorem, while local density and normalization arguments are fully proved here. No claim of a new proof of the global theorem is made.

## Finite fields and local lifting

- Norm surjectivity and trace surjectivity hold also at q even. The trace-pairing argument gives a nonzero-length vector, so the Hermitian classification and orthonormal frame count require no odd-characteristic assumption.
- The recurrences for zero/nonzero norms give B_n=q^(n-1)(q^n-(-1)^n), and nonzero isotropic count (q^n-(-1)^n)(q^(n-1)-(-1)^(n-1)). The unitary group order follows by exact basis extension.
- For Gram corank c, the isotropic-frame recurrence has q^(2(c-1)) independent lifts. Its product joins the orthonormal-frame product exactly at the common endpoint. Extracting q powers gives 2nm-m². The feasibility condition is m+c<=n, including all zero-rank and empty cases.
- In the split model, requiring both X and Y to have full rank is essential and is retained. For fixed X, Z restricted to ker(G) must be injective; the complement has precisely q^((n-m)(m-c)) free choices. The same normalized product results.
- The derivative of the Gram map is onto for every primitive frame: X*Phi H ranges over every square matrix, and T+T* surjects onto Hermitian matrices by the residue trace. The correction count q^(2nm-m²) is valid at every lift, including ramified base fields above2 because the quadratic algebra is unramified or split. No hidden factor2 occurs.
- The q=2 examples (9 and3 primitive isotropic frames,6 each for nonzero norm) check directly and correctly illustrate the corank/primitivity conditions.

## Global constants and source conventions

Independently read the supplied primary-source text:
- primary_mass/kirschmer_herm.txt, lines2433–2534: §4.2, Definition4.2.2 and Theorem4.2.3, including the unitary row in Table4.1.
- primary_mass/terakado_yu_2210_04054.txt, lines548–674: §2.3 and equation(2.6), including the explicit base-dyadic assumption in that paper.

Kirschmer's density normalization is #[H(O/p^a)]/q^(a dimG) for the connected unitary group. For a unimodular lattice its index factor is1, mu=1, dimG=n², degrees1,...,n, and Tamagawa number2. This yields exactly the displayed discriminant, relative-discriminant and archimedean factors. Terakado–Yu agrees but is not used to remove its own dyadic restriction.

Dividing ranks n and n-1 leaves d_F^((2n-1)/2), the factor ((n-1)!/(2pi)^n)^f, and L_n. With rho^f=d_F, this is the stated ratio. The L_1 normalization is retained before reorganizing products; absolute convergence is used only for j>=2.

The integral anti-conjugation condition is equivalent to finite unramifiedness: ramification makes the residue involution trivial, inert unramified primes have nontrivial residue involution, and split primes are separated by CRT. The tower discriminant is |d_E|=d_F². Inert E-prime norm q² and pairs of split norm-q primes give the exact Euler factors. The logarithm bound follows from |log(1-epsilon x)|<=-log(1-x) and zeta_F(n)<=zeta(n)^f.

## Reviewed typography update

The parent corrected the eleven conjugate-transpose superscripts after the mathematical review. The current file SHA256 is `d4c47abbc709430f0d4eb1cee0404830e4d35cf62ab1d2b0c2f4de6ac9190626`; no mathematical content was changed.

## Fixed-field addition

Independently read and checked the new fixed-field paragraph before md-source-conventions. For alpha not fixed, b=(x-bar(x))/(alpha-bar(alpha)) is fixed, as is x-b*alpha, proving degree2; extension of each embedding of the fixed field proves it totally real. This closes the CM interpretation from the actual involution hypothesis. The complete current fragment has 434 lines and SHA256 `c7dfbac7e6566ced93266868945e73ca984ca86db9eaed293714b5a48aa2eb13`. No mathematical correction requested.
