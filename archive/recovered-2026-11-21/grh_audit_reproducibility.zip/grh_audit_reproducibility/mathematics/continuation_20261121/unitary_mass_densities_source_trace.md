# Primitive densities and the exact unitary mass ratio

The ordinary proof is in unitary_mass_densities.tex. Exact source scopes,
hashes and primary-reference scopes are in the companion manifest.

DensExact.lean counts primitive inert or split frames, including
degenerate Gram matrices. Its normalization is q^(2nm-m^2) and its product
runs from n-m-c+1 through n, with the lower index truncated at zero in
impossible cases. The reconstruction proves this exact formula by
orthonormal frames and isotropic frames in the inert case, and by the
restriction of the bottom block to the Gram kernel in the split case.
The integral lifting proof makes the characteristic-two point explicit:
the Hermitian trace map, not division by two, solves the diagonal
linearized constraints. The argument allows a ramified base over Q_2.

StatementMass.lean uses standard orthonormal integral lattices and an
embedding-compatible involution. The reconstruction proves that the
fixed field is totally real and quadratic beneath E. Its condition on
theta-minus-conjugate-theta is exactly finite unramifiedness of E/F.
The discriminant identity and the inert/split pairing of E-prime Euler
factors yield precisely the source fDeg, vInv and lValEta.

MassRatio.lean writes the same formula using the fixed field F. The
reconstruction proves its degree, discriminant and Euler identities
and then its exact rText expression. The original source supplies the
mass result via SiegelMassRatioUnimodularDefinite and
SiegelMassRatioOfLI; the latter short assembly was read in full.
The reconstruction instead invokes the classical unitary Siegel mass
formula, with all its normalizations stated explicitly. This does not
claim a new proof of that global theorem or a full read of its long
formal development.

The classical formula was verified in Kirschmer, Theorem 4.2.3 (and its
definition of local density), with constants checked independently
against Terakado-Yu equation (2.6). The latter paper's restriction at two
is relevant to its ramified local calculations. It is not substituted
for the source hypothesis: our locally unramified calculation proves
the required factor in arbitrary residue characteristic.

The mass ratio is
M_n/M_(n-1)=((n-1)!*(rho/(2*pi))^n)^f*d_F^(-1/2)*L_F(n,chi^n).
All cancellations are explicit, including the rank-independent Tamagawa
factor and the rank-one convergence factor. Positivity follows from the
actual weighted class sum. The logarithmic Euler error bound is proved
termwise. Source-space dimensions and formal degrees are separate inputs.

58 exact enumerations check small primitive frame sets over F_4, F_9,
and the split algebras over F_2 and F_3. In particular, the zero-Gram
counts 9 and 3 at q=2,n=2,m=1 differ from the nonzero-Gram count 6.
Deleting either the corank or primitivity would change the assertion;
the source retains both. These are controls, not source counterexamples.
