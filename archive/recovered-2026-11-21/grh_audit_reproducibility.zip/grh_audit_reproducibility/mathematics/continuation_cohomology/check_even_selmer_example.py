"""Exact elementary checks for the S3 example in even_selmer_example.tex.

This checks only the stated integer arithmetic.  The cohomological proof
is in the accompanying TeX fragment; this script does not verify it.
No external packages are required.
"""

from math import isqrt


def is_prime(n):
    return n >= 2 and all(n % d for d in range(2, isqrt(n) + 1))


def mul(a, b, p):
    out = [0] * (len(a) + len(b) - 1)
    for i, x in enumerate(a):
        for j, y in enumerate(b):
            out[i + j] = (out[i + j] + x * y) % p
    return out


D = -4 * (-8) ** 3 - 27
assert D == 2021 == 43 * 47
assert is_prime(43) and is_prime(47)
assert D % 4 == 1
assert 1 - 8 + 1 != 0 and -1 + 8 + 1 != 0
assert mul([1, 1], [1, 1, 1], 2) == [1, 0, 0, 1]
assert mul([-1, 1], [-1, 1, 1], 3) == [1, 1, 0, 1]
assert all((x * x + x + 1) % 2 for x in range(2))
assert all((x * x + x - 1) % 3 for x in range(3))
assert mul([-5, 1], mul([-19, 1], [-19, 1], 43), 43) == [1, 35, 0, 1]
assert mul([18, 1], mul([-9, 1], [-9, 1], 47), 47) == [1, 39, 0, 1]

for p in [11, 263, 2039, 2099]:
    assert is_prime(p)
    assert D % p
    assert pow(D, (p - 1) // 2, p) == p - 1
assert 2099 % 8 == 3
assert 2039 % 16 == 7
assert 11 % 8 == 3 and 263 % 16 == 7
assert (263 + 1) % 11 == 0

print("All exact integer and polynomial checks passed.")
print("D =", D)
print("N =", 16 * D * 11 * 263)
