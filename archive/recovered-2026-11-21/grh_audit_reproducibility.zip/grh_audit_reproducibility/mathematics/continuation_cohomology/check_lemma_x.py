#!/usr/bin/env python3
"""Exact tests of the Bernoulli-unit assertion named LemmaX.

For an odd prime f, a nontrivial character modulo f is primitive.
The conductor-one character is also included.  All primitive characters
xi modulo 2^n with prescribed parity are obtained by xi(5)=zeta^h,
where zeta has order 2^(n-2) and h is odd.  Thus simultaneous testing of
all such xi reduces to a polynomial gcd with X^(2^(n-3))+1.

The first family uses quadratic phi and exact integer coefficients,
including coefficient primes dividing f.  The second family uses all
nontrivial phi with values in F_l, excluding l=f so that the usual
Bernoulli sum denominator can be inverted modulo l.  No floating point
arithmetic is used.  A zero gcd test means some l-adic embedding has a
nonunit Bernoulli number; it is a counterexample only if the displayed
threshold holds.
"""

from collections import Counter
from math import gcd
import json
from pathlib import Path

from sympy import isprime, primitive_root
from sympy.polys.domains import ZZ
from sympy.polys.galoistools import gf_gcd, gf_strip


def v2(n):
    assert n > 0
    r = 0
    while n % 2 == 0:
        n //= 2
        r += 1
    return r


def legendre(a, f):
    if f == 1:
        return 1
    a %= f
    if not a:
        return 0
    return 1 if pow(a, (f - 1) // 2, f) == 1 else -1


def bernoulli_integer_polynomial(f, n):
    """B_(1,phi*xi)=P(zeta), phi quadratic, xi(-1)=-phi(-1)."""
    modulus = 2**n
    order = 2 ** (n - 2)
    eta = -legendre(-1, f)
    conductor = f * modulus
    coeff = []
    a = 1
    for _ in range(order):
        b = modulus - a
        coeff.append(sum(
            (a + modulus * j) * legendre(a + modulus * j, f)
            + eta * (b + modulus * j) * legendre(b + modulus * j, f)
            for j in range(f)
        ))
        a = 5 * a % modulus
    degree = order // 2
    raw = [coeff[j] - coeff[j + degree] for j in range(degree)]
    assert all(c % conductor == 0 for c in raw)
    return [c // conductor for c in raw]


def bernoulli_modular_polynomial(f, n, ell, values):
    """The same expression for any phi valued in F_ell, ell not dividing f."""
    modulus = 2**n
    order = 2 ** (n - 2)
    eta = -values[-1] % ell
    denominator_inv = pow(f * modulus, -1, ell)
    coeff = []
    a = 1
    for _ in range(order):
        b = modulus - a
        coeff.append(sum(
            (a + modulus * j) * values[(a + modulus * j) % f]
            + eta * (b + modulus * j) * values[(b + modulus * j) % f]
            for j in range(f)
        ) % ell)
        a = 5 * a % modulus
    degree = order // 2
    return [((coeff[j] - coeff[j + degree]) * denominator_inv) % ell
            for j in range(degree)]


def common_factor(coeff, ell):
    degree = len(coeff)
    polynomial = gf_strip([c % ell for c in reversed(coeff)])
    cyclotomic = [1] + [0] * (degree - 1) + [1]
    return [int(c) for c in gf_gcd(polynomial, cyclotomic, ell, ZZ)]


def threshold(f, n, ell):
    d = 1 if ell % 4 == 1 else 2
    return f * 4 ** v2(ell**d - 1) <= 2**n


def finite_characters(f, ell):
    g = int(primitive_root(f))
    h = int(primitive_root(ell))
    count = gcd(f - 1, ell - 1)
    root = pow(h, (ell - 1) // count, ell)
    for exponent in range(1, count):
        values = [0] * f
        a = 1
        z = pow(root, exponent, ell)
        value = 1
        for _ in range(f - 1):
            values[a] = value
            a = a * g % f
            value = value * z % ell
        yield exponent, values


def run():
    primes = [p for p in range(3, 102) if isprime(p)]
    conductors = [1] + [p for p in range(3, 32) if isprime(p)]
    counts = Counter()
    failures = []
    below_threshold_examples = []
    for f in conductors:
        for n in range(4, 12):
            coeff = bernoulli_integer_polynomial(f, n)
            for ell in primes:
                h = common_factor(coeff, ell)
                within = threshold(f, n, ell)
                counts['quadratic_tests'] += 1
                counts['quadratic_within_threshold'] += within
                if len(h) > 1:
                    data = dict(f=f, n=n, ell=ell, gcd=h)
                    if within:
                        failures.append(data)
                    else:
                        counts['quadratic_nonunits_below_threshold'] += 1
                        if len(below_threshold_examples) < 20:
                            below_threshold_examples.append(data)

    # Positive control: the conductor-64 primitive odd characters have
    # a Bernoulli number nonunit at 17.  This lies below the n>=8 bound.
    assert common_factor(bernoulli_integer_polynomial(1, 6), 17) == [1, 6]
    assert not threshold(1, 6, 17)

    for f in conductors[1:]:
        for ell in primes:
            if ell == f:
                continue
            for exponent, values in finite_characters(f, ell):
                for n in range(4, 12):
                    if not threshold(f, n, ell):
                        continue
                    coeff = bernoulli_modular_polynomial(f, n, ell, values)
                    h = common_factor(coeff, ell)
                    counts['all_finite_character_tests_within_threshold'] += 1
                    if len(h) > 1:
                        failures.append(dict(f=f, n=n, ell=ell,
                                             exponent=exponent, gcd=h))

    result = dict(
        method='exact integer character sums and polynomial gcd over F_ell',
        ell_range=[3, 101],
        odd_prime_conductor_range=[3, 31],
        two_power_exponent_range=[4, 11],
        counts=dict(counts),
        counterexamples_satisfying_threshold=failures,
        nonunits_below_threshold=below_threshold_examples,
        positive_control=dict(f=1, n=6, ell=17, gcd=[1, 6]),
    )
    destination = Path(__file__).with_name('lemma_x_results.json')
    destination.write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))
    assert not failures, 'A candidate counterexample was found.'


if __name__ == '__main__':
    run()
