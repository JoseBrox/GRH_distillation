# Continuation: rank-four modular ideals and ordinary deformation control

Status: active audit; no confirmed error at this checkpoint. This file records exact mathematical definitions and genuine proof dependencies, not a claim of complete verification.

All source paths are relative to `sources/lean/src/`.

## 1. Actual ideal used in the rank-four argument

Theorem `UpperTheory.Gal.projectedFormsSystemPart.promodular_existence_of_local_zero` in
`Development/AutomorphicArithmetic/AutomorphicVarieties/ModularityArgument/ThresholdArguments/DenseThresholdCases/PmTwo.lean:21–51`
uses two auxiliary links `K,K'`, two universal ordinary determinant rings `B,B'`, their weight rings, and modular ideals `J0,J0'`. The ideal in the target deformation ring is exactly

`J0.map phi ⊔ J0'.map phi'`.

Its seed-local vanishing is proved separately for both summands. The two automorphic realizations are subsequently combined by `glueN` and descended by `Dn.pmDown_alt`. Thus merely observing that a unit ideal formally satisfies some quotient conditions does not refute the construction: the seed condition would forbid that ideal at an actual seed point.

`PotentialModularityTower.lean:38–55` defines the resulting requirements:

- finiteness of the special fibre with trivial inertial weights;
- local vanishing of J at certain irreducible characteristic-positive points;
- local vanishing of J at every specified automorphic seed point;
- weak purity and automorphy at the prescribed characteristic-zero weights.

## 2. Ordinary determinant ring and its integral conditions

`.../WeilGroupCharacters/UniversalOrdinaryDeterminantRing.lean:116–161` defines a pair `(D,psi)` over a complete coefficient algebra:

- D is an actual multiplicative polynomial-law determinant on the group algebra;
- D reduces to the diagonal sum of globally distinct residual characters;
- local ordinary characters have specified reductions and prescribed values on the local primary torsion subgroup;
- polarization is imposed on all characteristic-polynomial coefficients;
- ordinary Cayley–Hamilton products and the specified tame inertia relations have zero trace after left multiplication by every group element.

The ring is characterized by an existence-and-uniqueness universal property for these pairs. It is not merely an arbitrary local algebra with a chosen representation.

The quotient conditions in `.../WeilGroupCharacters/ArithmeticPointClassicality.lean:26–39` include finiteness and torsion-freeness over the weight ring, full determinant polarization, local characteristic-polynomial factorization, annihilation of the ordinary and tame relations in the determinant kernel, prescribed semisimple inertia types, and an auxiliary unramified condition under `r.V0ok`.

## 3. Hida quotient construction actually supplied

`.../DenseThresholdCases/THidaU.lean:38–53` constructs the input `HidaUAlt` from actual `UnitaryHeckeData`, `exists_hecke_ideal`, and separate proofs of the ring, density, point, purity, classicality, and twisting properties.

`.../DenseThresholdCases/ExistsHeckeIdeal.lean:58–89` gives the decisive construction. If the ordinary localized module `H.MK theta a K` is zero, it selects the unit ideal. Otherwise it constructs a determinant and ordinary characters on the Hecke algebra, uses the universal property to obtain a map from the deformation ring, proves this map surjective, and selects its kernel. The source does not infer nontriviality merely from an abstract existence record.

`.../DenseThresholdCases/UnitaryHeckeData.lean` defines the representation-theoretic type by testing occurrence in actual smooth irreducible representations of the local general linear groups and compatibility with a local Langlands correspondence. Its coefficient module, weight character, and residual Hecke eigenvalues are explicit components; the local type equivalence is a separate required field.

## 4. Adjoint and ordinary cohomology input

`.../DenseThresholdCases/AutomorphicPointGalois.lean:19–41` requires continuity, an actual associated determinant, arithmetic weights, cuspidal conjugate-self-dual automorphy, an auxiliary unramified condition, and ordinary flags. The locally generic version additionally requires irreducibility on the cyclotomic kernel, density of regular semisimple elements there, and a local element on that kernel whose eigenvalue ratios are not roots of unity.

`.../TheoremsMuLinked/OrdZero.lean:12–76` defines the ordinary cocycles with zero tame-inertia restriction and a local flag preserving condition with zero diagonal on inertia. `OrdZero` asserts these polarized cocycles are coboundaries. `AdZero` asserts the analogous rational Bloch–Kato assertion.

`.../DenseThresholdCases/AdLOf.lean:105–166` passes from the Bloch–Kato local condition to the ordinary one using the additional parallel-weight condition `Par`. Its initial lemmas explicitly transport local restrictions between embeddings and conjugate decomposition groups. The Bloch–Kato group has not been replaced with unramified cohomology at the primes above the coefficient characteristic.

In particular `.../PadicHodgeTheory/FiniteCohomology.lean:112–128` uses the kernel after tensoring with a crystalline period ring. That chosen ring is tied by an explicit ring isomorphism, compatible with action and filtration, to the concrete period ring in `Formalism/LocalRingCardinality/AdicCompletionLocal/LocTied.lean`. A trivial period ring is not an admissible substitute at this interface.

## 5. Ordinary deformation counting mechanism

`.../DenseThresholdCases/TOrdVan.lean:185–219` reduces an ordinary cocycle to a derivative on a universal ordinary determinant ring over a sufficiently large finite coefficient extension, applies the Hecke ideal point theorem, and then invokes `core_o_of_literal_automorphy_n`.

`.../DenseThresholdCases/TCoreO.lean:137–171` supplies this final ordinary assertion from:

- the ordinary Hecke control statement;
- a family of Taylor–Wiles primes;
- a determinant generation statement;
- a cohomology cardinality bound;
- a finite linear-algebra counting contradiction.

The counting theorem itself is `UpperTheory.V.Th.count` in
`.../TheoremsMuLinked/GaloisRepresentationTypes/MapRingHomSingleMulPartialCharpoly.lean:131–264`.
The elementary counting lemma at lines 8–43 is correct: if an O-linear map from a free module of rank D+1 has kernel contained, after a fixed nonzero multiplier, in m^m, then its image has more than |k|^(mD+C) elements for a suitable m. It follows by injecting `(O/m^k)^(D+1)` with k chosen larger than the fixed valuation losses and C. The later proof constructs the D+nq standard weight/tame derivatives plus a hypothetical additional vertical trace derivative, and compares the resulting image with the cohomology cardinality bound.

The potentially decisive remaining components of this particular chain are the exact Hecke control/freeness assertions, the construction of the standard derivatives, and the cohomology cardinality estimate, rather than the elementary final count.

## 6. Subsequent checks of ordinary freeness and the first cohomology bound

The relevant ordinary freeness result is `ordAbs` in
`.../HeckeAlgebras/OrdinaryHeckeCharacters/OrdFree.lean`. It uses the limit of
the powers `T^(j!)` as an ordinary projector, compatible finite-level
evaluation maps and sections, completeness, and finite generation. The
resulting module is a direct summand of a finite free module, hence finite
projective and then free over the local weight ring. The tempting test
module `A/(p)` does not satisfy the required section/evaluation hypotheses.
`ordStruct` obtains those sections from the explicit freeness of the
level stabilizer action. The auxiliary principal congruence level at an
odd unramified prime supplies that freeness. This is a check of the
displayed algebraic reduction; it is not an independent reproof of the
entire automorphic construction.

The semisimplicity used in `HidaSphRed` concerns the spherical Hecke
algebra at a classical fibre. It does not assert semisimplicity of every
ordinary `U_p` operator; a Jordan block in an oldform space is therefore
not a counterexample to its actual statement.

The first quantitative cohomology estimate is supplied by `b1absO` in
`.../TheoremsMuLinked/CyclicReductionCohomology/ResidualRepOne.lean`.
`OneLevelO.lean` keeps the exponent `n*d+n*q` after the archimedean and
local coboundary terms are combined. `PsiCont.lean` uses the successive
local characters `psi_i/psi_j`; the condition N1 excludes the critical
cyclotomic ratio in the relevant order. Fixed losses due to congruence
between characters enter a constant chosen before the torsion exponent.
`DualNO.lean` uses a fixed determinant-detection bound for the dual term.
The abstract lifting/counting argument in
`NcardTraceZeroTwistedCocyclesLeCoboundariesMul.lean` works with a
complete DVR and the finite reduction of its solution module. I did
not find an inference from the convention that the cardinality of an
infinite type is zero.

## 7. Exact K1, K2 and K3 hypotheses and the presentation step

`.../PatchingModules/PatchedSupportCompletions.lean:149` isolates a
substantive support statement: at the completed deformation point,
K1, K2 and K3, together with primes Z and Q, the discriminant condition
at Z, `dim(Bh/Z) >= 1+D0`, and the alternative that Q has nonzero
discriminant or is not semisimple, imply `Z <= Q`.

The definitions in
`.../PatchingModules/ThetaCoefficientMapEq.lean:69--80` have the
following content over `A=k[[t]]`:

* K1 bounds by D0 the number of Sel1 classes independent modulo Bd1.
* K2 concerns a `(g+1) by g` array of even SelP classes. A nonzero
  linear combination of the rows has all g columns lifting to Sel2.
* K3 says the chosen independent odd classes kappa_j span the odd
  Selmer group modulo odd coboundaries after multiplication by a
  suitable power of t.

`.../PatchingModules/AutomorphicDetection/GalOut.lean` obtains a
normalized coefficient DVR and a representation from S6. The theorem
`pres` in `.../PatchingModules/SelmerScaling/AlCSmul.lean` then supplies
the algebraic presentation. The type-I case uses `PresOut0.lean`; the
type-E case uses `presOut1` and the discriminant implication.

The linear algebra in this presentation was checked explicitly.
Write T for the even tangent space and U for the subspace of T^g whose
columns lift. K2 gives `codim(U) <= g`. Let
`W={a in T : each of the g single-coordinate insertions of a belongs
to U}`. The theorem in `FirstOrderLiftConstantPart.lean` produces,
from e independent elements of W, another g^2 independent Sel1
classes coming from the kappa_i epsilon_j terms. Thus
`dim(W)+g^2 <= D0`. The skew transpose condition and invertibility of
2 remove the even invariant ambiguity.

In `LinAlg.lean`, choose at most g linear forms defining U and write
their g coordinate components as phi_ij. Their span is the
annihilator of W. The presentation can use all g^2 phi_ij as
coordinates and then add a complement; its number of coordinates is
at most D0. This is permissible even if the phi_ij are themselves
linearly dependent: the coefficient vectors of the g^2 designated
coordinates are the standard basis in the presentation. The source
does not claim that all g^2 phi_ij are independent in the actual
tangent space.

### An excluded nodal test

The type-E theorem in
`.../PatchingModules/SelmerScaling/CotangentIndependentOfResidues.lean:74`
has a nontrivial hypothesis at Q. A concrete test is

    B = O[[X,Y]]/(XY),   A = B[m]/(m^2-Y, X*m),   N = B*m.

Here N is the odd part, the ideal generated by N^2 is `(Y)`, and
`Ann_B(N)=(X)`. With `g=D0=1`, the candidate Z is `(X)`, and the
other branch Q is `(Y)`. The desired inclusion `Z <= Q` is false.
However Q contains the ideal generated by N^2 and does not contain
`Ann_B(N)`. Consequently Q satisfies neither of the theorem's two
permitted alternatives. This example is not a counterexample.
Replacing the relation X*m=0 by X*Y*m=0 would introduce a nonlinear
relation and lose the required independence of the linear
coefficients. Thus that modification also fails the actual
hypotheses.

## 8. The obstruction bound behind K2

`.../PatchingModules/AutomorphicDetection/TaylorWilesObstructionBound.lean`
supplies the finite cohomology axioms from the actual global and local
duality statements. The theorem `obstructionBound_of_duality` in
`.../PatchingModules/ArchimedeanH0Cards/ObstructionBoundOfDuality.lean`
constructs the H^2 obstruction classes with their local conditions.
For every `e <= m` it bounds a quotient of the finite obstruction
module by

    |H/t^e H| <= |k|^(g*e+C),

where C is fixed before m and the auxiliary level. This quantifier is
essential: a bound on the total cardinality alone would not suffice
for the claimed relation.

The final module argument in `GenTrick.lean` has the following
independent proof. Write a finite DVR module as
`H = direct_sum_i A/(t^(lambda_i))`, with the lambda_i decreasing.
If `m > C`, use `e=C+1`. The inequality forbids g+1 elementary
divisors of length at least C+1, since they would contribute
`(g+1)*(C+1) > g*(C+1)+C`. Hence H is a sum of a module generated by
at most g elements and a module killed by t^C. Any g+1 specified
elements have a primitive linear relation after projection to the
first summand: lift their coordinates to A^g, take a nonzero kernel
vector over the fraction field, clear denominators, and divide out
the common uniformizer factor. Multiplication by t^C kills the
remaining component of this relation. If `m <= C`, the conclusion
is immediate. This proves the needed primitive relation.

In `OdCount.lean` the odd module has rank `2*a*(n-a)`, the complex
conjugation invariant part has rank `a*(n-a)`, and the ordinary local
quotient has that same rank. Those contributions cancel in the
Euler characteristic calculation. `DualBound.lean` controls the
remaining dual invariants using full matrix span on the cyclotomic
kernel and a block idempotent. The argument uses full block matrix
spaces, not a trace-zero quotient requiring division by n; the
case in which the coefficient characteristic divides n does not
yield the suggested central-matrix counterexample. `CkCastMod.lean`
supplies the required map between the local H^2 cokernel and global
dual H^0, with the primes in the local sum explicitly specified.

## 9. Quantitative uniformity in the two-adic auxiliary extensions

`.../QuadraticExtensions/IsAlgClosureRat.lean` starts with a fixed
Ferrero--Washington bound g for the base field M(i). The subsequent
bound is

    XRk <= 4*(g + 6*[M:Q]),

uniformly in the permitted auxiliary primes q and d. The congruence
conditions `q=3 mod 8` and `d=7 mod 16` bound the numbers of prime
orbits in the relevant two-adic tower by `2*[M:Q]` and `4*[M:Q]`.
`CharStep.lean` adds the tame inertia generators.
`QuadStep.lean` makes a quadratic step. In `IdxTwo.lean`, the
coefficient characteristic is 2 and the action of an involution c
satisfies `(1+c)^2=0`; therefore the full dimension is at most twice
the invariant dimension. These are the two factors of 2 in the
displayed estimate. No unbounded auxiliary splitting term was
dropped in the displayed calculation. This verifies the source's
reduction to its fixed base-field bound; it does not replace the
proof of Ferrero--Washington.

## 10. A genuine nonzero torsion Selmer class and what it tests

The file `even_selmer_example.tex` contains a full arithmetic proof,
and `check_even_selmer_example.py` checks its numerical inputs by
integer and polynomial arithmetic. For

    f=X^3-8X+1, D=2021=43*47, psi=the quadratic character of Q(sqrt(D)),

and every even e>=2, it constructs a nonzero class with coefficients
`(Q_3/Z_3)(psi^(-1)*epsilon_3^(-e))`, unramified everywhere and zero
on the full decomposition groups at 2, 3, 11, 43, 47, 263, 2039 and 2099.
It is obtained from the nonzero sign-module cocycle on S_3. The
inclusion from its order-three submodule is injective on H^1 because
global H^0 of the full divisible module is zero: inertia at 43 acts
by -1. This addresses the possibility that the residual class could
become a coboundary in the divisible module. Its local residual
coboundaries remain coboundaries under the inclusion, including at 3.

The exact groups tested are `Chr.VS`, `Chr.V`, and `Chr.V'` in
`.../CharacterLevelBounds/ShaFamMono.lean:15--34`, with the family
of local restrictions in
`.../GaloisLibrary/SelmerTransport/ConjStableShaFam.lean:94`.
For the updated choice `N=16*2021*11*263=93548048`, it gives
`Chr.V' 3 N e (dirG psi) >= 1`
as a Z_3-module with the discrete coefficients stated above. The
updated auxiliary primes have the required congruences and satisfy
11 | 263+1. They are not asserted to satisfy the asymptotic size
conditions of the final varying-parameter construction. This updated
choice supersedes the earlier example with auxiliary primes 2099
and 2039; its arithmetic is checked in the current reproducible script.

This is **not a contradiction to an actual theorem identified in
the source**. `PropZ` in `HeightAndVanishing/Counts.lean:49` requires
the trivial finite character and l>=5; neither condition holds
here. `CountII` and `CountIII` give upper bounds by large positive
powers, which permit a length of at least one. The `Raw.Good.xvan`
condition in `SymplecticGSp4/DecompSigmaOrd.lean:115` concerns the odd
auxiliary characters al, be and th and their inverses, whereas this
class has an even residual character. Finally `Raw.NoEnd` concerns
irreducible characteristic-zero rank-two blocks with distinct
specified weights, not the torsion cohomology group. The example
therefore rules out a blanket replacement of these actual inputs
by a vanishing assertion for every even character, but the source
has not been found to make that replacement.

## 11. Determinant detection and its span hypothesis

`.../PatchingModules/DeterminantPadicFree/FrameWith.lean` imposes
full span on the subgroup G' in ker(chi), a nontrivial twisting
character chi, the polarization equations, and independence of
the odd classes modulo polarized coboundaries. `DetAlg.lean`
then detects the twisted classes from the vanishing trace
identities. `DetAsm.lean` passes from power series to the fraction
field and clears denominators.

A nonabelian finite-group test is recorded, with all equations, in
`heisenberg_test.md` by the independent overview auditor. It uses
the Heisenberg group over F_p semidirect a Klein four group,
rho=diag(1,psi), kappa=u(E12-E21), lambda=v(E12+E21), and
phi=2*z*diag(1,-1). The center removes the cup-product obstruction
while leaving both H^1 classes nontrivial. However the required
trace identity fails: on ker(chi) it is
`(1-psi)*(2*z-u*v)`. At a suitable central element c and an element
t with rho(t)=diag(1,-1), the forced difference of the trace
expressions is 4, nonzero for every odd p. No alternative phi
repairs this, because the inhomogeneous cocycle equation forces
phi(c)=2*diag(1,-1). Thus this proposed counterexample is excluded
by an essential actual hypothesis.

The full span used here is for the **generic representation over
k((t))**, not the residual diagonal representation. In
`.../WeilGroupCharacters/UniversalOrdinaryDeterminantRing.lean:229--251`,
TypeI is absolute irreducibility on G', while TypeE requires
absolute irreducibility and zero Hom between its two blocks on G'.
`Pa.norm` in
`.../PatchingModules/AutomorphicDetection/ConjugationDescendsToSubring.lean:224--327`
preserves that hypothesis while normalizing the pairing.
`.../PatchingModules/DeterminantPadicFree/BlockForm.lean:236`
uses Burnside's theorem for the resulting block span.

In the actual rank-three endoscopic application, the blocks have
ranks two and one. `.../CurveDVRSpecialization/NiceIrrE.lean` proves
that the rank-two block remains irreducible on `U intersect G'`
for every open U. Thus a nonzero Hom to or from the rank-one block
is impossible by dimension. Its input `irrNormal` in
`.../CurveDVRSpecialization/IrrNormal.lean` was checked against
prime-dimensional imprimitive representations. Clifford theory
reduces a reducible restriction to the scalar or monomial cases;
the source excludes the first by local distinct characters and
the second by local character separation together with the
global residual character decomposition. A dihedral CM
representation with split residual characters is not an omitted
case: when the inducing quadratic extension splits locally, its
two residual characters coincide there, violating the specified
local residual separation. The rank-four TypeI input is `h4` in
`.../WeakShimuraTheory/CompactIntegralFields/H4.lean`; the root
auditor is separately testing its regular-semisimple-density
argument. The stabilizer-index and quadratic-self-twist reductions
in H4 were checked here, but this note does not claim independent
verification of `regCosetFour`.

## 12. Current counterexample search

The next concrete target is `LemmaX`, defined in
`.../LevelCohomology/UnramifiedCocycleIsCoboundaryOfBernoulliUnit.lean:23`.
It asserts that the generalized Bernoulli number B_(1,phi*xi) is an
l-adic unit for every primitive xi of conductor 2^n once

    f * 4^(v_2(l^d-1)) <= 2^n,

where phi is primitive of odd conductor f, its order divides
l^d-1, and the product character is odd. This explicit uniform
bound can be tested using exact character sums and reduction of
cyclotomic polynomials, including equality at the threshold.
The completed exact computation is in `check_lemma_x.py`, with results
in `lemma_x_results.json`. It tests odd primes 3<=l<=101, f=1 and odd
prime conductors 3<=f<=31, and 4<=n<=11. There are 2,200 quadratic
checks, of which 617 meet the size condition, and 1,305 further
checks of nontrivial F_l-valued primitive characters meeting that
condition (including some repeated quadratic cases). Polynomial
gcd detects all primitive two-power characters of the required
parity simultaneously. No permitted counterexample was found.
There are 18 nonunits below the threshold, including f=1, n=6,
l=17; its gcd with the cyclotomic polynomial is X+6 modulo 17.
This confirms that the test can detect actual failure.

More substantially, `lemma_x_proof.tex` now gives an independent
proof of the general assertion. It removes the possible conductor
denominator by a finite-sum difference identity, so it covers
l dividing f. Frobenius averaging restricts the character sum to
the elements whose character values have order dividing 2^a.
They lie in the two residue classes plus or minus 1 modulo 2^m.
A translation by s=f*2^a and the odd parity leave precisely a
nonzero term -2. Multiplication by 1+2^(n-1) cancels the constant
term. This also checks equality at the threshold. Thus the
specific Bernoulli-unit bound is not left as an unverified input.

## 13. The exact restricted cyclotomic assertion PropZ

The root requested an additional check of possible quadratic
class-group or even K-group obstructions to `PropZ`.
`LevelCohomology/PropZ.lean` splits its proof into `zOne` in
`TorsClass.lean:97` and `zQuad` in `ZqField.lean:228`. The latter
explicitly uses `hQuad` in `HQuad.lean`, namely that the class
number of a quadratic field of discriminant l is less than l.

`prop_z_proof.tex` gives a full independent proof of the actual
statement. If `l-1` divides `2e`, the residual character
`omega^(-e)` is trivial or quadratic. Since e is even, the
quadratic case has l=1 mod 4 and fixed field Q(sqrt(l)). Its
l-class group is zero: Minkowski gives ideal class representatives
of norm at most sqrt(l)/2, and summing the elementary bound
`number of ideals of norm r <= divisor_count(r) <= r` gives
`h_K < l`.

The delicate lift from divisible coefficients is also handled.
Given an l-torsion Selmer class, lift it through
`0 -> M[l] -> M --l--> M -> 0`. At l, its residual local class
is a connecting H0 class. The local and global cyclotomic images
are both Z_l^*, so `H0(D_l,M)=H0(G_Q,M)`: subtracting the global
connecting class makes the residual local restriction zero.
At other primes inertia acts trivially on M, and l-divisibility
of M makes the map from H1 with M[l] coefficients to H1 with M
coefficients injective on inertia. The resulting residual class
is therefore everywhere unramified. Restriction to Q or to the
real quadratic field is injective (degree at most two, prime to
l) and factors through its class group, hence is zero. All
continuous cohomology classes with coefficients M have l-power
order, by compactness of G_Q and discreteness of M, so the full
Selmer group vanishes.

Accordingly, the actual PropZ congruence does not include the
other even eigenspaces that would be implicated in a general
Vandiver-type assertion. No quadratic-field obstruction meets
its hypotheses. The discriminant-2021 example lies outside this
fixed-field condition.
