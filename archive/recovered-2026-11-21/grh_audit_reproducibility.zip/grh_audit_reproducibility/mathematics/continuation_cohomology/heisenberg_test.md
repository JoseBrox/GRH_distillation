# A nonabelian test of the determinant-cocycle assertion

## Status

This is **not a counterexample to the source theorem**. It is a rigorous test of
the natural attempt to remove the cup-product obstruction by passing from an
abelian p-group to a Heisenberg group. The central extension makes the required
inhomogeneous cocycle equation soluble, but the trace condition in the source
then fails. In fact, for the two cocycles constructed below, **no** solution of
the inhomogeneous equation can satisfy that trace condition.

The source definitions are in
`Development/AutomorphicArithmetic/AutomorphicVarieties/PatchingModules/DeterminantPadicFree/FrameWith.lean`:
`DetFr` at lines 26–44, `IsKap` at 56–60, and `IsTw` at 62–72.
The conclusion being tested is `Det.detAlg` in `DetAlg.lean:71–72`.
The argument in `RelPair.lean:23–176` uses the full block-diagonal span and the
trace condition; the test below makes their role explicit.

## 1. The finite group and its action

Let p be any odd prime and let F=F_p. Put

\[
 P=\{(u,v,z):u,v,z\in F\},\qquad
 (u,v,z)(u',v',z')=(u+u',v+v',z+z'+uv').
\]

This is the Heisenberg group of order p^3. Let
H={±1}×{±1}, with coordinates (psi,chi). It acts on P by

\[
 (\psi,\chi)\cdot(u,v,z)
  =(\psi u,\chi\psi v,\chi z).
\]

This is a group automorphism because
(psi u)(chi psi v')=chi uv'. Define G=P semidirect H, writing an element as
g=(u,v,z,psi,chi). Its multiplication is therefore

\[
\begin{split}
 &(u,v,z,\psi,\chi)(u',v',z',\psi',\chi')\\
 &\quad=(u+\psi u',\ v+\chi\psi v',\
 z+\chi z'+\chi\psi uv',\ \psi\psi',\ \chi\chi').
\end{split}
\]

For p=3 this group has order 108.

Take n=2, a=1, G'=ker(chi), sigma=id, and mu(g)=1. Define

\[
 r(g)=\begin{pmatrix}1&0\\0&\psi(g)\end{pmatrix}.
\]

Then every commutator lies in G', chi is trivial on G' and nontrivial on G,
and the F-span of r(G') is the full algebra of diagonal 2 by 2 matrices.
Indeed, I and diag(1,-1) are in r(G'), and 2 is invertible. Also
r(g)^T r(sigma(g))=I. Thus all the conditions defining `DetFr` hold.

## 2. Two nontrivial cocycles

Write

\[
 A=\begin{pmatrix}0&1\\-1&0\end{pmatrix},\qquad
 B=\begin{pmatrix}0&1\\1&0\end{pmatrix},\qquad
 D=\begin{pmatrix}1&0\\0&-1\end{pmatrix}.
\]

We have A^T=-A, B^T=B, D^T=D, AB=D, BA=-D, and [A,B]=2D.
Conjugation by r(g) multiplies A and B by psi(g) and fixes D.
Set m=1 and define

\[
 \kappa(g)=u(g)A,\qquad \lambda(g)=v(g)B.
\]

The group law gives

\[
 \kappa(gh)=\kappa(g)+r(g)\kappa(h)r(g)^{-1},
\]

and

\[
 \lambda(gh)=\lambda(g)+\chi(g)r(g)\lambda(h)r(g)^{-1}.
\]

Both take values in the off-diagonal block space. With s=1 their polarization
conditions are exactly
kappa(sigma(g))=-kappa(g)^T and lambda(sigma(g))=lambda(g)^T.

Let x=(1,0,0,1,1). Then r(x)=I and kappa(x)=A. Hence, if
c kappa(g)=r(g)Yr(g)^{-1}-Y for every g, evaluation at x gives cA=0,
so c=0. This proves the source's independence condition, even without its
additional requirements that Y be off-diagonal and skew symmetric.
Thus `IsKap` holds.

Likewise, for y=(0,1,0,1,1), one has r(y)=I, chi(y)=1, and lambda(y)=B.
Every twisted coboundary vanishes at y. Consequently lambda is not a twisted
coboundary.

## 3. The Heisenberg center solves the inhomogeneous equation

Define

\[
 \phi_0(g)=2z(g)D.
\]

It is diagonal and symmetric. Direct substitution gives

\[
\begin{split}
\phi_0(gh)={}&\phi_0(g)+\chi(g)\bigl(r(g)\phi_0(h)r(g)^{-1}\\
 &\qquad+[\kappa(g),r(g)\lambda(h)r(g)^{-1}]\bigr).
\end{split}
\]

Indeed, the commutator in the second line is 2u(g)psi(g)v(h)D, and
the z-coordinate of gh is z(g)+chi(g)z(h)+chi(g)psi(g)u(g)v(h).
Thus phi_0, kappa, lambda, s satisfy **all** the conditions of `IsTw` except
possibly its final trace condition `ell`.

## 4. The trace condition fails, and no alternate phi can repair it

For g in G', one has chi(g)=1. Since lambda(g)kappa(g)=-u(g)v(g)D,

\[
\begin{split}
 &\operatorname{tr}(\phi_0(g)r(g))+
  \operatorname{tr}(\lambda(g)\kappa(g)r(g))\\
 &\qquad=(2z(g)-u(g)v(g))(1-\psi(g)).
\end{split}
\]

At g=(0,0,1,-1,1) the value is 4, which is nonzero for every odd p.
In particular it equals 1 for p=3. The trace condition is not merely the trace
on the kernel of r: its values after multiplication by an element distinguishing
the two diagonal blocks are essential.

There cannot be another phi satisfying the inhomogeneous equation and `ell`.
To see this without enumerating cochains, let c=(0,0,1,1,1) and
t=(0,0,0,-1,1). Then c=[x,y], xy=c(yx), and
kappa(c)=lambda(c)=0. The equation at (x,y) and (y,x), followed by the equation
at (c,yx), gives

\[
 \phi(c)=2D.
\]

This also follows because any other solution differs from phi_0 by a twisted
cocycle; restricted to P, where r and chi are trivial on diagonal matrices,
such a difference is a homomorphism to an additive group and kills [P,P].

Now kappa(t)=lambda(t)=kappa(ct)=lambda(ct)=0, and the equation gives
phi(ct)=phi(c)+phi(t). Both t and ct belong to G', and r(ct)=r(t)=D.
If `ell` held at both points, subtracting the two equalities would give

\[
 0=\operatorname{tr}(\phi(c)D)=\operatorname{tr}(2D^2)=4,
\]

a contradiction. This proves that the nonabelian central extension does not
produce a counterexample satisfying the source hypotheses.

## Conclusion of this test

The abelian model fails because its cup-product obstruction cannot be integrated.
The Heisenberg model integrates that obstruction, but the full trace condition
detects the newly introduced central term. This supports the particular algebraic
mechanism used in `RelPair`; it is not a validation of the entire deformation or
GRH argument.
