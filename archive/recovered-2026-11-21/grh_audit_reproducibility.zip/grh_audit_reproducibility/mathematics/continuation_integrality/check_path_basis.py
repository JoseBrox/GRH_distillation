"""Exact small-case test of ObjPol.PPath, Kcol, Psi and IsSt.

The definitions are transcribed from the downloaded source; this is a test,
not a replacement for Lean checking or a proof in general dimensions.
Only integer arithmetic is used in polynomial construction and determinants.
"""
import itertools
import json
import math
from functools import lru_cache
from pathlib import Path
import sympy as sp


def add(p, q, a=1):
    r = dict(p)
    for m, c in q.items():
        r[m] = r.get(m, 0) + a*c
        if not r[m]: del r[m]
    return r


def mul(p, q):
    r = {}
    for m, a in p.items():
        for k, b in q.items():
            t = tuple(x+y for x,y in zip(m,k))
            r[t] = r.get(t,0)+a*b
    return {k:v for k,v in r.items() if v}


def xmul(p, v):
    r = {}
    for m, a in p.items():
        k=list(m); k[v]+=1; r[tuple(k)]=a
    return r


@lru_cache(None)
def next_weights(mu, b, positive):
    n=len(mu)
    out=[]
    for delta in itertools.product(range(b+1), repeat=n):
        if sum(delta)!=b: continue
        nu=tuple(mu[i]+(delta[i] if positive else -delta[i]) for i in range(n))
        if any(nu[i]<nu[i+1] for i in range(n-1)): continue
        lo,hi=(mu,nu) if positive else (nu,mu)
        if all(hi[i+1]<=lo[i] for i in range(n-1)):
            out.append(nu)
    return tuple(out)


def paths(n, letters, degrees):
    cur=[((0,)*n,)]
    for positive,b in zip(letters,degrees):
        cur=[pa+(nu,) for pa in cur for nu in next_weights(pa[-1],b,positive)]
    return cur


def height(mu,c): return sum(v>=c for v in mu)


def subsets(n,k):
    return tuple(sum(1<<i for i in s) for s in itertools.combinations(range(n),k))


def standard_columns(path):
    n=len(path[0]); full=(1<<n)-1
    lo=min(0,min(min(mu) for mu in path)+1)
    hi=max(0,max(max(mu) for mu in path))
    cols=tuple(range(lo,hi+1))
    end=path[-1]
    choices=[]
    for c in cols:
        h=height(end,c)
        choices.append(subsets(n,h if c>=1 else n-h))
    for masks in itertools.product(*choices):
        tab=[full]+[m if c>=1 else full^m for c,m in zip(cols,masks)]+[0]
        if all((b&((1<<(t+1))-1)).bit_count() <= (a&((1<<(t+1))-1)).bit_count()
               for a,b in zip(tab,tab[1:]) for t in range(n)):
            yield cols,masks


def kcol(path,c):
    n=len(path[0]); N=len(path)-1
    cur={0:{(0,)*(n*N):1}}
    for j in range(N):
        old,new=height(path[j],c),height(path[j+1],c)
        if old==new: continue
        wedge=(old<new)==(c>=1)
        nxt={}
        for mask,p in cur.items():
            for i in range(n):
                inside=bool(mask&(1<<i))
                if inside==wedge: continue
                target=mask^(1<<i)
                sign=(-1)**((target>>(i+1)).bit_count())
                nxt[target]=add(nxt.get(target,{}),xmul(p,j*n+i),sign)
        cur=nxt
    return cur


def vectors(n,letters,degrees):
    out=[]; labels=[]
    for pa in paths(n,letters,degrees):
        cache={}
        for cols,masks in standard_columns(pa):
            p={(0,)*(n*len(letters)):1}
            for c,mask in zip(cols,masks):
                if c not in cache: cache[c]=kcol(pa,c)
                p=mul(p,cache[c].get(mask,{}))
            out.append(p); labels.append((pa,cols,masks))
    return out,labels


def monomials(n,degrees):
    choices=[tuple(m for m in itertools.product(range(b+1),repeat=n) if sum(m)==b) for b in degrees]
    return [tuple(itertools.chain.from_iterable(ms)) for ms in itertools.product(*choices)]


def check(n,letters,degrees):
    vs,ls=vectors(n,letters,degrees)
    ms=monomials(n,degrees)
    index={m:i for i,m in enumerate(ms)}
    M=sp.zeros(len(ms),len(vs))
    for j,p in enumerate(vs):
        for m,c in p.items(): M[index[m],j]=c
    if M.rows==M.cols:
        det=int(M.det(method='domain-ge'))
        passed=abs(det)==1
    else: det=None; passed=False
    row=dict(n=n,letters=[int(x) for x in letters],degrees=degrees,
             dimension=len(ms),vectors=len(vs),determinant=det,unimodular=passed)
    if not passed:
        row['rank']=M.rank()
        row['matrix']=str(M)
        row['labels']=ls
    return row


def main():
    out=[]
    jobs=[]
    for n,N in [(1,3),(2,2),(2,3),(2,4),(3,2),(3,3)]:
        for letters in itertools.product([False,True],repeat=N):
            jobs.append((n,letters,[1]*N))
    for n,ds in [(2,[2,1]),(2,[2,2]),(2,[2,1,1]),(3,[2,1]),(3,[2,2])]:
        for letters in itertools.product([False,True],repeat=len(ds)):
            jobs.append((n,letters,ds))
    for n,letters,degrees in jobs:
        row=check(n,letters,degrees)
        out.append(row)
        print(json.dumps(row),flush=True)
        if not row['unimodular']: break
    Path(__file__).with_suffix('.json').write_text(json.dumps(out,indent=2))


if __name__=='__main__': main()
