# Continuation: theta kernels, geometric Galois representations, and small sections

## Status and scope

This continuation has not established a mathematical counterexample to an actual theorem of the archive. It followed several previously unexamined central dependencies substantially further. This is a record of what was inspected, what the hypotheses actually say, and what remains to check. It is not a certification of the full transitive Lean proof, nor an assertion that the remaining mathematics is false.

All source paths below are relative to `sources/lean/src/`.

## 1. The kernel identity and the actual Siegel--Weil proof

The assertion at `Development/AbelianVarietyTheory/Proofs/SiegelThetaTransformation/KernelIdentity.lean:181` relates a sum over the arithmetic group of an explicit reproducing kernel, multiplied by inner products of Schwartz functions, to a genus sum of products of theta series. The hypotheses include even positive-definite rank n, n>4r, a symplectic integral basis, and the full `IsSystem` conditions. Those conditions include compatibility with the Weil representation, support orthogonality outside the arithmetic subgroup, and cancellation at every nonzero isotropic vector. These latter conditions are used to kill the non-graph terms in the doubled Eisenstein series, not silently presumed for arbitrary Schwartz functions.

The proof of `hasSum_eis`, in the same file at line 50, classifies maximal isotropic subspaces of the doubled space into graphs of unitary maps and the remaining subspaces. For a remaining subspace an isotropic vector gives the cancellation supplied by `IsSystem.cusp`. The invariant harmonic-polynomial differentiation is justified by a separate result on doubled heat solutions and compact-unitary invariant polynomials. The argument does not identify all derivatives of an arbitrary function with its value at the origin: it uses the heat equation and the invariant-polynomial hypothesis.

The invoked Siegel--Weil theorem is actually proved by induction in

* `.../SiegelWeilDefiniteHermitianOfFourMulLt.lean:11`;
* `.../SiegelWeilFormulaDegreeSucc.lean:242`.

The definition `SWAt` concerns the weighted finite class sum of the theta series minus the associated Eisenstein series, for an explicitly admissible family of Schwartz functions. Admissibility controls integral support, period, rational-unitary covariance, and local agreement of the lattice family. The weight of the Hermitian theta series is n, not n/2. Its invariant norm therefore uses `detIm(Z)^(n/2)`.

### 1.1 What the induction needs

For a suitable split prime ideal of norm q, there are `(q^n-1)/(q-1)` neighboring positive-definite lattices. The pointwise Hecke identity for the Schwartz family and a weighted neighbor-count identity give an identity for the theta--Eisenstein difference D. Writing n=2k and N for the current Hermitian degree, the numerical contraction is

\[
 \vartheta=\frac{q^k(1+q^N)}{q^{2k}+q^N}<1.
\]

Indeed

\[
 q^{2k}+q^N-q^k(1+q^N)
   =(q^k-1)(q^k-q^N)>0
\]

because q>1 and k>N. The source assumes the stronger range n>4N. The two types of twist in the Hecke identity change the lattice index by q and q^{-1}, respectively; these changes account for the q^k factors in the invariant norm. The finite multiplicities are retained in `hecke_swd` and `bound_step`, at lines 115 and 170. Merely finding a strict contraction is therefore not a contradiction with Hecke theory.

The existence of a uniform finite upper bound on the invariant norm for all those twists is supplied by `TwistedSiegelWeilDifferenceBounded.lean:136`, which reduces to `SiegelWeilDifferenceInvariantNormBounded.lean:167`. The inspected reduction has the following real ingredients:

1. finite lattice classes give a common Schwartz level and a uniform bound for the original family;
2. rational Levi transformations move the variable lattice to a lattice with bounded denominator, with an explicit determinant-index comparison;
3. the determinant factor in the transformation of `detIm` matches the lattice-index factor;
4. Fourier expansion and vanishing at every rational rank-one cusp give the requisite polynomially weighted bound in a Siegel region;
5. reduction of Hermitian forms moves every point to such a region, with bounded denominators and controlled transforms of the Schwartz functions.

The cusp step is `SwdTendstoZeroAtCusps.lean:163`. It uses the inductive Siegel--Weil identity in degree N and the Siegel operator on theta and Eisenstein series. It moves an arbitrary nonzero rational vector to the first coordinate by a rational Levi element. Thus it is not checking only one cusp.

The Fourier estimate is `DecayOfVanishingAtCusps.lean:390`. The important intermediate assertions are `coef_psd` at line 120, `coef_sing` at line 153, and `coef_posDef` at line 214. Boundedness high in the half-space eliminates Fourier coefficients whose Hermitian index is not positive semidefinite. A singular rational Hermitian matrix has a nonzero rational kernel vector, so vanishing at all rational rank-one cusps eliminates the remaining singular indices. Bounded denominators give a positive lower bound on the product of the determinants at the embeddings. This is the arithmetic ingredient that permits the exponential Fourier decay to dominate the determinant weight.

The exact counting and reduction sublemmas are extensive. I read the principal induction, the invariant-norm reductions, and the Fourier arguments, but have not independently rederived every analytic summability and reduction-theoretic sublemma. No missing mass factor or contradictory weight normalization was found in the inspected equations.

## 2. The Galois representation used in the main theorem is a geometric construction

The main arithmetic endpoint uses

```
IntegralStructures/RowSrc.lean
 -> IntegralStructures/GaloisRepresentationsOfThetaLift.lean
 -> IntegralStructures/Development.lean
```

under `Development/AutomorphicArithmetic/Foundations/GaloisRepresentations/`. `Development.lean:27--30` constructs the local-global statement from `GeoOne` and `TLiftK`. It is not merely invoking a record called a published theorem and leaving its relevant field as an assumption.

The actual geometric source is

```
GeometricFlagBases/WeightOneGeometricRealization.lean
 -> GeometricFlagBases/GeometricRealizationOfWeightOne.lean
 -> GeometricFlagBases/PackExOf.lean
 -> GeometricFlagBases/MapInvMul.lean
```

The name “weight one” does not mean that arbitrary weights are claimed to occur in H^1 of an abelian variety. The construction uses fiber powers of the universal abelian variety, Hodge cohomology in varying bidegrees, finite Hecke correspondences, and an actual etale-cohomology eigenspace followed by semisimplification and a Hecke-character twist.

`GeometricFlagBases/IntegOfMem.lean` defines a `KS` tower by scheme isomorphisms with the relevant fiber powers, compatible with the moduli Hecke isogenies. `HodgeTrAt.lean:26` defines `IsPiece` through the actual etale eigenspace and its semisimplification. `PackExOf.lean:43` defines a `Plan` containing the PEL datum, tower, level, Hecke operators, eigensystem, algebraic Hecke character, highest weight, and spectral condition.

The required geometric models are not asserted at every bad prime without restrictions. The PEL datum contains an integral quadratic element with negative discriminant, with the chosen prime coprime to that discriminant and with specified splitting. The principal level is at least 3 and prime to that prime. The model-existence chain uses representability at an auxiliary level and finite quotient descent.

### 2.1 Hodge occurrences

The Hodge occurrence input in `LefschetzSigmaSums/KsHodgeOfGeo.lean` uses a holomorphic Lefschetz formula, finite fixed points, and weighted counts relating the indefinite unitary group to the definite group. It is not an equality of unweighted numbers of points. In `PGeoStep.lean`, the Hecke trace is divided by the explicit subgroup index, and the alternating Hodge trace uses the characteristic polynomial in the correct exterior-power degree.

The field-pair comparison `Proofs/DivisorProofs/MarkedFieldPairsSumEqDefinitePairsSum.lean` requires odd unitary rank and signature (1,n-1). Changing that signature to (n,0) changes the determinant sign by (-1)^(n-1)=1. An objection based solely on changing the archimedean determinant class in even rank therefore does not apply. The test function also excludes the reducible/nonregular support for which the marked-eigenline count used here would fail.

The extraction of a simultaneous Hecke eigenspace in `LefschetzSigmaSums/PHodgeEig.lean` uses a polynomial in finitely many Hecke operators to separate the chosen eigensystem. Commutativity is checked on the cyclic space furnished by the spectral hypothesis. A nonzero coefficient of the Hodge trace then produces a genuine nonzero eigenvector in at least one Hodge group.

### 2.2 The representation-theoretic multiplicity argument

`ZetaCharacterDivisibility/DivisionOneGeometricRepresentation.lean:52` invokes `Development/EtaleCohomology/DivisorCycles/GoalHolds.lean:19`. This is a strong but precisely stated theorem about semisimple representations. Its hypotheses cannot be reduced to “the characteristic polynomial divides a power of a polynomial of degree a.”

In ordinary language, one assumes a continuous semisimple representation rho of a compact group, a dense set on which rho(g) is annihilated by a monic polynomial P_g of degree a, and an element of the Lie algebra of the Zariski closure having a distinct selected eigenvalues e_1,...,e_a with the following property:

\[
 \frac1{|A|}\sum_{i\in A}e_i\ne
 \frac1{|B|}\sum_{i\in B}e_i
\]

for every pair of disjoint nonempty subsets A,B of {1,...,a}. There is also a continuous determinant character matching the constant terms of P_g. The conclusion supplies an a-dimensional semisimple subrepresentation, containing all the distinct constituent types of rho, with the desired determinant and characteristic polynomials on an open dense set.

The definition of the unequal-average condition is `Development/WeilBound/CoreStatements/PadicHodgeComparison/CocharacterLieDivisors/DivWCoreLacUseType.lean:86`. The bounded degree condition is a bound on the degree of an annihilating polynomial (`DivisorCycles/OpenCoset.lean:36`), not just on the number of eigenvalues without regard to Jordan blocks.

The proof in `DivisorCycles/DivPlus.lean:37` and `StructPf.lean:13` has substantial algebraic content. It transfers the degree condition to the Zariski closure and its Lie algebra. Spectral projectors for the selected Lie-algebra element yield orthogonal idempotents; the unequal-average condition separates off-diagonal eigenspaces of the adjoint action. The diagonal corners are scalar because a nonscalar diagonal corner would produce an element with annihilating degree exceeding a. The algebra generated by the Lie algebra is semisimple. The remaining finite-component argument is `SumMulSum.lean:90`; it uses generic diagonal points in the Zariski closure and separates the spectra belonging to different permutation cycles. Matrix units then produce the required subrepresentation.

The Hodge-theoretic condition is not inserted by defining a convenient matrix. `ZetaCharacterDivisibility/HtCocharOf.lean` obtains the cocharacter in the Zariski closure from actual Hodge--Tate weights. Its main input, `Proofs/InertiaEigenvalues/MemClosureOfJumps.lean`, uses a Hodge--Tate eigenbasis over C_l and the vanishing of nonzero twisted C_l invariants. Coefficients of the representation are fixed after a finite local extension, an essential hypothesis used in the polynomial-vanishing argument.

Ordinary examples with repeated or equally spaced weights do not contradict this theorem. I did not complete a separate proof of the finite-component matrix-unit argument; no counterexample satisfying its full unequal-average hypothesis was found.

### 2.3 Two normalization objections excluded by definitions

The local bridge `Induces` implies that the local place lies over l. Thus a statement quantified over all places and all inducing bridges is not automatically asserting l-adic crystallinity at places of residue characteristic different from l.

The Weil--Deligne comparison uses Frobenius semisimplification explicitly. `Definitions/AutomorphicMembership/WeilDeligneParamMonodromyEqZeroIff.lean:340--349`, under `Development/AbelianVarietyTheory/`, includes `IsFrobSS` in the definition of `IsWDOfWith`. An objection that the theorem omits Frobenius semisimplification would therefore misstate the source.

## 3. Further work on the uniform small-section theorem

The previously identified small-section theorem combines three independent steps: theta spanning with bounded harmonic polynomials, an archimedean estimate, and denominator clearing. In this continuation I read the actual denominator-clearing assembly and much of the archimedean reduction.

The uniform clearing integer is particularly explicit. Set

\[
 f=[E:\mathbf Q]/2,\quad r=p+q,\quad
 d=\deg P=\mathrm{DF}(a),\quad M=\text{the level}.
\]

The quantity called `intZ` satisfies

\[
 Z=M^{frn+d}|\operatorname{disc}E|^d.
\]

This identity is used in `Proofs/DivisorProofs/LogShortThetaSeriesDenominatorBoundLe.lean:118`. The final integer is Z^2, in `ExistsBoundedIntegerGoodCoverThetaSeriesIntegral.lean:31`. Hence this step does not claim integrality of arbitrary normalized derivatives without any discriminant or level denominators.

The proof treats separately primes not dividing M, primes dividing M but not M^2, and primes whose square divides M. The expression also contains a determinant-ideal scalar s: it must satisfy an explicit fractional-ideal inclusion determined by the positive-definite lattice and its intersection with the standard lattice. `ClearingIntegerShortSeriesIntegralCoprimeLevel.lean` uses that inclusion to control the primes away from the level; it does not discard the denominator of an arbitrary rational lattice change.

The local harmonic-derivative estimate reduces to two statements:

* at primes not dividing the discriminant, integral eigenprojectors give integral harmonic values;
* at a ramified prime, the Galois field and the condition that complex conjugation moves every prime above p give paired eigenlifts with denominators controlled by the different.

The latter condition is explicit in `Proofs/RingsOfIntegers/HarmonicValueBoundIntegralChartRamified.lean:61` and `ExistsRamifiedEigenLiftsOfChartDirections.lean:177`. The numerical bound is

\[
 v(\text{harmonic value})\ge
 -\frac{v(p)}e\frac{v_p(\operatorname{disc}E)}{[E:\mathbf Q]}\frac d2.
\]

The factor d/2 is obtained by counting paired derivative occurrences in each monomial; it is not applied to arbitrary unpaired derivatives. The field-family statement supplying the conjugation condition is `HostFieldGaloisDegreeDiscrConjMovesPrimes`. I have not independently reconstructed all its field arithmetic or all the formal-biextension identities used for the eigenlifts.

The archimedean bound `NormPhiHatIndPhi.lean:208` retains the factor

\[
 [\Lambda:\Lambda\cap\mathcal O_E^n]^{r/2}
 \|P\|_{\mathrm{coeff}}
 \exp\!\bigl(9000(frL)^2\kappa\bigr).
\]

The small scalar used in the final theorem compensates this index. In particular, an objection obtained by moving a lattice through a rational unitary matrix and then ignoring its index would not address the actual inequality.

The supremum bound is reduced to a point at which a cusp form has at least half its supremum and the period lattice has a quantitative first minimum. `FirstMinAtHalfMax.lean:111` proves this using a periodic holomorphic function on a unipotent orbit and its decay at infinity; its input includes membership in the cuspidal space `SS`. A constant noncuspidal function is not a permitted test case. The proof at `ReciprocityTheory/ReductiveGroups/ArithmeticGeometry/FundamentalDomains/MaxBoundPf.lean` explicitly uses `CuspidalExponentialDecay` before applying the periodic Schwarz lemma.

Finally, the coefficient bound on the harmonic polynomials is not an unrestricted short-vector assertion for arbitrary subspaces. `ExistsShortHarmonicFamilyUnimodular.lean` constructs polynomials from products of minors of pairs of short orthogonal lattice frames, using self-duality of the positive-definite lattice and the harmonic/highest-weight conditions. The exact coefficient-ring statement uses the integral symmetric algebra associated with that lattice, so arbitrary denominators of its coordinates alone do not contradict it. The remaining orthogonal-frame and polynomial-spanning constructions have not yet been independently rederived.

## 4. Remaining focused targets

The substantive remaining targets in this lane are the formal-biextension eigenlift identities behind the ramified harmonic valuation estimate, the geometric comparison between the algebraic theta rule and its analytic series, and the complete local-global compatibility descent from the initially constructed odd-rank geometric representation. They cannot be declared proved or disproved solely from the dependency traces above. The absence of a counterexample in these passes is evidence about the particular objections tested, not evidence that the complete claimed GRH proof is correct.

## 5. Subsequent tests of the theta normalization and geometric hypotheses

### 5.1 The square root is not asserted to be globally holomorphic

The normalized theta frame is chosen pointwise by a scalar kappa with
`kappa^2 = normConst * det(h)`, in
`Proofs/UnitaryExistence/ExistsNormalisedFramedPointOnEachComponent.lean`.
This initially suggests a possible metaplectic sign problem. The actual reading theorem
`DifferentiableOnReadingsNormalisedThetaPoints.lean` avoids it: the relevant degree n is
even, say n=2m, and the normalized section is expressed as
`(normConst * det(h))^m` times the unnormalized theta reading. It never needs a global
holomorphic choice of the square root. Arithmetic invariance similarly uses that a
scalar with square one acts trivially in even degree; see
`NormalisedFramedPointArithmeticGroupInvariantSig.lean`.

The square of the classical theta multiplier is also not discarded. In
`ThetaFrameDetMulSqInvariant.lean` the formula includes the factor chi_4(det D).
The adapted symplectic basis gives det A congruent to 1 modulo 8, which kills this
factor. The arithmetic ingredients are explicit: `CmUnitPowFourIdempotentModEight.lean`
uses the trace-one host-field element w with w^2=w-(4k+2); its fourth power is idempotent
modulo 8. The two eigenspaces form complementary Lagrangians modulo 8. A congruence
unitary transformation has determinant one because its determinant is a norm-one CM
unit and the full congruence level is at least 3. Interpolating its action by the
idempotent w^4 gives the claimed determinant congruence. Thus neither an arbitrary CM
field without an integral trace-one element nor an arbitrary degree-one theta form
satisfies the hypotheses used here.

`NormalisedPointsSatisfySingleFrame.lean` retains the analytic theta norm factor.
The mean is `(2^g det Im(tau))^(-1/2)`, while the period dictionary gives
`P det Im(tau)=|det(h)|^2`. Taking
`kappa^2=sqrt(2^g/P) det(h)` makes the normalized mean exactly one.

### 5.2 Compactness, level, and integral eigenspaces

The compact geometric realization is not asserted for arbitrary U(1,n-1) over an
imaginary quadratic field. In `Definitions/Divisors/NotCompactOfMEqOne.lean`,
`Datum.Compact` means `2*a < [F:Q]` or `(IsDivision and n < 2*m)`.
The class `Sc` used in
`Foundations/GaloisRepresentations/IntegralStructures/GeometricFlagBases/IntegOfMem.lean:193`
has a=m=1, odd n, and this compactness condition. If n>=3, it forces [F:Q]>2.
The holomorphic Lefschetz formula is applied to a smooth projective complex variety,
finite etale correspondences, a finite fixed-point set, and nonvanishing
`det(1-A)`; see `LefschetzSigmaSums/HodgeTraceFromLefschetzAndGroupSide.lean:102`.

The all-prime extension theorem assumes the good-level condition
`3 <= M / p^(v_p(M))`, explicitly defined in `TwoWeightEqOneAddRoot.lean:68`.
A level consisting only of a power of the residue characteristic fails it.
The integral frame contains a basis of each separate integral eigenspace, and does
not assert that their direct sum is the whole integral tangent module at a ramified
prime. The latter would be false in general, but is not the source statement.

The condition `PushInvertible` on the semiabelian extension concerns sections over
preimages of base open subsets and a generator nonzero at some point of each fiber.
It does not assert base change of H^0 to the entire special torus. Consequently the
infinite dimension of regular functions on a torus is not a counterexample.

### 5.3 The large principalization certificates do not prove resolution

`ResolutionOfSingularities/EmbeddedResolution/IdealPrincipalization/PrincipalizationCertificate.lean`
contains a `large` constructor requiring only `2 <= m`; this is a potentially
misleading name but not itself a false assertion. All actual geometric eliminations
found in this subtree were checked. `StrictTransformIsolation/RestrictionToOpens.lean:529`
and `SmoothOrderOneCenters.lean:307` conclude properties conditional on m=1, and their
large branches are discharged by the contradiction `2 <= m` and `m=1`.
In the conversion from an order certificate with mu>=2, the geometric support is
contained in the locus of order at least mu, hence cannot meet the smooth order-one
locus. Other recursors preserve certificates under isomorphism or open restriction.
The application in `StrictTransformSmoothness.lean:185` explicitly uses m=1 together
with the actual smoothness and ideal-agreement hypotheses. No false geometric
resolution theorem follows from the permissive `large` constructor in this trace.

## 6. Non-tempered theta lifts and the actual local bounds

The added Arthur summands in an iterated theta lift must be tested against any
purity or temperedness assertion. The current chain does retain their non-tempered
Frobenius exponents. In `ThetaPairLifts/ThirdPlaceSeries/SplitStepOAltAlt.lean`, the
local multiset has the form

\[
 e^{-1}\operatorname{Eig}(R_w)
 +\sum_{k=0}^{t-1}\{(m e^{-1})q^{(t-1)/2-k}\},
 \qquad |e|=|m|=1.
\]

The theorem named `tempered_of_true_cuspidal_alt` in `NOProd.lean:24` does not prove
temperedness of this whole lift. Its conclusion is `AllCuspidalOpenBound`, defined
in `Foundations/GaloisRepresentations/StringRepresentations/AllCuspidalOpenBound.lean:22-25`.
It says that for each genuine GL(a) cuspidal constituent pi with the stated
conjugate-self-dual and regular algebraicity properties, an unramified eigenvalue
alpha satisfies `q^(-1/2) < |alpha| < q^(1/2)`. Full temperedness is included only
when a=1. The proof uses the unitary cuspidal Jacquet--Shalika bound. In
`SplitStepOAltAlt.lean`, this estimate is applied to the cuspidal member of each
Speh pair, not to the complete Speh representation. The powers
`q^((d-1)/2-j)` are handled separately by the string-counting argument.

`SixthWeightPurity.lean` likewise does not assert that the mixed-weight lift is pure.
It uses the open interval bound on a cuspidal constituent, an explicit power of the
cyclotomic character, and the half-integrality of the exponent to rule out a
particular invariant character except at the prescribed integer in the long string.

Two other suggestive theorem names were checked against their definitions:

* `AmbientDualCrystallineAndPureOfDecompStatement.lean:6` concludes `ambW` and
  `ambT2`. The definitions in
  `Formalism/SharpRestriction/LevelLetterCocycles/EmbeddingTypes.lean:212-223`
  assert crystallinity of the selected summands, de Rhamness, and H^0=0.
  They contain no Weil-purity assertion. Its proof in
  `AmbientDualCrystallineAndPureOfDecomp.lean:38-55` uses direct-summand stability
  of crystallinity and obtains H^0=0 from the supplied geometric hypothesis.
* `pure_of_tripleAtt_n`, in
  `StringRepresentations/FrobDualOfTripleAttN.lean:256-281`, concludes only that
  the Frobenius eigenvalues of the twisted rank-r representation have modulus
  strictly less than one. `AttN.temp`, at lines 26-27, assumes the very weak bound
  `|alpha| <= q^((r+3)/2)` on the original unitary cusp representation. The twist
  is `q^((1-t)/2)` and the rank condition is `t >= r+5`; their product is at most
  `q^(-1/2) < 1`. This is a correct elementary implication and accommodates
  substantial non-temperedness.

The weak bound in the second item is actually supplied by the open cuspidal bound:
`TypeConditions/IsPotCrysAtOfMono0.lean:307-319` obtains a genuine unitary cuspidal
representation through `Blocks.readsCusp`, applies Jacquet--Shalika, and enlarges
the exponent 1/2 to (r+3)/2. `TripleAttOfIsTripleWith.lean:103-116` applies this to
unitary twists of the rank-r cusp representation pi. It does not use the ambient
rank-(r+t) theta lift as if it were a GL(r+t) cusp representation.

The separate `TLiftK` construction of Galois representations also makes no
temperedness assertion for its target. `ThetaParseval/SchurStep.lean` defines
`IsLift` by actual definite-unitary automorphy, an archimedean highest-weight
formula, and the split local theta pairing. Its passage back to the original
rank in `ThetaParseval/SplitLineSubtraction/SubtractHolds.lean` explicitly removes
the added rank-one Galois characters. The mixed weight of the large lift therefore
does not by itself contradict the traced assertions.

No counterexample satisfying these actual hypotheses was found in this pass.
## 7. Arithmetic-progression target weights and the unequal-average condition

An additional counterexample test asked whether the multiplicity-removal theorem is applied to the arithmetic progressions in `Formalism/SharpRestriction/InertJacobiLevels/RayPrimes.lean:19--34`. Such progressions do fail the unequal-average condition: if three terms are (c,c+d,c+2d), the singleton middle term and the pair of endpoints have equal means. The archive itself proves a special case in `Definitions/GaloisGeometry/DivisionOfDeterminantCharacter.lean:47--57` (`not_lacunary_three`) and explicitly gives the trivial weight in rank three as an example that fails the condition.

This does not yield an application error. The actual application in `IntegralStructures/Development.lean:20--28` is

`seedFinOdd_of_geoOne` + `congFinOdd_of_ex wtLacEx_holds` -> `TraceLimits.limFinOdd_of` -> the general Galois representation theorem.

The first theorem is only a seed statement for auxiliary automorphic representations (U') satisfying `WtLac`; the target (U) in the congruence and limit theorems has no such condition. The distinction is explicit in `Definitions/GaloisGeometry/LimWU4OfLimWU3.lean`, definitions `SeedWU4`, `CongUW4`, and `LimWU4`. In `ZetaCharacterDivisibility/SeedFinOddOf.lean:49--52`, the unequal-average hypothesis comes from the auxiliary argument `hwt`. In `TraceLimits/LimFinOddOf.lean:73--88`, the indexing set consists of those auxiliary (U'), and their seed representations are used in the limiting argument. The weights are fixed only away from two selected places over the coefficient prime; the changed weights occur over one of those places.

The auxiliary weights are explicitly far from arithmetic progressions. `WeightCharacters/TopOf.lean:31--35` chooses

\[
 N=(a+1)(4d+a)+1,\qquad \nu_i=-N(a+1)^i,
\]

and obtains highest weights within (2d) of \(\nu\). `CongruenceOddLevel/LacunaryBaseWeightAntitone.lean:43--93` proves that if \(|\lambda_i+N(a+1)^i|\leq D\) and \(N>(a+1)(2D+a)\), then their Hodge--Tate jumps (j_i=i-\lambda_i), in increasing order, satisfy

\[
 j_{i+1}-j_0>a(j_i-j_0)\qquad(i+1<a).
\]

The elementary estimate is sound. Write \(\lambda_i=-N(a+1)^i+\delta_i\), with \(|\delta_i|\leq D\). Then

\[
 (j_{i+1}-j_0)-a(j_i-j_0)
 =N((a+1)^i+a-1)+1-(a-1)i
   -\delta_{i+1}+a\delta_i-(a-1)\delta_0.
\]

The error has absolute value at most (2aD). For (i+1<a), the displayed hypothesis on (N) is more than enough for strict positivity. `PGapLac.lean` then gives the unequal-average conclusion by placing the largest term of two disjoint subsets in one subset and comparing its contribution with the sum of the other subset.

Thus the target arithmetic progressions do not contradict the multiplicity-removal application. This check verifies the separation of target and auxiliary weights and the elementary growth argument; it is not a verification of every analytic or representation-theoretic input in the full weight-approximation and trace-limit constructions.
### 7.1 Local properties in the limit are taken at fixed weights

`TraceLimits/LimFinOddOf.lean:166--173` only deduces crystallinity and de Rham comparison at a place (w\mid\ell) that lies over neither of the two auxiliary places (w_0,v'). The proof explicitly supplies `sameWtAt_of_off` to `crysDRU_of_linApprox`. The latter theorem (`Proofs/SatakeParameters/BlowUpFibreSemilocal.lean:67ff`) assumes the entire Hodge--Tate multiset of every auxiliary representation agrees with that of the target at the chosen place.

The closure theorem is stronger than a statement about ordinary sequences because `LinApprox` permits uniform linear combinations of traces. Its proof does not infer de Rham comparison merely from integral Sen weights. `Proofs/SatakeParameters/ClosedAtL.lean:25ff` constructs a covering tower of integral representations and invokes `Proofs/InertiaEigenvalues/ClosedOfCover.lean`. There the fixed finite multisets (J_\tau) give one bound (N=\max_\tau\max_{j\in J_\tau}|j|) (lines 167--174). Every layer has a Breuil--Kisin frame of that same height (N) (lines 183--189); the limit theorem supplies a de Rham frame, crystalline if all layers are crystalline (lines 190--197). This is the actual local comparison input requiring further proof review if this lane is extended.

Two tempting counterexamples therefore fail the stated hypotheses. Crystalline characters with unbounded weights approaching a non-de Rham character do not have a common (J\). Ramified finite-order characters, which could be used in uniform linear combinations approximating general functions on inertia, are not semistable over the fixed local field; `ClosedAtL` requires semistability over that field, not merely potential semistability after varying extensions. No counterexample satisfying these hypotheses was established.
