# QRH component review and connection to the Alpöge archive

This is a scoped mathematical review, not certification of all 247 pages in the two supplied papers. No fatal flaw in the original Alpöge argument has been established by this lane. The source claims and the independent implications proved here must be kept separate.

## Retrieved source identities

- OpenAI repository commit: `4eaee87548250b2682affda7d05d947c05554bae`.
- September PDF: 199 pages, 1,588,969 bytes, SHA-256 `8fe93046f8cf5ef1ba5969c89addc02d76311adc4ee907509ff9cd96f7ec99e7`.
- October PDF: 48 pages, 784,503 bytes, SHA-256 `f919b57829b178c8e60e7c17b018cf773e7907cf642ef5a3347d8a826e8dbf18`.
- Downloaded the exact TeX sources from the corresponding `build/` directories at the pinned commit; their hashes are in `manifest.json`.
- Catalogue commit: `5b7217781269248f39fbcec2432394d3d1610344`. Downloaded README, full maintained components (4,310 records, 33.2 MB), annotations (7.3 MB), directory, and recursive tree. The generated data duplicates and historical base-data shards were not all downloaded. No catalogue validator was used as proof evidence.

## Scope of reading

For the October paper: read the introduction, outline, Section 3 deduction, definitions and Poisson setup in Section 4, all the iteration argument in Section 5, the statements and structure of Section 6, both Poisson identities and the cancellation/reindexing in Section 7, Gauss-Jacobi arithmetic in Appendix A.1, and the cusp transformation/local factors in Appendix A.2. The metaplectic automorphy and its cusp tables were not independently rebuilt from first principles or checked against every cited primary theorem. Thus the mean-square proposition remains a quoted source input in the independent write-up, not a newly certified theorem.

For the September paper: read the complete introduction and theorem/quantifier discussion, the entire common continuation Proposition 2.1, fixed-character/zero-extension conventions, the key theorem statements throughout Parts I and II, sixth-power amplification, and the endpoint and order-of-choices argument in Section 20. Its long marked inverse and fourth-moment inductions were not independently reconstructed in full. No assertion of exhaustive verification of that 199-page proof is warranted.

For the catalogue: parsed all maintained records and selected 38 mathematically scoped records relevant to amplification, Möbius sums, Mellin transforms, cofactor estimates, or obstructions. `catalogue_selected.json` retains their full available statements and source links. Many records explicitly leave a stronger complete signed estimate open. In particular c11 = 312864909/2500000000 is conditional/source-relative, as the README itself states. It is not a proved RH endpoint. G276 and G280 have been independently reproved, with the polynomial version of G276 retained.

## Independent results produced

`contribution.tex` gives full proofs of the following.

1. Smoothed Möbius cancellation at every epsilon exponent alpha gives zero exclusion to the right of alpha; fixed-character implied constants suffice. A single exponential smoothing has nonvanishing Gamma Mellin multiplier and avoids a family of profile tests if that one bound can be proved.
2. General k-th-power amplification from B(D,H) <= D^(a+eps) H^b gives exponent max(a/2+h(b-1/k)/2, 1-h/k) at H=D^h. For the actual October input (a,b,k,h)=(1,1,6,1+eta), this is 11/12+5eta/12. Even arbitrary positive h with the same estimate and the same absolute deletion bound only gives k/(k+1), hence 6/7 for k=6. This is a limitation of a stated calculation, not a lower bound for actual Möbius sums or for the method with new input.
3. The exact prime-removal identity A1(D)=A_(p^k)(D)-nu(p)A_(p^k)(D/Np) retains a possible avenue for improvement. The later bootstrap section proves the prime-uniform control furnished by an a priori bound for A1 and states the additional shorter mean square still needed.
4. Hecke nonvanishing over Q(sqrt(-3)) transfers to all ordinary Dirichlet characters. At s=1 the only pole cancellation issue reduces to L(1,chi_-3)>0, proved directly by a positive series; no general nonvanishing theorem at s=1 is hidden here.
5. A disk logarithm bound, elementary partial summation, and Cauchy's formula prove L'/L(sigma+it,chi)=O(log(q(|t|+3))) on every fixed buffered line to the right of a common zero-free boundary. This is uniform in q and t.
6. Smooth Mellin inversion then proves a prime-in-progression estimate with error X^sigma log(q+3). This proof avoids an appeal to an unproved uniform explicit-formula estimate. It yields primes in every reduced class in (X,2X) once X >= C_B(q+1)^B for any B>1/(1-theta).
7. This directly supplies the ordinary `ProgPrimes` input, including the quadratic logarithmic derivative at 1, and constructs the auxiliary pair q,d with all the required size, splitting, and dlog conditions.
8. Finite Dirichlet polynomials cannot make the complete residual 1-LB contractive in coefficientwise absolute norm at real sigma<=1: either coefficient 1 already has size1, or the large-prime tail diverges. This is a complete elementary obstruction.
9. For real degree-d polynomial P and a>0, the d Mellin transforms of x^j exp(-ax-iP(x)), 0<=j<d, have no common zero on Re(s)>0. The proof uses a recurrence and Laplace-transform uniqueness, including exact endpoint/holomorphy justifications.

## Specific original-source connections

`Formalism/SharpRestriction/InertJacobiLevels/PrimeSupply.lean`:
- `ProgAt C`: all M,a,X with X>=M^C, X>=3 -> prime p in (X,X^2], p=a mod M, and |dlogQ p|<=C log p.
- `QDGood`: q,d prime with q size exp(V^(eps/5)), d size exp(V^(eps/5)log(V)^2), small primes split in Q(sqrt(-d)), |dlogQ d|<=V^eps.
- `RayAt C`: separate stronger statement for primes represented by (1+Mu)^2+d(Mv)^2 in [X,X(1+h)], avoiding a prescribed set. This is a varying quadratic ray-class theorem.

Uniform QRH for ordinary Dirichlet characters supplies the first two directly, but not `RayAt`. The QRH papers' Hecke theorem is over the single fixed field Q(sqrt(-3)), not every Q(sqrt(-d)). One must not silently extend its field scope.

`Formalism/SharpRestriction/GlobalSchurBounds/ShortIntervalPrimes.lean`:
- `adm5`: at-most-one exceptional real character;
- `adm6`: near-one zero-density and exceptional-zero conclusions;
- `adm8`: exceptional ray-class comparison both over Q and over the varying field D.host.K.
Ordinary common half-plane exclusion trivializes the near-one ordinary exceptional-zero case after thresholds are adjusted, but not the varying-field component.

`Formalism/SizeWindowBrackets/GrowthBoundGivesRiemannHypothesis.lean`:
- `aE<=2*x*b` is a height/weight budget, not a Möbius estimate.
- `ValuesAtX` in the RH subcase requires x^(1/2+eps) bounds for three special auxiliary quadratic characters, as well as logarithmic derivatives. The full Dirichlet-GRH path through `CoreGm` and `sigA_le` requires a finite family of fixed-character twists by those quadratic characters, uniformly over the selected interval. Generic QRH only gives x^(theta+eps) directly for an individual fixed character. The continuation review now proves that QRH can instead support the required simultaneous selection by averaging; that conditional result does not remove the other automorphic inputs.
- The division of the error by n_T*m*b yields aE/(m*b), aE*m/(k*b), a term proportional to m, and a rank term. The square-root balance x/m+m is structural at this level. QRH does not replace the input aE by b*x^theta.

## No logical upgrade from a fixed strip to RH

A common nonzero distance from the line Re(s)=1 does not itself imply that every zero has real part1/2. Functional equation symmetry only reflects a zero beta to1-beta. The reduced mean-square inequality above has a concrete numerical saturation at exponent11/12. A claim that repeating the same existing estimate gives RH must exhibit an improved estimate and track the changed conductor, twist, and scale; none has been proved by this review.

## Deliverables to parent

- `contribution.tex`: manuscript-ready mathematical section, with explicit conditional inputs and no Lean code.
- `references.tex`: bibliography items with immutable source URLs and exact original-archive locators.
- `manifest.json`: retrieved source identities.
- `catalogue_selected.json`: exact scoped records inspected further.
- this file: scope and relation to original proof.

## Further conditional self-improvement (after parent suggestion)

`bootstrap.tex` proves the precise improvement obtained when prior Möbius cancellation is retained in prime deletion. The geometric series identity has a uniform prime-independent constant because its ratio is at most 2^(-beta-epsilon), and compact support makes the original iteration finite. It yields beta_new(h)=max(1/2+(k-1)h/(2k), beta(1-h/k)). At h*=k(2beta-1)/(k-1+2beta), the improvement is T_k(beta)=k beta/(k-1+2beta). The exact iteration is 1/beta_n=2-((k-1)/k)^n(2-1/beta_0). For k=6 and beta0=7/8, the first desired range is H=D^(2/3), giving exponent7/9.

This has NOT been obtained from the supplied estimates. October Proposition5.1 assumes Hdual<=Sigma D^-kappa; for the common-divisor1 term, Hdual~D^(2-h), X=Sigma=D, F=1. At h<1 the assumption fails. The cube cutoff Hc<1 retains unit divisor b=1 and exactly the original scale. The supremum that one might attempt to reuse would include the original mean square. Lemma5.3 and Proposition5.4 themselves both require Hdual<=Sigma, so this diagnosis does not apply either lemma beyond its actual hypotheses. September's no-slot raw moment and canonical puncture condition enforce the same H>D direction. Its sixth-power-free bound cannot be directly amplified using p^6, which is excluded.

The bootstrap section explicitly notes that an all-h DH mean square already implies RH from the single u=1 term. Even h*(beta) gives a weaker direct exponent improvement by that term alone. Hence the missing shorter-range estimate is substantive new mathematics, not a disguised established lemma. A fixed floor h0 leaves the amplification exponent floor1/2+(k-1)h0/(2k); h0=1 leaves11/12.

A genuine counterexample for an improperly enlarged coefficient class is included: use the fixed coefficient sequence equal to1 on every prime ideal outside S and0 elsewhere, together with a fixed smooth weight supported in(1/3,3/2) and at least1 on[1/2,1]. At prime-power arguments p^k of norm<=H the contributing prime columns all add positively. The mean square is at least D²H^(1/k)/(logD)^3, contradicting DH up to arbitrarily small powers when h<k/(k-1). This concerns the complete outer set, not a set excluding k-th powers; it does not concern the actual Möbius coefficients.
