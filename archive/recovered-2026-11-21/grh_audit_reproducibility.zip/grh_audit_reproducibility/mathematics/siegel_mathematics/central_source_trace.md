# Central arithmetic comparison: source trace and scope

This note accompanies `central_step.tex`. It does not certify the construction
of the uniform arithmetic families. It records what was actually extracted
from the downloaded source and distinguishes the proved simplification from
the remaining work.

## 1. Final analytic chain

All paths below are relative to `sources/lean/src/`.

1. `Development/AutomorphicArithmetic/CharacterBoxes/ZeroFreeAllOfTopG.lean`:
   `zeroFreeAll_of_topG` invokes the fixed-level window theorem, with the
   family class supplied through `TopG`. `TopG` quantifies over admissible
   families and supplies `FamilyClassConnected`; it is not itself the
   arithmetic proof of the relevant estimates.
2. `Development/AutomorphicArithmetic/PrimitiveCosets/LevelGmLeOnFamilyScales.lean`:
   `tiedCore_of_chainTied` transports the concrete family to `CoreAtH`;
   `level_gm_le_on_family_scales` invokes `windowInequality_of_artinInputs`.
3. `.../PrimitiveCosets/WindowInequalityOfArtinInputs.lean`: `core_gm`
   supplies the fixed-level one-sided estimate
   `Gm(x) <= x^(1/2+(eD+eL+7)*eps)` along the selected family windows.
4. `.../PrimitiveCosets/CoreGm.lean`: the argument uses `ch_top`, `ch_core`,
   `charsA`, `gmA_eq`, and `sigA_le`. The latter needs square-root
   bounds for a fixed finite family of base characters twisted by either
   of the two selected quadratic characters or their product. The three
   quadratic sums alone describe the RH subcase. A fixed QRH gap does not
   directly give such square-root bounds for every fixed character.
   The subsequent reconstruction in
   `work/continuation_20261121/quadratic_selection.tex` proves the needed
   simultaneous selection, conditional on the explicit QRH half-plane
   Re(s)>11/12, using averaging over the auxiliary primes. This supersedes
   the earlier narrower conclusion that this selection remained open.
5. `.../DedekindLFunctions/LandauTheorems/ChTop.lean`: `ch_top` applies
   `each_unit_bound_statement`, then the numerical error bounds. It
   identifies the scalar main term with the actual Dirichlet main term.
6. `.../DedekindLFunctions/LandauTheorems/ChCore.lean`: finite character
   orthogonality averages the pointwise inequality over the subgroup.
   The remaining calculations are explicit weight perturbation and
   large-parameter estimates. This file was read in full.

The fixed-level coefficient extraction in this chain is separate from
constructing the arithmetic family. No change of `a` into a hypothetical
QRH error exponent is legitimate: `a` is the actual height/order scale,
with `a_t/b = x+O(1)`.

## 2. The scalar arithmetic comparison

The relevant complete files read were:

- `Formalism/RankGapBounds/MeanBoundSecondForm.lean`;
- `Formalism/SizeWindowBrackets/QuotientSlopeBoundsWith.lean`;
- `Formalism/SizeWindowBrackets/ChainSlopeWindows/LevelOfCongruence.lean`;
- the definition of `SizeData₂` and adjoining reductions in
  `Formalism/SizeWindowBrackets/SChain.lean`;
- `Formalism/SharpRestriction/GlobalSchurBounds/TieGlobal.lean`;
- `Formalism/SharpRestriction/GlobalTheoremInputs.lean`;
- the relevant definitions and transports in
  `Formalism/SharpRestriction/GlobalSchurBounds/QuadraticLogDerivCongr.lean`;
- the assembly of the eleven conditions in the first part of
  `Formalism/SharpRestriction/GlobalSchurBounds/LossesSmallShares.lean`.

`SizeData₂` contains exactly eleven conditions: the positive-size setting,
the divisor inequality, exponent comparison, variation of map heights,
prime counts, source slope bounds, quotient slope bounds, loss bounds,
the family slope inequality, a bound for the range of slopes, and small
error parameters.

`TieLocal` identifies these scalars with genuine lattice quantities:

| Scalar | Concrete meaning |
|---|---|
| `d u` | rank of the lattice `div.Nu u` |
| `muN`, `muMaxN` | its mean and maximum slopes |
| `muM`, `muMaxM` | corresponding slopes of `(fm u).lat 0` |
| `muCC`, `muMinCC` | mean and minimum slopes of the dual of `div.RR` |
| `h u` | upper bound for the height of the pairing map `div.Bk u` |
| `EeJ` | weighted finite-place divisor contribution at lift `j+1` |
| `T u` | the actual auxiliary prime `(mem u).A.T` |
| `Ga`, `Fo`, `IO` | actual gain, local correction, and loss quantities |

For a fixed subgroup parameter, the essential equations are:

1. `DIV`: target mean slope plus map height minus the local correction is
   bounded by the interpolation main term plus a uniform error.
2. `QuotientSlopeBoundsWith`: the shifted source mean and maximal slopes
   lie between the initial source slopes plus gain and local correction,
   minus the divisor contribution, with explicitly bounded errors.
3. `HComp`, `EComp5`, `Count5`: control the variation and cancel
   `m*sumA*log(g0*g1)` and the archimedean factor `log(v/pi)` exactly.
4. `SlopeIneq`: compares the rank-weighted source mean after subtraction
   of map heights with the target mean. This is where the nearly isotropic
   matrix estimates are used.

The new `central_step.tex` combination lemma proves this scalar reduction
directly. It is not a new existence claim about the arithmetic data.

## 3. Exact remaining divisor and norm assertions

`GlobalTheoremInputs.LinkDIV_at` has nine clauses. In ordinary symbols,
its central inequality is

    mu(R dual) + h_u - F
      <= sum_t [m(a_t log a_t-a_t-a_t log Omega)-a_t log T_u]
         + C |TT| a La + C m(B0+Nc) x^(Cabs eps).

Here `log Omega = EulerGamma+log(pi/v)-L'/L(1)`. The final shape assembly
uses **Cabs = 2**. The exponent is independent of `eps`; the coefficient
and the eventual threshold may depend on the family/eps. A proof with
an uncontrolled exponent depending on the growing number of lifts
would not supply the final theorem.

Its source path is:

- `Development/AutomorphicArithmetic/CharacterBoxes/ShapeWin.lean`:
  builds `BridgeRowsK` with exponent `2`;
- `Formalism/LocalToGlobal/Divisibility/RecBridgeSel.lean`:
  `BridgeRowsK.toT`, `linkDIVt_of_rowsK`, `linkDIVt_closedK`;
- `.../RecBridgeTied.lean` and `.../RecBridgeMkF.lean`: transfer the
  concrete row/column matrices to the divisor package;
- `.../LinkDIVL2R3Rec.lean`: calls `divClausesR_of` with the concrete
  interpolation chain;
- `.../ConstantGeTwentyEight.lean`: `DivInputs0R`, `DivInputsR`,
  `height_chain_atR`, and `divClausesR_of` expose the actual estimates.

The last file was read in full. Its inputs include all of the following:

* A genuine full lattice `Nu`, finite-support valuation shifts, invertible
  archimedean metric matrices, and a positive source rank.
* A chain of rectangular matrices `K_j`, whose product followed by the
  final pairing is the actual bilinear pairing; this is an equality on
  every vector, not a name-based identification.
* An operator norm bound for the final pairing and, at every infinite
  place, `log(cb.sq j v) <= sum_l hn.sz l v`. The theorem `nK_of_cb`
  turns the latter into `||K_j||_op^2 <= exp(sum_l hn.sz l v)`.
* A lower eigenvalue bound `sum hX <= sum l6`.
* Local bases for the relevant lattices, finite support of all Gram
  determinant valuations, and a weighted valuation bound for those
  determinants.
* `borderedMinorImage`: for each lift, a bound for the weighted sum of
  the additional bordered-minor valuations, divided by the base rank.
* `val2`: for **every** lattice vector and every vector of the local
  target lattice, the pairing is zero or its valuation is at least the
  specified real number. This supplies membership in the dual lattice
  after integral rounding of the shift.
* Explicit main-term and error bounds, and the numerical passage
  condition `3*de*Q <= 1` with `Q >= 1`.

`divClausesR_of` then proves dual-lattice membership, a global logarithmic
operator-norm bound, the numerical divisor inequality, and an exact
degree change under the ideal shift. Its generic algebraic combination
was checked, but the full construction of every input above has not been
independently reconstructed in ordinary mathematics.

For a further level of detail,
`Formalism/DivisorInequality/StatementObj.lean` defines `BoundsMu`; and
`.../DivisorInequalityProofs/BaseLevelBoundsWithCovolumeHolds.lean`
proves it using `divisor_bounds_chain_weak`. The theorem explicitly
assumes local determinant identities, quotient metrics, local bases,
the matching localized lattices, and bounds for all local index sums.
The displayed wrapper does not accidentally obtain a small error merely
from integrality or determinant nonvanishing. We did not re-audit all
of the deeper quotient-metric and representation-theoretic inputs.

## 4. Matrix hypotheses and new proof

Relevant files:

- `Formalism/SizeWindowBrackets/TraceSquareAndDiagBounds.lean`;
- `Formalism/SizeWindowBrackets/FrameTraceRatioFinEquiv.lean`;
- `Formalism/SizeWindowBrackets/ChainSlopeWindows/JointDModelAppliesUnitLattice.lean`;
- `Formalism/SharpRestriction/GlobalSchurBounds/TopDensityNGeSixteen.lean`,
  especially `FrameReal_at`, `frame_at_of`, and their family versions.

The concrete complex matrices have the form `A_i = sqrt(gamma_i) B_i`.
The code's `InputSG` requires

    ||A_i* A_j||_HS^2 <= (1+eta0) d_i d_j / Dstar    (i != j),
    ||A_i* A_i-I||_HS^2 <= e0 d_i,
    D <= (1+eta1) Dstar.

The first block of rows of each matrix represents the actual integral
map in invertible complex coordinate changes. The extra rows have a
controlled total relative dimension `delta`. The freedom of the
coordinate changes is not a missing metric hypothesis: the matrix
argument uses only dimensions of images at that embedding; the
arithmetic metrics enter through the global map height and HN
functoriality.

The TeX section proves, without these source wrappers:

1. Existence and needed properties of HN slopes, and map functoriality
   from the exterior-power determinant inequality.
2. A dimension inequality from Hilbert–Schmidt diagonal defects and
   the trace-square bound for `Q = sum_i A_i A_i*`.
3. A slope inequality by integrating the dimensions of the HN
   filtrations. It has coefficient **2** instead of 4 in
   `u log(1+H/u)` and does not require `log(number of words)`.
4. The exact elementary passage from pairwise bounds to a trace-square
   bound, including the restriction from the full matrices to their
   subspaces. If the deleted rank fraction is `theta`, the new diagonal
   defect is at most `e0/(1-theta)` and
   `tr Q >= (1-theta-sqrt(e0))*R_full`. Under the actual source ranges
   `Dstar/R_full <= sigma <= 1/20`, `eta0,eta1,sqrt(e0) <= sigma/2`,
   `theta <= 1/4`, one may take trace error `eta = 7*sigma+4*theta`.
   Thus the trace hypothesis in the new slope theorem is a proved
   consequence of the actual pairwise matrix hypotheses.
5. The scalar cancellation and comparison needed above.

The limiting cases `u=0`, `H=0`, zero individual maps, one-dimensional
lattices, and nonzero extra target dimension are covered in the proof.
All lattices in the stated slope theorem have positive ranks; the
aggregate source rank is positive. Complex coordinate changes need not
be isometries, because they preserve the relevant subspace dimensions.
Any zero-dimensional domains in the matrix restriction lemma can be
discarded. The final comparison proof and compression lemma were
independently read and checked by the QRH review agent; it found no
mathematical defect and suggested the shorter direct trace estimate
used in the final version.

## 5. Counterexamples and status

No counterexample to the actual conditional scalar, divisor-wrapper,
or matrix comparison statements was found in this review.

The explicit unimodular matrices [[1,M],[0,1]] show that even a
determinant equal to one, together with perfect normalization of each
column, does not imply near isotropy. Their exact trace defect tends
to one. This rules out a shortcut in our attempted reconstruction; it
is **not** claimed as an error in the submitted proof.

The independent reconstruction still needs:

- the actual uniform operator-norm and local minor estimates for the
  automorphic interpolation chain;
- the simultaneous nearly isotropic theta estimates and small
  codimension assertions for the same maps;
- the arithmetic source slope and local gain/loss estimates with the
  stated uniform exponents;
- the selected square-root twisted-character sums in the final character
  decomposition, unless the conditional QRH selection theorem in the
  continuation is admitted. That theorem handles the full fixed finite
  family, not only the three-character RH subcase.

The elementary Siegel-zero determinant addresses none of these merely
by being nonzero. It is useful for the conductor-uniform real zero gap
and logarithmic-derivative estimates discussed in `contribution.tex`.

## 6. Read coverage caveat

The complete `PChain.lean` was **not** read: an early bulk command
returned truncated output. Only its initial reductions and explicitly
selected portions were used. Similarly, the much larger
`RecBridgeSel.lean` transport declarations were inspected to locate
their inputs, not certified line by line. All substantive proofs
claimed in `central_step.tex` are displayed there independently of
these unread portions. This note must not be reported as an exhaustive
audit of the whole automorphic construction.
