// Exact reproduction of the finite residue sieve stated after Corollary 2
// of van Dijk, hexagon:2610.00409v2.  This does not by itself prove the
// analytic/determinant upper bound for the discriminant.
// g++ -O2 -std=c++17 check_class_number_sieve.cpp -o check_class_number_sieve
#include <cstdint>
#include <iostream>
#include <vector>

int main() {
  std::vector<int> primes;
  for (int p=3; p<=251; p+=2) {
    bool yes=true;
    for(int j=2; j*j<=p; ++j) if(p%j==0) yes=false;
    if(yes) primes.push_back(p);
  }
  std::vector<std::vector<bool>> inert;
  for(int p:primes) {
    std::vector<bool> nonresidue(p,true);
    for(int a=0;a<p;++a) nonresidue[(a*a)%p]=false;
    inert.push_back(nonresidue);
  }
  auto satisfies=[&](std::int64_t D) {
    for(std::size_t i=0;i<primes.size();++i) {
      int p=primes[i];
      if(4*p<D && !inert[i][(p-D%p)%p]) return false;
    }
    return true;
  };
  std::vector<std::int64_t> answers;
  // Handle the finite small range where the condition 4p<D matters.
  for(std::int64_t D=11;D<=1004;D+=8) if(satisfies(D)) answers.push_back(D);
  // A wheel in k, where D=8k+3, enforces the six primes <=17.
  const std::int64_t modulus=3*5*7*11*13*17;
  std::vector<int> wheel;
  for(int k=0;k<modulus;++k) {
    bool yes=true;
    for(std::size_t i=0;i<6;++i) {
      int p=primes[i];
      if(!inert[i][(p-(8*k+3)%p)%p]) { yes=false; break; }
    }
    if(yes) wheel.push_back(k);
  }
  std::uint64_t candidates=0;
  for(int residue:wheel) {
    for(std::int64_t k=residue;8*k+3<8000000000LL;k+=modulus) {
      std::int64_t D=8*k+3;
      if(D<=1004) continue;
      ++candidates;
      bool yes=true;
      for(std::size_t i=6;i<primes.size();++i) {
        int p=primes[i];
        if(!inert[i][(p-D%p)%p]) { yes=false; break; }
      }
      if(yes) answers.push_back(D);
    }
  }
  std::cout << "{\"range\":\"8<D<8000000000, D=3 mod 8\","
            << "\"odd_primes_tested\":" << primes.size()
            << ",\"wheel_modulus\":" << modulus
            << ",\"wheel_residues\":" << wheel.size()
            << ",\"large_candidates\":" << candidates
            << ",\"survivors\":[";
  for(std::size_t i=0;i<answers.size();++i) {
    if(i)std::cout<<',';
    std::cout<<answers[i];
  }
  std::cout << "]}\n";
  const std::vector<std::int64_t> expected{11,19,43,67,163};
  return answers==expected ? 0 : 1;
}
