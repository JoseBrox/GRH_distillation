#!/usr/bin/env python3
"""Exact rational checks of selected printed constants in Guo and van Dijk."""
from fractions import Fraction as F
from math import isqrt
from pathlib import Path
import json


def log_interval(n):
    b = n.bit_length() - 1
    y = F(n, 2**b)

    def atanh_log(x):
        z = (x-1)/(x+1)
        low = 2*sum((z**(2*j+1)/F(2*j+1) for j in range(12)), F(0))
        high = low + 2*z**25/(25*(1-z*z))
        return low, high

    lo, hi = atanh_log(y)
    l2, h2 = atanh_log(F(2))
    return lo+b*l2, hi+b*h2


def main():
    primes = [p for p in range(2,1001) if all(p%j for j in range(2,isqrt(p)+1))]
    lo = {p: log_interval(p)[0] for p in primes}
    hi = {p: log_interval(p)[1] for p in primes}
    C0 = sum((hi[p]/(p-1) for p in primes if p<=23), F(0))
    Alo = sum((lo[p] for p in primes if 3<=p<=23), F(0))
    Ahi = sum((hi[p] for p in primes if 3<=p<=23), F(0))
    W = sum((p*hi[p] for p in primes if 3<=p<=23), F(0))
    C1 = sum((hi[p]/(p*(p-1)) for p in primes if p>=29), F(0))+4*hi[2]/999
    C2 = sum((hi[p]/p**2 for p in primes if p>=29), F(0))+4*hi[2]/1000
    assert C0 <= F(2906,1000)
    assert Alo >= F(18529,1000) and Ahi <= 20
    assert W <= F(260911,1000)
    assert C1 <= F(37209,10**6) and C2 <= F(36547,10**6)
    loss = (F(3,2)+F(2906,1000)+F(37209,10**6)+9*F(36547,10**6)
            -F(18529,27000)+F(260911,2187000)+F(1,10**6))
    assert loss < F(2103,500)
    assert F(23,108)*F(207,10) > F(439,100)
    assert F(73,270)*(F(287,10)+6)+F(76,10000)+F(4,7) < 10
    assert F(451,60)*F(13,12) > 8
    assert (F(17,70)*(F(621,32)+4)+F(50,10000)
            +(F(17,35)+F(2,49))*F(18,35)) < 6
    assert F(4453,960)*F(35,18) > 8
    result = {
        'method': 'rational upper/lower logarithm series; 12 terms after powers of 2 normalization',
        'van_dijk_bounds_verified': ['C0<=2.906', '18.529<=A<=20', 'W<=260.911',
                                    'C1<=0.037209', 'C2<=0.036547',
                                    'total loss<2103/500', 'final rational contradiction'],
        'guo_bounds_verified': ['equation 5.11 error/logq<10', 'equation 5.15 contradiction',
                               'Appendix A error/logq<6', 'Appendix A final contradiction']}
    Path(__file__).with_name('constant_checks.json').write_text(json.dumps(result,indent=2)+'\n')
    print('All selected rational constant checks passed.')


if __name__ == '__main__':
    main()
