#!/usr/bin/env python3
"""Exact controls for the displayed determinant proof, using only Python integers.

Run: python3 work/siegel_mathematics/check_determinants.py
The general statements are proved in contribution.tex; these finite cases check
normalizations, derivative conventions and row factors independently.
"""
from math import comb, factorial, isqrt
from pathlib import Path
import json


def prime(n):
    return n >= 2 and all(n % j for j in range(2, isqrt(n) + 1))


def run_case(d, R, S):
    zero, one = (0, 0), (1, 0)

    def add(x, y):
        return (x[0] + y[0], x[1] + y[1])

    def neg(x):
        return (-x[0], -x[1])

    def mul(x, y):
        return (x[0]*y[0] + d*x[1]*y[1], x[0]*y[1] + x[1]*y[0])

    def power(x, n):
        z = one
        for _ in range(n):
            z = mul(z, x)
        return z

    def divide_exact(x, y):
        a, b = x
        c, e = y
        denominator = c*c - d*e*e
        assert denominator != 0
        numerators = (a*c - d*b*e, b*c - a*e)
        assert all(n % denominator == 0 for n in numerators)
        return tuple(n // denominator for n in numerators)

    def determinant(mat):
        a = [row[:] for row in mat]
        n, sign, previous = len(a), 1, one
        for k in range(n - 1):
            pivot = next((i for i in range(k, n) if a[i][k] != zero), None)
            if pivot is None:
                return zero
            if pivot != k:
                a[pivot], a[k] = a[k], a[pivot]
                sign *= -1
            p = a[k][k]
            for i in range(k + 1, n):
                for j in range(k + 1, n):
                    numerator = add(mul(p, a[i][j]), neg(mul(a[i][k], a[k][j])))
                    a[i][j] = divide_exact(numerator, previous)
                a[i][k] = zero
            previous = p
        z = a[-1][-1]
        return z if sign == 1 else neg(z)

    assert prime(R) and R > 2 and pow(d % R, (R - 1)//2, R) == R - 1
    # A small square of genuinely quadratic points, distinct modulo R.
    side = isqrt(R) + 1
    points = [(u, v) for v in range(side) for u in range(side)][:R]
    assert len(points) == R and side <= R
    rows = [(r, s) for r in range(R) for s in range(S)]
    columns = [(alpha, j) for alpha in points for j in range(S)]

    def evaluate_derivative(poly, alpha, j):
        z = zero
        beta = (alpha[0], -alpha[1])
        for (r, s), coefficient in poly.items():
            if j <= r:
                coefficient *= factorial(r)//factorial(r-j)
                term = mul(power(alpha, r-j), power(beta, s))
                z = add(z, (coefficient*term[0], coefficient*term[1]))
        return z

    matrix = [[evaluate_derivative({(r, s): 1}, alpha, j)
               for alpha, j in columns] for r, s in rows]
    delta = determinant(matrix)
    norm = delta[0]**2 - d*delta[1]**2
    assert norm != 0 and norm % R != 0
    controls = []
    for p in range(3, R + 3, 2):
        if not prime(p) or pow(d % p, (p - 1)//2, p) != p - 1:
            continue
        changed = []
        E = 0
        for r, s in rows:
            h = min(r//p, S-1-s)
            E += h
            poly = {(r - p*k, s+k): (-1)**k * comb(h, k) for k in range(h+1)}
            assert all(0 <= i < R and 0 <= j < S for i, j in poly)
            row = [evaluate_derivative(poly, alpha, j) for alpha, j in columns]
            assert all(a % (p**h) == 0 and b % (p**h) == 0 for a, b in row)
            changed.append(row)
        assert determinant(changed) == delta
        assert E == sum((S-k)*max(R-k*p, 0) for k in range(1, S))
        assert norm % (p**(2*E)) == 0
        controls.append({'prime': p, 'E_p': E, 'row_factors_checked': len(rows)})
    return {'d': d, 'R': R, 'S': S, 'matrix_dimension': R*S,
            'determinant': list(delta), 'norm': norm,
            'norm_mod_auxiliary_prime': norm % R, 'controls': controls}


def main():
    cases = [run_case(*c) for c in [(-1, 3, 2), (2, 5, 2),
                                  (-2, 5, 3), (-1, 7, 3), (5, 7, 2)]]
    # For F(z,w)=z^3-w, ordinary third derivative = 6, divided third = 1.
    assert factorial(3) % 3 == 0 and (factorial(3)//factorial(3)) % 3 != 0
    # Dropping S<=R fails: F(z,w)=w^R-w over F_R has all z-jets zero
    # at (a,a^R), a in F_R, although F is a nonzero polynomial.
    for R in (3, 5, 7):
        assert all((pow(pow(a, R, R), R, R) - pow(a, R, R)) % R == 0
                   for a in range(R))
    out = {'arithmetic': 'exact integers in Z[sqrt(d)], fraction-free Bareiss',
           'cases': cases,
           'divided_derivative_counterexample': {'p': 3, 'ordinary': 6, 'divided': 1},
           'multiplicity_counterexample': 'S=R+1; F(z,w)=w^R-w over F_R',
           'general_proofs_depend_on_computation': False}
    path = Path(__file__).with_name('determinant_checks.json')
    path.write_text(json.dumps(out, indent=2) + '\n')
    print(f'Passed {len(cases)} exact determinant cases and both negative controls.')


if __name__ == '__main__':
    main()
