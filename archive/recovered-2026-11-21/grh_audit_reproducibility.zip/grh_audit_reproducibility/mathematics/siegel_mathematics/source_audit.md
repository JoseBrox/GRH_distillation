# Siegel-zero source review and integration

## Scope and status

All six user references assigned to this lane were read in full mathematical
content. The original OpenAI PDF, the Guo and Kerr PDFs, Tao's article HTML,
and Pescador's version 3 TeX are saved here. Direct download of the van Dijk
PDF returned HTTP 403; its entire six-page mathematical text was readable
through the web PDF reader. A substantial retrieval including the full
appendix is saved as `vandijk_web_retrieval.json`; no access restriction was
bypassed. `sources.json` records download hashes and versions.

No fatal mathematical flaw was found in these six arguments. This statement
does not claim that every cited theorem in the literature has been reproved.
In particular, the classical analytic theory of Dirichlet L-functions and
Kerr's external Masser estimate are distinct inputs. Our replacement
determinant proof avoids the Masser input completely.

The contribution in `contribution.tex` is eight A4 pages in its standalone
test wrapper, excluding the full source bibliography. It contains standard
mathematical proofs, not Lean. It can be included in the reconstruction after
removing the repeated definition of a Dirichlet character if necessary.

## Source-by-source conclusions

### 4. OpenAI, October 1, 2026 (nine pages)

The exact target is an effective absolute positive lower bound for
`(1-beta) log q` at every real zero of every primitive real nonprincipal
character. It is not a fixed zero-free half-plane.

Read and checked: Lemma 2's nonnegative logarithmic derivative argument;
Lemma 3's supporting-face interpolation argument, including the rational
independence of the kernel vector; the anisotropic degree bounds of
Corollary 4; greedy row selection; and the determinant divisibility of
Lemma 7. The lower triangular row change there is over the number field,
but the transformed entries themselves are divisible in the order. Thus
the absence of an integrality bound for the row-change coefficients is
not a flaw. The exceptional quadratic field Q(sqrt(2)) is explicitly
excluded at the construction and disposed of in the final limiting
argument.

The new writeup replaces the biquadratic construction and supporting-face
interpolation with a quadratic construction and a direct finite-field
root count, retaining the norm and Frobenius mechanisms.

### 5. Guo, arXiv:2610.30476v1 (17 pages)

Theorem 1.1 gives `(1-beta) log q > 1/100` uniformly for q>=3.
Appendix A improves the explicit constant to 1/64, with elementary
positive-block arguments for conductors 3, 4 and 5. Its prime-sum input,
Proposition 3.1, is the explicit but weaker bound
`S_-(x,chi) <= (11/20)log x + (29/60)log q + 6`.

Read and checked: the injective integral-map counting lemma; the
quadratic-factor proof of injectivity modulo the largest inert prime;
the exact triangular basis change; the truncation and floor errors;
the paired tails in Proposition 4.1; the injective `(n,p)->np` comparison
in Lemma 5.1; and the final rational inequalities. The paired-tail
estimate is sound, including its uniformity as beta tends to 1.

The new contribution generalizes Proposition 4.1 from characters to any
bounded sequence with bounded interval sums, for all 0<beta<1. It computes
the exact kernel maximum `beta^(beta/(1-beta))`, rather than replacing it
at once by 1/2. It also gives the full positive-sum comparison proof.
Selected final explicit rational certificates were independently checked
using exact fractions; see `check_constants.py` and `constant_checks.json`.

### 6. Tao, October 19, 2026

Read the entire mathematical article, not just its introduction. The
article is explicitly a sketch. Its injectivity discussion assumes an
auxiliary polynomial irreducible and directs the reader to Green for the
general case. This should not be silently promoted into a complete
injectivity proof. The determinant reconstruction supplied here has no
irreducibility assumption and supplies full nonvanishing directly modulo
an auxiliary prime. The norm also treats both signs of d, instead of
restricting to imaginary quadratic fields.

The exposition contains local slips (for example the informal resultant
row counts), which are avoidable in the replacement proof. These are
not evidence against the core determinant mechanism and are not a fatal
flaw in the claimed number-theoretic result.

### 7. Pescador posting, version 3, October 22, 2026

The theorem is the uniform inert-prime bound
`S_-(X) <= (1/2)log X + (1/4)log q + loglog X + O(1)`.
The corollary gives `(1-beta)log q >= 1-O(loglog q/log q)`.
The version inspected is the current v3 TeX linked from the requested
page, rather than the v2 cited by Guo.

Checked the characteristic-p interpolation lemma, the weighted triangle
`i+ell*j<=D`, the inequalities `J<=I/ell` and `m<=3I/D`, the finite-field
rank argument, the ordinary derivative factors, and the determinant
norm. The triangular basis is preserved for p>ell. The largest inert
prime removes any need for a theorem about spacing of inert primes.

The logarithmic loss discussion concerns its specified determinant
comparison and a family of growing conductors. It is not a theorem that
no different method can remove a loglog term. Our manuscript makes only
the narrower, explicit optimization claim for its own displayed bound.

### 8. van Dijk, hexagon:2610.00409v2 (six pages)

Read Theorem 1, both corollaries, and Appendix A. The rectangular
determinant proof of Theorem 1 is sound. It is the cleanest route among
these six sources for the present purpose. We strengthen its determinant
size estimate by combining the cancellation of the derivative orders
with row-normalized Hadamard, giving `N log N` in place of `2 log(N!)`.
This does not change the final exponent or imply GRH.

The class-number-one corollary is not used in the GRH reconstruction.
Nevertheless its printed finite prime sums and final rational losses
were independently verified with rational upper and lower logarithm
bounds. The finite residue sieve was also reproduced exactly:
among 8<D<8*10^9 and D=3 mod 8, requiring (-D/p)=-1 at each odd prime
p<=251 with 4p<D leaves exactly 11,19,43,67,163. The C++ control uses a
wheel of modulus 255255 and tests 5,641,415 remaining large candidates.
See `check_class_number_sieve.cpp` and `class_number_sieve.json`.
This computation verifies the finite sieve, not the preceding
determinant inequality; the latter is handled mathematically.

### 9. Kerr, arXiv:2610.21099v1 (six pages)

Checked the coefficient count, the Chinese remainder image-size bound,
the asymptotic monomial sums, the weighted-degree comparison, and the
linear algebra giving the invariant mu>=4/3.
Lemma 6 invokes Masser's zero estimate as an external input. We located
the primary bibliographic record but did not obtain its full text here;
our alternative proof avoids relying on this citation.

There is a minor missing exception in the field setup: at the positive
fundamental discriminant q=8, Q(sqrt(q),sqrt(2)) has degree 2, not 4.
Thus the stated four-element integral basis and the indicated separate
automorphisms do not exist in that case. This is readily repaired.
For chi_8 and any real s>0, each block
`(8n+1)^(-s)-(8n+3)^(-s)-(8n+5)^(-s)+(8n+7)^(-s)`
is positive by strict convexity of t^(-s). Summing the convergent
character series proves L(s,chi_8)>0. The finite exceptional conductor
has no real zero and can be removed before constructing the field.
The original OpenAI paper already isolates this exception.

## Exact relation to the Alpoge proof

Inspected source definitions:

- `Formalism/SharpRestriction/InertJacobiLevels/PrimeSupply.lean`:
  `ProgAt`, `QDGood`, `RayAt`.
- `Formalism/SharpRestriction/GlobalSchurBounds/ShortIntervalPrimes.lean`:
  real ray characters, `SiegelZeroExceptionalCharacter`, `Q4`, `TieQ`,
  the good-character counting conditions and `Conclusion2`.
- `Formalism/SharpRestriction/GlobalSchurBounds/GeneralLinearActions/FiltrationCocycleLiftCriterion.lean`:
  `X1=exp(x^(eps/5))`, `X2=exp(x^(eps/5)(log x)^2)`, `GoodFor`, `BoxE`.

Proved simplification: a uniform real-zero gap, together with the
classical zero-free region, gives `|L'/L(1,chi)| << log conductor`
for every real primitive character. The proof compares each nonnegative
zero contribution in the completed-L partial fraction identity at
1 and at `1+1/log q`, so there is no unaccounted Borel--Caratheodory
loglog loss. For the source's auxiliary d, this is o(x^eps), uniformly.
Character avoidance solely to obtain that derivative bound can be removed.

Further conditional simplification: an all-Dirichlet zero-free half-plane
Re s>7/8 makes the source's zero-free clause in `GoodFor(Q,chi)` automatic,
since that clause only excludes zeros with Re s>399/400 and |Im s|<=Q.
The primitivity, reality and conductor inequalities must still be checked.

Limitations: neither result directly yields square-root smoothed-sum
bounds for every fixed character. The subsequent second-moment argument
in `work/continuation_20261121/quadratic_selection.tex` does prove the
actual simultaneous selection of a finite family of twisted characters,
conditional on the stated uniform QRH hypothesis. A theorem only about
Dirichlet characters still does not immediately
eliminate the real Hecke-character exceptional branch over the varying
imaginary quadratic field. No unproved descent is inserted. The original
theta-lift and integral-lattice estimates remain the main unresolved
human reconstruction.

## Negative and exact controls

`check_determinants.py` uses integer pairs in Z[sqrt(d)] and a fraction-free
Bareiss determinant, with exact divisions checked. Five examples, of matrix
dimensions 6,10,15,21,14, verify nonvanishing modulo the auxiliary prime,
every transformed row factor, unchanged determinant, the closed formula for
E_p, and the norm divisibility. The two explicit negative controls are:

1. Divided third derivative of z^3-w is 1, whereas its ordinary third
   derivative is 6. Thus replacing ordinary derivatives by divided
   derivatives destroys the required divisibility at the small prime 3.
2. If the interpolation restriction S<=R is omitted, over F_R the
   nonzero polynomial F(z,w)=w^R-w has all ordinary z-derivatives zero at
   every (a,a^R), a in F_R, and lies in the rectangle with S=R+1.

These are counterexamples to tempting altered intermediate statements,
not counterexamples to the hypotheses used in the reviewed papers.
