import Formalism.LocalToGlobal.NumberFieldFamilies.OwnStruct

/- Negative control created for this audit, not part of the submitted archive.
   It deliberately supplies a proof of True to a False goal through the
   archive's unchecked tactic assignment. A sound final kernel rejects it. -/
theorem audit_invalid_assignment : False := by
  kcopy True.intro
