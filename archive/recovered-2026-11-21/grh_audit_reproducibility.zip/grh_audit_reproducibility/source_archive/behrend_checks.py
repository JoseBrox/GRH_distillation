#!/usr/bin/env python3
"""Independent exact finite checks of statements in Formalism/BehrendSets.
No Lean code is executed. All arithmetic in decisive checks is integral or rational.
These bounded checks do not prove the universally quantified statements.
"""
from fractions import Fraction as Q
from itertools import combinations, product
from math import gcd
import json

counts={"order_iff":0,"order_large":0,"order_d":0,"window_two":0,"orbit_one":0,"tops_bad_split":0,"tops_bad":0,"select":0}

def insist(ok, where):
    if not ok: raise AssertionError(where)

def add_order(h,n): return n//gcd(h,n)

def order_pm(l,n):
    x=l%n;d=1
    while x not in (1,n-1):
        x=x*l%n;d+=1
    return d

def free(K,S):
    # Distinct x's suffice: a nontrivial equality with two equal entries and
    # all three nonzero coefficients would force the third entry equal too.
    for x,y,z in combinations(S,3):
        a=y-x;b=z-y;g=gcd(a,b)
        # Primitive coefficients for b*x -(a+b)*y+a*z=0 have max (a+b)/g.
        if (a+b)//g<=K:return False
    return True

for s in range(10):
    n=2**(s+2)
    for l in range(1,2001,2):
        d=order_pm(l,n)
        for j in range(s+5):
            m=2**max(s+2-j,0)
            rhs=(l-1)%m==0 or (l+1)%m==0
            insist((d<=2**j)==rhs,("OrdIff",s,l,j,d))
            insist((2**j%d==0)==rhs,("OrdDvd",s,l,j,d))
            counts['order_iff']+=1
        if l>=2:
            insist(n<=d*(l+1),("OrdLargeJ-minimal-J",s,l,d))
            counts['order_large']+=1
        if l%16==7:
            insist(d==2**max(s-1,0),("OrdD",s,l,d))
            counts['order_d']+=1

for n in range(1,65):
    for L in range(7):
        if L==0:
            # Window is empty; OrbitOne hypotheses would require order <= 0.
            continue
        allowed=list(range((n-1)//(8*L)+1))
        for mask in range(1<<len(allowed)):
            S=tuple(x for x in allowed if mask>>x&1)
            SF=free(2*L,S)
            SS=set(S)
            for h in range(n):
                d=add_order(h,n)
                if d<=8*L:
                    # Subgroups of Z/n: two points are in the same h-orbit
                    # iff congruent modulo gcd(h,n). Translating S is irrelevant.
                    g=gcd(h,n)
                    insist(len({x%g for x in S})==len(S),("OrbitOne",n,L,S,h))
                    counts['orbit_one']+=1
                if SF and d>2*L:
                    # j and u can be absorbed into t0, so all t0 modulo n
                    # suffice to check all translated windows.
                    for t in range(n):
                        hit=sum((t+i*h)%n in SS for i in range(2*L))
                        insist(hit<=2,("WindowTwo",n,L,S,h,t))
                        counts['window_two']+=1

for n in range(1,5):
    subs=list(range(1<<n)); allmask=(1<<n)-1
    families=[()]+[(W,) for W in subs]+list(combinations(subs,2))
    if n<=3:families=list(tuple(W for W in subs if F>>W&1) for F in range(1<<len(subs)))
    for delta in [Q(0),Q(1,4),Q(1,2),Q(3,4),Q(1)]:
        weights=[delta**T.bit_count()*(1-delta)**(n-T.bit_count()) for T in subs]
        insist(sum(weights)==1,("total",n,delta))
        for Ws in families:
            L=max([W.bit_count() for W in Ws]+[0])
            for t in range(n):
                inside=sum((W>>t)&1 for W in Ws)
                outside=len(Ws)-inside
                for K in range(n+1):
                    prob=sum((weights[T] for T in subs if (T>>t)&1 and any((T&W).bit_count()>=K+1 for W in Ws)),Q(0))
                    bound=delta*(inside*(L*delta)**K+outside*(L*delta)**(K+1))
                    insist(prob<=bound,("TopsBadSplit",n,delta,L,K,t,Ws,prob,bound))
                    counts['tops_bad_split']+=1
                    if L*delta<=1:
                        b=delta*len(Ws)*(L*delta)**K
                        insist(prob<=b,("TopsBad",n,delta,L,K,t,Ws,prob,b))
                        counts['tops_bad']+=1

for n in range(3):
    subs=list(range(1<<n))
    for delta in [Q(0),Q(1,4),Q(1,2),Q(3,4),Q(1)]:
        weights=[delta**T.bit_count()*(1-delta)**(n-T.bit_count()) for T in subs]
        for lam in [Q(1,4),Q(1,2),Q(1),Q(2),Q(3)]:
            if not 2*n*delta*(1-delta)<lam**2:continue
            for Y in product(range(3),repeat=len(subs)):
                ey=sum((weights[T]*Y[T] for T in subs),Q(0))
                insist(any(abs(Q(T.bit_count())-delta*n)<=lam and Y[T]<=2*ey for T in subs),("Select",n,delta,lam,Y))
                counts['select']+=1
print(json.dumps({"status":"all tested cases satisfy the statements","counts":counts},indent=2))
