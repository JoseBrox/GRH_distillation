#!/usr/bin/env python3
"""Retrieve exactly the audited source version, verify it, and safely extract it.

Requires Python 3.12+ and curl. Uses only the Python standard library.
Nothing from the downloaded archive is executed. No Lean packages are fetched.
"""
from __future__ import annotations

import argparse
import datetime
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import shutil
import subprocess
import sys
import tarfile
import tempfile

BASE_URL = "https://alpo.ge/"
PARTS = [f"lean.tar.gz.part{i:02d}" for i in range(1, 15)]
DOWNLOADS = ["remark.pdf", *PARTS]
COMBINED = "lean.tar.gz"
EXPECTED_REGULAR_FILES = 175190
EXPECTED_REGULAR_BYTES = 1030536719


def file_digest(path: Path) -> dict:
    h = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        while block := stream.read(1024 * 1024):
            size += len(block)
            h.update(block)
    return {"bytes": size, "sha256": h.hexdigest()}


def load_manifest(path: Path) -> dict:
    manifest = json.loads(path.read_text(encoding="utf-8"))
    expected_names = set(DOWNLOADS + [COMBINED])
    if set(manifest) != expected_names:
        raise ValueError("The manifest must contain the PDF, all 14 parts, and their combined archive.")
    for name, record in manifest.items():
        if not isinstance(record, dict) or not isinstance(record.get("bytes"), int):
            raise ValueError(f"Invalid manifest record: {name}")
        if record["bytes"] <= 0 or not re.fullmatch(r"[0-9a-f]{64}", record.get("sha256", "")):
            raise ValueError(f"Invalid size or SHA-256: {name}")
    if sum(manifest[name]["bytes"] for name in PARTS) != manifest[COMBINED]["bytes"]:
        raise ValueError("Part sizes do not add up to the combined archive size.")
    return manifest


def verify(path: Path, expected: dict) -> dict:
    if path.is_symlink() or not path.is_file():
        raise ValueError(f"Expected an ordinary local file: {path}")
    observed = file_digest(path)
    if observed != expected:
        raise ValueError(f"Size or SHA-256 mismatch for {path.name}: {observed}; expected {expected}")
    return observed


def fetch(name: str, destination: Path, expected: dict) -> dict:
    target = destination / name
    if target.exists() or target.is_symlink():
        return verify(target, expected)
    if shutil.which("curl") is None:
        raise RuntimeError("curl is required for downloading missing files.")
    with tempfile.NamedTemporaryFile(prefix=name + ".", suffix=".download",
                                     dir=destination, delete=False) as stream:
        temporary = Path(stream.name)
    try:
        subprocess.run([
            "curl", "--fail", "--location", "--silent", "--show-error",
            "--proto", "=https", "--proto-redir", "=https",
            "--connect-timeout", "30", "--max-time", "600",
            "--retry", "3", "--retry-delay", "5",
            "--output", str(temporary), BASE_URL + name
        ], check=True)
        observed = verify(temporary, expected)
        if target.exists() or target.is_symlink():
            raise FileExistsError(f"Destination appeared during download: {target}")
        temporary.rename(target)
        return observed
    finally:
        temporary.unlink(missing_ok=True)


def combine_parts(destination: Path, manifest: dict) -> dict:
    target = destination / COMBINED
    if target.exists() or target.is_symlink():
        return verify(target, manifest[COMBINED])
    with tempfile.NamedTemporaryFile(prefix=COMBINED + ".", suffix=".combined",
                                     dir=destination, delete=False) as output:
        temporary = Path(output.name)
        try:
            for name in PARTS:
                with (destination / name).open("rb") as source:
                    shutil.copyfileobj(source, output, length=1024 * 1024)
        except BaseException:
            temporary.unlink(missing_ok=True)
            raise
    try:
        observed = verify(temporary, manifest[COMBINED])
        if target.exists() or target.is_symlink():
            raise FileExistsError(f"Destination appeared during concatenation: {target}")
        temporary.rename(target)
        return observed
    finally:
        temporary.unlink(missing_ok=True)


def safe_extract(archive: Path, destination: Path, *,
                 expected_regular_files: int | None = None,
                 expected_regular_bytes: int | None = None) -> dict:
    """Extract only ordinary files/directories beneath a new destination/lean.

    Validate the whole member list before writing. Reject links, special files,
    absolute names, '..' components, backslashes, duplicate normalized paths,
    and files used as parent directories. Also apply Python's data filter.
    The temporary extraction directory is removed if validation/extraction fails.
    """
    if sys.version_info < (3, 12):
        raise RuntimeError("Safe extraction requires Python 3.12 or newer.")
    destination = destination.resolve()
    destination.mkdir(parents=True, exist_ok=True)
    final = destination / "lean"
    if final.exists() or final.is_symlink():
        raise FileExistsError(f"Refusing to merge with an existing tree: {final}")
    with tarfile.open(archive, "r:gz") as source:
        members = source.getmembers()
        if len(members) > 200000:
            raise ValueError("Archive exceeds the member-count limit.")
        paths = set()
        ordinary_files = set()
        regular_bytes = 0
        for member in members:
            if member.type not in (tarfile.REGTYPE, tarfile.AREGTYPE, tarfile.DIRTYPE):
                raise ValueError(f"Links and special archive entries are forbidden: {member.name}")
            if "\x00" in member.name or "\\" in member.name:
                raise ValueError(f"Forbidden archive path: {member.name!r}")
            path = PurePosixPath(member.name)
            if path.is_absolute() or not path.parts or ".." in path.parts or path.parts[0] != "lean":
                raise ValueError(f"Archive path escapes the lean tree: {member.name!r}")
            if path in paths:
                raise ValueError(f"Duplicate normalized archive path: {member.name}")
            paths.add(path)
            if member.isfile():
                if member.size < 0:
                    raise ValueError("Negative archive member size.")
                ordinary_files.add(path)
                regular_bytes += member.size
                if regular_bytes > 2_000_000_000:
                    raise ValueError("Archive exceeds the uncompressed-size limit.")
        for path in paths:
            if any(parent in ordinary_files for parent in path.parents):
                raise ValueError(f"A regular file is used as a parent directory: {path}")
        if expected_regular_files is not None and len(ordinary_files) != expected_regular_files:
            raise ValueError("Unexpected regular-file count.")
        if expected_regular_bytes is not None and regular_bytes != expected_regular_bytes:
            raise ValueError("Unexpected total regular-file size.")
        with tempfile.TemporaryDirectory(prefix=".extract-", dir=destination) as temporary:
            stage = Path(temporary)
            source.extractall(path=stage, members=members, filter="data")
            if not (stage / "lean").is_dir():
                raise ValueError("Archive did not produce a lean directory.")
            if final.exists() or final.is_symlink():
                raise FileExistsError(f"Destination appeared during extraction: {final}")
            (stage / "lean").rename(final)
    return {"regular_files": len(ordinary_files), "regular_bytes": regular_bytes,
            "source_directory": str(final / "src")}


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--destination", type=Path, default=Path("sources"))
    parser.add_argument("--manifest", type=Path, default=Path(__file__).with_name("sha256.json"))
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument("--download-only", action="store_true",
                      help="Download, concatenate, and verify, but do not extract.")
    mode.add_argument("--verify-only", action="store_true",
                      help="Verify existing files only; no downloads, writes, or extraction.")
    args = parser.parse_args()
    if sys.version_info < (3, 12):
        parser.error("Python 3.12+ is required.")
    manifest = load_manifest(args.manifest)
    destination = args.destination.resolve()
    if args.verify_only:
        observations = {name: verify(destination / name, manifest[name])
                        for name in DOWNLOADS + [COMBINED]}
        print(json.dumps({"verified_files": observations, "extracted": False}, indent=2))
        return
    destination.mkdir(parents=True, exist_ok=True)
    if not args.download_only and ((destination / "lean").exists() or (destination / "lean").is_symlink()):
        raise FileExistsError("The lean tree already exists; use --verify-only, --download-only, or a new destination.")
    observations = {}
    for name in DOWNLOADS:
        print(f"Obtaining and verifying {name}", flush=True)
        observations[name] = fetch(name, destination, manifest[name])
    observations[COMBINED] = combine_parts(destination, manifest)
    extraction = None
    if not args.download_only:
        extraction = safe_extract(
            destination / COMBINED, destination,
            expected_regular_files=EXPECTED_REGULAR_FILES,
            expected_regular_bytes=EXPECTED_REGULAR_BYTES)
    result = {
        "verified_at_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
        "verified_files": observations, "extraction": extraction,
        "lean_executed": False
    }
    (destination / "download_verification.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"verified_file_count": len(observations), "extraction": extraction}, indent=2))


if __name__ == "__main__":
    main()
