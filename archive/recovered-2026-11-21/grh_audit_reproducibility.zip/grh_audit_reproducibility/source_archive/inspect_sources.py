#!/usr/bin/env python3
"""Repeat the audit's line-based import inventory and lexical source scans.

This is NOT a Lean parser, a proof checker, a semantic audit, or a kernel replay.
No source code is executed. The source root is lean/src, not the .lake directory.
"""
from __future__ import annotations

import argparse
from collections import Counter, defaultdict, deque
import hashlib
import json
from pathlib import Path
import re
import sys

# The inspected archive uses ordinary, unindented "import Module.Name" lines.
# Keep the original audit's simple line-based approach; flag unsupported lines.
IMPORT_LINE = re.compile(r"^import[ \t]+([^\r\n]+)", re.MULTILINE)
EXTERNAL_ROOTS = {
    "Init", "Lean", "Std", "Lake", "Mathlib", "Batteries", "Aesop", "Qq",
    "ProofWidgets", "ImportGraph", "LeanSearchClient", "Plausible", "Cli"
}
TRUST_WORDS = [
    "axiom", "sorry", "admit", "sorryAx", "mkSorry", "native_decide",
    "unsafe", "unsafeCast", "skipKernelTC", "trustLevel",
    "addDeclWithoutChecking", "ofKernelEnv", "extern", "implemented_by",
    "trustCompiler", "reduceBool", "reduceNat", "addDecl", "addDeclCore",
    "addConst", "addConstAsync", "setEnv", "modifyEnv", "run_cmd", "run_tac",
    "eval_expr", "run_elab", "by_elab", "elab", "macro", "elab_rules", "macro_rules"
]
TRUST_PATTERN = re.compile(r"\b(?:" + "|".join(map(re.escape, TRUST_WORDS)) + r")\b|\.assign\b")
ADMISSION_OR_BYPASS_WORDS = TRUST_WORDS[:17]


def find_cycle(nodes: set[str], graph: dict[str, list[str]]) -> list[str]:
    """Give a directed cycle witness, if one exists, without Python recursion."""
    color = {}
    parent = {}
    for start in sorted(nodes):
        if color.get(start):
            continue
        color[start] = 1
        stack = [(start, iter(v for v in graph[start] if v in nodes))]
        while stack:
            u, children = stack[-1]
            try:
                v = next(children)
            except StopIteration:
                color[u] = 2
                stack.pop()
                continue
            if color.get(v, 0) == 0:
                parent[v] = u
                color[v] = 1
                stack.append((v, iter(w for w in graph[v] if w in nodes)))
            elif color[v] == 1:
                path = [u]
                while path[-1] != v:
                    path.append(parent[path[-1]])
                path.reverse()
                return path + [v]
    return []


def inspect(root: Path, index_path: Path, reference_graph: Path | None = None) -> tuple[dict, list]:
    root = root.resolve()
    if not root.is_dir():
        raise FileNotFoundError(root)
    expected = {}
    if index_path.exists():
        for section in json.loads(index_path.read_text(encoding="utf-8")):
            for record in section["files"]:
                expected[record["path"]] = record
    graph = {}
    hits = []
    marker_counts = Counter({word: 0 for word in TRUST_WORDS})
    marker_counts[".assign"] = 0
    unsupported = []
    index_checked = set()
    index_mismatches = []
    total_bytes = total_lines = 0
    for source in sorted(root.rglob("*.lean")):
        if source.is_symlink():
            raise ValueError(f"Source inventory refuses symlinks: {source}")
        relative = source.relative_to(root)
        relative_name = relative.as_posix()
        module = ".".join(relative.with_suffix("").parts)
        data = source.read_bytes()
        total_bytes += len(data)
        total_lines += data.count(b"\n")
        text = data.decode("utf-8")
        imports = []
        for match in IMPORT_LINE.finditer(text):
            tail = match.group(1).partition("--")[0].strip()
            names = tail.split()
            # Keep Unicode module names literally, as in the original inventory.
            # This text inventory does not attempt Lean identifier validation.
            if not names:
                unsupported.append({"path": relative_name,
                                    "line": text.count("\n", 0, match.start()) + 1,
                                    "text": match.group(0)})
            else:
                imports.extend(names)
        # Other import forms are not silently treated as parsed.
        for match in re.finditer(r"^(?:[ \t]+import\b|(?:public|private|meta)[ \t]+import\b)", text, re.MULTILINE):
            start = match.start()
            end = text.find("\n", start)
            unsupported.append({"path": relative_name, "line": text.count("\n", 0, start) + 1,
                                "text": text[start:end if end >= 0 else len(text)]})
        graph[module] = imports
        for match in TRUST_PATTERN.finditer(text):
            word = match.group(0)
            marker_counts[word] += 1
            start = text.rfind("\n", 0, match.start()) + 1
            end = text.find("\n", match.end())
            hits.append({"marker": word, "path": relative_name,
                         "line": text.count("\n", 0, match.start()) + 1,
                         "text": text[start:end if end >= 0 else len(text)]})
        if relative_name in expected:
            index_checked.add(relative_name)
            record = expected[relative_name]
            observed = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
            if observed != {"bytes": record["bytes"], "sha256": record["sha256"]}:
                index_mismatches.append({"path": relative_name, "observed": observed, "expected": record})
        if len(graph) % 25000 == 0:
            print(f"Inspected {len(graph):,} source files", file=sys.stderr, flush=True)

    local = {u: [v for v in imports if v in graph] for u, imports in graph.items()}
    external = sorted({v for imports in graph.values() for v in imports if v not in graph})
    missing = [v for v in external if v.partition(".")[0] not in EXTERNAL_ROOTS]
    reachable = set()
    todo = ["Main"]
    while todo:
        u = todo.pop()
        if u in reachable or u not in local:
            continue
        reachable.add(u)
        todo.extend(local[u])
    reverse = defaultdict(list)
    remaining = {u: len(vs) for u, vs in local.items()}
    for u, imports in local.items():
        for v in imports:
            reverse[v].append(u)
    queue = deque(u for u in local if remaining[u] == 0)
    depth = {u: 1 for u in queue}
    processed = 0
    while queue:
        u = queue.popleft()
        processed += 1
        for v in reverse[u]:
            depth[v] = max(depth.get(v, 1), depth[u] + 1)
            remaining[v] -= 1
            if remaining[v] == 0:
                queue.append(v)
    blocked = {u for u, count in remaining.items() if count}
    result = {
        "method": "Raw UTF-8 text inventory, anchored ordinary-import lines, graph traversal, and lexical regular expressions.",
        "limitations": [
            "No Lean code is executed; this is not elaboration, kernel verification, or a semantic proof audit.",
            "Imports and trust markers are scanned as text, including text in comments or strings.",
            "Whitespace-separated import tokens are retained literally, including Unicode identifiers; their Lean grammar is not validated.",
            "Module import reachability is not theorem proof-term dependency reachability.",
            "Zero admission-marker hits do not certify absence of axioms or kernel bypasses.",
            "Missing-local-import classification uses the explicitly listed external package roots."
        ],
        "source_root": str(root),
        "lean_files": len(graph),
        "lean_bytes": total_bytes,
        "newline_count": total_lines,
        "total_import_occurrences": sum(map(len, graph.values())),
        "local_import_occurrences": sum(map(len, local.values())),
        "external_package_roots_allowed": sorted(EXTERNAL_ROOTS),
        "imports_outside_local_tree": external,
        "missing_local_import_candidates": missing,
        "unsupported_import_lines": unsupported,
        "main_exists": "Main" in graph,
        "main_reachable_local_modules": len(reachable),
        "unreachable_local_modules": sorted(set(graph) - reachable),
        "main_reachable_names_sha256": hashlib.sha256(("\n".join(sorted(reachable)) + "\n").encode()).hexdigest(),
        "acyclic": processed == len(graph),
        "cycle_witness": find_cycle(blocked, local) if blocked else [],
        "cycle_or_cycle_dependent_modules": len(blocked),
        "main_import_depth_including_main": depth.get("Main") if not blocked else None,
        "lexical_marker_counts": dict(sorted(marker_counts.items())),
        "admission_or_bypass_word_hits": sum(marker_counts[word] for word in ADMISSION_OR_BYPASS_WORDS),
        "lexical_hit_count": len(hits),
        "source_index": {
            "manifest": str(index_path.resolve()),
            "unique_indexed_files": len(expected),
            "checked_files": len(index_checked),
            "missing_indexed_files": sorted(set(expected) - index_checked),
            "hash_or_size_mismatches": index_mismatches
        }
    }
    if reference_graph is not None:
        reference = json.loads(reference_graph.read_text(encoding="utf-8"))
        differing = sorted(u for u in set(graph) | set(reference) if graph.get(u) != reference.get(u))
        result["comparison_with_original_audit_import_graph"] = {
            "equal": not differing, "differing_modules": differing,
            "reference_module_count": len(reference)
        }
    return result, hits


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source_root", type=Path)
    parser.add_argument("--source-index", type=Path, default=Path(__file__).with_name("source_index.json"))
    parser.add_argument("--output", type=Path, default=Path("inspection_result.json"))
    parser.add_argument("--hits", type=Path, default=Path("lexical_hits.json"))
    parser.add_argument("--reference-graph", type=Path,
                        help="Optional original audit graph for comparing this inventory; not required.")
    args = parser.parse_args()
    result, hits = inspect(args.source_root, args.source_index, args.reference_graph)
    args.output.write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    args.hits.write_text(json.dumps(hits, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in [
        "lean_files", "lean_bytes", "newline_count", "main_reachable_local_modules",
        "acyclic", "main_import_depth_including_main", "admission_or_bypass_word_hits",
        "lexical_hit_count"
    ]}, indent=2))
    print("Static inspection only: no endpoint proof certificate was produced.")


if __name__ == "__main__":
    main()
