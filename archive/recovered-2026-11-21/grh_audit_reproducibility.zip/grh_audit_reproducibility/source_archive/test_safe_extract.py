#!/usr/bin/env python3
"""Tiny artificial-tar checks; no network access or original archive extraction."""
import io
import json
from pathlib import Path
import sys
import tarfile
import tempfile

sys.dont_write_bytecode = True
from download_sources import safe_extract


def entry(name, kind=tarfile.REGTYPE, linkname=""):
    item = tarfile.TarInfo(name)
    item.type = kind
    item.linkname = linkname
    content = b"-- harmless test input\n" if kind == tarfile.REGTYPE else b""
    item.size = len(content)
    return item, content


cases = {
    "ordinary_file": ([entry("lean/src/Test.lean")], False),
    "directory_and_file": ([entry("lean", tarfile.DIRTYPE), entry("lean/src/Test.lean")], False),
    "parent_traversal": ([entry("lean/../../escape")], True),
    "absolute_path": ([entry("/lean/escape")], True),
    "symbolic_link": ([entry("lean/link", tarfile.SYMTYPE, "../escape")], True),
    "hard_link": ([entry("lean/link", tarfile.LNKTYPE, "lean/target")], True),
    "fifo": ([entry("lean/pipe", tarfile.FIFOTYPE)], True),
    "character_device": ([entry("lean/device", tarfile.CHRTYPE)], True),
    "duplicate_path": ([entry("lean/src/Test.lean"), entry("lean/src/Test.lean")], True),
    "file_as_parent": ([entry("lean/src"), entry("lean/src/Test.lean")], True),
}
outcomes = {}
with tempfile.TemporaryDirectory(prefix="grh-extraction-test-") as temporary:
    root = Path(temporary)
    for name, (members, must_reject) in cases.items():
        archive = root / (name + ".tar.gz")
        destination = root / name
        with tarfile.open(archive, "w:gz") as output:
            for member, data in members:
                output.addfile(member, io.BytesIO(data) if data else None)
        rejected = False
        try:
            safe_extract(archive, destination)
        except (ValueError, tarfile.FilterError):
            rejected = True
        assert rejected == must_reject, (name, rejected, must_reject)
        if must_reject:
            assert not (destination / "lean").exists()
        else:
            assert (destination / "lean/src/Test.lean").read_bytes() == b"-- harmless test input\n"
        outcomes[name] = "rejected as required" if rejected else "extracted ordinary file"
print(json.dumps({"status": "all tiny extraction tests passed", "cases": outcomes}, indent=2))
