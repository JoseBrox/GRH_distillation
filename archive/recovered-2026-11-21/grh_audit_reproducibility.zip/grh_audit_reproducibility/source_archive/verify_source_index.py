#!/usr/bin/env python3
"""Check only the selected-file index, without rescanning the full source tree."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path, PurePosixPath


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source_root", type=Path)
    parser.add_argument("--index", type=Path, default=Path(__file__).with_name("source_index.json"))
    parser.add_argument("--output", type=Path, default=Path("source_index_verification.json"))
    args = parser.parse_args()
    root = args.source_root.resolve()
    manifest_data = args.index.read_bytes()
    expected = {}
    for section in json.loads(manifest_data):
        for record in section["files"]:
            name = record["path"]
            path = PurePosixPath(name)
            if path.is_absolute() or ".." in path.parts or "\\" in name:
                raise ValueError(f"Invalid source index path: {name}")
            if name in expected and expected[name] != record:
                raise ValueError(f"Conflicting index entries: {name}")
            expected[name] = record
    checked = []
    missing = []
    mismatches = []
    for name, record in sorted(expected.items()):
        path = root / name
        if not path.resolve().is_relative_to(root) or path.is_symlink():
            raise ValueError(f"Path escapes source tree or is a symbolic link: {name}")
        if not path.is_file():
            missing.append(name)
            continue
        data = path.read_bytes()
        observed = {"bytes": len(data), "sha256": hashlib.sha256(data).hexdigest()}
        checked.append({"path": name, **observed})
        if observed != {"bytes": record["bytes"], "sha256": record["sha256"]}:
            mismatches.append({"path": name, "observed": observed, "expected": record})
    result = {
        "checked_at_utc": datetime.now(timezone.utc).isoformat(),
        "method": "Independent size and SHA-256 checks of the final selected-file index only.",
        "source_root": str(root),
        "source_index_sha256": hashlib.sha256(manifest_data).hexdigest(),
        "unique_indexed_files": len(expected),
        "checked_files": len(checked),
        "missing_indexed_files": missing,
        "hash_or_size_mismatches": mismatches,
        "checked": checked,
        "status": "all indexed files match" if not missing and not mismatches else "verification failed"
    }
    args.output.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({key: result[key] for key in [
        "status", "unique_indexed_files", "checked_files", "source_index_sha256"
    ]}, indent=2))
    if missing or mismatches:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
